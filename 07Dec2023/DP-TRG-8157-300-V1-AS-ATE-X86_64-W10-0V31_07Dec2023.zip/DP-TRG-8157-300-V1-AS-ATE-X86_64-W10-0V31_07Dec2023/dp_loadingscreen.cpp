#include "dp_loadingscreen.h"
#include "ui_dp_loadingscreen.h"

CLoadingScreen::CLoadingScreen(QWidget *parent) :
	QDialog(parent),
	ui(new Ui::CLoadingScreen)
{
	ui->setupUi(this);

    setWindowFlags (Qt::SplashScreen | Qt::FramelessWindowHint);
    setModal(true);
    setFixedSize (100, 100);
    setAttribute(Qt::WA_TranslucentBackground);

    movieLoading = new QMovie (this);
    movieLoading->setFileName (":/images/images/loading_gif.gif");
    movieLoading->setScaledSize (QSize(75, 75));
    ui->lbGIFAnimation->setMovie (movieLoading);
}

CLoadingScreen::~CLoadingScreen()
{
    delete ui;
}

void CLoadingScreen::Start()
{
    movieLoading->start();
    this->show();
}

void CLoadingScreen::Stop()
{
    movieLoading->stop();
    this->close();
}
