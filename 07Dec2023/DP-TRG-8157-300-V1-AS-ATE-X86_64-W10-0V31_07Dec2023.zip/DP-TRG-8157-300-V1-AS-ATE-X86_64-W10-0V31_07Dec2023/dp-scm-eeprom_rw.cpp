#include "dp-scm-eeprom_rw.h"

CEEPROM_RW::CEEPROM_RW(QObject *parent) : QObject(parent)
{

}

int CEEPROM_RW::EEPROM_Write(unsigned short in_usAddress, unsigned char in_ucData)
{
	int iRetVal = 0;
	unsigned int uiTimeout_ms = 0;
	unsigned short usTxDataSize = 0;
	S_EEPROM_RW SWriteData;

	memset(&SWriteData, 0, sizeof(S_EEPROM_RW));

	SWriteData.m_usAddress = in_usAddress;
	SWriteData.m_ucData    = in_ucData;

	uiTimeout_ms = 200;
	usTxDataSize = sizeof(S_EEPROM_RW);

	iRetVal = sig_UART_WriteRead (DP_SCM_EEPROM_WR_CMD, (char*)&SWriteData, usTxDataSize, NULL, 0, uiTimeout_ms);
	return iRetVal;
}

int CEEPROM_RW::EEPROM_Read(unsigned short in_usAddress, unsigned char *out_pucData)
{
	int iRetVal = 0;
	unsigned int uiTimeout_ms = 0;
	unsigned short usTxDataSize = 0;
	unsigned short usRxDataSize = 0;

	uiTimeout_ms = 200;
	usRxDataSize = sizeof(unsigned char);

	iRetVal = sig_UART_WriteRead (DP_SCM_EEPROM_BRD_INFO_RD_CMD, (char*)&in_usAddress, usTxDataSize, (char*)out_pucData, usRxDataSize, uiTimeout_ms);
	return iRetVal;
}

int CEEPROM_RW::EEPROM_WriteBoardInfo(unsigned short in_usSerialNo, unsigned short in_usBoardId)
{
	int iRetVal = 0;
	unsigned int uiTimeout_ms = 0;
	unsigned short usTxDataSize = 0;
	S_BOARD_INFO S_BoardInfo;

	memset(&S_BoardInfo, 0, sizeof(S_BOARD_INFO));

	S_BoardInfo.m_usSerialNumber = in_usSerialNo;
	S_BoardInfo.m_usBoardID      = in_usBoardId;

	uiTimeout_ms = 200;
	usTxDataSize = sizeof(S_BOARD_INFO);

	iRetVal = sig_UART_WriteRead (DP_SCM_EEPROM_BRD_INFO_WR_CMD, (char*)&S_BoardInfo, usTxDataSize, NULL, 0, uiTimeout_ms);
	return iRetVal;
}

int CEEPROM_RW::EEPROM_ReadBoardInfo(unsigned short *out_usSerialNo, unsigned short *out_usBoardId)
{
	int iRetVal = 0;
	unsigned int uiTimeout_ms = 0;
	unsigned short usRxDataSize = 0;
	S_BOARD_INFO S_BoardInfo;
	QString qsSNo = "", qsBrdID = "";

	memset(&S_BoardInfo, 0, sizeof(S_BOARD_INFO));

	uiTimeout_ms = 200;
	usRxDataSize = sizeof(S_BOARD_INFO);

	iRetVal = sig_UART_WriteRead (DP_SCM_EEPROM_BRD_INFO_RD_CMD, NULL, 0, (char*)&S_BoardInfo, usRxDataSize, uiTimeout_ms);
	if(iRetVal == DPSCM_SUCCESS)
	{
		*out_usSerialNo = S_BoardInfo.m_usSerialNumber;
		*out_usBoardId = S_BoardInfo.m_usBoardID;
	}

	return iRetVal;
}

int CEEPROM_RW::EEPROM_ReadChecksum(unsigned char *out_pucCalcChecksum, unsigned char *out_pucReadChecksum)
{
	int iRetVal = 0;
	unsigned int uiTimeout_ms = 0;
	unsigned short usRxDataSize = 0;
	S_EEPROM_CHECKSUM s_CksmData;
	memset(&s_CksmData, 0, sizeof(S_EEPROM_CHECKSUM));

	uiTimeout_ms = 200;
	usRxDataSize = sizeof(S_EEPROM_CHECKSUM);

	iRetVal = sig_UART_WriteRead (DP_SCM_EEPROM_CKSM_TST_CMD,NULL, 0, (char *)&s_CksmData, usRxDataSize, uiTimeout_ms);
	if(iRetVal == DPSCM_SUCCESS)
	{
		*out_pucCalcChecksum = s_CksmData.m_ucComputedChecksum;
		*out_pucReadChecksum = s_CksmData.m_ucReadChecksum;
	}

	return iRetVal;
}

int CEEPROM_RW::EEPROM_ProtectWrite()
{
	int iRetVal = 0;

	iRetVal = sig_UART_WriteRead (DP_SCM_EEPROM_WR_PRTCT_CMD, NULL, 0, NULL, 0, 200);
	return iRetVal;
}

int CEEPROM_RW::EEPROM_CounterDataTest(unsigned short in_usStartAddr, unsigned short in_usNoOfLoc)
{
	int iRetVal = 0;
	unsigned int uiTimeout_ms = 0;
	unsigned short usTxDataSize = 0;
	unsigned short usRxDataSize = 0;
	short sTestResp = 0;
	S_EEPROM_PATTERN_COUNTER	S_EEPROM_Counter;

	memset(&S_EEPROM_Counter, 0, sizeof(S_EEPROM_PATTERN_COUNTER));

	uiTimeout_ms = 200;
	usTxDataSize = sizeof(S_EEPROM_PATTERN_COUNTER);
	usRxDataSize = sizeof(unsigned short);

	S_EEPROM_Counter.m_usStartAddress	   = in_usStartAddr;
	S_EEPROM_Counter.m_usNumberOfLocations = in_usNoOfLoc;

	iRetVal = sig_UART_WriteRead (DP_SCM_EEPROM_CNTR_DATA_TST_CMD,(char *)&S_EEPROM_Counter,usTxDataSize, (char *)&sTestResp, usRxDataSize, uiTimeout_ms);
	return iRetVal;

}

int CEEPROM_RW::EEPROM_PatternDataTest(unsigned short in_usStartAddr, unsigned short in_usNoOfLoc, unsigned char in_ucPattern)
{
	int iRetVal = 0;
	unsigned int uiTimeout_ms = 0;
	unsigned short usTxDataSize = 0;
	unsigned short usRxDataSize = 0;
	short sTestResponse = 0;
	S_EEPROM_PATTERN_COUNTER	S_EEPROM_Pattern;

	memset(&S_EEPROM_Pattern, 0, sizeof(S_EEPROM_PATTERN_COUNTER));

	S_EEPROM_Pattern.m_usStartAddress	   = in_usStartAddr;
	S_EEPROM_Pattern.m_usNumberOfLocations = in_usNoOfLoc;
	S_EEPROM_Pattern.m_ucPattern		   = in_ucPattern;

	uiTimeout_ms = 200;
	usTxDataSize = sizeof(S_EEPROM_PATTERN_COUNTER);
	usRxDataSize = sizeof(unsigned short);

	iRetVal = sig_UART_WriteRead (DP_SCM_EEPROM_PTTRN_TST_CMD, (char *)&S_EEPROM_Pattern, usTxDataSize, (char *)&sTestResponse, usRxDataSize, uiTimeout_ms);
	return iRetVal;
}

int CEEPROM_RW::EEPROM_FullMemoryTest()
{
	int iRetVal = 0;
	unsigned int uiTimeout_ms = 0;

	iRetVal = sig_UART_WriteRead (DP_SCM_EEPROM_FULL_MEM_TST_CMD, NULL, 0, NULL, 0, uiTimeout_ms);
	return iRetVal;
}

