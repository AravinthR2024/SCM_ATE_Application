#include "uart_wrapper.h"


DP_UART_Wrapper::DP_UART_Wrapper()
{


}

short DP_UART_Wrapper::ComPortList(QStringList &out_qslPortName)
{
    short sRetVal = 0;
    QList<QSerialPortInfo> qPorts = QSerialPortInfo::availablePorts();
    if(!qPorts.count())
    {
        sRetVal = -1;
    }

    for(int iIndex = 0;iIndex < qPorts.count();iIndex++)
    {
        QSerialPortInfo qTemp = qPorts.at(iIndex);
        out_qslPortName << qTemp.portName();
    }
    return sRetVal;
}

void DP_UART_Wrapper::ComPortName(QString in_qsComNo)
{
    if(m_objqserialportUART.isOpen())
    {
        m_objqserialportUART.close();
    }
    m_objqserialportUART.setPortName(in_qsComNo);
}

short DP_UART_Wrapper::Baudrate(unsigned long in_ulBaudRate)
{
    short sRetVal = DPSCM_SUCCESS;
    switch(in_ulBaudRate)
    {
    case QSerialPort::Baud1200:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud1200);
        break;
    }
    case QSerialPort::Baud2400:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud2400);
        break;
    }
    case QSerialPort::Baud4800:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud4800);
        break;
    }
    case QSerialPort::Baud9600:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud9600);
        break;
    }
    case QSerialPort::Baud19200:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud19200);
        break;
    }
    case QSerialPort::Baud38400:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud38400);
        break;
    }
    case QSerialPort::Baud57600:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud57600);
        break;
    }
    case QSerialPort::Baud115200:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud115200);
        break;
    }
    default:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::UnknownBaud);
        sRetVal = -1;//DP_INVALID_BAUDRATE;
    }
    }
    return sRetVal;
}

short DP_UART_Wrapper::DataBit(unsigned char in_ucDataBits)
{
    short sRetVal = DPSCM_SUCCESS;
    switch(in_ucDataBits)
    {
    case QSerialPort::Data5:
    {
        m_objqserialportUART.setDataBits(QSerialPort::Data5);
        break;
    }
    case QSerialPort::Data6 :
    {
        m_objqserialportUART.setDataBits(QSerialPort::Data6);
        break;
    }
    case QSerialPort::Data7 :
    {
        m_objqserialportUART.setDataBits(QSerialPort::Data7);
        break;
    }
    case QSerialPort::Data8 :
    {
        m_objqserialportUART.setDataBits(QSerialPort::Data8);
        break;
    }
    default:
    {
        m_objqserialportUART.setDataBits(QSerialPort::UnknownDataBits);
        sRetVal = -1;
    }
    }
    return sRetVal;
}

short DP_UART_Wrapper::ParityBit(unsigned char in_ucParity)
{
    short sRetVal = DPSCM_SUCCESS;
    switch(in_ucParity)
    {
    case QSerialPort::NoParity:
    {
        m_objqserialportUART.setParity(QSerialPort::NoParity);
        break;
    }
    case QSerialPort::EvenParity :
    {
        m_objqserialportUART.setParity(QSerialPort::EvenParity);
        break;
    }
    case QSerialPort::OddParity :
    {
        m_objqserialportUART.setParity(QSerialPort::OddParity);
        break;
    }
    case QSerialPort::SpaceParity :
    {
        m_objqserialportUART.setParity(QSerialPort::SpaceParity);
        break;
    }
    case QSerialPort::MarkParity :
    {
        m_objqserialportUART.setParity(QSerialPort::MarkParity);
        break;
    }
    default:
    {
        m_objqserialportUART.setParity(QSerialPort::UnknownParity);
        sRetVal = DP_INVALID_PARITY;
    }
    }
    return sRetVal;
}

short DP_UART_Wrapper::FlowControl(unsigned char in_ucFlowControl)
{
    short sRetVal = DPSCM_SUCCESS;
    switch (in_ucFlowControl)
    {
    case QSerialPort::NoFlowControl:
    {
        m_objqserialportUART.setFlowControl(QSerialPort::NoFlowControl);
        break;
    }
    case QSerialPort::HardwareControl :
    {
        m_objqserialportUART.setFlowControl(QSerialPort::HardwareControl);
        break;
    }
    case QSerialPort::SoftwareControl :
    {
        m_objqserialportUART.setFlowControl(QSerialPort::SoftwareControl);
        break;
    }

    default:
    {
        m_objqserialportUART.setFlowControl(QSerialPort::UnknownFlowControl);
        sRetVal =  DP_INVALID_FLOW_CONTROL;
    }
    }
    return sRetVal;
}

short DP_UART_Wrapper::StopBit(unsigned char in_ucStopBit)
{
    short sRetVal = 0;
    switch (in_ucStopBit)
    {
    case QSerialPort::OneStop:
    {
        m_objqserialportUART.setStopBits(QSerialPort::OneStop);
        break;
    }
    case QSerialPort::TwoStop:
    {
        m_objqserialportUART.setStopBits(QSerialPort::TwoStop);
        break;
    }
    case QSerialPort::OneAndHalfStop:
    {
        m_objqserialportUART.setStopBits(QSerialPort::OneAndHalfStop);
        break;
    }
    default:
    {
        m_objqserialportUART.setStopBits(QSerialPort::UnknownStopBits);
        sRetVal = -1;
    }
    }
    return sRetVal;
}

short DP_UART_Wrapper::PortStatus()
{
    short sRetVal = DPSCM_SUCCESS;

    if(m_objqserialportUART.open(QIODevice::ReadWrite))
    {
        sRetVal = DPSCM_SUCCESS;
    }
    else
    {
        sRetVal = DP_COM_PORT_NOT_OPENED;
    }
    return sRetVal;
}

short DP_UART_Wrapper::PortOpen()
{
    short sRetVal = 0;
    if(m_objqserialportUART.open(QIODevice::ReadWrite))
    {
        qDebug()<<m_objqserialportUART.portName() + " Opened";
    }
    else
    {
        qDebug()<<m_objqserialportUART.portName() + " Port Not Opened";
        sRetVal = DP_COM_PORT_NOT_OPENED;
    }
    return sRetVal;
}

short DP_UART_Wrapper::PortClose()
{
    short sRetVal = 0;
    m_objqserialportUART.close();
    qDebug()<<m_objqserialportUART.portName() + " Port Closed";
    return sRetVal;
}

int DP_UART_Wrapper::DataWrite(char *in_pcBuffData, long long in_lliDataLen)
{
    int iRetVal = DPSCM_SUCCESS;
    long long int lliDataWritten = 0;

    lliDataWritten = m_objqserialportUART.write(in_pcBuffData, in_lliDataLen);

    m_objqserialportUART.waitForBytesWritten(-1);

    if(lliDataWritten != in_lliDataLen)
    {
        iRetVal = DP_FAILURE;
    }

    return iRetVal;
}


int DP_UART_Wrapper::DataRead(unsigned char *out_pucRxBuffer)
{

    int iRetVal = 0;
    unsigned int uiTimer = 500;
    long long int lliTotalBytes = 0;

    m_objqserialportUART.clearError();

    while(uiTimer--)
    {
        m_objqserialportUART.waitForReadyRead(100);

        lliTotalBytes = m_objqserialportUART.read((char*)out_pucRxBuffer, 1);

        if(lliTotalBytes < 0)
        {
            *out_pucRxBuffer = 0;
            iRetVal = DP_FAILURE;
        }
        else
        {
            iRetVal = DPSCM_SUCCESS;
            break;
        }
    }

    return iRetVal;
}

int DP_UART_Wrapper::DataRead(unsigned int in_uiTotalBytesToRead, unsigned char *out_pucRxBuffer, unsigned int *out_puiBytesRead, unsigned int in_uiMilliSecTOut)
{
    int iRetVal = 0;
    long long int lliTotalBytes = 0;

    m_objqserialportUART.waitForReadyRead(in_uiMilliSecTOut);

    lliTotalBytes = m_objqserialportUART.read((char*)out_pucRxBuffer, in_uiTotalBytesToRead);

    if(lliTotalBytes <= 0)
    {
        iRetVal = DP_FAILURE;
    }
    else
    {
        *out_puiBytesRead = (unsigned int)lliTotalBytes;
        iRetVal = DPSCM_SUCCESS;
    }
    return iRetVal;
}


short DP_UART_Wrapper::ClearInput()
{
    short sRetVal = DPSCM_SUCCESS;
    bool bResult = 0;

    bResult = m_objqserialportUART.clear(QSerialPort::Input);

    if(bResult == false)
    {
        sRetVal = DP_FAILURE;
    }


    return sRetVal;
}
short DP_UART_Wrapper::ClearOutput()
{
    short sRetVal = DPSCM_SUCCESS;
    bool bResult = 0;

    bResult = m_objqserialportUART.clear(QSerialPort::Output);

    if(bResult == false)
    {
        sRetVal = DP_FAILURE;
    }

    return sRetVal;
}
int DP_UART_Wrapper::ClearAll()
{
    int iRetVal = DPSCM_SUCCESS;
    bool bResult = 0;

    bResult = m_objqserialportUART.clear(QSerialPort::AllDirections);

    if(bResult == false)
    {
        iRetVal = DP_FAILURE;
    }

    return iRetVal;
}
