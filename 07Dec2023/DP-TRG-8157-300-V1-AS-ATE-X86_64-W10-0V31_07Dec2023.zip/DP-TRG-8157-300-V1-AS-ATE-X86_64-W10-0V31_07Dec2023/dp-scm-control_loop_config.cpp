/**
* \file dp-scm-control_loop_config.cpp
* \brief This file contains the code for Control Loop Configuration panel
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-control_loop_config.h"
#include "ui_dp-scm-control_loop_config.h"
#include "dp-scm-mainwindow.h"

extern S_GLOBAL g_SGlobal;

/*******************************************************************************
 * Name					: CControlLoopConfig
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CControlLoopConfig class
 *
 * @param[in]	parent	Holds the reference to the parent
 * @return	NA
 ******************************************************************************/
CControlLoopConfig::CControlLoopConfig(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CControlLoopConfig)
{
    ui->setupUi(this);
    ui->cbSelectAll->setHidden(false);

    m_pthControlLoopConfig = new CControlLoopConfigThread(this);

    initializeConfig();
}

/*******************************************************************************
 * Name					: ~CControlLoopConfig
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief	This function is the destructor of CControlLoopConfig class
 *
 * @param		NIL
 * @return	NA
 ******************************************************************************/
CControlLoopConfig::~CControlLoopConfig()
{
    delete ui;
}

/*******************************************************************************
 * Name					: initializeConfig
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To initialize the constant values
 ***************************************************************************//**
 * @brief	This function is used to initialize all Control loop configuration panel controls
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CControlLoopConfig::initializeConfig()
{
    memset(&m_SCtrlLoopConfig, DPSCM_INIT_0, sizeof(S_CTRL_LOOP_CONFIG));
    m_uiSelectedConstants = 0x7FFFFFF;

    /* Storing Checkboxes */
    m_liCheckbox.clear();
    m_liCheckbox.append(ui->cbInversionWord);
    m_liCheckbox.append(ui->cbEnableEndstops);
    m_liCheckbox.append(ui->cbEnableNoiseFilter);
    m_liCheckbox.append(ui->cbEnableRateFeedFrwrd);
    m_liCheckbox.append(ui->cbEnableLagCtrl);
    m_liCheckbox.append(ui->cbMinEndstop);
    m_liCheckbox.append(ui->cbMaxEndstop);
    m_liCheckbox.append(ui->cbRateLimit);
    m_liCheckbox.append(ui->cbAccLimit);
    m_liCheckbox.append(ui->cbCurrLimit);
    m_liCheckbox.append(ui->cbRateDeadZone);
    m_liCheckbox.append(ui->cbNoiseCuttoff_Rate);
    m_liCheckbox.append(ui->cbNoiseDamp);
    m_liCheckbox.append(ui->cbPrefilterDiscount);
    m_liCheckbox.append(ui->cbPrefilterLinearZone);
    m_liCheckbox.append(ui->cbRateFeedFrwrdBW);
    m_liCheckbox.append(ui->cbTotalGearRatio);
    m_liCheckbox.append(ui->cbLoadedPropGain);
    m_liCheckbox.append(ui->cbLoadedDerGain);
    m_liCheckbox.append(ui->cbUnloadedPropGain);
    m_liCheckbox.append(ui->cbUnloadedDerGain);
    m_liCheckbox.append(ui->cbLoadedNormGain);
    m_liCheckbox.append(ui->cbUnloadedNormGain);
    m_liCheckbox.append(ui->cbLagFilterLagBreakPt);
    m_liCheckbox.append(ui->cbLagFilterLeadBreakPt);
    m_liCheckbox.append(ui->cbLowpassBW);
    m_liCheckbox.append(ui->cbCurr_P_Gain);
    m_liCheckbox.append(ui->cbCurr_I_Gain);

    foreach(QCheckBox *pObj, m_liCheckbox)
    {
        pObj->setChecked(true);
        connect(pObj, SIGNAL(toggled(bool)), this, SLOT(slot_getSelectedConstants()));
    }

    /* Storing Double Spinbox */
    m_liDSB.clear ();
    m_liDSB.append(ui->sbInversionWord);
    m_liDSB.append(ui->sbEnableEndstops);
    m_liDSB.append(ui->sbEnableNoiseFilter);
    m_liDSB.append(ui->sbEnableRateFeedFrwrd);
    m_liDSB.append(ui->sbEnableLagCtrl);
    m_liDSB.append(ui->sbMinEndstop);
    m_liDSB.append(ui->sbMaxEndstop);
    m_liDSB.append(ui->dsbRateLimit);
    m_liDSB.append(ui->dsbAccLimit);
    m_liDSB.append(ui->sbCurrLimit);
    m_liDSB.append(ui->sbRateDeadZone);
    m_liDSB.append(ui->dsbNoiseCuttoff_Rate);
    m_liDSB.append(ui->dsbNoiseDamp);
    m_liDSB.append(ui->dsbPrefilterDiscount);
    m_liDSB.append(ui->dsbPrefilterLinearZone);
    m_liDSB.append(ui->dsbRateFeedfrwrdBW);
    m_liDSB.append(ui->dsbTotalGearRatio);
    m_liDSB.append(ui->dsbLoadedPropGain);
    m_liDSB.append(ui->dsbLoadedDerGain);
    m_liDSB.append(ui->dsbUnloadedPropGain);
    m_liDSB.append(ui->dsbUnloadedDerGain);
    m_liDSB.append(ui->dsbLoadedNormGain);
    m_liDSB.append(ui->dsbUnloadedNormGain);
    m_liDSB.append(ui->dsbLagFilterLagBreakPt);
    m_liDSB.append(ui->dsbLagFilterLeadBreakPt);
    m_liDSB.append(ui->dsbLowpassBW);
    m_liDSB.append(ui->dsbCurr_P_Gain);
    m_liDSB.append(ui->dsbCurr_I_Gain);

    m_pthControlLoopConfig->m_liDSB.clear();
    m_pthControlLoopConfig->m_liDSB.append(m_liDSB);

    m_pthControlLoopConfig->m_liCheckbox.clear();
    m_pthControlLoopConfig->m_liCheckbox.append(m_liCheckbox);

    ui->cbSelectAll->setCheckState (Qt::Checked);
    on_cbSelectAll_clicked ();
}

/*******************************************************************************
 * Name					: setDefaultConfig
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set default values for all constants
 ***************************************************************************//**
 * @brief	This function is used to set default values for all constant
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CControlLoopConfig::setDefaultConfig()
{
    m_uiSelectedConstants = DPSCM_INIT_0;

    // To be updated - Create macro for every entity for default values
    m_SCtrlLoopConfig.m_iInversionWord          = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_ucEnableEndstops        = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_ucEnableNoiseFilter     = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_ucEnableRateFeedFrwrd   = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_ucEnableLagController   = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dEndstopMin             = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dEndstopMax             = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dRateLimit              = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dAccLimit               = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dCurLimit               = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dRateDeadZone           = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dNoiseFilterCutoff_Rate = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dNoiseFilterDamping     = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dPrefilterDiscount      = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dPrefilterLinearZone    = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dRateFeedFrwrdBW        = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dTotalGearRatio         = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dPropGain_Loaded        = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dDervGain_Loaded        = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dPropGain_Unload        = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dDervGain_Unload        = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dNormGain_Loaded        = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dNormGain_Unload        = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dLagFilterLagBP         = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dLagFilterLeadBP        = DPSCM_INIT_0;
    m_SCtrlLoopConfig.m_dLowpassBW              = DPSCM_INIT_0;
}
/*******************************************************************************
 * Name					: getConfigValues
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To get the configured values from GUI
 ***************************************************************************//**
 * @brief	This function is used to get configured values and store in structure
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CControlLoopConfig::getConfigValues()
{
    m_SCtrlLoopConfig.m_iInversionWord              = ui->sbInversionWord->value(); // / DP_SCM_CONFIG_ST;
    m_SCtrlLoopConfig.m_ucEnableEndstops            = ui->sbEnableEndstops->value(); // / DP_SCM_EN_ENDSTOP;
    m_SCtrlLoopConfig.m_ucEnableNoiseFilter         = ui->sbEnableNoiseFilter->value(); // / DP_SCM_EN_NLP;
    m_SCtrlLoopConfig.m_ucEnableRateFeedFrwrd       = ui->sbEnableRateFeedFrwrd->value(); // / DP_SCM_EN_RFF;
    m_SCtrlLoopConfig.m_ucEnableLagController       = ui->sbEnableLagCtrl->value(); // / DP_SCM_EN_LAG;
    m_SCtrlLoopConfig.m_dEndstopMin                 = ui->sbMinEndstop->value(); // / DP_SCM_THETA_MIN_PREC;
    m_SCtrlLoopConfig.m_dEndstopMax                 = ui->sbMaxEndstop->value(); // / DP_SCM_THETA_MAX_PREC;
    m_SCtrlLoopConfig.m_dRateLimit                  = ui->dsbRateLimit->value(); // / DP_SCM_LIM_R_PREC;
    m_SCtrlLoopConfig.m_dAccLimit                   = ui->dsbAccLimit->value(); // / DP_SCM_LIM_A_PREC;
    m_SCtrlLoopConfig.m_dCurLimit                   = ui->sbCurrLimit->value(); // / DP_SCM_LIM_I_PREC;
    m_SCtrlLoopConfig.m_dRateDeadZone               = ui->sbRateDeadZone->value(); // / DP_SCM_RATE_DZ_PREC;
    m_SCtrlLoopConfig.m_dNoiseFilterCutoff_Rate     = ui->dsbNoiseCuttoff_Rate->value(); // / DP_SCM_OMG_NLP_PREC;
    m_SCtrlLoopConfig.m_dNoiseFilterDamping         = ui->dsbNoiseDamp->value(); // / DP_SCM_ZETA_NLP_PREC;
    m_SCtrlLoopConfig.m_dPrefilterDiscount          = ui->dsbPrefilterDiscount->value(); // / DP_SCM_ALPHA_PREC;
    m_SCtrlLoopConfig.m_dPrefilterLinearZone        = ui->dsbPrefilterLinearZone->value(); // / DP_SCM_DELTA_PREC;
    m_SCtrlLoopConfig.m_dRateFeedFrwrdBW            = ui->dsbRateFeedfrwrdBW->value(); // / DP_SCM_OMG_RFF_PREC;
    m_SCtrlLoopConfig.m_dTotalGearRatio             = ui->dsbTotalGearRatio->value(); // / DP_SCM_N_PREC;
    m_SCtrlLoopConfig.m_dPropGain_Loaded            = ui->dsbLoadedPropGain->value(); // / DP_SCM_KPL_PREC;
    m_SCtrlLoopConfig.m_dDervGain_Loaded            = ui->dsbLoadedDerGain->value(); // / DP_SCM_KDL_PREC;
    m_SCtrlLoopConfig.m_dPropGain_Unload            = ui->dsbUnloadedPropGain->value(); // / DP_SCM_KPM_PREC;
    m_SCtrlLoopConfig.m_dDervGain_Unload            = ui->dsbUnloadedDerGain->value(); // / DP_SCM_KDM_PREC;
    m_SCtrlLoopConfig.m_dNormGain_Loaded            = ui->dsbLoadedNormGain->value(); // / DP_SCM_WL_PREC;
    m_SCtrlLoopConfig.m_dNormGain_Unload            = ui->dsbUnloadedNormGain->value(); // / DP_SCM_WM_PREC;
    m_SCtrlLoopConfig.m_dLagFilterLagBP             = ui->dsbLagFilterLagBreakPt->value(); // / DP_SCM_OMG_1_PREC;
    m_SCtrlLoopConfig.m_dLagFilterLeadBP            = ui->dsbLagFilterLeadBreakPt->value(); // / DP_SCM_OMG_2_PREC;
    m_SCtrlLoopConfig.m_dLowpassBW                  = ui->dsbLowpassBW->value(); // / DP_SCM_OMG_LP_PREC;
    m_SCtrlLoopConfig.m_dCurrPGain                  = ui->dsbCurr_P_Gain->value(); // / DP_SCM_CURR_P_GAIN_PREC;
    m_SCtrlLoopConfig.m_dCurrIGain                  = ui->dsbCurr_I_Gain->value(); // / DP_SCM_CURR_I_GAIN_PREC;
}

/*******************************************************************************
 * Name					: slot_getSelectedConstants
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To get all the selected constants
 ***************************************************************************//**
 * @brief	This function is get the constants which are selected (checked)
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CControlLoopConfig::slot_getSelectedConstants()
{
    unsigned int uiShift = DPSCM_INIT_0; // Shift number of bits equals to the current interation count
    unsigned char ucNumOfCheckedParameters = DPSCM_INIT_0;
    QString qstrTemp = QString();

    foreach(QCheckBox *pObj, m_liCheckbox)
    {
        qstrTemp = pObj->text();
        if (pObj->isChecked())
        {
            m_uiSelectedConstants = m_uiSelectedConstants | (0x1 << uiShift);
            m_liDSB.at(uiShift)->setEnabled(true);  // Enable the respective edit-box if checked
            ucNumOfCheckedParameters++;
        }
        else
        {
            m_uiSelectedConstants = m_uiSelectedConstants & (~(0x1 << uiShift));
            m_liDSB.at(uiShift)->setEnabled(false); // Disable the respective edit-box if unchecked
        }

        uiShift++;
    }

    if (ucNumOfCheckedParameters == DPSCM_INIT_0)
    {
        ui->cbSelectAll->setCheckState (Qt::Unchecked);
    }
    else if (ucNumOfCheckedParameters == CLC_TOTAL_NO_OF_PARAMETERS)
    {
        ui->cbSelectAll->setCheckState (Qt::Checked);
    }
    else
    {
        ui->cbSelectAll->setCheckState (Qt::PartiallyChecked);
    }
}

void CControlLoopConfig::slot_threadCompleted()
{
    m_pthControlLoopConfig->Stop();
    emit sig_showLoadingScreen(false);
}

/*******************************************************************************
 * Name					: setConfigValues
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set the constant values to GUI
 ***************************************************************************//**
 * @brief	This function is used to set constant values to GUI
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CControlLoopConfig::setConfigValues()
{
    ui->sbInversionWord->setValue(m_SCtrlLoopConfig.m_iInversionWord);
    ui->sbEnableEndstops->setValue(m_SCtrlLoopConfig.m_ucEnableEndstops);
    ui->sbEnableNoiseFilter->setValue(m_SCtrlLoopConfig.m_ucEnableNoiseFilter);
    ui->sbEnableRateFeedFrwrd->setValue(m_SCtrlLoopConfig.m_ucEnableRateFeedFrwrd);
    ui->sbEnableLagCtrl->setValue(m_SCtrlLoopConfig.m_ucEnableLagController);
    ui->sbMinEndstop->setValue(m_SCtrlLoopConfig.m_dEndstopMin);
    ui->sbMaxEndstop->setValue(m_SCtrlLoopConfig.m_dEndstopMax);
    ui->dsbRateLimit->setValue(m_SCtrlLoopConfig.m_dRateLimit);
    ui->dsbAccLimit->setValue(m_SCtrlLoopConfig.m_dAccLimit);
    ui->sbCurrLimit->setValue(m_SCtrlLoopConfig.m_dCurLimit);
    ui->sbRateDeadZone->setValue(m_SCtrlLoopConfig.m_dRateDeadZone);
    ui->dsbNoiseCuttoff_Rate->setValue(m_SCtrlLoopConfig.m_dNoiseFilterCutoff_Rate);
    ui->dsbNoiseDamp->setValue(m_SCtrlLoopConfig.m_dNoiseFilterDamping);
    ui->dsbPrefilterDiscount->setValue(m_SCtrlLoopConfig.m_dPrefilterDiscount);
    ui->dsbPrefilterLinearZone->setValue(m_SCtrlLoopConfig.m_dPrefilterLinearZone);
    ui->dsbRateFeedfrwrdBW->setValue(m_SCtrlLoopConfig.m_dRateFeedFrwrdBW);
    ui->dsbTotalGearRatio->setValue(m_SCtrlLoopConfig.m_dTotalGearRatio);
    ui->dsbLoadedPropGain->setValue(m_SCtrlLoopConfig.m_dPropGain_Loaded);
    ui->dsbLoadedDerGain->setValue(m_SCtrlLoopConfig.m_dDervGain_Loaded);
    ui->dsbUnloadedPropGain->setValue(m_SCtrlLoopConfig.m_dPropGain_Unload);
    ui->dsbUnloadedDerGain->setValue(m_SCtrlLoopConfig.m_dDervGain_Unload);
    ui->dsbLoadedNormGain->setValue(m_SCtrlLoopConfig.m_dNormGain_Loaded);
    ui->dsbUnloadedNormGain->setValue(m_SCtrlLoopConfig.m_dNormGain_Unload);
    ui->dsbLagFilterLagBreakPt->setValue(m_SCtrlLoopConfig.m_dLagFilterLagBP);
    ui->dsbLagFilterLeadBreakPt->setValue(m_SCtrlLoopConfig.m_dLagFilterLeadBP);
    ui->dsbLowpassBW->setValue(m_SCtrlLoopConfig.m_dLowpassBW);
    ui->dsbCurr_P_Gain->setValue(m_SCtrlLoopConfig.m_dCurrPGain);
    ui->dsbCurr_I_Gain->setValue(m_SCtrlLoopConfig.m_dCurrIGain);

    DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Configuration Loaded successfully");
}

/*******************************************************************************
 * Name					: readConfigFile
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To read the config file
 ***************************************************************************//**
 * @brief	This function is used to read constant values from config file
 *
 * @param[in]	in_qstrFile	Holds the name of the config file to read
 * @return	DPSCM_SUCCESS	on successful read of constant values
 *			DPSCM_FAILURE	if any error occurred while reading
 ******************************************************************************/
int CControlLoopConfig::readConfigFile(QString in_qstrFile)
{
#ifdef _BIN_FILE_
    int iRetval = DPSCM_INIT_0;
    FILE *fpConfig;
    fpConfig = fopen(in_qstrFile.toLatin1().data(), "rb");
    if (!fpConfig)
    {
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Error opening Binary file");
        return DPSCM_FAILURE;
    }

    iRetval = fread(&m_SCtrlLoopConfig, sizeof(S_CTRL_LOOP_CONFIG), 1, fpConfig);
    if (iRetval == DPSCM_INIT_0)
    {
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Error reading Binary file");
        fclose(fpConfig);
        return DPSCM_FAILURE;
    }

    fclose(fpConfig);
#else
    bool bRetval = false;
    QFile fpConfig(in_qstrFile);
    QString qstrLine = QString("");
    QStringList qstrliTokens;

    bRetval = fpConfig.open(QIODevice::ReadOnly);
    if (!bRetval)
    {
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Error opening CSV File");
        return DPSCM_FAILURE;
    }

    fpConfig.readLine();    // Skipping the first line (Header line)
    qstrLine = fpConfig.readLine().trimmed();
    qstrliTokens = qstrLine.split(",");

    m_SCtrlLoopConfig.m_iInversionWord              = qstrliTokens.at(CLC_INVERSION_WORD).toInt(); // * DP_SCM_CONFIG_ST;
    m_SCtrlLoopConfig.m_ucEnableEndstops            = qstrliTokens.at(CLC_ENABLE_ENDSTOP).toInt(); // * DP_SCM_EN_ENDSTOP;
    m_SCtrlLoopConfig.m_ucEnableNoiseFilter         = qstrliTokens.at(CLC_ENABLE_NOISE_FILTER).toInt(); // * DP_SCM_EN_NLP;
    m_SCtrlLoopConfig.m_ucEnableRateFeedFrwrd       = qstrliTokens.at(CLC_ENABLE_RATE_FEED_FRWRD).toInt(); // * DP_SCM_EN_RFF;
    m_SCtrlLoopConfig.m_ucEnableLagController       = qstrliTokens.at(CLC_ENABLE_LAG_CONTROLLER).toInt(); // * DP_SCM_EN_LAG;
    m_SCtrlLoopConfig.m_dEndstopMin                 = qstrliTokens.at(CLC_MINIMUM_ENDSTOP).toDouble(); // * DP_SCM_THETA_MIN_PREC;
    m_SCtrlLoopConfig.m_dEndstopMax                 = qstrliTokens.at(CLC_MAXIMUM_ENDSTOP).toDouble(); // * DP_SCM_THETA_MAX_PREC;
    m_SCtrlLoopConfig.m_dRateLimit                  = qstrliTokens.at(CLC_RATE_LIMIT).toDouble(); // * DP_SCM_LIM_R_PREC;
    m_SCtrlLoopConfig.m_dAccLimit                   = qstrliTokens.at(CLC_ACC_LIMIT).toDouble(); // * DP_SCM_LIM_A_PREC;
    m_SCtrlLoopConfig.m_dCurLimit                   = qstrliTokens.at(CLC_CUR_LIMIT).toDouble(); // * DP_SCM_LIM_I_PREC;
    m_SCtrlLoopConfig.m_dRateDeadZone               = qstrliTokens.at(CLC_RATE_DEAD_ZONE).toDouble(); // * DP_SCM_RATE_DZ_PREC;
    m_SCtrlLoopConfig.m_dNoiseFilterCutoff_Rate     = qstrliTokens.at(CLC_NOISEFILTER_CUTOFF_RATEMODE).toDouble(); // * DP_SCM_OMG_NLP_PREC;
    m_SCtrlLoopConfig.m_dNoiseFilterDamping         = qstrliTokens.at(CLC_DAMPING_FACTOR).toDouble(); // * DP_SCM_ZETA_NLP_PREC;
    m_SCtrlLoopConfig.m_dPrefilterDiscount          = qstrliTokens.at(CLC_PREFILTER_DISCOUNT).toDouble(); // * DP_SCM_ALPHA_PREC;
    m_SCtrlLoopConfig.m_dPrefilterLinearZone        = qstrliTokens.at(CLC_PREFILTER_LINEARZONE).toDouble(); // * DP_SCM_DELTA_PREC;
    m_SCtrlLoopConfig.m_dRateFeedFrwrdBW            = qstrliTokens.at(CLC_RATE_FEEDFRWRD_BW).toDouble(); // * DP_SCM_OMG_RFF_PREC;
    m_SCtrlLoopConfig.m_dTotalGearRatio             = qstrliTokens.at(CLC_TOTAL_GEAR_RATIO).toDouble(); // * DP_SCM_N_PREC;
    m_SCtrlLoopConfig.m_dPropGain_Loaded            = qstrliTokens.at(CLC_PROP_GAIN_LOADED).toDouble(); // * DP_SCM_KPL_PREC;
    m_SCtrlLoopConfig.m_dDervGain_Loaded            = qstrliTokens.at(CLC_DERV_GAIN_LOADED).toDouble(); // * DP_SCM_KDL_PREC;
    m_SCtrlLoopConfig.m_dPropGain_Unload            = qstrliTokens.at(CLC_PROP_GAIN_UNLOADED).toDouble(); // * DP_SCM_KPM_PREC;
    m_SCtrlLoopConfig.m_dDervGain_Unload            = qstrliTokens.at(CLC_DERV_GAIN_UNLOADED).toDouble(); // * DP_SCM_KDM_PREC;
    m_SCtrlLoopConfig.m_dNormGain_Loaded            = qstrliTokens.at(CLC_NORM_GAIN_LOADED).toDouble(); // * DP_SCM_WL_PREC;
    m_SCtrlLoopConfig.m_dNormGain_Unload            = qstrliTokens.at(CLC_NORM_GAIN_UNLOADED).toDouble(); // * DP_SCM_WM_PREC;
    m_SCtrlLoopConfig.m_dLagFilterLagBP             = qstrliTokens.at(CLC_LAGFILTER_LAG_BREAKPOINT).toDouble(); // * DP_SCM_OMG_1_PREC;
    m_SCtrlLoopConfig.m_dLagFilterLeadBP            = qstrliTokens.at(CLC_LAGFILTER_LEAD_BREAKPOINT).toDouble(); // * DP_SCM_OMG_2_PREC;
    m_SCtrlLoopConfig.m_dLowpassBW                  = qstrliTokens.at(CLC_LOWPASS_FILTER_BW).toDouble(); // * DP_SCM_OMG_LP_PREC;
    m_SCtrlLoopConfig.m_dCurrPGain                  = qstrliTokens.at(CLC_CURRLOOP_P_GAIN).toDouble(); // * DP_SCM_CURR_P_GAIN_PREC;
    m_SCtrlLoopConfig.m_dCurrIGain                  = qstrliTokens.at(CLC_CURRLOOP_I_GAIN).toDouble(); // * DP_SCM_CURR_I_GAIN_PREC;
#endif

    return DPSCM_SUCCESS;
}

/*******************************************************************************
 * Name					: writeConfigFile
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To store the constant values in config file
 ***************************************************************************//**
 * @brief	This function is used to store the configured values in GUI to bin file
 *
 * @param[in]	in_qstrFile	Holds the name of config file to store
 * @return	DPSCM_SUCCESS	if writing is successful
 *			DPSCM_FAILURE	if any error occurred while storing values
 ******************************************************************************/
int CControlLoopConfig::writeConfigFile(QString in_qstrFile)
{
    int iRetval = DPSCM_INIT_0;

#ifdef _BIN_FILE_
    FILE *fpConfig;
    fpConfig = fopen(in_qstrFile.toLatin1().data(), "wb");
    if (!fpConfig)
    {
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Error opening Binary file");
        return DPSCM_FAILURE;
    }

    iRetval = fwrite(&m_SCtrlLoopConfig, sizeof(S_CTRL_LOOP_CONFIG), 1, fpConfig);
    if (iRetval == DPSCM_INIT_0)
    {
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Error writing Binary file");
        fclose(fpConfig);
        return DPSCM_FAILURE;
    }

    fclose(fpConfig);
#else
    QFile fpConfig(in_qstrFile);
    QString qstrWriteData = QString("");
    QString qstrTemp = QString("");

    if (!fpConfig.open(QIODevice::WriteOnly))
    {
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Error opening Binary File");
        return DPSCM_FAILURE;
    }

    WRITE_CLC_PARAM_HEADER(qstrWriteData);

    qstrTemp.sprintf("%d,", m_SCtrlLoopConfig.m_iInversionWord);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%d,", m_SCtrlLoopConfig.m_ucEnableEndstops);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%d,", m_SCtrlLoopConfig.m_ucEnableNoiseFilter);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%d,", m_SCtrlLoopConfig.m_ucEnableRateFeedFrwrd);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%d,", m_SCtrlLoopConfig.m_ucEnableLagController);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dEndstopMin);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dEndstopMax);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dRateLimit);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dAccLimit);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dCurLimit);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dRateDeadZone);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dNoiseFilterCutoff_Rate);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dNoiseFilterDamping);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dPrefilterDiscount);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dPrefilterLinearZone);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dRateFeedFrwrdBW);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dTotalGearRatio);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dPropGain_Loaded);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dDervGain_Loaded);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dPropGain_Unload);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dDervGain_Unload);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dNormGain_Loaded);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dNormGain_Unload);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dLagFilterLagBP);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dLagFilterLeadBP);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dLowpassBW);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f,", m_SCtrlLoopConfig.m_dCurrPGain);
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("%.5f", m_SCtrlLoopConfig.m_dCurrIGain);
    qDebug() << "3. " << m_SCtrlLoopConfig.m_dCurrIGain;
    qstrWriteData.append(qstrTemp);
    qstrTemp.sprintf("\r\n");
    qstrWriteData.append(qstrTemp);

    iRetval = fpConfig.write(qstrWriteData.toLatin1());
    fpConfig.close();
    if (!iRetval)
    {
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Error while saving the constants");
        return DPSCM_FAILURE;
    }
#endif

    return DPSCM_SUCCESS;
}

/*******************************************************************************
 * Name					: on_pbReadEEPROM_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To read EEPROM values
 ***************************************************************************//**
 * @brief	This function is used to read constant values from EEPROM
 *		This function is called when Read Button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CControlLoopConfig::on_pbReadEEPROM_clicked()
{
    CHECK_TC_RUNNING;
    CHECK_PORT_OPEN (DIAGNOSTIC_PORT_IDX);
    if (g_SGlobal.m_ucConfiguredMode != DIAGNOSTICS_MODE)
    {
        DISPLAY_MESSAGE_BOX(this, "Mode Configuration", "Please switch to Diagnostics Mode to Read EEPROM Constants");
        return;
    }

    emit sig_showLoadingScreen(true);
    m_pthControlLoopConfig->setOperation(CLCTHREAD_MODE_READ);
    m_pthControlLoopConfig->Start();
}

CControlLoopConfigThread::CControlLoopConfigThread(QObject *parent) : QThread(parent)
{
    m_bIsRunning = false;
    m_cRunningMode = CLCTHREAD_MODE_INVALID;
}

void CControlLoopConfigThread::Delay(unsigned long in_ulTime_usec)
{
    LARGE_INTEGER freq;
    LARGE_INTEGER iStartCount;
    LARGE_INTEGER iEndCount;
    unsigned long in_ulMeasureTime_usec = 0;


    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&iStartCount);

    while(in_ulMeasureTime_usec < in_ulTime_usec)
    {
        QueryPerformanceCounter(&iEndCount);
        in_ulMeasureTime_usec = ((double)(iEndCount.QuadPart-iStartCount.QuadPart) / freq.QuadPart) * 1000000;
    }

    return;
}

void CControlLoopConfigThread::Start()
{
    m_bIsRunning = true;
    start(QThread::HighestPriority);
}

void CControlLoopConfigThread::Stop()
{
    m_bIsRunning = false;
    terminate();
}

void CControlLoopConfigThread::setOperation(char in_cMode)
{
    if ((in_cMode < CLCTHREAD_MODE_WRITE) || (in_cMode > CLCTHREAD_MODE_READ))
    {
        return;
    }

    m_cRunningMode = in_cMode;
}

void CControlLoopConfigThread::run()
{
    while (m_bIsRunning)
    {
        switch (m_cRunningMode)
        {
        case CLCTHREAD_MODE_WRITE:
        {
            writeEEPROM();
        } break;
        case CLCTHREAD_MODE_READ:
        {
            readEEPROM();
        } break;
        default: break;
        }

        m_bIsRunning = false;
    }
}

void CControlLoopConfigThread::writeEEPROM()
{
    unsigned char ucLoop = DPSCM_INIT_0;
    double dData = DPSCM_INIT_0;
    int iRetVal = DPSCM_INIT_0;
    unsigned int uiBytesRead = DPSCM_INIT_0;
    double darrResolution[CLC_TOTAL_NO_OF_PARAMETERS]={
        DP_SCM_CONFIG_ST,
        DP_SCM_EN_ENDSTOP,
        DP_SCM_EN_NLP,
        DP_SCM_EN_RFF,
        DP_SCM_EN_LAG,
        DP_SCM_THETA_MIN_PREC,
        DP_SCM_THETA_MAX_PREC,
        DP_SCM_LIM_R_PREC,
        DP_SCM_LIM_A_PREC,
        DP_SCM_LIM_I_PREC,
        DP_SCM_RATE_DZ_PREC,
        DP_SCM_OMG_NLP_PREC,
        DP_SCM_ZETA_NLP_PREC,
        DP_SCM_ALPHA_PREC,
        DP_SCM_DELTA_PREC,
        DP_SCM_OMG_RFF_PREC,
        DP_SCM_N_PREC,
        DP_SCM_KPL_PREC,
        DP_SCM_KDL_PREC,
        DP_SCM_KPM_PREC,
        DP_SCM_KDM_PREC,
        DP_SCM_WL_PREC,
        DP_SCM_WM_PREC,
        DP_SCM_OMG_1_PREC,
        DP_SCM_OMG_2_PREC,
        DP_SCM_OMG_LP_PREC,
        DP_SCM_CURR_P_GAIN_PREC,
        DP_SCM_CURR_I_GAIN_PREC
    };

    QString qstrErrMsg = QString();
    QString qstrTemp = QString();
    QCheckBox *pcbCheckbox;
    QDoubleSpinBox *pdsbDSB;
    U_DEM_PORT_TX UTxCommand = { 0 };
    U_DEM_PORT_RX URxResponse = { 0 };

    long lConstant = 0;
    unsigned char ucChecksum = 0;
    unsigned char ucErrCount = DPSCM_INIT_0;

    for (ucLoop = DPSCM_INIT_0; ucLoop < CLC_TOTAL_NO_OF_PARAMETERS; ucLoop++)
    {
        pcbCheckbox = (QCheckBox *)m_liCheckbox.at(ucLoop);
        pdsbDSB = (QDoubleSpinBox *)m_liDSB.at(ucLoop);

        if (pcbCheckbox->isChecked())
        {
            dData = pdsbDSB->value();

            memset (&UTxCommand, 0, sizeof(U_DEM_PORT_TX));
            memset (&URxResponse, 0, sizeof(U_DEM_PORT_RX));

            lConstant = dData / darrResolution[ucLoop];

            UTxCommand.m_S_DiagCmd.m_ucByte0_Bit6_0 = 0;
            UTxCommand.m_S_DiagCmd.m_ucByte0_Bit7 = 1;

            UTxCommand.m_S_DiagCmd.m_ucByte1_CmdID = CMDID_CLCCONFIG_UPDATE & 0x1F;
            UTxCommand.m_S_DiagCmd.m_ucByte1_TestInit = DPSCM_INIT_0;
            UTxCommand.m_S_DiagCmd.m_ucByte1_Bit7 = DPSCM_INIT_0;

            UTxCommand.m_S_DiagCmd.m_ucByte2_Bit6_0 = (ucLoop) & 0x7F;
            UTxCommand.m_S_DiagCmd.m_ucByte2_Bit7 = DPSCM_INIT_0;

            UTxCommand.m_S_DiagCmd.m_ucByte3_Bit6_0 = (lConstant >> 21) & 0x7F;
            UTxCommand.m_S_DiagCmd.m_ucByte3_Bit7 = DPSCM_INIT_0;

            UTxCommand.m_S_DiagCmd.m_ucByte4_Bit6_0 = (lConstant >> 14) & 0x7F;
            UTxCommand.m_S_DiagCmd.m_ucByte4_Bit7 = DPSCM_INIT_0;

            UTxCommand.m_S_DiagCmd.m_ucByte5_Bit6_0 = (lConstant >> 7) & 0x7F;
            UTxCommand.m_S_DiagCmd.m_ucByte5_Bit7 = DPSCM_INIT_0;

            UTxCommand.m_S_DiagCmd.m_ucByte6_Bit6_0 = lConstant & 0x7F;
            UTxCommand.m_S_DiagCmd.m_ucByte6_Bit7 = DPSCM_INIT_0;

            dp_scm_7bit_xor_checksum((unsigned char *)&UTxCommand.m_S_DiagCmd, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);
            UTxCommand.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;
            UTxCommand.m_S_DiagCmd.m_ucByte7_Bit7 = DPSCM_INIT_0;

            iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *)UTxCommand.m_arrucData, sizeof(S_DIAG_CMDRESP));
            if (iRetVal != DPSCM_SUCCESS)
            {
                g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
                qstrTemp.sprintf("Error Send Command : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
                emit sig_updateActionLog(qstrTemp, LOG_ERROR);
                ucErrCount++;
                continue;
            }

            iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_DIAG_CMDRESP), (char *) &URxResponse.m_S_DiagResp, &uiBytesRead, 300);
            if (iRetVal != DPSCM_INIT_0)
            {
                g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
                qstrTemp.sprintf("Error Receiving Response : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
                emit sig_updateActionLog(qstrTemp, LOG_ERROR);
                ucErrCount++;
                continue;
            }

            Delay(100000);  // 100ms === 100,000 micro seconds

            if (URxResponse.m_S_DiagResp.m_ucByte1_CmdID == (CMDID_CLCCONFIG_UPDATE & 0x1F))
            {
                if (URxResponse.m_S_DiagResp.m_ucByte2_Bit6_0 == (ucLoop & 0x1F))
                {
                    qstrTemp.sprintf("Control Loop Constant Updated Successfully");
                }
                else
                {
                    qstrTemp.sprintf("Invalid Constant ID Received");
                }
            }
            else
            {
                qstrTemp.sprintf("Invalid Command ID Received");
            }

            if (qstrTemp.contains("Invalid"))
            {
                qstrErrMsg.sprintf("Error Updating %s : %s", CONV_QSTR_TO_SZ(pcbCheckbox->text()), CONV_QSTR_TO_SZ(qstrTemp));
                ucErrCount++;
                emit sig_updateActionLog(qstrErrMsg, LOG_ERROR);
            }
            else
            {
                // Do nothing
            }
        }
    }

    emit sig_threadCompleted();
    if (ucErrCount == DPSCM_INIT_0)
    {
        emit sig_updateActionLog("Control loop constant values updated successfully", LOG_SUCCESS);
    }
    else
    {
        // Do nothing
    }
}

void CControlLoopConfigThread::readEEPROM()
{
    unsigned char ucLoop = DPSCM_INIT_0;
    int iRetVal = DPSCM_INIT_0;
    unsigned int uiBytesRead = DPSCM_INIT_0;
    QString qstrTemp = QString();
    QString qstrErrMsg = QString();
    QCheckBox *pcbCheckbox;
    QDoubleSpinBox *pdsbDSB;
    U_DEM_PORT_TX UTxCommand = { 0 };
    U_DEM_PORT_RX URxResponse = { 0 };
    double darrResolution[CLC_TOTAL_NO_OF_PARAMETERS] = {
        DP_SCM_CONFIG_ST,
        DP_SCM_EN_ENDSTOP,
        DP_SCM_EN_NLP,
        DP_SCM_EN_RFF,
        DP_SCM_EN_LAG,
        DP_SCM_THETA_MIN_PREC,
        DP_SCM_THETA_MAX_PREC,
        DP_SCM_LIM_R_PREC,
        DP_SCM_LIM_A_PREC,
        DP_SCM_LIM_I_PREC,
        DP_SCM_RATE_DZ_PREC,
        DP_SCM_OMG_NLP_PREC,
        DP_SCM_ZETA_NLP_PREC,
        DP_SCM_ALPHA_PREC,
        DP_SCM_DELTA_PREC,
        DP_SCM_OMG_RFF_PREC,
        DP_SCM_N_PREC,
        DP_SCM_KPL_PREC,
        DP_SCM_KDL_PREC,
        DP_SCM_KPM_PREC,
        DP_SCM_KDM_PREC,
        DP_SCM_WL_PREC,
        DP_SCM_WM_PREC,
        DP_SCM_OMG_1_PREC,
        DP_SCM_OMG_2_PREC,
        DP_SCM_OMG_LP_PREC,
        DP_SCM_CURR_P_GAIN_PREC,
        DP_SCM_CURR_I_GAIN_PREC
    };

    unsigned char ucChecksum = DPSCM_INIT_0;
    unsigned char ucErrCount = DPSCM_INIT_0;
    long ulData = DPSCM_INIT_0;
    float fData = 0.0f;

    for (ucLoop = DPSCM_INIT_0; ucLoop < CLC_TOTAL_NO_OF_PARAMETERS; ucLoop++)
    {
        pcbCheckbox = (QCheckBox *)m_liCheckbox.at (ucLoop);
        pdsbDSB = (QDoubleSpinBox *)m_liDSB.at (ucLoop);

        if (pcbCheckbox->isChecked())
        {
            memset (&URxResponse, 0, sizeof(U_DEM_PORT_RX));
            memset (&UTxCommand, 0, sizeof(U_DEM_PORT_TX));

            UTxCommand.m_S_DiagCmd.m_ucByte0_Bit6_0 = 0;
            UTxCommand.m_S_DiagCmd.m_ucByte0_Bit7 = 1;
            UTxCommand.m_S_DiagCmd.m_ucByte1_CmdID = CMDID_CLCCONFIG_READ & 0x1F;
            UTxCommand.m_S_DiagCmd.m_ucByte2_Bit6_0 = (ucLoop & 0x7F);
            iRetVal = dp_scm_7bit_xor_checksum((unsigned char *)&UTxCommand.m_S_DiagCmd, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);
            UTxCommand.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;

            iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *)UTxCommand.m_arrucData, sizeof(S_DIAG_CMDRESP));
            if (iRetVal != DPSCM_SUCCESS)
            {
                g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
                qstrTemp.sprintf("Error Send Command : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
                emit sig_updateActionLog(qstrTemp, LOG_ERROR);
                ucErrCount++;
                continue;
            }

            iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_DIAG_CMDRESP), (char *) &URxResponse.m_S_DiagResp, &uiBytesRead, 200);
            if (iRetVal != DPSCM_INIT_0)
            {
                g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
                qstrTemp.sprintf("Error Receiving Response : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
                ucErrCount++;
                emit sig_updateActionLog(qstrTemp, LOG_ERROR);
            }

            if (iRetVal == DPSCM_SUCCESS)
            {
                if (URxResponse.m_S_DiagResp.m_ucByte1_CmdID == (CMDID_CLCCONFIG_READ & 0x1F))
                {
                    if (URxResponse.m_S_DiagResp.m_ucByte2_Bit6_0 == (ucLoop & 0x1F))
                    {
                        // Do nothing
                    }
                    else
                    {
                        qstrTemp.sprintf("Invalid Constant ID Received");
                    }
                }
                else
                {
                    qstrTemp.sprintf("Invalid Command ID Received");
                }
            }

            ulData = URxResponse.m_S_DiagResp.m_ucByte3_Bit6_0 << 21;

            ulData |= URxResponse.m_S_DiagResp.m_ucByte4_Bit6_0 << 14;

            ulData |= URxResponse.m_S_DiagResp.m_ucByte5_Bit6_0 << 7;
            URxResponse.m_S_DiagResp.m_ucByte5_Bit7 = DPSCM_INIT_0;

            ulData |= URxResponse.m_S_DiagResp.m_ucByte6_Bit6_0;

            if (ucLoop == CLC_MINIMUM_ENDSTOP || ucLoop == CLC_MAXIMUM_ENDSTOP)
            {
                if ((URxResponse.m_S_DiagResp.m_ucByte3_Bit6_0 & 0x40) != 0x00)
                {
                    ulData |= 0xF0000000;
                }
            }

            ucChecksum = URxResponse.m_S_DiagResp.m_ucByte7_Crc_Xor_CS;

            fData = ulData * darrResolution[ucLoop];

            pdsbDSB->setValue (fData);

            if (qstrTemp.contains("Invalid"))
            {
                qstrErrMsg.sprintf("Error Reading Control Loop Constant : %s", CONV_QSTR_TO_SZ(qstrTemp));
                ucErrCount++;
                emit sig_updateActionLog(qstrErrMsg, LOG_ERROR);
            }
            else
            {
                // Do nothing
            }
        }
    }

    emit sig_threadCompleted();
    if (ucErrCount == DPSCM_INIT_0)
    {
        emit sig_updateActionLog("Control Loop Constant Read Successfully", LOG_SUCCESS);
    }
    else
    {
        // Do nothing
    }
}

/*******************************************************************************
 * Name					: on_pbWriteEEPROM_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To write values to EEPROM
 ***************************************************************************//**
 * @brief	This function is used to write the configured data to EEPROM
 *		This function is called when Write Button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CControlLoopConfig::on_pbWriteEEPROM_clicked()
{
    CHECK_TC_RUNNING;
    CHECK_PORT_OPEN(DIAGNOSTIC_PORT_IDX);
    if (g_SGlobal.m_ucConfiguredMode != DIAGNOSTICS_MODE)
    {
        DISPLAY_MESSAGE_BOX(this, "Mode Configuration", "Please switch to Diagnostics Mode to Write EEPROM Constants");
        return;
    }

    emit sig_showLoadingScreen(true);
    m_pthControlLoopConfig->setOperation(CLCTHREAD_MODE_WRITE);
    m_pthControlLoopConfig->Start();
}

/*******************************************************************************
 * Name					: on_pbLoadFile_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To load values from config file
 ***************************************************************************//**
 * @brief	This function is used to load constant values from the selected file (.bin)
 *		This function is called when Load button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CControlLoopConfig::on_pbLoadFile_clicked()
{
    QString qstrFile = QString("");
    int iRetval = DPSCM_INIT_0;

#ifndef _BIN_FILE_
    qstrFile = QFileDialog::getOpenFileName(this, "Control Loop Configuration", CONFIG_FILE_DIR, "CSV (*.csv)");
    if (qstrFile.isEmpty())
    {
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Please select a CSV file to load constant values");
        return;
    }
#else
    qstrFile = QFileDialog::getOpenFileName(this, "Control Loop Configuration", CONFIG_FILE_DIR, "Binary File (*.bin)");

    if (qstrFile.isEmpty())
    {
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Please select a Binary file to load constant values");
        return;
    }
#endif

    iRetval = readConfigFile(qstrFile);
    if (iRetval != DPSCM_SUCCESS)
    {
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Error while reading Control Loop constants configuration file");
        return;
    }

    setConfigValues();
}

/*******************************************************************************
 * Name					: on_pbSaveFile_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To save constant values to config file
 ***************************************************************************//**
 * @brief	This function is used to save constant values in selected file (.bin)
 *		This function is called when Save button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CControlLoopConfig::on_pbSaveFile_clicked()
{
    QString qstrMsg = QString("");
    QString qstrFile = QString("");
    int iRetval = DPSCM_INIT_0;

#ifndef _BIN_FILE_
    qstrFile = QFileDialog::getSaveFileName(this, "Control Loop Configuration", CONFIG_FILE_DIR, "CSV (*.csv)");;
    if (qstrFile.isEmpty())
    {
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Please choose a CSV file to save constant values");
        return;
    }
#else
    qstrFile = QFileDialog::getSaveFileName(this, "Control Loop Configuration", CONFIG_FILE_DIR, "Binary File (*.bin)");

    if (qstrFile.isEmpty())
    {
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Please choose a Binary file to save constant values");
        return;
    }
#endif
    getConfigValues();
    qDebug() << "2. " << m_SCtrlLoopConfig.m_dCurrIGain;

    iRetval = writeConfigFile(qstrFile);
    if (iRetval == DPSCM_SUCCESS)
    {
        qstrMsg.sprintf("Control loop constant values saved in the file : <a href=\"file:///%s\">%s</a>", \
                        qstrFile.toStdString().c_str(), qstrFile.toStdString().c_str());
        emit sig_updateActionLog(qstrMsg, LOG_INFO);
        DISPLAY_MESSAGE_BOX(this, "Control Loop Configuration", "Constant values saved in file");
    }
}

void CControlLoopConfig::on_cbSelectAll_clicked()
{
    unsigned char ucLoop = DPSCM_INIT_0;
    bool bIsChecked = false;

    if (ui->cbSelectAll->checkState () == Qt::PartiallyChecked)
    {
        ui->cbSelectAll->setCheckState (Qt::Checked);
    }

    bIsChecked = ui->cbSelectAll->isChecked ();

    for (ucLoop = DPSCM_INIT_0; ucLoop < CLC_TOTAL_NO_OF_PARAMETERS; ucLoop++)
    {
        m_liCheckbox.at (ucLoop)->setChecked (bIsChecked);
    }
}
