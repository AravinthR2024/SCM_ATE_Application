/**
* \file dp-scm-scmoperation.h
* \brief This file contains the code for SCM Servo Control Operation panel
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-scmoperation.h"
#include "ui_dp-scm-scmoperation.h"
#include "dp-scm-mainwindow.h"

extern S_GLOBAL g_SGlobal;
SDPPCI755_CONFIG  g_ScfgData[SCM_ATE_MAX_PCI755_BRDS];

/*******************************************************************************
 * Name					: CSCMOperation
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CSCMOperation class
 *
 * @param[in]	parent	Holds the reference of the parent
 *
 * @return	NA
 ******************************************************************************/
CSCMOperation::CSCMOperation(QWidget *parent) :
	QWidget(parent),
	ui(new Ui::CSCMOperation)
{
	ui->setupUi(this);

    qRegisterMetaType<S_SERVO_MODE_TEST>("S_SERVO_MODE_TEST");

    m_bCloseLoopEnable = false;
	m_iSelectedMode = SERVO_MODE;
	m_iSelectedTestcase = E_TC_SERVO_MODE;
    m_iSelectedWaveform = E_WAVEINP_SINE;
	m_qstrLogfile = QString("");
	m_qstrDataFileName = QString("");
    m_ucSelectedPage = MOTORCONTROL_PAGE_TESTCASE;

    m_bIsConfigured = false;
    m_ucTestStart_CMD_ID = DPSCM_INIT_0;
    m_ucScansCompleted = DPSCM_INIT_0;
    m_uiCurrIdx = DPSCM_INIT_0;

    m_qtServo = new QTimer();
    m_qtDiagnostic = new QTimer();

    ui->pbTC_Collapse->setShortcut(QKeySequence(Qt::ALT + Qt::Key_Left));

    connect(m_qtServo, &QTimer::timeout, this, &CSCMOperation::slot_getServoModeCommand, Qt::AutoConnection);
    connect(m_qtDiagnostic, &QTimer::timeout, this, &CSCMOperation::slot_getDiagnosticsModeCommand, Qt::AutoConnection);

    ui->pbStart->setEnabled(false); /* To disable start button before configure clicked */
    ui->stackTestConfig->setCurrentIndex(DDTEST_LARGE_ANGLE_SLEW);
    ui->pbTC_Collapse->setCursor(Qt::PointingHandCursor);
	ui->treewDiag_TestCases->setCursor(Qt::PointingHandCursor);
}

/*******************************************************************************
 * Name					: ~CSCMOperation
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief	This function is the destructor of CSCMOperation class
 *
 * @param		NA
 * @return	NA
 ******************************************************************************/
CSCMOperation::~CSCMOperation()
{
	delete ui;
}

/*******************************************************************************
 * Name					: initialize
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To initialize the page
 ***************************************************************************//**
 * @brief	This function is used to initialize default values and min max values
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CSCMOperation::initialize()
{
	m_qstrliTestCaseName << "Servo Mode Test" << "Diagnostics Mode Test" << "Closed Loop Test"\
                     << "Motor/Amp Test Mode" << "TFA Closed Loop Test"\
                     << "TFA Open Loop Test" << "Diagnostics Demand Mode";

	m_iarrGainValues[GAIN_1] = 1;
	m_iarrGainValues[GAIN_10] = 10;
	m_iarrGainValues[GAIN_100] = 100;
	m_iarrGainValues[GAIN_1000] = 1000;

	ui->stackConfigurations->setCurrentIndex(MOTOR_CTRL_ANALOG);
	ui->stackConfigurations->setCurrentIndex(MOTOR_CTRL_DIGITAL);

	/* Testcases initialization and configuration */
	ui->treewDiag_TestCases->setHeaderHidden(true);

    ui->treewDiag_TestCases->clear();
    m_item1 = new QTreeWidgetItem(ui->treewDiag_TestCases, QStringList() << m_qstrliTestCaseName.at (0));
    m_item2 = new QTreeWidgetItem(ui->treewDiag_TestCases, QStringList() << m_qstrliTestCaseName.at (1));
    m_item3 = new QTreeWidgetItem(ui->treewDiag_TestCases, QStringList() << m_qstrliTestCaseName.at (2));

    m_item21 = new QTreeWidgetItem(m_item2, QStringList() << m_qstrliTestCaseName.at (3));
    m_item22 = new QTreeWidgetItem(m_item2, QStringList() << m_qstrliTestCaseName.at (4));
    m_item23 = new QTreeWidgetItem(m_item2, QStringList() << m_qstrliTestCaseName.at (5));
    m_item24 = new QTreeWidgetItem(m_item2, QStringList() << m_qstrliTestCaseName.at (6));
    QList<QTreeWidgetItem *> itemList;
    itemList << m_item21 << m_item22 << m_item23 << m_item24;
    m_item2->addChildren(itemList);

    ui->treewDiag_TestCases->insertTopLevelItem(0, m_item1);
    ui->treewDiag_TestCases->insertTopLevelItem(1, m_item2);

    if (g_SGlobal.m_iUserPrivil == SUPER_USER)
    {
        ui->treewDiag_TestCases->insertTopLevelItem(2, m_item3);
    }

    ui->treewDiag_TestCases->setCurrentIndex(ui->treewDiag_TestCases->model()->index(0, 0));
}

short CSCMOperation::configureTestcaseInput()
{
    unsigned int uiLoop = DPSCM_INIT_0;
    double dStartAngle = 0.0;
    double dStopAngle = 0.0;
    double dRamp = 0.0;
    double dAmplitude = 0.0;
    double dTimePeriod = 0.0;
    double dHrSpread = 0.0;
    double dVrSpread = 0.0;
    double dTemp = 0.0;
    double dPts = 0.0;
    double dTime = 0.0;
    double dTime1 = 0.0;
    double dTime2 = 0.0;
    memset (&m_SServoTest, 0, sizeof(S_SERVO_MODE_TEST));

    m_arrdServoData.clear();
    m_SServoTest.m_uiTime_ms = 10;

    if (ui->rbTest_BidirScan->isChecked())  // Generate Trapezoidal Wave as command
    {
        g_SGlobal.m_ucNoofScans = ui->sbBidir_NoofScans->value();
        dStartAngle = ui->sbBidir_MinScanAngle->value();
        dStopAngle = ui->sbBidir_MaxScanAngle->value();
        dRamp = ui->sbBidir_ScanRate->value(); // deg/s
        dAmplitude = abs (dStartAngle) + abs (dStopAngle);
        dTimePeriod = (dAmplitude / ((dRamp / 1000.0) * m_SServoTest.m_uiTime_ms)) * 2;
        dHrSpread = 5.0;
        dVrSpread = 0.0;
        g_SGlobal.m_uiServoDataCount = dTimePeriod * 2;
        m_SServoTest.m_ucMode = DP_SCM_POS_MODE;

        /* Generating Trapezoidal Wave */
        for (uiLoop = DPSCM_INIT_0; uiLoop < g_SGlobal.m_uiServoDataCount; uiLoop++)
        {
            dPts = uiLoop;
            dTemp = dAmplitude / M_PI * (acos (cos ((M_PI / dTimePeriod) * dPts + dHrSpread)) + asin (sin ((M_PI / dTimePeriod) * dPts + dHrSpread))) - dAmplitude / 2 + dVrSpread;
            m_arrdServoData.append(dTemp);
        }

        m_SServoTest.m_dAmplitude = dAmplitude / 2;
    }
    else if (ui->rbTest_AltScan->isChecked())   // Generate Square Wave as command
    {
        g_SGlobal.m_ucNoofScans = ui->sbAltScan_NoofScans->value();
        m_SServoTest.m_dAmplitude = ui->sbAltScan_Amplitude->value();
        dTime1 = ui->sbAltScan_Time->value();
        m_SServoTest.m_ucMode = DP_SCM_RATE_MODE;

        dAmplitude = m_SServoTest.m_dAmplitude;

        m_SServoTest.m_dFrequency = 1 / dTime1;
        dTime2 = dTime1 / 2;
        g_SGlobal.m_uiServoDataCount = ((dTime1 * 1000.0) / m_SServoTest.m_uiTime_ms) + 1;

        for (uiLoop = 0; uiLoop < g_SGlobal.m_uiServoDataCount; uiLoop++)
        {
            if(fmod(dTime, dTime1) < dTime2)
            {
                m_arrdServoData.append(dAmplitude);
            }
            else
            {
                m_arrdServoData.append(-1 * dAmplitude);
            }

            dTime += (m_SServoTest.m_uiTime_ms / 1000.0);
        }
    }
    else if (ui->rbTest_ContRateMode->isChecked() || ui->rbTest_LargeAngleSlew->isChecked())    // Generate a constant DC Wave as command
    {
        g_SGlobal.m_ucNoofScans = DPSCM_INIT_0;
        if (ui->rbTest_ContRateMode->isChecked())
        {
            m_SServoTest.m_ucMode = DP_SCM_RATE_MODE;
            dAmplitude = ui->sbContRate_RateDemand->value();
        }
        else
        {
            m_SServoTest.m_ucMode = DP_SCM_POS_MODE;
            dAmplitude = ui->sbLAS_Angle->value();
        }

        m_SServoTest.m_dAmplitude = dAmplitude;
        g_SGlobal.m_uiServoDataCount = 1;
        m_arrdServoData.append(dAmplitude);
    }
    else
    {
        DISPLAY_MESSAGE_BOX(this, "SCM Configuration", "Invalid Testcase Selected");
        return DPSCM_FAILURE;
    }

    return DPSCM_SUCCESS;
}

short CSCMOperation::configureFRAInput()
{
    U32BIT u32WaveformType = E_WAVEINP_SINE;
    S32BIT s32RetVal = DPSCM_INIT_0;
    FSINGLE fStartFreq = DPSCM_INIT_0;
    FSINGLE fStopFreq = DPSCM_INIT_0;
    FSINGLE fStepFreq = DPSCM_INIT_0;
    FSINGLE fAmplitude = DPSCM_INIT_0;
    FSINGLE fBias = DPSCM_INIT_0;
    U32BIT u32StartAngle = DPSCM_INIT_0;
    U32BIT u32StopAngle = DPSCM_INIT_0;
    U32BIT u32IntegrationTime = DPSCM_INIT_0;
    QString qstrTemp = QString();
    bool bStepFreqInLog = false;
    char szErrMsg[200] = { 0 };

    QDoubleSpinBox *pdsbStartFreq = NULL;
    QDoubleSpinBox *pdsbStopFreq = NULL;
    QDoubleSpinBox *pdsbStepFreq = NULL;
    QDoubleSpinBox *pdsbAmplitude = NULL;
    QDoubleSpinBox *pdsbBias = NULL;
    QSpinBox *psbIntegrationTime = NULL;
    QSpinBox *psbStartAngle = NULL;
    QSpinBox *psbStopAngle = NULL;
    QCheckBox *pcbStepFreqInLog = NULL;

    m_SFRAConfig.m_u32BoardNo = PCI_BRD_IDX;
    m_SFRAConfig.m_u32Mode = 1;
    m_SFRAConfig.m_u32WaveformType = DPSCM_INIT_0;
    m_SFRAConfig.m_fStartFreq = DPSCM_INIT_0;
    m_SFRAConfig.m_fEndFreq = DPSCM_INIT_0;
    m_SFRAConfig.m_fStepSize = DPSCM_INIT_0;
    m_SFRAConfig.m_fTime = DPSCM_INIT_0;
    m_SFRAConfig.m_fAmplitude = DPSCM_INIT_0;
    m_SFRAConfig.m_fOffset = DPSCM_INIT_0;
    m_SFRAConfig.m_fDelay = 0;
    m_SFRAConfig.m_u32NoOfCycles = DPSCM_INIT_0;
    m_SFRAConfig.m_u32GainIndex[FRA_ADC_1] = GAIN_1;
    m_SFRAConfig.m_u32GainIndex[FRA_ADC_2] = GAIN_1;
    m_SFRAConfig.m_u32StopAngle = DPSCM_INIT_0;
    m_SFRAConfig.m_u32StartAngle = DPSCM_INIT_0;
    m_SFRAConfig.m_bLog = false;
    m_SFRAConfig.m_bRMS = false;
    m_SFRAConfig.m_bDelayInSec = false;

    pdsbStartFreq = ui->dsbFRA_StartFreq;
    pdsbStopFreq = ui->dsbFRA_StopFreq;
    pdsbStepFreq = ui->dsbFRA_StepFreq;
    pdsbAmplitude = ui->dsbFRA_Amplitude;
    pdsbBias = ui->dsbFRA_Bias;
    psbIntegrationTime = ui->sbFRA_IntegrationTime;
    psbStartAngle = ui->sbFRA_StartAngle;
    psbStopAngle = ui->sbFRA_StopAngle;
    pcbStepFreqInLog = ui->cbFRA_StepFreqInLog;

    fStartFreq = pdsbStartFreq->value ();
    fStopFreq = pdsbStopFreq->value ();
    fStepFreq = pdsbStepFreq->value ();
    u32IntegrationTime = psbIntegrationTime->value ();
    u32StartAngle = psbStartAngle->value ();
    u32StopAngle = psbStopAngle->value ();
    bStepFreqInLog = pcbStepFreqInLog->isChecked ();
    fAmplitude = pdsbAmplitude->value();
    fBias = pdsbBias->value();

    if (u32IntegrationTime == DPSCM_INIT_0)
    {
        psbStopAngle->setValue (DPSCM_INIT_0);
        u32StopAngle = DPSCM_INIT_0;
    }

    if (((fBias + fAmplitude) * 1) > 10.0f)
    {
        DISPLAY_MESSAGE_BOX(this, "SCM Configuration", "Value of (Bias + Amplitude) should be Less than or Equal to 10V");
        pdsbBias->setFocus();
        return DPSCM_FAILURE;
    }
    else
    {
        m_SFRAConfig.m_fAmplitude = fAmplitude;
        m_SFRAConfig.m_fOffset = fBias;
    }

     u32WaveformType = ui->cmbFRA_WaveType->currentIndex ();
    if (u32WaveformType < E_WAVEINP_TOTAL_COUNT)
    {
        m_SFRAConfig.m_u32WaveformType = u32WaveformType;
    }
    else
    {
        DISPLAY_MESSAGE_BOX(this, "SCM Configuration", "Invalid Waveform Type selected");
        return DPSCM_FAILURE;
    }

    if ((fStartFreq < FRA_MIN_FREQUENCY) || (fStartFreq > FRA_MAX_FREQUENCY))
    {
        pdsbStartFreq->setFocus ();
        pdsbStartFreq->selectAll ();
        qstrTemp.sprintf ("Start Frequency value should be in range of %.4fHz and %.4fHz",\
                       FRA_MIN_FREQUENCY, FRA_MAX_FREQUENCY);
        DISPLAY_MESSAGE_BOX(this, "SCM Configuration", qstrTemp);
        return DPSCM_FAILURE;
    }
    else
    {
        m_SFRAConfig.m_fStartFreq = fStartFreq;
    }

    /* Check the start angle is Valid or Not */
    if ((u32StartAngle < FRA_MIN_ANGLE) || (u32StartAngle > FRA_MAX_ANGLE))
    {
        qstrTemp.sprintf ("Start Angle should be within the range of %d and %d (both inclusive)", FRA_MIN_ANGLE, FRA_MAX_ANGLE);
        psbStartAngle->setFocus ();
        psbStartAngle->selectAll ();
        DISPLAY_MESSAGE_BOX(this, "SCM Configuration", qstrTemp);
        return DPSCM_FAILURE;
    }

    /* Check the stop angle is valid or not */
    if ((u32StopAngle < FRA_MIN_ANGLE) || (u32StopAngle > FRA_MAX_ANGLE))
    {
        qstrTemp.sprintf ("Stop Angle should be within the range of %d and %d (both inclusive)", FRA_MIN_ANGLE, FRA_MAX_ANGLE);
        psbStartAngle->setFocus ();
        psbStartAngle->selectAll ();
        DISPLAY_MESSAGE_BOX(this, "SCM Configuration", qstrTemp);
        return DPSCM_FAILURE;
    }

    if (u32WaveformType == E_WAVEINP_SINE)
    {
        if ((fStopFreq < fStartFreq) || (fStopFreq > FRA_MAX_FREQUENCY))
        {
            pdsbStopFreq->setFocus ();
            pdsbStopFreq->selectAll ();
            qstrTemp.sprintf ("Stop Frequency for Sine wave should be within the range of %.4fHz and %.4fHz",\
                           fStartFreq, FRA_MAX_FREQUENCY);
            DISPLAY_MESSAGE_BOX(this, "SCM Configuration", qstrTemp);
            return DPSCM_FAILURE;
        }
        else
        {
            m_SFRAConfig.m_fEndFreq = fStopFreq;
        }

        if (((fStepFreq > (fStopFreq - fStartFreq)) && (fStartFreq != fStopFreq)) || fStepFreq < FRA_MIN_STEP_FREQ)
        {
            pdsbStepFreq->setFocus ();
            pdsbStepFreq->selectAll ();
            qstrTemp.sprintf ("Step Frequency should be between %.4fHz and difference between Start and Stop Frequency (%.4fHz)",\
                           FRA_MIN_STEP_FREQ, (fStopFreq - fStartFreq));
            DISPLAY_MESSAGE_BOX(this, "SCM Configuration", qstrTemp);
            return DPSCM_FAILURE;
        }
        if (((!bStepFreqInLog) && (((fStepFreq <= (fStopFreq - fStartFreq)) && (fStopFreq != fStartFreq) \
                                                    && (fStepFreq > 0.001f)) || ((fStopFreq == fStartFreq) && (fStepFreq == FRA_MIN_STEP_FREQ)))) || \
                 (bStepFreqInLog  && (((fStopFreq != fStartFreq) && ((fStopFreq) >= FRA_MIN_STEP_LOG)) \
                                                         || ((fStopFreq == fStartFreq) && (fStepFreq == FRA_MIN_STEP_LOG)))))
        {
            m_SFRAConfig.m_fStepSize = fStepFreq;
        }
        else
        {
            if (fStopFreq == fStartFreq)
            {
                DISPLAY_MESSAGE_BOX(this, "SCM Configuration", "Invalid Mode in Log Linear. Start and Stop Frequency cannot be same");
                pdsbStopFreq->setFocus ();
                pdsbStopFreq->selectAll ();
                return DPSCM_FAILURE;
            }

            if (bStepFreqInLog && (fStepFreq > (fStopFreq - fStartFreq)))
            {
                DISPLAY_MESSAGE_BOX(this, "SCM Configuration", "Invalid Points/Decades");
                pdsbStepFreq->setFocus ();
                pdsbStepFreq->selectAll ();
                return DPSCM_FAILURE;
            }

            if (bStepFreqInLog && (fStepFreq < FRA_MIN_STEP_LOG))
            {
                qstrTemp.sprintf ("Minimum Points/Decade is %.2f", FRA_MIN_STEP_LOG);
                DISPLAY_MESSAGE_BOX(this, "SCM Configuration", qstrTemp);
                pdsbStepFreq->setFocus ();
                pdsbStepFreq->selectAll ();
                return DPSCM_FAILURE;
            }
        }

        m_SFRAConfig.m_bLog = bStepFreqInLog;

        /* Validating Integration Time */
        if (((fStopFreq != fStartFreq) && (u32IntegrationTime > FRA_MIN_NO_OF_CYCLES) && (u32IntegrationTime <= FRA_MAX_NO_OF_CYCLES)) \
                || ((u32IntegrationTime >= FRA_MIN_NO_OF_CYCLES) && (fStopFreq == fStartFreq) && (u32IntegrationTime <= FRA_MAX_NO_OF_CYCLES)))
        {
            m_SFRAConfig.m_u32NoOfCycles = u32IntegrationTime;
        }
        else
        {
            if ((fStopFreq != fStartFreq) && ((u32IntegrationTime <= FRA_MIN_NO_OF_CYCLES) || (u32IntegrationTime > FRA_MAX_NO_OF_CYCLES)))
            {
                qstrTemp.sprintf ("Integration Time should be within the range of %d(excluded) and %d(included)", FRA_MIN_NO_OF_CYCLES, FRA_MAX_NO_OF_CYCLES);
            }
            else if ((fStopFreq == fStartFreq) && ((u32IntegrationTime < FRA_MIN_NO_OF_CYCLES) || (u32IntegrationTime > FRA_MAX_NO_OF_CYCLES)))
            {
                qstrTemp.sprintf ("Integration Time should be within the range of %d and %d (both inclusive)", FRA_MIN_NO_OF_CYCLES, FRA_MAX_NO_OF_CYCLES);
            }
            else
            {
                qstrTemp.sprintf ("Invalid Integration Time");
            }

            DISPLAY_MESSAGE_BOX(this, "SCM Configuration", qstrTemp);
            psbIntegrationTime->setFocus ();
            psbIntegrationTime->selectAll ();
            return DPSCM_FAILURE;
        }

        /* Validating Start and Stop Angle */
        if ((fStartFreq == fStopFreq) && (u32StartAngle > 0) && (u32StopAngle > 0))
        {
            psbStartAngle->setFocus ();
            psbStartAngle->selectAll ();
            DISPLAY_MESSAGE_BOX(this, "SCM Configuration", "Start and Stop Angles cannot be entered for Continuous Wave");
            return DPSCM_FAILURE;
        }
        else
        {
            m_SFRAConfig.m_u32StartAngle = u32StartAngle;
            m_SFRAConfig.m_u32StopAngle = u32StopAngle;
        }
    }	// Sinewave end
    else
    {
        if ((u32WaveformType == E_WAVEINP_SQUARE) && (u32IntegrationTime == 1) && (u32StartAngle == u32StopAngle) && (u32StartAngle > DPSCM_INIT_0))
        {
            psbStartAngle->setFocus ();
            psbStartAngle->selectAll ();
            DISPLAY_MESSAGE_BOX(this, "SCM Configuration", "Start and Stop Angle cannot be same for Single Cycle");
            return DPSCM_FAILURE;
        }
        else
        {
            m_SFRAConfig.m_u32StartAngle = u32StartAngle;
            m_SFRAConfig.m_u32StopAngle = u32StopAngle;
        }

        if (m_SFRAConfig.m_fStartFreq >= FRA_MIN_FREQUENCY && m_SFRAConfig.m_fStartFreq <= FRA_MAX_FREQUENCY)
        {
            m_SFRAConfig.m_fTime = m_SFRAConfig.m_fStartFreq;
        }

        if((u32IntegrationTime >= FRA_MIN_NO_OF_CYCLES) && (u32IntegrationTime <= FRA_MAX_NO_OF_CYCLES))
        {
            m_SFRAConfig.m_u32NoOfCycles = u32IntegrationTime;
        }
        else
        {
            qstrTemp.sprintf ("Integration Time should be within the range of %d and %d (both inclusive)", FRA_MIN_NO_OF_CYCLES, FRA_MAX_NO_OF_CYCLES);
            psbIntegrationTime->setFocus ();
            psbIntegrationTime->selectAll ();
            DISPLAY_MESSAGE_BOX(this, "SCM Configuration", qstrTemp);
            return DPSCM_FAILURE;
        }
    }

    s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_ConfigureWaveform(PCI_BRD_IDX, m_SFRAConfig);
    if (s32RetVal != DPPCI755_SUCCESS)
    {
        g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);
        qstrTemp.sprintf("Error configuring waveform : %s [ErrCode: %d]", szErrMsg, s32RetVal);
        emit sig_updateActionLog (qstrTemp, LOG_ERROR);
        DISPLAY_MESSAGE_BOX(this, "SCM Configuration", qstrTemp);
        return DPSCM_FAILURE;
    }

    s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_ConfigureAnaParameters(PCI_BRD_IDX, m_SFRAConfig);
    if (s32RetVal != DPPCI755_SUCCESS)
    {
        g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);
        qstrTemp.sprintf("Error configuring Analytical Parameters : %s [ErrCode: %d]", szErrMsg, s32RetVal);
        emit sig_updateActionLog (qstrTemp, LOG_ERROR);
        DISPLAY_MESSAGE_BOX(this, "SCM Configuration", qstrTemp);
        return DPSCM_FAILURE;
    }

    memcpy (&g_SGlobal.m_SFRAConfig, &m_SFRAConfig, sizeof(SDPPCI755_CONFIG));
    return DPSCM_SUCCESS;
}


void CSCMOperation::slot_changeButtonName(QString in_qstr)
{
    Q_UNUSED(in_qstr);

    on_pbStart_clicked();
}

void CSCMOperation::slot_stopAcq()
{
    g_SGlobal.g_u16CurrentDataReadFlg = false;
    m_pThAnaDataRead->g_u16AnalysedDataReadFlg = false;
    g_SGlobal.g_u16RawDataReadFlg[0] = false;
}

void CSCMOperation::slot_acqStart()
{
    int iRetVal = DPSCM_INIT_0;
    unsigned char ucChecksum = DPSCM_INIT_0;
    unsigned int uiBytesRead = DPSCM_INIT_0;
    QString qstrErrMsg = QString();
    QString qstrMsg = QString();
    U_DEM_PORT_TX UDiagCmd;
    U_DEM_PORT_RX UDiagResp;
    memset (&UDiagCmd, 0, sizeof(U_DEM_PORT_TX));
    memset (&UDiagResp, 0, sizeof(U_DEM_PORT_RX));


    if ((m_ucTestStart_CMD_ID != DPSCM_FAILURE) && (m_ucSelectedPage != MOTORCONTROL_PAGE_TESTCASE))
    {
        UDiagCmd.m_S_DiagCmd.m_ucByte0_Bit6_0 = DPSCM_INIT_0;
        UDiagCmd.m_S_DiagCmd.m_ucByte0_Bit7 = 1;

        UDiagCmd.m_S_DiagCmd.m_ucByte1_CmdID = m_ucTestStart_CMD_ID & 0x1F;
        UDiagCmd.m_S_DiagCmd.m_ucByte1_TestInit = 1;
        UDiagCmd.m_S_DiagCmd.m_ucByte1_ElorAz = DPSCM_INIT_0;
        UDiagCmd.m_S_DiagCmd.m_ucByte1_Bit7 = DPSCM_INIT_0;

        UDiagCmd.m_S_DiagCmd.m_ucByte2_Bit6_0 = DPSCM_INIT_0;
        UDiagCmd.m_S_DiagCmd.m_ucByte2_Bit7 = DPSCM_INIT_0;

        UDiagCmd.m_S_DiagCmd.m_ucByte3_Bit6_0 = DPSCM_INIT_0;
        UDiagCmd.m_S_DiagCmd.m_ucByte3_Bit7 = DPSCM_INIT_0;

        UDiagCmd.m_S_DiagCmd.m_ucByte4_Bit6_0 = DPSCM_INIT_0;
        UDiagCmd.m_S_DiagCmd.m_ucByte4_Bit7 = DPSCM_INIT_0;

        UDiagCmd.m_S_DiagCmd.m_ucByte5_Bit6_0 = DPSCM_INIT_0;
        UDiagCmd.m_S_DiagCmd.m_ucByte5_Bit7 = DPSCM_INIT_0;

        UDiagCmd.m_S_DiagCmd.m_ucByte6_Bit6_0 = DPSCM_INIT_0;
        UDiagCmd.m_S_DiagCmd.m_ucByte6_Bit7 = DPSCM_INIT_0;

        dp_scm_7bit_xor_checksum((unsigned char *)&UDiagCmd.m_S_DiagCmd, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);
        UDiagCmd.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;
        UDiagCmd.m_S_DiagCmd.m_ucByte7_Bit7 = DPSCM_INIT_0;

#ifndef _TESTING_FRA_
        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *) UDiagCmd.m_arrucData, sizeof(S_DIAG_CMDRESP));
        if (iRetVal != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrMsg.sprintf("Error starting Test : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrMsg, LOG_ERROR);
            return;
        }

        /** Temp Commanded */
        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData(sizeof(S_DIAG_CMDRESP), \
                                                                                 (char *) &UDiagResp.m_S_DiagResp, &uiBytesRead, 2);
        if (iRetVal != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrMsg.sprintf("Error starting Test : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrMsg, LOG_ERROR);
            return;
        }
#endif
    }
}

unsigned int CSCMOperation::startFRAAcquisitionThread()
{
    QString qstrFileText = "";

    /*If file name is null then store the data in default file name*/
    if(m_qstrDataFileName.isEmpty ())
    {
        qstrFileText.sprintf("%s", "TempDataFRA");
        m_qstrDataFileName = g_SGlobal.g_qstrAppPath + "/" + qstrFileText;
    }
    g_ScfgData[PCI_BRD_IDX].m_u32WaveformType = m_iSelectedWaveform;
    if (m_iSelectedWaveform == E_WAVEINP_SINE)
    {
        if(!m_qstrDataFileName.endsWith(".ana"))
        {
            g_SGlobal.m_qstrFRADataFile.sprintf("%s.ana", m_qstrDataFileName.toLatin1().data());
        }
        else
        {
            g_SGlobal.m_qstrFRADataFile = m_qstrDataFileName.toLatin1().data();
        }

        g_SGlobal.m_bIsAnaFlag = true;
    }
    else
    {
        if(!m_qstrDataFileName.endsWith(".raw"))
        {
            g_SGlobal.m_qstrFRADataFile.sprintf("%s.raw", m_qstrDataFileName.toLatin1().data());
        }
        else
        {
            g_SGlobal.m_qstrFRADataFile = m_qstrDataFileName.toLatin1().data();
        }

        g_SGlobal.m_bIsAnaFlag = false;
    }

    g_SGlobal.g_SRawDataThreadInfo[PCI_BRD_IDX].m_qFileName.clear();
    g_SGlobal.g_SRawDataThreadInfo[PCI_BRD_IDX].m_qFileName = m_qstrDataFileName;
    g_SGlobal.g_SRawDataThreadInfo[PCI_BRD_IDX].m_u16BoardNo = PCI_BRD_IDX;

    g_SGlobal.g_SthInfo[PCI_BRD_IDX].m_qFileName.clear();
    g_SGlobal.g_SthInfo[PCI_BRD_IDX].m_qFileName = m_qstrDataFileName;
    g_SGlobal.g_SthInfo[PCI_BRD_IDX].m_scfgData	= m_SFRAConfig;
    g_SGlobal.g_SthInfo[PCI_BRD_IDX].m_u16BoardNo = PCI_BRD_IDX;
    g_SGlobal.g_SthInfo[PCI_BRD_IDX].m_bStoreRawData = false;

    //start the read raw data thread
    if(g_ScfgData[PCI_BRD_IDX].m_u32WaveformType != E_WAVEINP_SINE)   // Temp Commented
    {
        g_SGlobal.g_SRawDataThreadInfo[PCI_BRD_IDX].m_u8semStartExitEvent = 1;
        g_SGlobal.g_u16RawDataReadFlg[PCI_BRD_IDX] = 1;

        m_pThReadRawDataFIFO->start(QThread::HighestPriority);
        return 0;
    }

    if(g_ScfgData[PCI_BRD_IDX].m_u32WaveformType == E_WAVEINP_SINE)
    {
        g_SGlobal.g_objPCI755.DPPCI755Wrap_ConfigureWaveform (PCI_BRD_IDX, g_ScfgData[PCI_BRD_IDX]);
        emit sig_updateActionLog("Starting FRA Output...", LOG_INFO);
    }

    g_SGlobal.g_SthInfo[PCI_BRD_IDX].m_u32semStopEvent = 0;

    g_SGlobal.g_u16CurrentDataReadFlg = 1;
    m_pThDataRead->start(QThread::LowestPriority);

    if(g_ScfgData[PCI_BRD_IDX].m_u32WaveformType == E_WAVEINP_SINE)
    {
        m_pThAnaDataRead->g_u16AnalysedDataReadFlg = 1;
        m_pThAnaDataRead->start(QThread::HighestPriority);
    }

    return DPPCI755_SUCCESS;
}

void CSCMOperation::slot_getServoModeCommand()
{
    U_DEM_PORT_TX U_cmd = { 0 };
    int iRetVal = 0;
    float fPos = DPSCM_INIT_0;
    short sAzCommand = 0;
    unsigned char ucChecksum = 0;

    fPos = m_arrdServoData[m_uiCurrIdx];
    m_uiCurrIdx++;
    if (m_uiCurrIdx == g_SGlobal.m_uiServoDataCount)
    {
        m_ucScansCompleted++;
        m_uiCurrIdx = 0;
    }

    memset (&U_cmd, 0, sizeof(U_DEM_PORT_TX));

    if (ui->rbTest_LargeAngleSlew->isChecked() || ui->rbTest_BidirScan->isChecked())
    {
        sAzCommand = (fPos * BIT_RESOLUTION_13BIT) / BIT_RESOLUTION_AZ_POS;
    }
    else
    {
        sAzCommand = (fPos * BIT_RESOLUTION_13BIT) / BIT_RESOLUTION_RATE;
    }

    U_cmd.m_S_RGACmd.m_ucByte0_MsgLength = sizeof(S_RGA_COMMAND) & 0x7F;
    U_cmd.m_S_RGACmd.m_ucByte0_Bit7 = 1;

    U_cmd.m_S_RGACmd.m_ucByte1_Spare = 0;
    U_cmd.m_S_RGACmd.m_ucByte1_StrParameters = 0;
    U_cmd.m_S_RGACmd.m_ucByte1_Bit7 = 0;

    U_cmd.m_S_RGACmd.m_ucByte2_AzCmd_12_7 = (sAzCommand >> 7) & 0x3F;
    U_cmd.m_S_RGACmd.m_ucByte2_AzModeSel = m_SServoTest.m_ucMode;
    U_cmd.m_S_RGACmd.m_ucByte2_Bit7 = 0;

    U_cmd.m_S_RGACmd.m_ucByte3_Spare = 0;
    U_cmd.m_S_RGACmd.m_ucByte3_CW_UpEndStop = 0;
    U_cmd.m_S_RGACmd.m_ucByte3_CCW_LowEndStop = 0;
    U_cmd.m_S_RGACmd.m_ucByte3_ArrayIdent = 0;
    U_cmd.m_S_RGACmd.m_ucByte3_Bit7 = 0;

    U_cmd.m_S_RGACmd.m_ucByte4_AzCmd_6_0 = sAzCommand & 0x7F;
    U_cmd.m_S_RGACmd.m_ucByte4_Bit7 = 0;

    U_cmd.m_S_RGACmd.m_ucByte5_DiagnosticsID = 1;
    U_cmd.m_S_RGACmd.m_ucByte5_Bit7 = 0;

    dp_scm_crc6_checksum((unsigned char *)&U_cmd.m_S_RGACmd, (sizeof(S_RGA_COMMAND) - 1), &ucChecksum);
    U_cmd.m_S_RGACmd.m_ucByte6_Crc6_CS = ucChecksum & 0x3F;
    U_cmd.m_S_RGACmd.m_ucByte6_FarEndCSErr = 0;
    U_cmd.m_S_RGACmd.m_ucByte6_Bit7 = 0;

    m_mutex.lock();
    iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_WriteData((char *) U_cmd.m_arrucData, sizeof(S_RGA_COMMAND));
    m_mutex.unlock();
    if (iRetVal != DPSCM_SUCCESS)
    {
        emit sig_updateActionLog("Command Send Failed", LOG_ERROR);
        return;
    }

    g_SGlobal.m_pobjCommandMsgQ->Send(&U_cmd, sizeof(U_DEM_PORT_TX));
    if (g_SGlobal.m_ucNoofScans != DPSCM_INIT_0)
    {
        if (m_ucScansCompleted == g_SGlobal.m_ucNoofScans)
        {
            on_pbStart_clicked();
            return;
        }
        else
        {
            // Do nothing
        }
    }
    else
    {
        // Do nothing
    }

    g_SGlobal.g_ulTime += m_SServoTest.m_uiTime_ms;
}

void CSCMOperation::slot_getDiagnosticsModeCommand()
{
    U_DEM_PORT_TX U_cmd = { 0 };
    int iRetVal = 0;
    float fPos = DPSCM_INIT_0;
    short sAzCommand = 0;
    unsigned char ucChecksum = 0;

    fPos = m_arrdServoData[m_uiCurrIdx];
    m_uiCurrIdx++;
    if (m_uiCurrIdx == g_SGlobal.m_uiServoDataCount)
    {
        m_ucScansCompleted++;
        m_uiCurrIdx = 0;
    }

    memset (&U_cmd, 0, sizeof(U_DEM_PORT_TX));

    if (ui->rbTest_LargeAngleSlew->isChecked() || ui->rbTest_BidirScan->isChecked())
    {
        sAzCommand = (fPos * BIT_RESOLUTION_14BIT) / BIT_RESOLUTION_AZ_POS;
    }
    else
    {
        sAzCommand = (fPos * BIT_RESOLUTION_14BIT) / BIT_RESOLUTION_RATE;
    }

    U_cmd.m_S_DiagCmd.m_ucByte0_Bit6_0 = 0;
    U_cmd.m_S_DiagCmd.m_ucByte0_Bit7 = 1;

#if 0
    if (ui->rbServo_Cmd_Pos->isChecked())
        U_cmd.m_S_DiagCmd.m_ucByte1_CmdID = 0x05;
    else
        U_cmd.m_S_DiagCmd.m_ucByte1_CmdID = 0x04;
#endif
    U_cmd.m_S_DiagCmd.m_ucByte1_CmdID = m_ucTestStart_CMD_ID;

    U_cmd.m_S_DiagCmd.m_ucByte1_TestInit = 0;
    U_cmd.m_S_DiagCmd.m_ucByte1_Bit7 = 0;

    U_cmd.m_S_DiagCmd.m_ucByte2_Bit6_0 = (sAzCommand >> 7) & 0x7F;  // MSB
    U_cmd.m_S_DiagCmd.m_ucByte2_Bit7 = 0;

    U_cmd.m_S_DiagCmd.m_ucByte3_Bit6_0 = sAzCommand & 0x7F; // LSB
    U_cmd.m_S_DiagCmd.m_ucByte3_Bit7 = 0;

    U_cmd.m_S_DiagCmd.m_ucByte4_Bit6_0 = 0;
    U_cmd.m_S_DiagCmd.m_ucByte4_Bit7 = 0;

    U_cmd.m_S_DiagCmd.m_ucByte5_Bit6_0 = 0;
    U_cmd.m_S_DiagCmd.m_ucByte5_Bit7 = 0;

    U_cmd.m_S_DiagCmd.m_ucByte6_Bit6_0 = 0;
    U_cmd.m_S_DiagCmd.m_ucByte6_Bit7 = 0;

    iRetVal = dp_scm_7bit_xor_checksum((unsigned char *) &U_cmd.m_S_DiagCmd, (sizeof(S_DIAG_CMDRESP) - 1), &ucChecksum);
    U_cmd.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;
    U_cmd.m_S_DiagCmd.m_ucByte7_Bit7 = 0;


    m_mutex.lock();
    iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *) U_cmd.m_arrucData, sizeof(S_DIAG_CMDRESP));
    m_mutex.unlock();
    if (iRetVal != DPSCM_SUCCESS)
    {
        emit sig_updateActionLog("Command Send Failed", LOG_ERROR);
        return;
    }

    g_SGlobal.m_objDiagCmdMsgQ->Send(&U_cmd, sizeof(U_DEM_PORT_TX));
    if (g_SGlobal.m_ucNoofScans != DPSCM_INIT_0)
    {
        if (m_ucScansCompleted == g_SGlobal.m_ucNoofScans)
        {
            on_pbStart_clicked();
            return;
        }
        else
        {
            // Do nothing
        }
    }
    else
    {
        // Do nothing
    }

    g_SGlobal.g_ulTime += m_SServoTest.m_uiTime_ms;
}

void CSCMOperation::on_pbConfigure_clicked ()
{
    short sRetval = DPSCM_SUCCESS;
    QString qstrTemp = QString();

#ifndef _TESTING_FRA_
    if (m_iSelectedMode != g_SGlobal.m_ucConfiguredMode)
    {
        qstrTemp.sprintf("Error configuring Test.\nPlease switch to %s Mode.", (m_iSelectedMode == DIAGNOSTICS_MODE) ? "Diagnostics" : "Servo");
        DISPLAY_MESSAGE_BOX(this, "Mode Configuration", qstrTemp);
        return;
    }
#endif

    if (m_ucSelectedPage == MOTORCONTROL_PAGE_TESTCASE)
    {
        sRetval = configureTestcaseInput();
        m_cSelectedGraph = GRAPHTYPE_VS_POSITION;

        if (ui->rbTest_AltScan->isChecked())
        {
            g_SGlobal.m_qstrSelectedTC = "diag_alt_scan";
            m_qstrTCName = "Alternating Scan";
        }
        else if (ui->rbTest_BidirScan->isChecked())
        {
            g_SGlobal.m_qstrSelectedTC = "diag_bidir_scan";
            m_qstrTCName = "Bidirectional Scan";
        }
        else if (ui->rbTest_ContRateMode->isChecked())
        {
            g_SGlobal.m_qstrSelectedTC = "diag_cont_rate_mode";
            m_qstrTCName = "Continuous Rate Mode";
        }
        else if (ui->rbTest_LargeAngleSlew->isChecked())
        {
            g_SGlobal.m_qstrSelectedTC = "diag_large_angle_slew";
            m_qstrTCName = "Large Angle Slew";
        }
        else
        {
            g_SGlobal.m_qstrSelectedTC = "diag_debug_data";
        }

        m_iXMin = DPSCM_INIT_0;
        m_iXMax = (60 * 1000);  // 1-Minute Data Range
        m_iYMin = (m_SServoTest.m_dAmplitude * -1) - (m_SServoTest.m_dAmplitude * 50 / 100);
        m_iYMax = (m_SServoTest.m_dAmplitude * 1) + (m_SServoTest.m_dAmplitude * 50 / 100);
        m_iY2Min = m_iYMin;
        m_iY2Max = m_iYMax;
    }
    else if (m_ucSelectedPage == MOTORCONTROL_PAGE_FRA)
    {
#ifndef _HIDE_PCI_
        sRetval = configureFRAInput();
#endif
        m_cSelectedGraph = GRAPHTYPE_GAIN_PHASE;
        m_iXMin = m_SFRAConfig.m_fStartFreq;
        m_iXMax = m_SFRAConfig.m_fEndFreq;
        m_iYMin = -20;
        m_iYMax = 20;
        m_iY2Min = -180;
        m_iY2Max = 180;

        m_qstrTCName = ui->treewDiag_TestCases->currentItem()->text(0);
    }
    else
    {
        m_bIsConfigured = false;
        ui->pbStart->setEnabled(false);
        DISPLAY_MESSAGE_BOX(this, "SCM Configuration", "Invalid Testcase Selected");
        return;
    }

    if (m_iSelectedTestcase == E_TC_MOTOR_AMP_TEST)
    {
        m_ucTestStart_CMD_ID = CMDID_MOTOR_AMP_TEST;
    }
    else if (m_iSelectedTestcase == E_TC_TFA_TEST_LOOP)
    {
        m_ucTestStart_CMD_ID = CMDID_TFA_TEST_LOOP_TEST;
    }
    else if (m_iSelectedTestcase == E_TC_TFA_TEST_PLANT)
    {
        m_ucTestStart_CMD_ID = CMDID_TFA_TEST_PLANT_TEST;
    }
    else if (m_iSelectedTestcase == E_TC_DIAG_DEM_MODE)
    {
        if (ui->rbTest_LargeAngleSlew->isChecked() || ui->rbTest_BidirScan->isChecked())
        {
            m_ucTestStart_CMD_ID = CMDID_DIAGDEM_POS;
        }
        else if (ui->rbTest_AltScan->isChecked() || ui->rbTest_ContRateMode->isChecked())
        {
            m_ucTestStart_CMD_ID = CMDID_DIAGDEM_RATE;
        }
        else
        {
            m_bIsConfigured = false;
            ui->pbStart->setEnabled(false);
            DISPLAY_MESSAGE_BOX(this, "SCM Configuration", "Invalid Testcase Selected");
            return;
        }
    }
    else if (m_iSelectedTestcase == E_TC_CLOSED_LOOP_TEST)
    {
            m_ucTestStart_CMD_ID = CMDID_CLOSED_POS;
    }
    else if (m_iSelectedTestcase == E_TC_SERVO_MODE)
    {
        m_ucTestStart_CMD_ID = DPSCM_FAILURE;
    }
    else
    {
        m_bIsConfigured = false;
        ui->pbStart->setEnabled(false);
        DISPLAY_MESSAGE_BOX(this, "SCM Configuration", "Invalid Testcase Selected");
        return;
    }

    if (sRetval != DPSCM_SUCCESS)
    {
        return;
    }
    else
    {
        m_bIsConfigured = true;
        ui->pbStart->setEnabled(true);
        emit sig_updateActionLog ("SCM Configuration Successful", LOG_SUCCESS);
    }

}

/*******************************************************************************
 * Name					: on_pbStart_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To start response monitoring
 ***************************************************************************//**
 * @brief	This function is used to start monitoring and change to Response Monitoring page
 *		This function is called when Start button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CSCMOperation::on_pbStart_clicked()
{
    bool bIsStart = false;
    unsigned char ucChecksum = DPSCM_INIT_0;
    unsigned int uiBytesRead = DPSCM_INIT_0;
    int iRetVal = DPSCM_INIT_0;
    QString qstrTemp = QString();
    QString m_qstrtempLogFileName = QString();
    QString qstrPath;
    QDir qLogDir;
    QString qstrTemp2 = QString();
    QString qstrErrMsg = QString();
    QString qstrMsg = QString();
    U_DEM_PORT_TX UDiagCmd;
    U_DEM_PORT_RX UDiagResp;
    memset (&UDiagCmd, 0, sizeof(U_DEM_PORT_TX));
    memset (&UDiagResp, 0, sizeof(U_DEM_PORT_RX));

    if (!m_bIsConfigured)
    {
        DISPLAY_MESSAGE_BOX(this, "SCM Configuration", "No Operation have been configured.\nPlease Configure a testcase to Start.");
        return;
    }
#ifndef _TESTING_FRA_
    if (m_iSelectedMode != g_SGlobal.m_ucConfiguredMode)
    {
        qstrTemp.sprintf("Error starting Test.\nPlease switch to %s Mode.", (m_iSelectedMode == DIAGNOSTICS_MODE) ? "Diagnostics" : "Servo");
        DISPLAY_MESSAGE_BOX(this, "SCM Configuration", qstrTemp);
        return;
    }
#endif

    if (ui->pbStart->text().compare("S&tart", Qt::CaseInsensitive) == DPSCM_SUCCESS)
    {
        bIsStart = true;
    }
    else if (ui->pbStart->text().compare("S&top", Qt::CaseInsensitive) == DPSCM_SUCCESS)
    {
        bIsStart = false;
    }
    else
    {
        return;
    }

    m_ucScansCompleted = DPSCM_INIT_0;

    if (bIsStart)
    {
        m_uiCurrIdx = 0;
        emit sig_clearGraph();
        emit sig_updateTestcaseDetails (m_iSelectedTestcase, m_cSelectedGraph, m_iXMin, m_iXMax, m_iYMin, m_iYMax, m_iY2Min, m_iY2Max);
        emit sig_enableGraphInteraction(false);
        g_SGlobal.m_qDemPortLogMsgQ->Clear();
        g_SGlobal.m_qDiagPortLogMsgQ->Clear();
        g_SGlobal.m_qDebugDataLogMsgQ->Clear();
        g_SGlobal.m_qActionLogMsgQ->Clear();

        if (m_ucSelectedPage == MOTORCONTROL_PAGE_FRA)
        {
#ifndef _HIDE_PCI_
            qstrPath = LOG_FRADATA_PATH;
            qLogDir.setPath(qstrPath);
            if (!qLogDir.exists())
            {
                qLogDir.mkpath(".");
            }

            if (g_SGlobal.m_qfFRALog.isOpen())
            {
                g_SGlobal.m_qfFRALog.close();
            }

            qstrTemp2 = "FRA_Log_%s.csv";
            LOGFNAME_SETFNAME(m_qstrtempLogFileName, CONV_QSTR_TO_SZ(qstrTemp2), qstrPath);
            g_SGlobal.m_qfFRALog.setFileName(m_qstrtempLogFileName);
            if (!g_SGlobal.m_qfFRALog.open(QIODevice::Append))
            {
                emit sig_updateActionLog("Error creating FRA Log file : " + g_SGlobal.m_qfFRALog.errorString(), LOG_WARNING);
            }
            else
            {
                qstrTemp.sprintf("Frequency(Hz),Gain(dB),Phase(deg)\n");
                g_SGlobal.m_qfFRALog.write(CONV_QSTR_TO_SZ(qstrTemp));
            }

            slot_startMonitoring();
            m_cSelectedGraph = GRAPHTYPE_GAIN_PHASE;
#endif
        }
        else if (m_ucSelectedPage == MOTORCONTROL_PAGE_TESTCASE)
        {
            m_cSelectedGraph = GRAPHTYPE_VS_POSITION;
            m_uiCurrIdx = 0;
            g_SGlobal.g_ulTime = 0;
            if (m_iSelectedTestcase == E_TC_SERVO_MODE)
            {
                m_qtServo->start(m_SServoTest.m_uiTime_ms);
                emit sig_startTest(true, SERVO_MODE);
            }
            else
            {
                m_qtDiagnostic->start(m_SServoTest.m_uiTime_ms);
                emit sig_startTest(true, DIAGNOSTICS_MODE);
            }
        }
        else
        {
            // Do nothing
        }

        /** Change button name only if every functions pass */
        ui->treewDiag_TestCases->setEnabled(false);
        ui->stackConfigurations->setEnabled(false);
        ui->pbConfigure->setEnabled(false);
        g_SGlobal.m_bSCM_Testcase_Running = true;
        ui->pbStart->setText("S&top");
        emit sig_changeButtonName("S&top");
        emit sig_changeTestcaseName(m_qstrTCName);
        emit sig_changePage(PAGE_RESPONSE_MONITORING);
    }
    else
    {
        g_SGlobal.m_qDemPortLogMsgQ->Clear();
        g_SGlobal.m_qDiagPortLogMsgQ->Clear();
        g_SGlobal.m_qDebugDataLogMsgQ->Clear();
        g_SGlobal.m_qActionLogMsgQ->Clear();
        if (m_ucSelectedPage != MOTORCONTROL_PAGE_TESTCASE)
        {
            UDiagCmd.m_S_DiagCmd.m_ucByte0_Bit6_0 = DPSCM_INIT_0;
            UDiagCmd.m_S_DiagCmd.m_ucByte0_Bit7 = 1;

            UDiagCmd.m_S_DiagCmd.m_ucByte1_CmdID = m_ucTestStart_CMD_ID & 0x1F;
            UDiagCmd.m_S_DiagCmd.m_ucByte1_TestInit = DPSCM_INIT_0;
            UDiagCmd.m_S_DiagCmd.m_ucByte1_ElorAz = DPSCM_INIT_0;
            UDiagCmd.m_S_DiagCmd.m_ucByte1_Bit7 = DPSCM_INIT_0;

            UDiagCmd.m_S_DiagCmd.m_ucByte2_Bit6_0 = DPSCM_INIT_0;
            UDiagCmd.m_S_DiagCmd.m_ucByte2_Bit7 = DPSCM_INIT_0;

            UDiagCmd.m_S_DiagCmd.m_ucByte3_Bit6_0 = DPSCM_INIT_0;
            UDiagCmd.m_S_DiagCmd.m_ucByte3_Bit7 = DPSCM_INIT_0;

            UDiagCmd.m_S_DiagCmd.m_ucByte4_Bit6_0 = DPSCM_INIT_0;
            UDiagCmd.m_S_DiagCmd.m_ucByte4_Bit7 = DPSCM_INIT_0;

            UDiagCmd.m_S_DiagCmd.m_ucByte5_Bit6_0 = DPSCM_INIT_0;
            UDiagCmd.m_S_DiagCmd.m_ucByte5_Bit7 = DPSCM_INIT_0;

            UDiagCmd.m_S_DiagCmd.m_ucByte6_Bit6_0 = DPSCM_INIT_0;
            UDiagCmd.m_S_DiagCmd.m_ucByte6_Bit7 = DPSCM_INIT_0;

            dp_scm_7bit_xor_checksum((unsigned char *)&UDiagCmd.m_S_DiagCmd, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);
            UDiagCmd.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;
            UDiagCmd.m_S_DiagCmd.m_ucByte7_Bit7 = DPSCM_INIT_0;
#ifndef _TESTING_FRA_
            iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *) UDiagCmd.m_arrucData, sizeof(S_DIAG_CMDRESP));
            if (iRetVal != DPSCM_SUCCESS)
            {
                g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
                qstrMsg.sprintf("Error starting Test : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
                emit sig_updateActionLog(qstrMsg, LOG_ERROR);
            }

            /** Temp Commanded */
            iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData(sizeof(S_DIAG_CMDRESP), \
                                                                                     (char *) &UDiagResp.m_S_DiagResp, &uiBytesRead, 2);
            if (iRetVal != DPSCM_SUCCESS)
            {
                g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
                qstrMsg.sprintf("Error starting Test : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
                emit sig_updateActionLog(qstrMsg, LOG_ERROR);
            }
#endif
        }
        emit sig_startTest(false, SERVO_MODE);
#ifndef _HIDE_PCI_
        g_SGlobal.m_qfFRALog.close();
        slot_stopAcq();
#endif
        emit sig_enableGraphInteraction(true);
        if (m_iSelectedTestcase == E_TC_SERVO_MODE)
        {
            m_qtServo->stop();
        }
        else
        {
            m_qtDiagnostic->stop();
        }
        /** Change button name only if every functions pass */
        ui->treewDiag_TestCases->setEnabled(true);
        ui->pbConfigure->setEnabled(true);
        ui->stackConfigurations->setEnabled(true);
        g_SGlobal.m_bSCM_Testcase_Running = false;
        ui->pbStart->setText("S&tart");
        emit sig_changeButtonName("S&tart");
    }
}

/*******************************************************************************
 * Name					: on_treeDiag_TestCases_currentItemChanged
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To select the test case
 ***************************************************************************//**
 * @brief	This function is used to change the selected testcase
 *
 * @param[in]	current	Specifies the current selected test case
 * @param[in]	previous	Specifies the previously selected test case
 *
 * @return	NIL
 ******************************************************************************/
void CSCMOperation::on_treewDiag_TestCases_currentItemChanged(QTreeWidgetItem *current, QTreeWidgetItem *previous)
{
	int iSelectedRow = ui->treewDiag_TestCases->currentIndex ().row ();
	if (!current || !previous)
	{
		return;
    }

	if (iSelectedRow == E_TC_DIAGNOSTICS_MODE && current->parent () == NULL)
	{
		ui->treewDiag_TestCases->expandAll ();
		return;
	}

	if (current->parent () != NULL)
	{
		iSelectedRow += 3;
	}

	if (iSelectedRow == E_TC_SERVO_MODE)
	{
		m_iSelectedMode = SERVO_MODE;
	}
	else
	{
		m_iSelectedMode = DIAGNOSTICS_MODE;
	}

	m_iSelectedTestcase = iSelectedRow;

	switch (m_iSelectedTestcase)
    {
    case E_TC_SERVO_MODE:
    {
        m_ucSelectedPage = MOTORCONTROL_PAGE_TESTCASE;
    } break;
    case E_TC_DIAGNOSTICS_MODE:
    {
        // No change
    } break;
    case E_TC_CLOSED_LOOP_TEST:
    {
        m_ucSelectedPage = MOTORCONTROL_PAGE_TESTCASE;
    } break;
    case E_TC_MOTOR_AMP_TEST:
    {
        m_ucSelectedPage = MOTORCONTROL_PAGE_FRA;
        ui->dsbFRA_StopFreq->setValue(2000);
        ui->sbFRA_IntegrationTime->setValue(20);
    } break;
    case E_TC_TFA_TEST_LOOP:
    {
        m_ucSelectedPage = MOTORCONTROL_PAGE_FRA;
        ui->dsbFRA_StopFreq->setValue(20);
        ui->sbFRA_IntegrationTime->setValue(10);
    } break;
    case E_TC_TFA_TEST_PLANT:
    {
        m_ucSelectedPage = MOTORCONTROL_PAGE_FRA;
        ui->dsbFRA_StopFreq->setValue(20);
        ui->sbFRA_IntegrationTime->setValue(10);
    } break;
    case E_TC_DIAG_DEM_MODE:
    {
        m_ucSelectedPage = MOTORCONTROL_PAGE_TESTCASE;
    } break;
    default:
    {
        emit sig_updateActionLog("Invalid Testcase Selected", LOG_ERROR);
        return;
    }
    }

    ui->stackConfigurations->setCurrentIndex (m_ucSelectedPage);
}

int CSCMOperation::slot_startMonitoring()
{
#ifdef _DPPCI755_DRV_ENABLE_
    if (g_SGlobal.m_DPPCI755Details.m_s8BoardSts != true)
    {
        DISPLAY_MESSAGE_BOX (this, "FRA", "FRA Board is not open.");
        return DPSCM_FAILURE;
    }
#endif

    startFRAAcquisitionThread ();

    emit sig_startOnlineGraphAcquisition();
    g_SGlobal.m_bIsGraphBeingPlotted = true;

    return DPSCM_SUCCESS;
}

void CSCMOperation::on_rbTest_LargeAngleSlew_toggled(bool checked)
{
    Q_UNUSED(checked);

    if (ui->rbTest_LargeAngleSlew->isChecked())
    {
        ui->stackTestConfig->setCurrentIndex(DDTEST_LARGE_ANGLE_SLEW);
        ui->sbLAS_Angle->setFocus();
    }
    else if (ui->rbTest_BidirScan->isChecked())
    {
        ui->stackTestConfig->setCurrentIndex(DDTEST_BIDIR_SCAN);
        ui->sbBidir_NoofScans->setFocus();
    }
    else if (ui->rbTest_AltScan->isChecked())
    {
        ui->stackTestConfig->setCurrentIndex(DDTEST_RATEMODE_ALT_SCAN);
        ui->sbAltScan_Amplitude->setFocus();
    }
    else if (ui->rbTest_ContRateMode->isChecked())
    {
        ui->stackTestConfig->setCurrentIndex(DDTEST_CONT_RATEMODE);
        ui->sbContRate_RateDemand->setFocus();
    }
    else
    {
        // Do nothing
    }
}

void CSCMOperation::on_rbTest_BidirScan_toggled(bool checked)
{
    on_rbTest_LargeAngleSlew_toggled(checked);
}

void CSCMOperation::on_rbTest_AltScan_toggled(bool checked)
{
    on_rbTest_LargeAngleSlew_toggled(checked);
}

void CSCMOperation::on_rbTest_ContRateMode_toggled(bool checked)
{
    on_rbTest_LargeAngleSlew_toggled(checked);
}

void CSCMOperation::on_cbFRA_StepFreqInLog_toggled(bool checked)
{
    if (checked)
    {
        ui->lbDisp_FRA_StepFreq->setText("&Points/Decade");
        ui->dsbFRA_StepFreq->setMinimum(FRA_MIN_STEP_FREQ);
    }
    else
    {
        ui->lbDisp_FRA_StepFreq->setText("Step Frequency (H&z)");
        ui->dsbFRA_StepFreq->setMinimum(FRA_MIN_FREQUENCY);
    }
}

void CSCMOperation::on_pbTC_Collapse_clicked()
{
    if (ui->frameTescaseSelection->isVisible())
    {
        ui->frameTescaseSelection->setHidden(true);
        ui->pbTC_Collapse->setIcon(QIcon(":/images/images/icon_right_arrow.png"));
        ui->pbTC_Collapse->setShortcut(QKeySequence(Qt::ALT + Qt::Key_Right));
    }
    else
    {
        ui->frameTescaseSelection->setHidden(false);
        ui->pbTC_Collapse->setIcon(QIcon(":/images/images/icon_left_arrow.png"));
        ui->pbTC_Collapse->setShortcut(QKeySequence(Qt::ALT + Qt::Key_Left));
        ui->treewDiag_TestCases->setFocus();
    }
}
