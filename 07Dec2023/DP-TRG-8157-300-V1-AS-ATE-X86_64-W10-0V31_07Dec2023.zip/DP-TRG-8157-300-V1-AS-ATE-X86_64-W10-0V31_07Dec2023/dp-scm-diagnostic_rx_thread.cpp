/**
* \file dp-scm-diagnostic_rx_thread.cpp
* \brief This file contains the code for Diagnostics reception thread
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-diagnostic_rx_thread.h"

extern S_GLOBAL g_SGlobal;

/*******************************************************************************
 * Name					: CDiagnosticRx
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CDiagnosticRx class
 *
 * @param[in]	parent	Holds the reference to the parent	(QObject*)
 * @param[in]	in_iTimeout	Holds the timeout value for reception	(int)
 *
 * @return	NA
 ******************************************************************************/
CDiagnosticRx::CDiagnosticRx(QObject *parent, int in_iTimeout) : QThread(parent)
{
	m_bRespRxSts = false;
    m_iTimeout = in_iTimeout;
}

void CDiagnosticRx::setMode(unsigned char in_ucMode)
{
    m_ucDiagMode = in_ucMode;
}

/*******************************************************************************
 * Name					: setTimeout
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set timout value
 ***************************************************************************//**
 * @brief	This function is used to set the Timeout values for reception
 *
 * @param[in]	in_iTimeout	Holds the timeout values (int)
 * @return
 ******************************************************************************/
void CDiagnosticRx::setTimeout(int in_iTimeout)
{
	m_iTimeout = in_iTimeout;
}

/*******************************************************************************
 * Name					: Start
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To start the thread
 ***************************************************************************//**
 * @brief	This function is used to start the DiagnosticRx thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CDiagnosticRx::Start()
{
	m_bRespRxSts = true;
    this->start(QThread::HighPriority);
}

/*******************************************************************************
 * Name					: Stop
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To stop the thread
 ***************************************************************************//**
 * @brief	This function is used to terminate the DiagnosticRx thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CDiagnosticRx::Stop()
{
	m_bRespRxSts = false;
	this->terminate();
}

/*******************************************************************************
 * Name					: run
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To execute the thread
 ***************************************************************************//**
 * @brief	This function contains the repeated execution of DiagnosticsRx thread
 *
 * @param
 * @return
 ******************************************************************************/
void CDiagnosticRx::run()
{
    int iRetval = DPSCM_SUCCESS;
    unsigned int uiReadBytes = DPSCM_SUCCESS;
    QString qstrErrMsg;
    U8BIT u8DiagId = DPSCM_INIT_0;
    U8BIT u8BITStatus = DPSCM_INIT_0;
    QString qstrTemp;
    U_DEM_PORT_RX USCM_DiagRx;
    S_DIAG_DATA_RESP SDiagInfo;
    unsigned short usCount = 0;
    unsigned char ucErr = 1;
    memset (&USCM_DiagRx, 0, sizeof(U_DEM_PORT_RX));
    memset (&SDiagInfo, 0, sizeof(S_DIAG_DATA_RESP));

    while (m_bRespRxSts)
    {
        if (m_ucDiagMode == DIAGRX_DIAG_DATA)
        {
            iRetval = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData(sizeof(S_DIAG_CMDRESP), (char *) &USCM_DiagRx.m_S_DiagResp, \
                                                                                     &uiReadBytes, 2);
            if (iRetval != DPSCM_SUCCESS)
            {
                ucErr++;
                if((ucErr%DP_SCM_ERRLOG_CNT) == 0)
                {
                    ucErr = 0;
                    g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetval, qstrErrMsg);
                    qstrTemp.sprintf("Error Reading Diagnostics Data : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetval);
                    emit sig_updateActionLog(qstrTemp, LOG_ERROR);
                }

                usleep(100);
                continue;
            }
            g_SGlobal.m_pobjDiagRespMsgQ->Send(&USCM_DiagRx, sizeof(U_DEM_PORT_RX));
            ucErr = 0;
            u8DiagId = USCM_DiagRx.m_S_DiagResp.m_ucByte2_Bit6_0 & 0x7F;
            u8BITStatus = USCM_DiagRx.m_S_DiagResp.m_ucByte2_Bit6_0 & 0x7F;
            usCount++;

            if((usCount%DP_SCM_BITSTS_CNT) == 0)
            {
                usCount = 0;
                emit sig_updateBITStatus(u8DiagId, u8BITStatus);
            }
        }
        else
        {
            iRetval = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData(sizeof(S_DIAG_DATA_RESP), (char *) &SDiagInfo, \
                                                                                     &uiReadBytes, 2);
            if (iRetval != DPSCM_SUCCESS)
            {
                ucErr++;
                if((ucErr%DP_SCM_ERRLOG_CNT) == 0)
                {
                    ucErr = 0;
                    g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetval, qstrErrMsg);
                    qstrTemp.sprintf("Error Reading Diagnostics Data : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetval);
                    emit sig_updateActionLog(qstrTemp, LOG_ERROR);
                }

                usleep(100);
                continue;
            }

            ucErr = 0;

            g_SGlobal.m_objDebugDataMsgQ->Send(&SDiagInfo, sizeof(S_DIAG_DATA_RESP));
        }
    }
}

