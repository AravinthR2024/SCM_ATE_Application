/**
 *	\file dppci755_err.h
 *	\brief This file contains the  error code definition
 *
 *	This file contains the  error code definition
 *
 *	\author sandadi.mahesh 
 *	\date 11:08AM on March 28, 2020
 *
 *	\version
 *	- Initial version
 *
 *	Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
 *	All Rights Reserved.\n
 *	Address:	Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
 *				Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
 *				Chennai-603103 | India\n
 *				Website : http://www.datapatternsindia.com/\n
 *				Phone: 91-44-4741-4000\n
 *				FAX: 91-44-4741-4444 \n
 *
	////////////////////////////REVISION LOG ENTRY//////////////////////////////////
	Date		Version Number	     Reason for Revision	Revised by 
	----		--------------		 -------------------	----------
									 

	 
*/
#ifndef _DPPCI755_ERR_H
#define _DPPCI755_ERR_H

#define DPPCI755_SUCCESS		0


/**
* This list the enumeration of driver error values 
*/ 
enum DPPCI755_ERROR_MACROS{
	DP_DRV_ERR_INVALID_HANDLE = -999,		/*!< (-999) 	Invalid Handle*/
	DP_DRV_ERR_INVALID_POINTER,			/*!< (-998) Invalid Pointer*/
	DP_DRV_ERR_INVALID_PARAM,			/*!< (-997) Invalid Param*/
	DP_DRV_ERR_MEM_ALLOCATION,			/*!< (-996) Mem Allocation*/
	DP_DRV_ERR_NO_ZEROTH_DEVICE,			/*!< (-995) No Zeroth Device*/
	DP_DRV_ERR_DEVICE_NOT_OPEN,			/*!< (-994) Device Is Not Open*/
	DP_DRV_ERR_INVALID_SHARE_VALUE,			/*!< (-993) Invalid Share Value*/
	DP_DRV_ERR_INVALID_DEVICE_REQUEST,			/*!< (-992) Invalid Device Request*/
	DPPCI755_ERR_INVALID_PARAM,			/*!< (-991) Invalid Param*/
	DPPCI755_ERR_DEVICE_BUSY,			/*!< (-990) Device Busy*/
	DPPCI755_ERR_NO_DEVICE_FOUND,			/*!< (-989) No Device Found*/
	DPPCI755_ERR_INVALID_BARNO,			/*!< (-988) Invalid Barno*/
	DPPCI755_ERR_INVALID_ENDIS,			/*!< (-987) Invalid Endis*/
	DPPCI755_ERR_INVALID_MSMODE,			/*!< (-986) Invalid Msmode*/
	DPPCI755_ERR_INVALID_BIAS,			/*!< (-985) Invalid Bias*/
	DPPCI755_ERR_INVALID_AMPUNIT,			/*!< (-984) Invalid Ampunit*/
	DPPCI755_ERR_INVALID_ADCCHANNELNO,			/*!< (-983) Invalid Adcchannelno*/
	DPPCI755_ERR_INVALID_GAIN,			/*!< (-982) Invalid Gain*/
	DPPCI755_ERR_INVALID_STARTFREQ,			/*!< (-981) Invalid Startfreq*/
	DPPCI755_ERR_INVALID_ENDFREQ,			/*!< (-980) Invalid Endfreq*/
	DPPCI755_ERR_INVALID_FREQUNIT,			/*!< (-979) Invalid Frequnit*/
	DPPCI755_ERR_INVALID_TIME,			/*!< (-978) Invalid Time*/
	DPPCI755_ERR_INVALID_NOOFCYCLE,			/*!< (-977) Invalid Noofcycle*/
	DPPCI755_ERR_INVALID_DELAY,			/*!< (-976) Invalid Delay*/
	DPPCI755_ERR_INVALID_DELAYTYPE,			/*!< (-975) Invalid Delaytype*/
	DPPCI755_ERR_INVALID_WAVEFORM,			/*!< (-974) Invalid Waveform*/
	DPPCI755_ERR_INVALID_STARTANGLE,			/*!< (-973) Invalid Startangle*/
	DPPCI755_ERR_INVALID_STOPANGLE,			/*!< (-972) Invalid Stopangle*/
	DPPCI755_ERR_INVALID_NOOFSEGMENTS,			/*!< (-971) Invalid Noofsegments*/
	DPPCI755_ERR_INVALID_CALIBRATIONMODE,			/*!< (-970) Invalid Calibrationmode*/
	DPPCI755_ERR_INVALID_CHANNELNO,			/*!< (-969) Invalid Channelno*/
	DPPCI755_ERR_INVALID_REFLVL,			/*!< (-968) Invalid Reflvl*/
	DPPCI755_ERR_INVALID_INPUTVOLTAGE,			/*!< (-967) Invalid Inputvoltage*/
	DPPCI755_ERR_INVALID_DACTYPE,			/*!< (-966) Invalid Dactype*/
	DPPCI755_ERR_INVALID_MEASVOLTAGE,			/*!< (-965) Invalid Measvoltage*/
	DPPCI755_ERR_INVALID_STATUS,			/*!< (-964) Invalid Status*/
	DPPCI755_ERR_INVALID_RELAYONOFF,			/*!< (-963) Invalid Relayonoff*/
	DPPCI755_ERR_INVALID_BIASVOLT,			/*!< (-962) Invalid Biasvolt*/
	DPPCI755_ERR_INVALID_REFVOLT,			/*!< (-961) Invalid Reference voltage*/
	DPPCI755_ERR_IN_CALIBRATION,			/*!< (-960) Calibration In Progress*/
	DPPCI755_ERR_BUFFER_NOT_FULL,		/*!< (-959) Buffer Not Full*/
	DPPCI755_ERR_SELFTEST,				/*!< (-958) Buffer Not Full*/
	DPPCI755_ERR_MODULE_BUSY,		/*!< (-957) Invalid Module Busy*/
	DPPCI755_ERR_INVALID_AMPLITUDE,				/*!< (-956) Invalid Amplitude */
	DPPCI755_ERR_INVALID_AMPLITUDE_BIAS_VOLT,	/*!< (-955) Invalid Amplitude Bias Voltage*/
	DPPCI755_ERR_INVALID_STEPSIZE,				/*!< (-954) Invalid step size*/
	DPPCI755_ERR_INVALID_REFVOLT_SEL,			/*!< (-953) Invalid Reference voltage selection*/
	DPPCI755_ERR_DATA_OVERFLOW,					/*!< (-952) Invalid Data Overflow*/
	DPPCI755_ERR_SWEEP_FINISH					/*!< (-951) Error in sweep*/
};
#endif