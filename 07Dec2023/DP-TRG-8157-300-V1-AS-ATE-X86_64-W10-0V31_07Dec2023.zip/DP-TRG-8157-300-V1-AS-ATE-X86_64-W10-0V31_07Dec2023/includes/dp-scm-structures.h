#ifndef DP_SCM_STRUCTURES
#define DP_SCM_STRUCTURES

#include <QFile>

#include "includes/dp_types.h"
#include "dp_qt_msgqueue.h"
#include "dppci755_wrapper.h"
#include "dprs232_wrapper.h"
#include "dpxmc5775wrapper.h"
#include "dp-scm-eeprom_rw.h"
#include "includes/dp-scm-macros.h"

#pragma pack(push, 1)
/************************** MODULE DETAIL **************************/
typedef struct  _S_MODULE_INFO
{
		char m_szBoardName[30];
		unsigned short m_usBusNo;
		unsigned short m_usSlotNo;
		unsigned short m_usFunctionNo;
		bool m_bIsDetected;
} S_MODULE_INFO, *PS_MODULE_INFO; // old

typedef struct  _SMODULE_LOC_DETAILS
{
		QString m_qstrBoardName;
		U8BIT m_u8BoardId;
		U8BIT m_u8BusNo;
		U8BIT m_u8SlotNo;
		U8BIT m_u8FunctionNo;
		U8BIT m_u8BoardStatus;
} SMODULE_LOC_DETAILS, *PSMODULE_LOC_DETAILS;

/************************** SYSTEM DETAILS *************************/
typedef struct  _S_SCM_SYSTEM_DETAILS
{
		float m_fSoftwareVersion;
		float m_fFirmwareVersion;
        unsigned int m_uiSystemVersion;
} S_SCM_SYSTEM_DETAILS, *PS_SCM_SYSTEM_DETAILS;

/******************** ENCODER CALIBRATION ********************/
typedef struct _S_POSFDBK_READ_CMD
{
		unsigned long m_ulPosFdbkReadCh;
} S_POSFDBK_READ_CMD, *PS_POSFDBK_READ_CMD;


typedef struct _S_POSFDBK_READ_CMD_ACK
{
		float m_fPosFdbkData;
} S_POSFDBK_READ_CMD_ACK, *PS_POSFDBK_READ_CMD_ACK;
/*************************************************************/

/************************** MOTOR CONTROL **************************/
typedef struct  _S_MOTOR_WAVE_INPUTS
{
		double m_dFrequency;        // In Hz
		double m_dTime;             // In sec
		double m_dAmplitude;        // In deg
		double m_dBias;             // In deg
		double m_dTimeInterval;     // In ms
		double m_dNoOfSamples;      // As count
		bool m_bRAMFlag;            // As True or False
		bool m_bSquareFlag;         // As True or False
} S_MOTOR_WAVE_INPUTS, *PS_SCM_MOTOR_WAVE_INPUTS;

/********** SOFTWARE PROGRAMMING FLASH (RS232) **********/
typedef struct
{
		unsigned short m_usAddress;
		unsigned short m_usData;

}S_FPGA_RW;


typedef struct
{
		unsigned short m_usAddress;
		unsigned char  m_ucData;
		unsigned char  m_Reserved;
}S_EEPROM_RW;

typedef struct
{
		unsigned char  m_ucReadChecksum;
		unsigned char  m_ucComputedChecksum;
		unsigned char  m_Reserved[2];
}S_EEPROM_CHECKSUM, *PS_EEPROM_CHECKSUM;


typedef struct
{
		unsigned short m_usStartAddress;
		unsigned short m_usNumberOfLocations;
		unsigned char  m_ucPattern;
		unsigned char  m_ucReserved[3];
}S_EEPROM_PATTERN_COUNTER, *PS_EEPROM_PATTERN_COUNTER;

typedef struct
{
		unsigned long m_ulAddress;
		unsigned long m_ulData;

}S_DSP_DDR3L_RW;

typedef struct
{
		unsigned short m_usAddress;

}S_EEPROM_READ_TX;

typedef struct
{
		unsigned short m_usData;                     //!<Specifies Data*/

}S_EEPROM_READ_RX;

// NVSRAM_DDR3L_Test
typedef struct
{
		unsigned long m_ulAddress;
		unsigned short m_usData;
		unsigned char m_ucReserved[2];

}S_NVSRAM_RW;

// QUADSPI_Test
typedef struct
{
		unsigned short m_usAddress;
		unsigned short m_usData;

}S_QUADSPI_RW;

/**
*	\struct S_QUADSPI_READ_TX
*	\brief  Specifies QUAD SPI Address and Data
*
*   This structure is used for QUAD SPI Read write operation to hold the address and data.
*/
typedef struct
{
		unsigned short m_usAddress;

}S_QUADSPI_READ_TX;

/**
*	\struct S_QUADSPI_READ_RX
*	\brief  Specifies QUAD SPI Address and Data
*
*   This structure is used for QUAD SPI Read write operation to hold the address and data.
*/
typedef struct
{
		unsigned short m_usData;                     //!<Specifies Data*/

}S_QUADSPI_READ_RX;

//DAC_MODULATOR_Test
typedef struct
{
		float m_fFrequency;
		float m_fPowerLevel;

}S_DAC_MODULATOR_TEST;

//TEMPERATURE_MONITORING_Test
typedef struct
{
		float m_fLocal;
		float m_fRemote;

}S_TEMP_MNTR_TEST;

//ELAPSED_TIME_RECORDER_Test
typedef struct
{
		unsigned long m_ulEventCount;                               //!< Holds ETR Event count value*/
		unsigned long m_ulSeconds;                              //!< Holds ETR Elapsed Time seconds*/
		unsigned long m_ulMinutes;                              //!< Holds ETR Elapsed Time MInutes*/
		unsigned long m_ulHours;                              //!< Holds ETR Elapsed Time Hours*/

}S_ETR_TEST;

//SIGNAL_PROCESSING_ADC_TEST
typedef struct
{
		unsigned long m_ulCurrentPacketCount;
		unsigned long m_ulTotalPacketCount;
		unsigned char m_uc_ADC_Data[SCM_ADC_BUFF_SLICE_LENGTH];
}S_SIG_PROC_RX_ADC;

typedef struct
{

		unsigned long m_ulChannel;
		unsigned long m_ulADCType;

}S_SIG_PROC_TX_ADC;

//RTC_TEST
typedef struct
{
		unsigned char m_ucSec;
		unsigned char m_ucMin;
		unsigned char m_ucHour;
		unsigned char m_ucDay;

		unsigned char m_ucDate;
		unsigned char m_ucMonth;
		unsigned short m_usYear;
}S_RTC_TEST;

//POWER_MONITORING_TEST
typedef struct
{
		float m_fCh1;
		float m_fCh2;
		float m_fCh3;
		float m_fCh4;

}S_PWR_MNTR_TEST;

typedef struct
{
		unsigned int uiSrcId;
		unsigned int uiDestId;
}S_ETHERNET_TEST;

//ARINC429 TX
typedef struct
{
		unsigned long m_ulParity						: 1;	/*!< Parity Bit*/
		unsigned long m_ulSSM							: 2;	/*!< Sign Status Matrix */
		unsigned long m_ulData							:19;	/*!< Data filed */
		unsigned long m_ulSDI							: 2;	/*!< ARINC 429 Source designation Identifier */
		unsigned long m_ulLabel				 			: 8;	/*!< ARINC 429 label number */

}S_ARINC429_WRDFORMAT;

typedef struct
{
		S_ARINC429_WRDFORMAT m_sARINC429TxWord;
		unsigned char m_ucTxChannelNum;
		unsigned char m_ucRxChannelNum;
		unsigned char m_ucTestType;
		unsigned char m_ucReserved;

}S_ARINC429_INTERFACE_TEST_TX;

typedef struct
{
		S_ARINC429_WRDFORMAT m_sARINC429RxWord;

}S_ARINC429_INTERFACE_TEST_RX;

//SCM_RS422_IO_MODE_CMD
typedef struct
{
		unsigned char m_ucIOGroup;
		unsigned char m_ucIOChannel;
		unsigned char m_ucMode;
		unsigned char m_ucData;

}S_IO_MODE_CMD_TX;

typedef struct
{

		unsigned char m_ucData;
		unsigned char m_ucReserved[3];

}S_IO_MODE_CMD_RX;

//LVTTL

typedef struct
{

		unsigned long m_ulPRT_ns;
		unsigned long m_POnTime_ns;
		unsigned long m_PulseCnt;
		unsigned char m_ucGrpNumber;
		unsigned char m_ucChannelNum;
		unsigned char m_ucReserved[2];

}S_LVTTL_PULSE_TX;

typedef struct
{
		unsigned long m_ulPRT_ns;
		unsigned long m_POnTime_ns;
		unsigned long m_PulseCnt;

}S_LVTTL_PULSE_RX;

//SCM_RS422_ADM_SEQUENCER_TEST_CMD
typedef struct
{
		float m_fChannel_1;
		float m_fChannel_2;
		float m_fChannel_3;
		float m_fChannel_4;
		float m_fChannel_5;
		float m_fChannel_6;
		float m_fChannel_7;
		float m_fChannel_8;
		float m_fChannel_9;
		float m_fChannel_10;
		float m_fAux_1;
		float m_fAux_2;

}S_ADM_SEQUENCER_TEST;

typedef struct
{
		unsigned char m_ucChannel;
		unsigned char m_ucDirection;
		unsigned short m_usDatacnt;

}S_LINK_PORT_TEST;

typedef struct
{
		unsigned short m_usAddress;
		unsigned short m_usData;

}S_RF_PLL;

typedef struct
{
		short sData;
		unsigned char ucTestType;
		unsigned char ucReserved;
		unsigned short usCurrentCount;
		unsigned short usTotalDataCnt;
}S_DAC_BLOCK_RAM_DATA;

typedef struct
{
		unsigned long ulFlashAddress;
		unsigned long ulDataCountToRead;

}S_FPGA_FLASH_DATA_READ_REQ;

typedef struct
{
		unsigned long ulFlashAddress;
		unsigned long ulDataCount;
		unsigned char ucFlashData[DP_SCM_FPGA_FLASH_SECTOR_ERASE_SIZE];

}S_FPGA_FLASH_DATA;

typedef struct
{
		unsigned short m_usIndexValue;
		unsigned long m_ulCurrentPacketCount;					//!< Holds the ADC current packet count*/
		unsigned long m_ulTotalPacketCount;						//!< Holds the total packet count*/
		unsigned char m_ucFFTData[SCM_FFT_BUFF_SLICE_LENGTH];

}S_FFT_DATA;

typedef struct
{
		unsigned int m_uiCycles;
		unsigned int m_uiDelayBwCycles;
		unsigned int m_uiDelayBwTestcases;
		unsigned int m_uiTestCseCnt;
		unsigned char m_ucTstslctArr[RS232_UART_BUFF_LEN];

}S_SCM_DIAG_TEST_CONFIG;

typedef union
{
		float m_fPow_Mon_CH_Volt[4];
		float m_fADM_Volt[12];
		float m_fTemperature[2];
		int  m_iResult;

}U_SCM_SELFTEST_DATA;

typedef struct
{
		U_SCM_SELFTEST_DATA  m_USCM_SelfTest_Data;

		int iRetVal;

}S_SCM_SELFTEST_DATA;

typedef struct
{
		unsigned char m_ucSucsCnt;
		unsigned char m_ucFailCnt;

}S_SCM_SUCS_FAIL_CNT;

typedef struct
{
		int iResult;

}S_SCM_DIAG_RESULT;

typedef struct
{
		unsigned char ucData;
}S_BOOT_LOAD;

typedef struct
{
		unsigned long ulStartAddress;
		unsigned long ulEndAddress;

}S_FPGAFULLMEM_TEST;

typedef struct
{
        unsigned short m_usSerialNumber;
        unsigned short m_usBoardID;
        unsigned char  m_ucReserved[3];
        unsigned char  m_ucChecksum;
}S_BOARD_INFO, *PS_BOARD_INFO;

typedef struct
{
		char m_arrcBoardID[12];
		char m_arrcBoardVersion[4];
		int m_iSerialNumber;
		int m_iFGNumber;
		unsigned int m_uiChecksum;
}S_EEPROM_BOARD_DETAILS;

typedef union
{
		S_PWR_MNTR_TEST m_PWR_MNTR_TEST;
		S_RTC_TEST m_RTC_TEST;
		S_SIG_PROC_TX_ADC m_SIG_PROC_ADC;
		S_ETR_TEST m_ETR_TEST;
		S_TEMP_MNTR_TEST m_TEMP_MNTR_TEST;
		S_DAC_MODULATOR_TEST m_DAC_MOD_TEST;
		S_QUADSPI_RW m_QUADSPI_RW;
		S_EEPROM_RW m_EEPROM_RW;
		S_DSP_DDR3L_RW m_DSPDDR3L_RW;
		S_QUADSPI_READ_TX m_QUADSPI_ReadTx;                          //!<Specifies structure holding Quad SPI Read Data*/
		S_FPGAFULLMEM_TEST  m_FPGAFULLMEM_TEST;
		S_FPGA_RW m_SFPGA_RW;
		S_NVSRAM_RW m_NVSRAM_RW;
		S_IO_MODE_CMD_TX m_IO_Test;
		S_ADM_SEQUENCER_TEST m_Adm_Sequencer;
		S_LINK_PORT_TEST m_Link_Port_Test;
		S_RF_PLL        m_sRFPll;
		S_ETHERNET_TEST m_sEthernetTest;
		char	m_arrucData[RS232_UART_BUFF_LEN];
		U_SCM_SELFTEST_DATA u_SCM_SelfTestData;

		S_SCM_DIAG_RESULT m_SCM_Diag_Result;

}USCM_RS232_TX;

typedef union
{
		S_PWR_MNTR_TEST m_PWR_MNTR_TEST;
		S_RTC_TEST m_RTC_TEST;
		S_SIG_PROC_RX_ADC m_SIG_PROC_ADC;
		S_ETR_TEST m_ETR_TEST;
		S_TEMP_MNTR_TEST m_TEMP_MNTR_TEST;
		S_DAC_MODULATOR_TEST m_DAC_MOD_TEST;
		S_QUADSPI_RW m_QUADSPI_RW;
		S_EEPROM_RW m_EEPROM_RW;
		S_DSP_DDR3L_RW m_DSPDDR3L_RW;
		S_QUADSPI_READ_RX m_QUADSPI_ReadRx;                          //!<Specifies structure holding Quad SPI Read Data*/
		S_FPGA_RW m_SFPGA_RW;
		S_NVSRAM_RW m_NVSRAM_RW;
		S_IO_MODE_CMD_RX m_IO_Test;
		S_ADM_SEQUENCER_TEST m_Adm_Sequencer;
		S_BOARD_INFO m_BoardInfo;
		S_RF_PLL        m_sRFPll;
		char	m_arrucData[RS232_UART_BUFF_LEN];
		U_SCM_SELFTEST_DATA u_SCM_SelfTestData;
		S_SCM_DIAG_RESULT m_SCM_Diag_Result;

}USCM_RS232_RX;

typedef struct  _S_FLASH_DATA
{
		unsigned long ulFlashAddress;
		unsigned long ulDataCount;
		unsigned char ucFlashData[DP_SCM_FLASH_PAGE_SIZE];
} S_FLASH_DATA, *PS_FLASH_DATA;

typedef struct  S_FLASH_READ_REQ
{
		unsigned long ulFlashAddress;
		unsigned long ulDataCountToRead;

} S_FLASH_READ_REQ, *PS_FLASH_READ_REQ;

typedef struct  _S_UART_DATA_PKT
{
		unsigned char	 m_ucHeader[2];	// 2 bytes
		unsigned short   m_usCmdID;		// 2 bytes
		short			 m_sStatus;		// 2 bytes
		unsigned short	 m_usDataLength;		// 2 bytes
		unsigned char 	 m_ucarrDataBuffer[512];	// 512 bytes
		unsigned short	 m_uschecksum;		// 2 bytes

} S_UART_DATA_PKT, *PS_UART_DATA_PKT;

//typedef struct  _S_RS232_RX_PKT
//{
//    unsigned char	 m_ucHeader[2];
//    unsigned short   m_usCmdID;
//    unsigned short	 m_usDataSize;
//    int              m_iRetVal;
//    USCM_RS232_RX 	 u_USCM_RS232_RX;
//    unsigned short	 m_uschecksum;

//} S_RS232_RX_PKT, *PS_RS232_RX_PKT;
/************************************************/

/************* FRA *****************/
//typedef struct  _SDPPCI755_DeviceDetails
//{
//    U8BIT u8BusNo;
//    U8BIT u8SlotNo;
//    U8BIT u8FunctionNo;
//    S8BIT s8BoardSts;
//} SDPPCI755_DeviceDetails, *PSDPPCI755_DeviceDetails;

//typedef struct  _SDPPCI755App_DeviceLocation
//{
//    U8BIT u8BusNo;
//    U8BIT u8SlotNo;
//    U8BIT u8FunctionNo;
//} SDPPCI755App_DeviceLocation, *PSDPPCI755App_DeviceLocation;
//typedef struct  _SDPPCI755_CONFIG
//{
//    U32BIT m_u32BoardNo;
//    U32BIT m_u32Mode;
//    U32BIT m_u32WaveformType;
//    FSINGLE m_fStartFreq;
//    FSINGLE m_fEndFreq;
//    FSINGLE m_fStepSize;
//    FSINGLE m_fTime;
//    FSINGLE m_fAmplitude;
//    FSINGLE m_fOffset;
//    FSINGLE m_fDelay;
//    U32BIT m_u32NoOfCycles;
//    U32BIT m_u32GainIndex[FRA_ADC_CHN_COUNT];
//    U32BIT m_u32StopAngle;
//    U32BIT m_u32StartAngle;
//    bool m_bLog;
////    U8BIT m_u8Reserved1[3];
//    bool m_bRMS;
////    U8BIT m_u8Reserved2[3];
//    bool m_bDelayInSec;
//} SDPPCI755_CONFIG, *PSDPPCI755_CONFIG;

typedef struct _SDPPCI755_DATA_BUFFER
{
    FSINGLE m_fFreqData;
    FSINGLE m_fGainData;
    FSINGLE m_fPhaseData;
    FSINGLE m_fRMSVolt1;
    FSINGLE m_fRMSVolt2;
}SDPPCI755_DATA_BUFFER,*PSDPPCI755_DATA_BUFFER;
/**********************************/

/***** Control Loop Constant */
/*** Control Loop Constant Update Command ***/
typedef struct  _SSCM_CTRL_LOOP_CONST_READ_UPDATE_CMD
{
		U8BIT m_u8By0_StartBit : 1;
		U8BIT m_u8By0_bit6_0 : 7;

		U8BIT m_u8By1_StartBit : 1;
		U8BIT m_u8DataLength : 7;

		U8BIT m_u8By2_StartBit : 1;
		U8BIT m_u8CommandID : 7;

		U8BIT m_u8By3_StartBit : 1;
		U8BIT m_u8By3_ConstantID : 7;

		U8BIT m_u8By4_StartBit : 1;
		U8BIT m_u8ConstValue1_31_28 : 7;

		U8BIT m_u8By5_StartBit : 1;
		U8BIT m_u8ConstValue2_27_21 : 7;

		U8BIT m_u8By6_StartBit : 1;
		U8BIT m_u8ConstValue3_20_14 : 7;

		U8BIT m_u8By7_StartBit : 1;
		U8BIT m_u8ConstValue4_13_7 : 7;

		U8BIT m_u8By8_StartBit : 1;
		U8BIT m_u8ConstValue5_6_0 : 7;

		U8BIT m_u8By9_StartBit : 1;
		U8BIT m_u8Checksum : 7;
} SSCM_CTRL_LOOP_CONST_READ_UPDATE_CMD, *PSSCM_CTRL_LOOP_CONST_READ_UPDATE_CMD;

typedef struct  _SSCM_CTRL_LOOP_CONST_READ_UPDATE_RESP
{
		U8BIT m_u8By0_StartBit : 1;
		U8BIT m_u8By0_bit6_0 : 7;

		U8BIT m_u8By1_StartBit : 1;
		U8BIT m_u8By1_DateLength : 7;

		U8BIT m_u8By2_StartBit : 1;
		U8BIT m_u8CommandId : 7;

		U8BIT m_u8By3_StartBit : 1;
		U8BIT m_u8ConstUpdateStatus : 7;

		U8BIT m_u8By4_StartBit : 1;
		U8BIT m_u8Checksum : 7;
} SSCM_CTRL_LOOP_CONST_READ_UPDATE_RESP, *PSSCM_CTRL_LOOP_CONST_READ_UPDATE_RESP;
/*****************************/

/***** DIAGNOSTICS TESTS *****/
/** For Command ID = 0x01 to 0x06 */
/*** Test Init Command ***/
typedef struct  _SSCM_DIAG_TEST_INIT_CMD
{
		U8BIT m_u8By0_StartBit : 1;
		U8BIT m_u8By0_bit6_0 : 7;

		U8BIT m_u8By1_StartBit : 1;
		U8BIT m_u8DataLength : 7;

		U8BIT m_u8By2_StartBit : 1;
		U8BIT m_u8CommandID : 7;

		U8BIT m_u8By3_StartBit : 1;
		U8BIT m_u8TestStartStop : 7;

		U8BIT m_u8By4_StartBit : 1;
		U8BIT m_u8By4_Unused : 3;
		U8BIT m_u8AzCmd_15_12 : 4;

		U8BIT m_u8By5_StartBit : 1;
		U8BIT m_u8AzCmd_11_5 : 7;

		U8BIT m_u8By6_StartBit : 1;
		U8BIT m_u8AzCmd_4_0 : 5;
		U8BIT m_u8ElCmd_9_8 : 2;

		U8BIT m_u8By7_StartBit : 1;
		U8BIT m_u8ElCmd_7_0 : 7;

		U8BIT m_u8By8_StartBit : 1;
		U8BIT m_u8Checksum : 7;
} SSCM_DIAG_TEST_INIT_CMD, *PSSCM_DIAG_TEST_INIT_CMD;

/*** Test Init Response ***/
typedef struct  _SSCM_DIAG_TEST_INIT_RESPONSE
{
		U8BIT m_u8By0_StartBit : 1;
		U8BIT m_u8By0_bit6_0 : 7;

		U8BIT m_u8By1_StartBit : 1;
		U8BIT m_u8DataLength : 7;

		U8BIT m_u8By2_StartBit : 1;
		U8BIT m_u8CommandID : 7;

		U8BIT m_u8By3_StartBit : 1;
		U8BIT m_u8TestInitStatus : 7;

		U8BIT m_u8By4_StartBit : 1;
		U8BIT m_u8Checksum : 7;
} SSCM_DIAG_TEST_INIT_RESPONSE, *PSSCM_DIAG_TEST_INIT_RESPONSE;

/*** Diagnostics Test response ***/
typedef struct  _SSCM_DIAG_TEST_RESPONSE
{
		U8BIT m_u8By0_StartBit : 1;
		U8BIT m_u8By0_bit6_0 : 7;

		U8BIT m_u8By1_StartBit : 1;
		U8BIT m_u8DataLength : 7;

		U8BIT m_u8By2_StartBit : 1;
		U8BIT m_u8SystemInfo : 7;	/* RTGA-0 / RGA-1 */

		U8BIT m_u8By3_StartBit : 1;
		U8BIT m_u8AzMotorCurrent_13_7 : 7;

		U8BIT m_u8By4_StartBit : 1;
		U8BIT m_u8AzMotorCurrent_6_0 : 7;

		U8BIT m_u8By5_StartBit : 1;
		U8BIT m_u8AzMotorCtrlDem_13_7 : 7;

		U8BIT m_u8By6_StartBit : 1;
		U8BIT m_u8AzMotorCtrlDem_6_0 : 7;

		U8BIT m_u8By7_StartBit : 1;
		U8BIT m_u8By7_bit6_4 : 3;
		U8BIT m_u8AzMotorAngle_17_14 : 4;

		U8BIT m_u8By8_StartBit : 1;
		U8BIT m_u8AzMotorAngle_13_7 : 7;

		U8BIT m_u8By9_StartBit : 1;
		U8BIT m_u8AzMotorAngle_6_0 : 7;

		U8BIT m_u8By10_StartBit : 1;
		U8BIT m_u8by10_bit6_4 : 3;
		U8BIT m_u8AzPayloadAngle_17_14 : 4;

		U8BIT m_u8By11_StartBit : 1;
		U8BIT m_u8AzPayloadAngle_13_7 : 7;

		U8BIT m_u8By12_StartBit : 1;
		U8BIT m_u8AzPayloadAngle_6_0 : 7;

		U8BIT m_u8By13_StartBit : 1;
		U8BIT m_u8by13_bit6_4 : 3;
		U8BIT m_u8AzGimbalDemand_17_14 : 4;

		U8BIT m_u8By14_StartBit : 1;
		U8BIT m_u8AzGimbalDemand_13_7 : 7;

		U8BIT m_u8By15_StartBit : 1;
		U8BIT m_u8AzGimbalDemand_6_0 : 7;

		U8BIT m_u8By16_StartBit : 1;
		U8BIT m_u8by16_bit6_4 : 3;
		U8BIT m_u8AzAngleDemand_17_14 : 4;

		U8BIT m_u8By17_StartBit : 1;
		U8BIT m_u8AzAngleDemand_13_7 : 7;

		U8BIT m_u8By18_StartBit : 1;
		U8BIT m_u8AzAngleDemand_6_0 : 7;

		U8BIT m_u8By19_StartBit : 1;
		U8BIT m_u8by19_bit6_4 : 3;
		U8BIT m_u8AzRateDemand_17_14 : 4;

		U8BIT m_u8By20_StartBit : 1;
		U8BIT m_u8AzRateDemand_13_7 : 7;

		U8BIT m_u8By21_StartBit : 1;
		U8BIT m_u8AzRateDemand_6_0 : 7;

		U8BIT m_u8By22_StartBit : 1;
		U8BIT m_u8ElMotorCurrent_13_7 : 7;

		U8BIT m_u8By23_StartBit : 1;
		U8BIT m_u8ElMotorCurrent_6_0 : 7;

		U8BIT m_u8By24_StartBit : 1;
		U8BIT m_u8ElMotorCtrlDem_13_7 : 7;

		U8BIT m_u8By25_StartBit : 1;
		U8BIT m_u8ElMotorCtrlDem_6_0 : 7;

		U8BIT m_u8By26_StartBit : 1;
		U8BIT m_u8By26_bit6_4 : 3;
		U8BIT m_u8ElMotorAngle_17_14 : 4;

		U8BIT m_u8By27_StartBit : 1;
		U8BIT m_u8ElMotorAngle_13_7 : 7;

		U8BIT m_u8By28_StartBit : 1;
		U8BIT m_u8ElMotorAngle_6_0 : 7;

		U8BIT m_u8By29_StartBit : 1;
		U8BIT m_u8by29_bit6_4 : 3;
		U8BIT m_u8ElPayloadAngle_17_14 : 4;

		U8BIT m_u8By30_StartBit : 1;
		U8BIT m_u8ElPayloadAngle_13_7 : 7;

		U8BIT m_u8By31_StartBit : 1;
		U8BIT m_u8ElPayloadAngle_6_0 : 7;

		U8BIT m_u8By32_StartBit : 1;
		U8BIT m_u8by32_bit6_4 : 3;
		U8BIT m_u8ElGimbalDemand_17_14 : 4;

		U8BIT m_u8By33_StartBit : 1;
		U8BIT m_u8ElGimbalDemand_13_7 : 7;

		U8BIT m_u8By34_StartBit : 1;
		U8BIT m_u8ElGimbalDemand_6_0 : 7;

		U8BIT m_u8By35_StartBit : 1;
		U8BIT m_u8by35_bit6_4 : 3;
		U8BIT m_u8ElAngleDemand_17_14 : 4;

		U8BIT m_u8By36_StartBit : 1;
		U8BIT m_u8ElAngleDemand_13_7 : 7;

		U8BIT m_u8By37_StartBit : 1;
		U8BIT m_u8ElAngleDemand_6_0 : 7;

		U8BIT m_u8By38_StartBit : 1;
		U8BIT m_u8by38_bit6_4 : 3;
		U8BIT m_u8ElRateDemand_17_14 : 4;

		U8BIT m_u8By39_StartBit : 1;
		U8BIT m_u8ElRateDemand_13_7 : 7;

		U8BIT m_u8By40_StartBit : 1;
		U8BIT m_u8ElRateDemand_6_0 : 7;

		U8BIT m_u8By41_StartBit : 1;
		U8BIT m_u8Checksum : 7;
} SSCM_DIAG_TEST_RESPONSE, *PSSCM_DIAG_TEST_RESPONSE;

/*****************************/

/********** Demand and Status Structures **********/
/** RTGA CONFIGURATION */

/* RTGA DEMAND */
typedef struct  _SSCM_RTGA_CMD_PKT
{
		U8BIT m_u8By1EndBit         :1;
		U8BIT m_u8StoreParam        :1;
		U8BIT m_u8AzDemRateMSB      :6;

		U8BIT m_u8By2EndBit         :1;
		U8BIT m_u8AzDemRateLSB      :7;

		U8BIT m_u8By3EndBit         :1;
		U8BIT m_u8Spare_01          :2;
		U8BIT m_u8ConfigOffset      :1;
		U8BIT m_u8CCWEndStop        :1;
		U8BIT m_u8CWEndStop         :1;
		U8BIT m_u8ElDemPositionMSB  :2;

		U8BIT m_u8By4EndBit         :1;
		U8BIT m_u8ElDemPositionLSB  :7;

		U8BIT m_u8By5EndBit         :1;
		U8BIT m_u8DiagnosticsID     :7;

		U8BIT m_u8By6EndBit         :1;
		U8BIT m_u8Checksum          :7;
} SSCM_RTGA_CMD_PKT, *PSSCM_RTGA_CMD_PKT;

/* RTGA STATUS */
typedef struct  _SSCM_RTGA_RESP_PKT
{
		U8BIT m_u8By1EndBit         :1;
		U8BIT m_u8AzPositionMSB     :7;

		U8BIT m_u8By2EndBit         :1;
		U8BIT m_u8AzPositionMID     :7;

		U8BIT m_u8By3EndBit         :1;
		U8BIT m_u8AzPositionLSB     :2;
		U8BIT m_u8Spare_01          :2;
		U8BIT m_u8BitFault          :1;
		U8BIT m_u8ElPositionMSB     :2;

		U8BIT m_u8By4EndBit         :1;
		U8BIT m_u8ElDemPositionLSB  :7;

		U8BIT m_u8By5EndBit         :1;
		U8BIT m_u8BITStatus         :7;

		U8BIT m_u8By6EndBit         :1;
		U8BIT m_u8DiagnosticsID     :7;

		U8BIT m_u8By7EndBit         :1;
		U8BIT m_u8Checksum          :7;
} SSCM_RTGA_RESP_PKT, *PSSCM_RTGA_RESP_PKT;

/***** DIAGNOSTICS ID READ *****/
/*** Diagnostics Read Command ***/
typedef struct  _SSCM_DIAG_ID_READ_CMD
{
        U8BIT m_u8By0_StartBit : 1;
        U8BIT m_u8By0_bit6_0 : 7;

        U8BIT m_u8By1_StartBit : 1;
        U8BIT m_u8DataLength : 7;

        U8BIT m_u8By2_StartBit : 1;
        U8BIT m_u8CommandID : 7;

        U8BIT m_u8By3_StartBit : 1;
        U8BIT m_u8DiagnosticsID : 7;

        U8BIT m_u8By4_StartBit : 1;
        U8BIT m_u8Checksum : 7;
} SSCM_DIAG_READ_CMD, *PSSCM_DIAG_READ_CMD;
/*** Diagnostics ID Read Response ***/
typedef struct  _SSCM_DIAG_ID_READ_RESPONSE
{
        U8BIT m_u8By0_StartBit : 1;
        U8BIT m_u8By0_bit6_0 : 7;

        U8BIT m_u8By1_StartBit : 1;
        U8BIT m_u8DataLength : 7;

        U8BIT m_u8By2_StartBit : 1;
        U8BIT m_u8CommandID : 7;

        U8BIT m_u8By3_StartBit : 1;
        U8BIT m_u8DiagResponse : 7;

        U8BIT m_u8By4_StartBit : 1;
        U8BIT m_u8Checksum : 7;
} SSCM_DIAG_RESPONSE, *PSSCM_DIAG_ID_READ_RESPONSE;
/*******************************/

typedef struct  _SSCM_TEST_INIT_CMD
{
        U8BIT m_u8By0_StartBit : 1;
        U8BIT m_u8By0_bit6_0 : 7;

        U8BIT m_u8By1_StartBit : 1;
        U8BIT m_u8By1_DateLength : 7;

        U8BIT m_u8By2_StartBit : 1;
        U8BIT m_u8CommandId : 7;

        U8BIT m_u8By3_StartBit : 1;
        U8BIT m_u8TestInitSts : 7;

        U8BIT m_u8By4_StartBit : 1;
        U8BIT m_u8Checksum : 7;
} SSCM_TEST_INIT_CMD, *PSSCM_TEST_INIT_CMD;

typedef union _UCMDDATA{
    SSCM_DIAG_READ_CMD m_SCMD_DIAG_READ;
    SSCM_TEST_INIT_CMD m_SCM_TEST_INIT;
    SSCM_RTGA_CMD_PKT m_SCM_RTGA_CMD;
    SSCM_RTGA_RESP_PKT m_SCM_RTGA_RESP;
    SSCM_DIAG_RESPONSE m_SCM_DIAG_RESP;
    SSCM_DIAG_TEST_INIT_CMD m_SCM_DIAG_TEST_INIT;
    SSCM_DIAG_TEST_INIT_RESPONSE m_SCM_DIAG_TEST_INIT_RESP;
    SSCM_DIAG_TEST_RESPONSE m_SCM_DIAG_TEST_RESP;
    SSCM_CTRL_LOOP_CONST_READ_UPDATE_CMD m_SCM_CTRL_LOOP_READ_CMD;
    SSCM_CTRL_LOOP_CONST_READ_UPDATE_RESP m_SCM_CTRL_LOOP_READ_RESP;
    
} UCMD_DATA;

typedef struct _S_SERVO_MODE_TEST
{
    double m_dAmplitude;
    double m_dFrequency;
    unsigned char m_ucMode;
    double m_dRatePos;
    unsigned char m_ucWaveformType;
    unsigned int m_uiTime_ms;
} S_SERVO_MODE_TEST, *PS_SERVO_MODE_TEST;

typedef struct _SSCM_CMDPACKET{
    unsigned char m_ucCmdID;
    unsigned char m_usDataLength;
    unsigned char m_usCmdID;
    unsigned char m_uschecksum;
    unsigned char m_usConstantID;
    unsigned char m_usDiagID;
    unsigned char m_usReadstatus;
    UCMD_DATA m_UCmdData;
}SSCM_CMDPACKET,* PSSCM_CMDPACKET;
typedef struct
{
    unsigned short m_usAddress;
    unsigned short m_usData;

}S_FPGA_WRITE;
typedef struct
{
   unsigned short m_usAddress;
   unsigned char  m_ucData;
   unsigned char  m_ucReserved;
}S_EEPROM_DATA;

//typedef struct
//{
//    unsigned short m_usBrdSerialNo;
//    char           m_carrBoardID[16];
//}S_BOARD_INFO;

typedef struct
{
    unsigned short m_usStartAddress;
    unsigned short m_usNumberOfLocations;
    unsigned char  m_ucPattern;
}S_EEPROM_PATTERN_CMD;

typedef struct
{
    unsigned short m_usFailAddress;
    unsigned char  m_ucFailData;
}S_EEPROM_PATTERN_RES;

typedef struct
{
    float m_fSlope[12];
    float m_fConstant[12];

}S_ADC_CALIB;

typedef struct
{
    float m_fSlope[2];
    float m_fConstant[2];

}S_DAC_CALIB;

typedef struct
{
    float m_fANA_IP;
    float m_fPHA;
    float m_fPHB;
    float m_fPHC;
    float m_fV_SNS;
    float m_fFBK_RTN;
    float m_fREF_IN;
    float m_fINV_BD_TEMP;
    float m_f1P8V;
    float m_f1V;
    float m_f1P2V;
    float m_f3P3V;

}S_ADC_MONIT_PARAM;

typedef struct
{
    float   m_fDACCH1Voltage;
    float   m_fDACCH2Voltage;
}S_DAC_CONF;

typedef struct
{
    unsigned char m_ucC1PinSts;
    unsigned char m_ucC2PinSts;
    unsigned char m_ucProg_En;
    unsigned char m_ucReserved2;

}S_GPIO_STS;

typedef struct
{
    unsigned short  m_us_OUTPinSel;
    unsigned short  m_us_OUTONTime;
    unsigned short  m_us_OUTOFFTime;
    unsigned short  m_us_OUTPulseCount;

    unsigned short  m_us_INPinSel;
    unsigned short  m_us_INONTime;
    unsigned short  m_us_INOFFTime;
    unsigned short  m_us_INPulseCount;

}S_IO_VAL;

typedef struct
{
    float m_fBoardTemp;
    float m_fPATemp;

}S_TEMP_MONIT;

typedef struct
{
   unsigned short  m_usFPGARdCksum;
   unsigned short  m_usFPGACompCksum;
   unsigned short  m_usDSPRdCksum;
   unsigned short  m_usDSPCompCksum;

}S_FLASH_CSTEST;

typedef struct
{
    unsigned short m_usModuleSel;
    unsigned short m_usTxPKtCount;
    unsigned short m_usDataSize;
    unsigned char  m_ucarrData[DP_SCM_FPGA_PACKET_SIZE];

}S_FPGA_FLASH_LOAD;
typedef struct
{
    char m_carrFWVersion[12];
}S_FW_VER;
typedef union
{
    S_FPGA_WRITE			m_S_FPGAWr;
    S_EEPROM_DATA           m_S_EEPROMData;
    S_BOARD_INFO			m_S_BoardInfo;
    S_EEPROM_PATTERN_CMD    m_S_PatternTest;
    S_EEPROM_PATTERN_RES    m_S_PatternRes;
    S_ADC_CALIB             m_S_ADCCalib;
    S_DAC_CALIB             m_S_DACCalib;
    S_ADC_MONIT_PARAM		m_S_ADCMonitParam;
    S_DAC_CONF              m_S_DACConf;
    S_GPIO_STS              m_S_GPIO_Sts;
    S_IO_VAL                m_S_IOVal;
    S_FLASH_CSTEST          m_S_FlashCksmTst;
    S_FPGA_FLASH_LOAD       m_S_FPGAFlashLoad;
    S_FW_VER				m_S_FWVersion;
    S_TEMP_MONIT            m_S_TempMonit;
    unsigned short          m_usExtPin_OnOff;
    unsigned char           m_ucData[1024];
}U_DATA;

typedef struct
{
    unsigned char	m_ucHeader[2];
    unsigned short	m_usCommandID;
    short		    m_sStatus;
    unsigned short	m_usDataLength;
    U_DATA			m_UData;
    unsigned short	m_usChecksum;
}S_DATA_PACKET;

#if 1
/* RTGA INTER SCM DEMAND */
typedef struct  _S_RTGA_INTER_SCM_DEMAND
{
		/* Byte 0 */
		unsigned char m_ucStartBit_0 : 1;
		unsigned char m_ucMessageLength : 7;

		/* Byte 1 */
		unsigned char m_ucStartBit_1 : 1;
		unsigned char m_ucStoreParameters : 1;
		unsigned char m_ucSpare_byte1 : 6;

		/* Byte 2 */
		unsigned char m_ucStartBit_2 : 1;
		unsigned char m_ucAzModeSelect : 1;
		unsigned char m_ucAzDemandMSB : 6;

		/* Byte 3 */
		unsigned char m_ucStartBit_3 : 1;
		unsigned char m_ucArrayIdent : 3;
		unsigned char m_ucCCW_LowerEndstop : 1;
		unsigned char m_ucCW_UpperEndstop : 1;
		unsigned char m_ucSpare_byte3 : 2;

		/* Byte 4 */
		unsigned char m_ucStartBit_4 : 1;
		unsigned char m_ucAzDemandLSB : 7;

		/* Byte 5 */
		unsigned char m_ucStartBit_5 : 1;
		unsigned char m_ucDiagnosticID : 7;

		/* Inter SCM PIPE Data */
		unsigned char *m_pucInterSCMPipe;		/* To be decided - N */

		/* Byte N + 1 */
		unsigned char m_ucStartBit_Nplus1 : 1;
		unsigned char m_ucFarEndChecksumError : 1;
		unsigned char m_uc6Bit_Checksum : 6;
} S_RTGA_INTER_SCM_DEMAND;

/* RTGA INTER SCM STATUS */
typedef struct  _S_RTGA_INTER_SCM_STATUS
{
		/* Byte 0 */
		unsigned char m_ucStartBit_0 : 1;
		unsigned char m_ucMessageLength : 7;

		/* Byte 1 */
		unsigned char m_ucStartBit_1 : 1;
		unsigned char m_ucAzPosMSB : 7;

		/* Byte 2 */
		unsigned char m_ucStartBit_2 : 1;
		unsigned char m_ucAzPos_bit8_2 : 7;

		/* Byte 3 */
		unsigned char m_ucStartBit_3 : 1;
		unsigned char m_ucAzPosLSB : 2;
		unsigned char m_ucAzIndependentSensorPos : 1;
		unsigned char m_ucNullBit : 1;
		unsigned char m_ucBITFault : 1;
		unsigned char m_ucSpare_byte3 : 2;

		/* Byte 4 */
		unsigned char m_ucStartBit_4 : 1;
		unsigned char m_ucBITDataValue : 7;

		/* Byte 5 */
		unsigned char m_ucStartBit_5: 1;
		unsigned char m_ucDiagnosticID : 7;

		/* Inter SCM PIPE Data */
		unsigned char *m_pucInterSCMPipe;		/* To be decided - N and Datatype */

		/* Byte N + 1 */
		unsigned char m_ucStartBit_Nplus1 : 1;
		unsigned char m_ucFarEndChecksumError : 1;
		unsigned char m_uc6Bit_Checksum : 6;
} S_RTGA_INTER_SCM_STATUS;
#endif

/** RGA CONFIGURATION */

/* RGA DEMAND */
typedef struct  _S_RGA_DEMAND
{
		/* Byte 0 */
		unsigned char m_ucStartBit_0 : 1;
		unsigned char m_ucMessageLength : 7;

		/* Byte 1 */
		unsigned char m_ucStartBit_1 : 1;
		unsigned char m_ucStoreParameters : 1;
		unsigned char m_ucSpare_byte1 : 6;

		/* Byte 2 */
		unsigned char m_ucStartBit_2 : 1;
		unsigned char m_ucAzModeSelect : 1;
		unsigned char m_ucAzDemandMSB : 6;

		/* Byte 3 */
		unsigned char m_ucStartBit_3 : 1;
		unsigned char m_ucArrayIdent : 3;
		unsigned char m_ucCCW_LowerEndstop : 1;
		unsigned char m_ucCW_UpperEndstop : 1;
		unsigned char m_ucSpare_byte3 : 2;

		/* Byte 4 */
		unsigned char m_ucStartBit_4 : 1;
		unsigned char m_ucAzDemandLSB : 7;

		/* Byte 5 */
		unsigned char m_ucStartBit_5 : 1;
		unsigned char m_ucDiagnosticID : 7;

		/* Byte 6 */
		unsigned char m_ucStartBit_6 : 1;
		unsigned char m_ucFarEndChecksumError : 1;
		unsigned char m_uc6Bit_Checksum : 6;
} S_RGA_DEMAND;

/* RGA STATUS */
typedef struct  _S_RGA_STATUS
{
		/* Byte 0 */
		unsigned char m_ucStartBit_0 : 1;
		unsigned char m_ucMessageLength : 7;

		/* Byte 1 */
		unsigned char m_ucStartBit_1 : 1;
		unsigned char m_ucAzPosMSB : 7;

		/* Byte 2 */
		unsigned char m_ucStartBit_2 : 1;
		unsigned char m_ucAzPos_bit8_2 : 7;

		/* Byte 3 */
		unsigned char m_ucStartBit_3 : 1;
		unsigned char m_ucAzPosLSB : 2;
		unsigned char m_ucAzIndependentSensorPos : 1;
		unsigned char m_ucNullBit : 1;
		unsigned char m_ucBITFault : 1;
		unsigned char m_ucSpare_byte3 : 2;

		/* Byte 4 */
		unsigned char m_ucStartBit_4 : 1;
		unsigned char m_ucBITDataValue : 7;

		/* Byte 5 */
		unsigned char m_ucStartBit_5: 1;
		unsigned char m_ucDiagnosticID : 7;

		/* Byte 6 */
		unsigned char m_ucStartBit_6 : 1;
		unsigned char m_ucFarEndChecksumError : 1;
		unsigned char m_uc6Bit_Checksum : 6;
} S_RGA_STATUS;

/** SEASPRAY PPC DATA FORMAT */

/* PPC CONSTANT VALUES
 * IDLE FLAG : 0x7E
 * ADDR (PPC TO SCM) : 0x01
 * ADDR (SCM TO PPC) : 0x02
 **************************/

#define IDLE_FLAG	0x7E
#define ADDR_PPC_SCM	0x01
#define ADDR_SCM_PPC	0x02

/* SEASPRAY PPC TO SCM (DEMAND) */
typedef struct  _S_PPC_SCM_DEMAND
{
		unsigned char m_ucIdleFlag_Start;
		unsigned char m_ucAddress;

		// unsigned char m_ucControl;
		unsigned char m_ucControl_Spare : 6;
		unsigned char m_ucControl_ErrorReset : 1;
		unsigned char m_ucControl_PedestalOnOff : 1;

		// unsigned short m_usRotationCmd;
		unsigned short m_usRotationCmd_Sign : 1;
		unsigned short m_usRotationCmd_VelocityData : 14;
		unsigned short m_usRotationCmd_Free : 1;

		unsigned char m_ucIncrementCount;
		unsigned short m_usSpare1;
		unsigned char m_ucSpare2;
		unsigned short m_usCRC;
		unsigned char m_ucIdleFlag_Stop;
} S_PPC_SCM_DEMAND;

/* SEASPRAY SCM TO PPC (STATUS) */
typedef struct  _S_SCM_PPC_STATUS
{
		unsigned char m_ucIdleFlag_Start;
		unsigned char m_ucAddress;

		// unsigned char m_ucControl;
		unsigned char m_ucControl_Spare : 6;
		unsigned char m_ucControl_ErrorReset : 1;
		unsigned char m_ucControl_PedestalOnOff : 1;

		// unsigned short m_usRotationCmd;
		unsigned short m_usRotationCmd_Sign : 1;
		unsigned short m_usRotationCmd_VelocityData : 14;
		unsigned short m_usRotationCmd_Free : 1;

		unsigned char m_ucIncrementCount;

		// unsigned short m_usPosition;
		unsigned short m_usPosition_Data : 15;
		unsigned short m_usPosition_Free : 1;

		// unsigned char m_ucInfo;
		unsigned char m_ucInfo_SystemReady : 1;
		unsigned char m_ucInfo_OverTempError : 1;
		unsigned char m_ucInfo_CurrLimitationInfo : 1;
		unsigned char m_ucInfo_TempInfo : 1;
		unsigned char m_ucInfo_InterUVError : 1;
		unsigned char m_ucInfo_MotorOCError : 1;
		unsigned char m_ucInfo_MotorResolverError : 1;
		unsigned char m_ucInfo_EncoderError : 1;

		unsigned short m_usCRC;
		unsigned char m_ucIdleFlag_Stop;
} S_SCM_PPC_STATUS;

typedef struct                      // for testing EEPROM control loop constant
{
    unsigned char m_ucByte0_Bit_6_0 : 7;
    unsigned char m_ucByte0_Bit7 : 1;

    unsigned char m_ucByte1_DataLength: 7;
    unsigned char m_ucByte1_Bit7 : 1;

    unsigned char m_ucByte2_CommandID : 7;
    unsigned char m_ucByte2_Bit7 : 1;

    unsigned char m_ucByte3_ConstID : 7;
    unsigned char m_ucByte3_Bit7 : 1;

    unsigned char m_ucByte4_ConstVal_31_28 : 7;
    unsigned char m_ucByte4_Bit7 : 1;

    unsigned char m_ucByte5_ConstVal_27_21 : 7;
    unsigned char m_ucByte5_Bit7 : 1;

    unsigned char m_ucByte6_ConstVal_20_14 : 7;
    unsigned char m_ucByte6_Bit7 : 1;

    unsigned char m_ucByte7_ConstVal_13_7 : 7;
    unsigned char m_ucByte7_Bit7 : 1;

    unsigned char m_ucByte8_ConstVal_6_0 : 7;
    unsigned char m_ucByte8_Bit7 : 1;

    unsigned char m_ucByte9_Xor_crc_CS : 7;
    unsigned char m_ucByte9_Bit7 : 1;
}S_SCM_CONST_UPDATE;

typedef union
{
    unsigned char	   m_ucData[10];
    S_SCM_CONST_UPDATE m_S_SCMConst;
}U_SCM_CONST_UPDATE;

/** BIT FAULT STATUS FORMAT */

/* BIT STATUS DATA */
typedef struct  _SSCM_BITSTATUS
{
        U8BIT m_u8DiagID;
		U8BIT m_u8BITStatus;
} SSCM_BITSTATUS, *PSSCM_BITSTATUS;

/* DIAGNOSTIC ID 01 - BIT FAULT STATUS */
typedef struct  _SSCM_CBIT01STS
{
		U8BIT m_u8GimbalStatus : 1;     /* ID 03 */
		U8BIT m_u8CommErr : 1;          /* ID 04 */
		U8BIT m_u8ServoLoopErr : 1;     /* ID 05 */
		U8BIT m_u8I2TTempErr : 1;       /* ID 07 */
		U8BIT m_u8InternalFault : 1;    /* ID 06 */
		U8BIT m_u8Spare_01 : 1;
		U8BIT m_u8Spare_02 : 1;
		U8BIT m_u8Spare_03 : 1;
} SSCM_CBIT01STS, *PSSCM_CBIT01STS;

/* DIAGNOSTIC ID 02 - BIT FAULT STATUS */
typedef struct  _SSCM_PBIT02STS
{
		unsigned char m_ucPBIT_Fault : 1;   /* ID 11 */
		unsigned char m_ucSpare_02 : 7;
} SSCM_PBIT02STS, *PSSCM_PBIT02STS;

/* DIAGNOSTIC ID 03 - GIMBAL STATUS */
typedef struct  _SSCM_CBIT03STS
{
		U8BIT m_u8AzCCWLimit : 1;       /* ID -- */
		U8BIT m_u8AzCWLimit : 1;        /* ID -- */
		U8BIT m_u8ElPositiveDem : 1;    /* ID -- */
		U8BIT m_u8ElNegativeDem : 1;    /* ID -- */
		U8BIT m_u8ElZettlexStsErr : 1;  /* ID 40 */
		U8BIT m_u8AzZettlexStsErr : 1;  /* ID 41 */
		U8BIT m_u8Spare_01 : 1;
		U8BIT m_u8Spare_02 : 1;
} SSCM_CBIT03STS, *PSSCM_CBIT03STS;

/* DIAGNOSTIC ID 04 - COMMUNICATION ERROR */
typedef struct  _SSCM_CBIT04STS
{
		U8BIT m_u8ChecksumErr : 1;      /* ID 64, 69, 72 */
		U8BIT m_u8IncorrectFormat : 1;  /* ID 65, 70, 73 */
		U8BIT m_u8PartialMessage : 1;   /* ID 66, 71, 74 */
		U8BIT m_u8LossOfComm : 1;       /* ID 67 */
		U8BIT m_u8AzSCMHigh : 1;        /* ID -- */
		U8BIT m_u8ElSCMHigh : 1;        /* ID -- */
		U8BIT m_u8UnrecArrIndent : 1;   /* ID -- */
		U8BIT m_u8Spare_01 : 1;
} SSCM_CBIT04STS, *PSSCM_CBIT04STS;

/* DIAGNOSTIC ID 05 - SERVO CONTROL LOOP ERROR */
typedef struct  _SSCM_CBIT05STS
{
		U8BIT m_u8AzPositionErr : 1;    /* ID -- */
		U8BIT m_u8ElPositionErr : 1;    /* ID -- */
		U8BIT m_u8Spare_01 : 1;
		U8BIT m_u8Spare_02 : 1;
		U8BIT m_u8Spare_03 : 1;
		U8BIT m_u8Spare_04 : 1;
		U8BIT m_u8Spare_05 : 1;
		U8BIT m_u8Spare_06 : 1;
} SSCM_CBIT05STS, *PSSCM_CBIT05STS;

/* DIAGNOSTIC ID 06 - INTERNAL SCM FAULT */
typedef struct  _SSCM_CBIT06STS
{
		U8BIT m_u8ElInternalErr : 1;    /* ID 38 */
		U8BIT m_u8AzInternalErr : 1;    /* ID 39 */
		U8BIT m_u8Spare_01 : 1;
		U8BIT m_u8Spare_02 : 1;
		U8BIT m_u8Spare_03 : 1;
		U8BIT m_u8Spare_04 : 1;
		U8BIT m_u8Spare_05 : 1;
		U8BIT m_u8Spare_06 : 1;
} SSCM_CBIT06STS, *PSSCM_CBIT06STS;

/* DIAGNOSTIC ID 07 - I2T AND TEMP FAULT */
typedef struct  _SSCM_CBIT07STS
{
		U8BIT m_u8ElExccI2TLim : 1; /* ID 44 */
		U8BIT m_u8AzExccI2TLim : 1; /* ID 45 */
		U8BIT m_u8ElTempErr : 1;    /* ID 42 */
		U8BIT m_u8AzTempErr : 1;    /* ID 43 */
		U8BIT m_u8Spare_01 : 1;
		U8BIT m_u8Spare_02 : 1;
		U8BIT m_u8Spare_03 : 1;
		U8BIT m_u8Spare_04 : 1;
} SSCM_CBIT07STS, *PSSCM_CBIT07STS;

/* DIAGNOSTIC ID 11 - PBIT FAULT */
typedef struct  _SSCM_PBIT11STS
{
		U8BIT m_u8ElProgMemCRC : 1; /* ID -- */
		U8BIT m_u8ElEepromCRC : 1;  /* ID -- */
		U8BIT m_u8ElRAMFault : 1;   /* ID -- */
		U8BIT m_u8AzProgMemCRC : 1; /* ID -- */
		U8BIT m_u8AzEepromCRC : 1;  /* ID -- */
		U8BIT m_u8AzRAMFault : 1;   /* ID -- */
		U8BIT m_u8Spare_01 : 1;     /* ID -- */
		U8BIT m_u8Spare_02 : 1;     /* ID -- */
} SSCM_PBIT11STS, *PSSCM_PBIT11STS;

/* DIAGNOSTIC ID 38 - ELEVATION INTERNAL FAULT */
typedef struct  _SSCM_CBIT38STS
{
		U8BIT m_u8InternalPSUFault : 1; /* ID -- */
		U8BIT m_u8FloatSupplyFault : 1; /* ID -- */
		U8BIT m_u8LatchedError : 1;     /* ID -- */
		U8BIT m_u8OverCurretFault : 1;  /* ID -- */
		U8BIT m_u8Spare_01 : 1;
		U8BIT m_u8Spare_02 : 1;
		U8BIT m_u8Spare_03 : 1;
		U8BIT m_u8Spare_04 : 1;
} SSCM_CBIT38STS, *PSSCM_CBIT38STS;

/* DIAGNOSTIC ID 39 - AZIMUTH INTERNAL FAULT */
typedef struct  _SSCM_CBIT39STS
{
		U8BIT m_u8InternalPSUFault : 1; /* ID -- */
		U8BIT m_u8FloatSupplyFault : 1; /* ID -- */
		U8BIT m_u8LatchedError : 1;     /* ID -- */
		U8BIT m_u8OverCurretFault : 1;  /* ID -- */
		U8BIT m_u8Spare_01 : 1;
		U8BIT m_u8Spare_02 : 1;
		U8BIT m_u8Spare_03 : 1;
		U8BIT m_u8Spare_04 : 1;
} SSCM_CBIT39STS, *PSSCM_CBIT39STS;

/* DIAGNOSTIC ID 40 - ELEVATION ZETTLEX STATUS */
typedef struct  _SSCM_CBIT40STS
{
		U8BIT m_u8ChecksumError : 1;    /* ID -- */
		U8BIT m_u8StaleData : 1;        /* ID -- */
		U8BIT m_u8PositionNotSync : 1;  /* ID -- */
		U8BIT m_u8PositionInvalid : 1;  /* ID -- */
		U8BIT m_u8AngleSetStatus : 1;   /* ID -- */
		U8BIT m_u8Spare_01 : 1;
		U8BIT m_u8Spare_02 : 1;
		U8BIT m_u8Spare_03 : 1;
} SSCM_CBIT40STS, *PSSCM_CBIT40STS;

/* DIAGNOSTIC ID 41 - AZIMUTH ZETTLEX STATUS */
typedef struct  _SSCM_CBIT41STS
{
		U8BIT m_u8ChecksumError : 1;    /* ID -- */
		U8BIT m_u8StaleData : 1;        /* ID -- */
		U8BIT m_u8PositionNotSync : 1;  /* ID -- */
		U8BIT m_u8PositionInvalid : 1;  /* ID -- */
		U8BIT m_u8AngleSetStatus : 1;   /* ID -- */
		U8BIT m_u8Spare_01 : 1;
		U8BIT m_u8Spare_02 : 1;
		U8BIT m_u8Spare_03 : 1;
} SSCM_CBIT41STS, *PSSCM_CBIT41STS;

/** DIAGNOSTICS MONITORING **/
typedef struct  _SSCM_DIAG_MON_PARAM
{
		double m_dMotorCurrent;
		U16BIT m_u16MotorAngle;
		U16BIT m_u16PayloadAngle;
		U32BIT m_u32CtrlDem;
		U32BIT m_u32GimbalDem;
		U16BIT m_u16AngleDem;
		double m_dRateDem;
} SSCM_DIAG_MON_PARAM, *PSSCM_DIAG_MON_PARAM;
/****************************/
/**********************************************************/

/***** FRA *****/
//typedef struct  _SDPPCI755_RAWDATABUFFER
//{
//    FSINGLE	m_fChannel1Data;	/*!< ADC Channel 1 data*/
//    FSINGLE	m_fChannel2Data;	/*!< ADC Channel 2 data*/
//    FSINGLE	m_fTime;			/*!< Calculated time value*/
//}PACK_ATTRIBUTE SDPPCI755_RAWDATABUFFER, *PSDPPCI755_RAWDATABUFFER;

typedef struct  _SDPPCI755_ONLINEDATA
{
		U32BIT m_u32nBrdNo , m_u32nDataCount[SCM_ATE_MAX_PCI755_BRDS];
		U32BIT m_u32nChlNo;
		SDPPCI755_CONFIG m_SCfgData;
		bool m_bIsBoardSelected[SCM_ATE_MAX_PCI755_BRDS];
		bool m_bIsDataReady[SCM_ATE_MAX_PCI755_BRDS];

}SDPPCI755_ONLINEDATA,*PSDPPCI755_ONLINEDATA;

typedef struct  _SDPPCI755_RAW_DATA_THREAD_INFO
{
		U16BIT m_u16BoardNo;
		U8BIT m_u8ChannelNo;
		PSDPPCI755_RAWDATABUFFER m_pSRawDataBuff;
		U32BIT m_u32nRawDataCount;
		QString m_qFileName;
		U32BIT m_u8semStartExitEvent;	// Events to indicate Start or Exit
		U32BIT m_u32semStopEvent;			// Event to indicate Stop Transmitt
}SDPPCI755_RAW_DATA_THREAD_INFO,*PSDPPCI755_RAW_DATA_THREAD_INFO;

typedef struct  _SDPPCI755_RAW_THREAD_INFO
{
		QString m_qFileName[SCM_ATE_MAX_PCI755_BRDS][SCM_ATE_MAX_PCI755_CHN];
		U32BIT m_u32BoardNo;
		U32BIT m_u32ChannelNo;
		U32BIT m_u32BufferNo;
		U32BIT m_u32RawDataCount;
}SDPPCI755_RAW_THREAD_INFO,*PSDPPCI755_RAW_THREAD_INFO;

typedef struct  _SDPPCI755_ANA_THREAD_INFO
{
		QString m_qFileName[SCM_ATE_MAX_PCI755_BRDS][SCM_ATE_MAX_PCI755_CHN];
		U32BIT m_u32BoardNo;
		U32BIT m_u32ChannelNo;
		U32BIT m_u32BufferNo;
		U32BIT m_u32nAnalyzeDataCount;
}SDPPCI755_ANA_THREAD_INFO,*PSDPPCI755_ANA_THREAD_INFO;

// Structure to store the thread information
typedef struct  _SDPPCI755_ThreadInfo
{
		U16BIT m_u16BoardNo;
		QString m_qFileName;
		SDPPCI755_CONFIG m_scfgData;
		bool	m_bStoreRawData;
		U8BIT m_u8semStartExitEvent;	// Events to indicate Start or Exit
		U32BIT m_u32semStopEvent;			// Event to indicate Stop Transmitt
		QSemaphore m_cSemaStartStop;
}SDPPCI755_ThreadInfo,*PSDPPCI755_ThreadInfo;

typedef struct  _SDPPCI755_FLAGS
{
		bool m_bIsAnalyzeData;
		bool m_bIsSyncSelected;
		bool m_bIsDataLoad;
		bool m_bIsArbitraryWave;
}SDPPCI755_FLAGS,*PSDPPCI755_FLAGS;

/*****FRA END*****/

/************* UPDATED PACKET STRUCTURE FOR COMMAND AND DEBUG PORTS ************/
typedef struct
{
    float 		   m_fCCWLimit;
    float 		   m_fCWLimit;
    float 	       m_fAzCommand;
    short 		   m_sCmd;
    unsigned char  m_ucAzModeSel;
    unsigned char  m_ucCCWLowEndStop;
    unsigned char  m_ucCCWLmtFlag;
    unsigned char  m_ucCWUprEndStop;
    unsigned char  m_ucCWLmtFlag;
    unsigned char  m_ucStoreParamFlag;
}S_RGA_CMD_DATA;

typedef struct
{
    float 		   m_fElCommand;
    float 		   m_fCCWLimit;
    float 		   m_fCWLimit;
    short 		   m_sCmd;
    unsigned char  m_ucCCWLowEndStop;
    unsigned char  m_ucCCWLmtFlag;
    unsigned char  m_ucCWUprEndStop;
    unsigned char  m_ucCWLmtFlag;
    unsigned char  m_ucStoreParamFlag;
}S_RTGA_CMD_DATA;

typedef struct
{
    unsigned char m_ucByte0_MsgLength : 7;
    unsigned char m_ucByte0_Bit7 : 1;

    unsigned char m_ucByte1_Spare : 6;
    unsigned char m_ucByte1_StrParameters : 1;
    unsigned char m_ucByte1_Bit7 : 1;

    unsigned char m_ucByte2_AzCmd_12_7 : 6;
    unsigned char m_ucByte2_AzModeSel : 1;
    unsigned char m_ucByte2_Bit7 : 1;

    unsigned char m_ucByte3_Spare : 2;
    unsigned char m_ucByte3_CW_UpEndStop : 1;
    unsigned char m_ucByte3_CCW_LowEndStop : 1;
    unsigned char m_ucByte3_ArrayIdent : 3;
    unsigned char m_ucByte3_Bit7 : 1;

    unsigned char m_ucByte4_AzCmd_6_0 : 7;
    unsigned char m_ucByte4_Bit7 : 1;

    unsigned char m_ucByte5_DiagnosticsID : 7;
    unsigned char m_ucByte5_Bit7 : 1;

    unsigned char m_ucByte6_Crc6_CS : 6;
    unsigned char m_ucByte6_FarEndCSErr : 1;
    unsigned char m_ucByte6_Bit7 : 1;
}S_RGA_COMMAND;

typedef struct
{
    unsigned char m_ucByte0_MsgLength : 7;
    unsigned char m_ucByte0_Bit7 : 1;

    unsigned char m_ucByte1_AzPosition_15_9 : 7;
    unsigned char m_ucByte1_Bit7 : 1;

    unsigned char m_ucByte2_AzPosition_8_2 : 7;
    unsigned char m_ucByte2_Bit7 : 1;

    unsigned char m_ucByte3_Spare : 2;
    unsigned char m_ucByte3_BIT_Fault : 1;
    unsigned char m_ucByte3_Bit3 : 1;
    unsigned char m_ucByte3_AzIndSenPosition : 1;
    unsigned char m_ucByte3_AzPosition_1_0 : 2;
    unsigned char m_ucByte3_Bit7 : 1;

    unsigned char m_ucByte4_BIT_DataVal : 7;
    unsigned char m_ucByte4_Bit7 : 1;

    unsigned char m_ucByte5_DiagnosticsID : 7;
    unsigned char m_ucByte5_Bit7 : 1;

    unsigned char m_ucByte6_Crc6_CS : 6;
    unsigned char m_ucByte6_FarEndCSErr : 1;
    unsigned char m_ucByte6_Bit7 : 1;
}S_RGA_RESPONSE;

typedef struct
{
    unsigned char m_ucByte0_AzCmd_12_7 : 6;
    unsigned char m_ucByte0_StrParameters : 1;
    unsigned char m_ucByte0_Bit7 : 1;

    unsigned char m_ucByte1_AzCmd_6_0 : 7;
    unsigned char m_ucByte1_Bit7 : 1;

    unsigned char m_ucByte1_ElCmd_8_7 : 2;
    unsigned char m_ucByte2_CW_UpEndStop : 1;
    unsigned char m_ucByte2_CCW_LowEndStop : 1;
    unsigned char m_ucByte2_ConfOffset : 1;
    unsigned char m_ucByte2_Bit_5_6 : 2;
    unsigned char m_ucByte2_Bit7 : 1;

    unsigned char m_ucByte3_ElCmd_6_0 : 7;
    unsigned char m_ucByte3_Bit7 : 1;

    unsigned char m_ucByte4_DiagnosticsID : 7;
    unsigned char m_ucByte4_Bit7 : 1;

    unsigned char m_ucByte5_Crc7_CS : 7;
    unsigned char m_ucByte5_Bit7 : 1;
}S_RTGA_COMMAND;


typedef struct
{
    unsigned char m_ucByte0_AzCmd_15_9 : 7;
    unsigned char m_ucByte0_Bit7 : 1;

    unsigned char m_ucByte1_AzCmd_8_2 : 7;
    unsigned char m_ucByte1_Bit7 : 1;

    unsigned char m_ucByte1_ElCmd_8_7 : 2;
    unsigned char m_ucByte2_BITFault : 1;
    unsigned char m_ucByte2_Bit_3_4 : 2;
    unsigned char m_ucByte2_AzCmd_0_1 : 2;
    unsigned char m_ucByte2_Bit7 : 1;

    unsigned char m_ucByte3_ElCmd_6_0 : 7;
    unsigned char m_ucByte3_Bit7 : 1;

    unsigned char m_ucByte4_BitDataVal : 7;
    unsigned char m_ucByte4_Bit7 : 1;

    unsigned char m_ucByte5_DiagnosticsID : 7;
    unsigned char m_ucByte5_Bit7 : 1;

    unsigned char m_ucByte6_Crc7_CS : 7;
    unsigned char m_ucByte6_Bit7 : 1;
}S_RTGA_RESPONSE;
#if 0
typedef struct
{
    unsigned char m_ucByte0_Bit6_0 : 7;
    unsigned char m_ucByte0_Bit7 : 1;

    unsigned char m_ucByte1_DataLength : 7;
    unsigned char m_ucByte1_Bit7 : 1;

    unsigned char m_ucByte2_CmdID : 7;
    unsigned char m_ucByte2_Bit7 : 1;

    unsigned char m_ucByte3_TestInit : 7;
    unsigned char m_ucByte3_Bit7 : 1;

    unsigned char m_ucByte4_AzCmd_15_12 : 4;
    unsigned char m_ucByte4_Bit_6_4 : 3;
    unsigned char m_ucByte4_Bit7 : 1;

    unsigned char m_ucByte5_AzCmd_11_5 : 7;
    unsigned char m_ucByte5_Bit7 : 1;

    unsigned char m_ucByte6_ElCmd_9_8 : 2;
    unsigned char m_ucByte6_AzCmd_4_0 : 5;
    unsigned char m_ucByte6_Bit7 : 1;

    unsigned char m_ucByte7_ElCmd_7_0 : 7;
    unsigned char m_ucByte7_Bit7 : 1;

    unsigned char m_ucByte8_Crc_Xor_CS : 7;
    unsigned char m_ucByte8_Bit7 : 1;
}S_DIAG_COMMAND;

typedef struct
{
    unsigned char m_ucByte0_Bit6_0 : 7;
    unsigned char m_ucByte0_Bit7 : 1;

    unsigned char m_ucByte1_DataLength : 7;
    unsigned char m_ucByte1_Bit7 : 1;

    unsigned char m_ucByte2_SysInfo : 7;
    unsigned char m_ucByte2_Bit7 : 1;

    unsigned char m_ucByte3_AzMtrCurr_13_7 : 7;
    unsigned char m_ucByte3_Bit7 : 1;

    unsigned char m_ucByte4_AzMtrCurr_6_0 : 7;
    unsigned char m_ucByte4_Bit7 : 1;

    unsigned char m_ucByte5_AzMtrCtrl_Dem_13_7 : 7;
    unsigned char m_ucByte5_Bit7 : 1;


    unsigned char m_ucByte6_AzMtrCtrl_Dem_6_0 : 7;
    unsigned char m_ucByte6_Bit7 : 1;

    unsigned char m_ucByte7_AzMtr_Angle_17_15 : 3;
    unsigned char m_ucByte7_Bit6_2 : 4;
    unsigned char m_ucByte7_Bit7 : 1;

    unsigned char m_ucByte8_AzMtr_Angle_14_7 : 7;
    unsigned char m_ucByte8_Bit7 : 1;
}S_DIAG_RESPONSE;
#endif
/// New Diagnostics Command and Response structure
#if 0
typedef struct
{
    unsigned char m_ucByte0_Bit6_0 : 7;
    unsigned char m_ucByte0_Bit7 : 1;

    unsigned char m_ucByte1_CmdID : 6;
    unsigned char m_ucByte1_TestInit : 1;
    unsigned char m_ucByte1_Bit7 : 1;

    unsigned char m_ucByte2_Bit6_0 : 7;
    unsigned char m_ucByte2_Bit7 : 1;

    unsigned char m_ucByte3_Bit6_0 : 7;
    unsigned char m_ucByte3_Bit7 : 1;

    unsigned char m_ucByte4_Bit6_0 : 7;
    unsigned char m_ucByte4_Bit7 : 1;

    unsigned char m_ucByte5_Bit6_0 : 7;
    unsigned char m_ucByte5_Bit7 : 1;

    unsigned char m_ucByte6_Bit6_0 : 7;
    unsigned char m_ucByte6_Bit7 : 1;

    unsigned char m_ucByte7_Crc_Xor_CS : 7;
    unsigned char m_ucByte7_Bit7 : 1;
} S_DIAG_CMDRESP;
#else
typedef struct
{
    unsigned char m_ucByte0_Bit6_0 : 7;
    unsigned char m_ucByte0_Bit7 : 1;

    unsigned char m_ucByte1_CmdID : 5;
    unsigned char m_ucByte1_TestInit : 1;
    unsigned char m_ucByte1_ElorAz : 1;
    unsigned char m_ucByte1_Bit7 : 1;

    unsigned char m_ucByte2_Bit6_0 : 7;
    unsigned char m_ucByte2_Bit7 : 1;

    unsigned char m_ucByte3_Bit6_0 : 7;
    unsigned char m_ucByte3_Bit7 : 1;

    unsigned char m_ucByte4_Bit6_0 : 7;
    unsigned char m_ucByte4_Bit7 : 1;

    unsigned char m_ucByte5_Bit6_0 : 7;
    unsigned char m_ucByte5_Bit7 : 1;

    unsigned char m_ucByte6_Bit6_0 : 7;
    unsigned char m_ucByte6_Bit7 : 1;

    unsigned char m_ucByte7_Crc_Xor_CS : 7;
    unsigned char m_ucByte7_Bit7 : 1;
} S_DIAG_CMDRESP;
#endif

typedef union
{
    unsigned char   m_arrucData[16];
    S_RGA_COMMAND	m_S_RGACmd;
    S_RTGA_COMMAND	m_S_RTGACmd;
    S_DIAG_CMDRESP m_S_DiagCmd;
    SDPXMC5775_12_HDLC_FRAME_CONFIG m_S_HDLCCmd;
}U_DEM_PORT_TX;

typedef union
{
    unsigned char   m_arrucData[16];
    S_RGA_RESPONSE	m_S_RGAResp;
    S_RTGA_RESPONSE m_S_RTGAResp;
    S_DIAG_CMDRESP	m_S_DiagResp;
    unsigned int m_uiHDLCResponse;
}U_DEM_PORT_RX, *PU_DEM_PORT_RX;

typedef union
{
    unsigned char   m_arrucData[16];
    S_RGA_COMMAND	m_S_RGACmd;
    S_DIAG_CMDRESP m_S_DiagCmd;
}U_DIAG_PORT_TX;

typedef union
{
    unsigned char   m_arrucData[16];
    S_RGA_RESPONSE  m_S_RGAResp;
    S_DIAG_CMDRESP  m_S_DiagCmd;
}U_DIAG_PORT_RX;

typedef struct
{
    unsigned char 	m_ucPacketType;
    unsigned char 	m_ucDataRxState;
    unsigned char 	m_ucDataLength;

//	unsigned char 	m_ucPartialPkt_EltoAz;
//	unsigned char 	m_ucPartialPkt_ErDem;
//	unsigned char	m_ucPartialPkt_Ant;
//	unsigned char 	m_ucPktCSError_EltoAz;
//	unsigned char 	m_ucPktCSError_ErDiag;
//	unsigned char	m_ucPktCSError_Ant;

    unsigned char 	m_ucReadIndex;
    unsigned char 	m_ucDataRxStatus;
    U_DEM_PORT_TX	m_U_DemRx;
}S_DEM_PORT_RX;

typedef struct
{
    unsigned char	m_ucPacketType;
    U_DEM_PORT_RX	m_U_DemTx;
}S_DEM_PORT_TX;

typedef struct
{
    unsigned char 	m_ucPacketType;
    unsigned char 	m_ucDataRxState;
    unsigned char 	m_ucDataLength;

//	unsigned char 	m_ucPartialPkt_AztoEl;
//	unsigned char 	m_ucPartialPkt_ErDiag;
//	unsigned char 	m_ucPktCSError_AztoEl;
//	unsigned char 	m_ucPktCSError_ErDiag;
//	unsigned char 	m_ucPktIncorFrmt_AztoEl;
//	unsigned char 	m_ucPktIncorFrmt_ErDiag;
    unsigned char 	m_ucReadIndex;

    unsigned char 	m_ucDataRxStatus;
    U_DIAG_PORT_RX	m_U_DiagRx;
}S_DIAG_PORT_RX;

typedef struct
{
    unsigned char	m_ucPacketType;
    U_DIAG_PORT_TX	m_U_DiagTx;
}S_DIAG_PORT_TX;

/*************COMMAND STRUCTURE END *******************/
/* Stored data from RTGA Command */
typedef struct _S_CMD_DATA_RTGA
{
    unsigned char m_ucStoreParam;
    double m_dAzRate;
    unsigned char m_ucCCW_LowerEndStop;
    unsigned char m_ucCW_UpperEndStop;
    double m_dElPosition;
    unsigned char m_ucDiagID;
} S_CMD_DATA_RTGA, *PS_CMD_DATA_RTGA;
/**********************************************************/

/* Stored data from RGA Command */
typedef struct _S_CMD_DATA_RGA
{
    unsigned char   m_ucStoreParam;
    unsigned char   m_ucAzMode;
    double          m_dAzRatePos;
    unsigned char   m_ucArrayIdent;
    unsigned char   m_ucCCW_LowerEndStop;
    unsigned char   m_ucCW_UpperEndStop;
    unsigned char   m_ucDiagnosticsID;
    unsigned char   m_ucInterSCMPipe;
    unsigned char   m_ucFarEndCSError;
} S_CMD_DATA_RGA, *PS_CMD_DATA_RGA;
/**********************************************************/

/* Stored data from Diagnostics Port Command */
typedef struct _S_CMD_DATA_DIAG
{
    unsigned char m_ucTestInit;
    unsigned char m_ucCommandId;
    double m_dPosRateData;
    double m_dConstValue;
    unsigned char m_ucConstantId;
    unsigned char m_ucDiagID;
} S_CMD_DATA_DIAG, *PS_CMD_DATA_DIAG;
/**********************************************************/

/* Stored data from Demand and Diagnostics Port Command */
typedef union _U_CMD_DATA
{
    unsigned char m_ucCmdData[10];
    S_CMD_DATA_RTGA m_SCmd_RTGA;
    S_CMD_DATA_RGA m_SCmd_RGA;
    S_CMD_DATA_DIAG m_SCmd_Diag;
} U_CMD_DATA, *PU_CMD_DATA;
/**********************************************************/

/* Stored data from RTGA Response */
typedef struct _S_RESP_DATA_RTGA
{
    double m_dAzPosition;
    double m_dElPosition;
    unsigned char m_ucDiagData;
    unsigned char m_ucDiagId;
} S_RESP_DATA_RTGA, *PS_RESP_DATA_RTGA;
/**********************************************************/

/* Stored data from RGA Response */
typedef struct _S_RESP_DATA_RGA
{
    double          m_dAzPosition;
    unsigned char   m_ucAzIndependentSensorPos;
    unsigned char   m_ucBITFault;
    unsigned char   m_ucDiagData;
    unsigned char   m_ucDiagId;
} S_RESP_DATA_RGA, *PS_RESP_DATA_RGA;
/**********************************************************/

/* Stored data from Diagnostics Port Response */
typedef struct _S_RESP_DATA_DIAG
{
    unsigned char m_ucCommandID;
    double m_dPositionData;
    double m_dRateData;
    unsigned char m_ucConstantID;
    double m_dCLC_Const_Data;
    unsigned char m_ucDiagId;
    unsigned char m_ucDiagData;
} S_RESP_DATA_DIAG, *PS_RESP_DATA_DIAG;
/**********************************************************/

typedef struct _S_RESP_DEBUG_DATA
{
    double m_dMotorCurrent;
    double m_dMotorCtrlDemand;
    double m_dMotorAngle;
    double m_dPayloadAngle;
    double m_dPayloadRate;
    double m_dGimbalDemand;
    double m_dRateDemand;
    double m_dPositionDemand;
    unsigned short m_usTimeCount;
} S_RESP_DEBUG_DATA, *PS_RESP_DEBUG_DATA;

/* Stored data from Demand and Diagnostics Port Responses */
typedef union _U_RESP_DATA
{
    unsigned char m_ucRespData[56];
    S_RESP_DATA_RTGA m_SResp_RTGA;
    S_RESP_DATA_RGA m_SResp_RGA;
    S_RESP_DATA_DIAG m_SResp_Diag;
    S_RESP_DEBUG_DATA m_SResp_DebugData;
} U_RESP_DATA, *PU_RESP_DATA;
/**********************************************************/

/* Stored data from Demand and Diagnostics Port Command and Responses */
typedef union _U_CMDRESP_DATA
{
    unsigned char m_ucRespData[56];
    U_CMD_DATA m_UCmdData;
    U_RESP_DATA m_URespData;
} U_CMDRESP_DATA, *PU_CMDRESP_DATA;
/**********************************************************/

/* Stored data for HDLC Response */
typedef struct _S_HDLC_Response_Data
{
    unsigned char m_ucFrameCounter;
    unsigned char m_ucBITEStatus;
    double m_dEncoderData;
} S_HDLC_Response_Data, *PS_HDLC_Response_Data;

/* Diagnostics Port Debug Data - for FRA and Servo Mode Tests */
typedef struct _S_DIAG_DATA_RESP
{
    unsigned char  m_ucByte0_Bit6_0 : 7;
    unsigned char  m_ucByte0_Header : 1;

    unsigned char  m_ucByte1_CmdID : 6;
    unsigned char  m_ucByte1_TestInit : 1;
    unsigned char  m_ucByte1_Bit7 : 1;

    unsigned char  m_ucByte2_PL_Angle_13_7  : 7;		//PL Encoder data
    unsigned char  m_ucByte2_Bit7 : 1;

    unsigned char  m_ucByte3_PL_Angle_6_0  : 7;
    unsigned char  m_ucByte3_Bit7 : 1;

    unsigned char  m_ucByte4_PL_Rate_13_7  : 7;		//PL Encoder data
    unsigned char  m_ucByte4_Bit7 : 1;

    unsigned char  m_ucByte5_PL_Rate_6_0  : 7;
    unsigned char  m_ucByte5_Bit7 : 1;

    unsigned char  m_ucByte6_Mtr_Angle_13_7 : 7;		//Mtr Encoder Data
    unsigned char  m_ucByte6_Bit7 : 1;

    unsigned char  m_ucByte7_Mtr_Angle_6_0  : 7;
    unsigned char  m_ucByte7_Bit7 : 1;

    unsigned char  m_ucByte8_Mtr_Cur_13_7 : 7;	//From FPGA
    unsigned char  m_ucByte8_Bit7 : 1;

    unsigned char  m_ucByte9_Mtr_Cur_6_0 : 7;
    unsigned char  m_ucByte9_Bit7 : 1;

    unsigned char  m_ucByte10_Gimbal_Demad_13_7  : 7;		//Input Control Command
    unsigned char  m_ucByte10_Bit7 : 1;

    unsigned char  m_ucByte11_Gimbal_Demad_6_0  : 7;
    unsigned char  m_ucByte11_Bit7 : 1;

    unsigned char  m_ucByte12_CTRL_Demand_13_7  : 7;		//Current Demand to FPGA
    unsigned char  m_ucByte12_Bit7 : 1;

    unsigned char  m_ucByte13_CTRL_Demand_6_0  : 7;
    unsigned char  m_ucByte13_Bit7 : 1;

    unsigned char  m_ucByte14_Rate_Demand_13_7  : 7;
    unsigned char  m_ucByte14_Bit7 : 1;

    unsigned char  m_ucByte15_Rate_Demand_6_0  : 7;
    unsigned char  m_ucByte15_Bit7 : 1;

    unsigned char  m_ucByte16_Pos_Demand_13_7  : 7;
    unsigned char  m_ucByte16_Bit7 : 1;

    unsigned char  m_ucByte17_Pos_Demand_6_0  : 7;
    unsigned char  m_ucByte17_Bit7 : 1;

    unsigned char m_ucTimerCount_MSB_13_7 : 7;
    unsigned char m_ucTimerSpare_1 : 1;

    unsigned char m_ucTimerCount_LSB_6_0 : 7;
    unsigned char m_ucTimerSpare_2 : 1;

    unsigned char  m_ucByte18_Checksum  : 7;
    unsigned char  m_ucByte18_Bit7 : 1;
} S_DIAG_DATA_RESP, *PS_DIAG_DATA_RESP;
/**************************************************************/

/******************** GLOBAL STRUCTURE ********************/
typedef struct  _S_BOARD_STATUS
{
        U8BIT m_u8PCI755_Status;
        U8BIT m_u8XMC5775_Status;
        U8BIT m_arru8RS232Port_Status[NO_OF_PORTS];
} S_BOARD_STATUS, *PS_BOARD_STATUS;

typedef struct  _S_GLOBAL
{
    QDateTime g_qdatetimeBuild;
    QDateTime g_qdatetimeRun;

    CDPMsgQueue *m_pobjCommandMsgQ;
    CDPMsgQueue *m_pobjResponseMsgQ;
    CDPMsgQueue *m_pobjDiagRespMsgQ;
    CDPMsgQueue *m_objDiagCmdMsgQ;
    CDPMsgQueue *m_objDebugDataMsgQ;
    CDPMsgQueue *m_objHDLCDataMsgQ;

    CDPMsgQueue *m_qActionLogMsgQ;
    CDPMsgQueue *m_qDemPortLogMsgQ;
    CDPMsgQueue *m_qDiagPortLogMsgQ;
    CDPMsgQueue *m_qDebugDataLogMsgQ;
    CDPMsgQueue *m_qHDLCDataLogMsgQ;

    unsigned char m_ucSystem;
    U_CMDRESP_DATA m_UCmdRespData;

    CDPPCI755Wrapper g_objPCI755;
    CDPXMC5775Wrapper m_objXMC5775;
    SDPPCI755APP_DEVICELOC m_DPPCI755Details;
    SDPXMC5775APP_DEVICELOC m_DPXMC5775Details;

    CDPRS232Wrapper m_objRS232[NO_OF_PORTS];
    QString m_qstrFRADataFile;
    bool m_bIsAnaFlag;
    SDPPCI755_DATA_BUFFER m_sCurrentDataBuffer;

    class CEEPROM_RW *m_pobjEEPROM_RW;
    SSCM_DIAG_MON_PARAM m_SDiagMonData;
    SSCM_BITSTATUS m_SBITStatus;
    SDPPCI755_CONFIG m_SFRAConfig;
    SDPPCI755_ThreadInfo g_SthInfo[SCM_ATE_MAX_PCI755_BRDS];
    U8BIT g_u8FlgSweepFinished[SCM_ATE_MAX_PCI755_BRDS];
    U8BIT g_u8ThreadAcqStop[SCM_ATE_MAX_PCI755_BRDS];
    SDPPCI755_FLAGS Sflag;
    SDPPCI755_ONLINEDATA g_SData;
    SDPPCI755_RAW_DATA_THREAD_INFO g_SRawDataThreadInfo[SCM_ATE_MAX_PCI755_BRDS];
    U16BIT g_u16RawDataReadFlg[SCM_ATE_MAX_PCI755_BRDS];
    U16BIT g_u16CurrentDataReadFlg;
    U16BIT g_u16RandomDataReadFlg;
    U16BIT g_u16AnalysedDataReadFlg;
    U8BIT g_u8RandomSts[SCM_ATE_MAX_PCI755_BRDS];
    bool m_bSCM_Testcase_Running;
    U32BIT g_u32SweepSts;
    QString g_qstrAppPath;
    int m_iUserPrivil;
    unsigned long g_ulAppChecksum;
    bool m_bIsGraphBeingPlotted;
    unsigned long g_ulTime;
    unsigned int m_uiServoDataCount;
    unsigned char m_ucNoofScans;

    QFile m_qfFRALog;
    QString m_qstrSelectedTC;
    unsigned char m_ucConfiguredMode;
    volatile double m_dCurrRespPos;
    volatile double m_dCurrRespRate;
    bool m_bIsRespRead;
} S_GLOBAL, *PS_GLOBAL;
/**********************************************************/

#pragma pack(pop)

#endif // DP_SCM_STRUCTURES
