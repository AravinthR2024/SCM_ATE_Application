#ifndef CELIDEDCOMBOBOXDELEGATE_H
#define CELIDEDCOMBOBOXDELEGATE_H

#include <QStyledItemDelegate>
#include <QMap>


class CElidedItemDelegate : public QStyledItemDelegate
{
	public:
		QMap<QString, QString> x;
		unsigned int m_uiMaxLen = 0;

		QString displayText (const QVariant &value, const QLocale &) const override {
			return x.value (value.toString ());
		}

		void addKeyValue(QString in_qstrKey, QString in_qstrValue) {
			x.insert (in_qstrKey, in_qstrValue);
			if (m_uiMaxLen < (unsigned int) in_qstrValue.length ())
			{
				m_uiMaxLen = in_qstrValue.length ();
			}
		}

};

#endif // CELIDEDCOMBOBOXDELEGATE_H
