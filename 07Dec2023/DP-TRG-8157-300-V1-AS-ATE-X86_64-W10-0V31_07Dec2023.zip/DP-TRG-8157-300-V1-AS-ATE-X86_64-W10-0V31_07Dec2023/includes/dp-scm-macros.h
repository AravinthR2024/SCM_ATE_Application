#ifndef MACROS
#define MACROS

#include <QMessageBox>
#include <QDateTime>

#include "dp_types.h"

#pragma GCC diagnostic ignored "-Wtype-limits"

#define _DPPCI755_DRV_ENABLE_    // Undef to disable PCI driver functionalities
#define _DPXMC5775_DRV_ENABLE_   // Undef to disable XMC driver functionalities
#define _PORT_CONNECTED_     // undef to disable RS232 RW
#undef _TEMP_BIT_              // Temporary BIT_ status
#undef _TEMP_TX_RX_	// Undef to send the actual SCM Commands and receive response
#undef _HIDE_PCI_
#undef _TESTING_FRA_

#define SCM_ATE_APP_VER     "1.00"

#define PCI_BRD_NAME        "DP-PCI-755"
#define XMC_BRD_NAME        "DP-XMC-5775"

#define MODINIT_PCI_IDX     0
#define MODINIT_XMC_IDX     1

#define SCM_RESP_CNT        171
#define SCM_FIFO_FULL_INT        1
#define SCM_FIFO_EMPTY_INT       2
#define SCM_FIFO_THRESHOLD_INT   4
#define SCM_RESP_TIMEOUT_INT     8

#define PCI_BRD_IDX         0
#define XMC_BRD_IDX         0

#define SERVO_MODE          1
#define DIAGNOSTICS_MODE    2

#define MAX_RETRY_LOOP_CNT  3

#define DP_PI                   3.1415926535897
#define BIT_RESOLUTION_9BIT     256.0
#define BIT_RESOLUTION_13BIT    4096.0
#define BIT_RESOLUTION_14BIT    8192.0
#define BIT_RESOLUTION_16BIT    32768.0
#define BIT_RESOLUTION_EL_POS   22.5
#define BIT_RESOLUTION_AZ_POS   180.0
#define BIT_RESOLUTION_RATE     200.0
#define BIT_RESOLUTION_ANGLE    360.0
#define BIT_RESOLUTION_MAX_CUR  5.0

#define LOGTYPE_DEM_PORT    1
#define LOGTYPE_DIAG_PORT   2
#define LOGTYPE_ACTIONLOG   3
#define LOGTYPE_DEBUGDATA   4
#define LOGTYPE_HDLCDATA    5

#define ACTION_LOG_SIZE     20
#define DIAG_DATA_DISP_SIZE 160
#define WINDOW_TITLE        "DP-TRG-8157-300 SCM ATE Application"
#define CHANGE_PAGE         ui->stackedWidget->setCurrentIndex

#define ENABLE_MENUBAR(val) { \
	ui->menuSC_M_Operation->setEnabled(val);\
	ui->menu_BIT_Status->setEnabled(val);\
	ui->menu_Configuration->setEnabled(val);\
	ui->menu_Debug->setEnabled(val);\
	ui->menu_System->setEnabled(val);\
	}
#define CONFIG_FILE_DIR     "./config/"
#define LOGFILE_DIR         "./log_files/"


/* Modules */
#define MAX_MODULES         2
#define MODTBL_ROW_PCI_755  0
#define MODTBL_ROW_XMC_5775 1

#define ICON_SUCCESS        ":/images/images/img_checkmark.png"
#define ICON_FAILURE        ":/images/images/img_crossmark.png"
#define LED_RED             ":/images/images/ledred.png"
#define LED_GREEN           ":/images/images/ledgreen.png"
#define LED_GRAY            ":/images/images/ledgrey.png"

#define MODTBL_COL_BRDNAME  0
#define MODTBL_COL_BUSNO    1
#define MODTBL_COL_SLOTNO   2
#define MODTBL_COL_FUNCNO   3
#define MODTBL_COL_STATUS   4
#define MODTBL_COL_RESET    5
#define MODTBL_COL_CLOSE    6


#define DPSCM_INIT_0        0

#define DPSCM_SUCCESS       0
//#define DPSCM_BIT_SET       1
#define DPSCM_FAILURE       -1

#define VALUE_PI            3.1428

/* System Selection Enum */
enum SYSTEM_SELECTION
{
    SYSTEM_SEASPRAY_HDLC,
    SYSTEM_OSPREY50,
    SYSTEM_RTGA_EL,
    SYSTEM_RGA_RTGA_AZ
};

#define NO_OF_PORTS         2
#define NO_OF_SYSTEMS       4   /* RGA/RTGA AZ, RTGA EL, OSPREY 50, SEAPRAY */
#define NO_OF_ACTUATORS     2

#define COMMAND_PORT_IDX    0
#define DIAGNOSTIC_PORT_IDX 1

#define COMCFG_IDX_RGA_RTGA 0
#define COMCFG_IDX_SEASPRAY 1

#define ACTUATOR_EL         0
#define ACTUATOR_AZ         1

#define SIMULATE_TIME_INT   1
#define FREQ_RTGA_RGA       100
#define FREQ_SEASPRAY       1000
#define TOTAL_SIMULATIONS   205

#define PALETTE_R   148
#define PALETTE_G   205
#define PALETTE_B   255
#define PALETTE_RGB QPalette(QColor(PALETTE_R, PALETTE_G, PALETTE_B))
#define QSS_FILE    ":/styles/styles/BlueTheme.txt"
#define MSG_STYLE   "QMainWindow, QDialog {\
background-color: rgb(4, 67, 85);\
background-color: rgb(4, 95, 120);\
background-color: rgb(148, 205, 255);\
font: 9pt \"Arial Black\";\
}\
QPushButton {\
	background-color: qlineargradient(spread:reflect, x1:0.511, y1:0, x2:0.523, y2:1, stop:0 rgba(218, 218, 218, 255), stop:0.528409 rgba(245, 245, 245, 255), stop:1 rgba(218, 218, 218, 255));\
	border-radius: 2;\
border: 1px solid grey;\
color: black;\
padding: 6px 0;\
}\
QPushButton:pressed, QPushButton:focus {\
							   background-color: qlineargradient(spread:reflect, x1:0.511, y1:0, x2:0.523, y2:1, stop:0 rgba(210, 218, 223, 255), stop:0.528409 rgba(223, 237, 245, 255), stop:1 rgba(210, 218, 223, 255));\
border-radius: 2;\
border: 1px solid rgb(85, 170, 255);\
color: black;\
}\
QPushButton:hover:!pressed {\
				    background-color: qlineargradient(spread:reflect, x1:0.511, y1:0, x2:0.523, y2:1, stop:0 rgba(230, 230, 230, 255), stop:0.528409 rgba(246, 246, 246, 255), stop:1 rgba(230, 230, 230, 255));\
border-radius: 5;\
border: 1px solid rgb(85, 170, 255);\
color: black;\
}\
QPushButton:disabled\
{\
	background-color: rgb(200, 200, 200);\
}\
QPushButton\
{\
padding: 3px 5px;\
}\
"

#define SET_STYLESHEET(obj) {\
	QFile qFile(QSS_FILE);\
	if (!qFile.open(QIODevice::ReadOnly))\
{\
	return;\
	}\
	obj->setStyleSheet(qFile.readAll().data());\
	obj->setPalette(PALETTE_RGB);\
	qFile.close();\
	}

#define DISPLAY_MESSAGE_BOX(obj, title, msg)    {\
	QMessageBox msgbox(obj);\
	msgbox.setWindowTitle(title);\
	msgbox.setText(msg);\
	msgbox.layout()->setSizeConstraint(QLayout::SetFixedSize);\
    msgbox.setStyleSheet(MSG_STYLE);\
	msgbox.exec();\
	}

#define APPEND_ACTION_LOG(message, color) {\
	QString qstrTime = QDateTime::currentDateTime().toString("dd/MM/yyyy HH:mm:ss.zzz");\
	ui->teActionLog->append(QString("%1   - <span style=\"color: %3; font-weight: bold;\">%2</span>").arg(qstrTime).arg(message).arg(color));\
	}

#define CHECK_TC_RUNNING {\
    if (g_SGlobal.m_bSCM_Testcase_Running)\
    {\
        DISPLAY_MESSAGE_BOX(NULL, "Warning", "Testcase is Running.\nPlease stop the testcase to continue.");\
        return;\
    }\
}

/******************** GENERAL CONVERSIONS ********************/
#define CONV_BYTES_TO_MB(bytes)	bytes / 1024.0 / 1024.0
#define CONV_MB_TO_BYTES(mb)		mb * 1024.0 * 1024.0

#define CONV_QSTR_TO_SZ(qstr) qstr.toStdString().c_str()
/*************************************************************/

/******************** LOG FILES ********************/
#define LOG_FOLDER_PATH	QString("%1/SCM_ATE_Application/Logs/%2/").arg(QString(getenv("AppData")).replace('\\','/')).arg(g_SGlobal.g_qdatetimeRun.toString("dd_MMM_yyyy"))

#define LOG_ACTIVITY_PATH       QString("Activity_Logs/").prepend(LOG_FOLDER_PATH)
#define LOG_DEMPORT_PATH        QString("Demand_Port_Logs/").prepend(LOG_FOLDER_PATH)
#define LOG_DIAGPORT_PATH       QString("Diagnostic_Port_Logs/").prepend(LOG_FOLDER_PATH)
#define LOG_DEBUGDATA_PATH      QString("Debug_Data_Logs/").prepend(LOG_FOLDER_PATH)
#define LOG_HDLCDATA_PATH       QString("HDLC_Data_Logs/").prepend(LOG_FOLDER_PATH)
#define LOG_FRADATA_PATH        QString("FRA_Data_Logs/").prepend(LOG_FOLDER_PATH)
#define LOG_ENCODER_DATA_PATH   QString("Encoder_Data_Logs/").prepend(LOG_FOLDER_PATH)
/***************************************************/

/******************** ACTION LOG ********************/
//#define ACTIONLOG_FILENAME_FORMAT			"./Logs/Activity Log/activity_log_%s.txt"

/****************************************************/

/************************* SELF TEST ********************************/
#define SELFTEST_PAGE_ATE       0
#define SELFTEST_PAGE_HDLC      1

#define SELFTEST_HDLC_PAGE_TEXT  0
#define SELFTEST_HDLC_PAGE_FILE  1
/********************************************************************/

/*** Seaspray Configuration ***/
#define SEASPRAY_ADDR_TX    0x01
#define SEASPRAY_ADDR_RX    0x02

#define SEASPRAY_IDLE_FLAG  0x7E

#define SEASPRAY_RESET      1
#define SEASPRAY_NO_RESET   0

#define SEASPRAY_PEDESTAL_ON    1
#define SEASPRAY_PEDESTAL_OFF   2

#define SEASPRAY_FRAMEGAP_TIME  50  // MICROSECONDS

#define SEASPRAY_CONTINUOUS_TX  0
#define SEASPRAY_SINGLE_TX      1

#define SEASPRAY_ALL_DEVICE_MASTER  0x00

/// Seaspray Commands
#define SEASPRAY_CMD_ERR_NORESET_PEDESTAL_OFF   0x00
#define SEASPRAY_CMD_ERR_NORESET_PEDESTAL_ON    0x01
#define SEASPRAY_CMD_ERR_RESET_PEDESTAL_OFF     0x02
#define SEASPRAY_CMD_ERR_RESET_PEDESTAL_ON      0x03
/******************************/

/********** PBIT DISPLAY **********/
#define CHECK_PBIT_AZ       0x02
#define CHECK_CBIT_EL       0x01
/**********************************/

/***** LOG FILE NAMES *****/
#define LOGFILE_LRG_ANG_SLEW    "Rate_Mode_Response.csv"    // Temp
#define LOGFILE_TORQUE_SPEED    "Rate_Mode_Response.csv"    // Temp
#define LOGFILE_BIDIRECT_SCAN   "Pos_Mode_Dem.csv"
#define LOGFILE_CONT_RATE_MODE  "Rate_Mode_Response.csv"    // Temp
#define LOGFILE_RATE_MODE_ALT   "Rate_Mode_Response.csv"
#define LOGFILE_OPENLOOP_TEST   "Freq_Gain_Phase.csv"
#define LOGFILE_CLOSEDLOOP_TEST "Rate_Mode_Response.csv"    // Temp

enum LOG_TYPE
{
	LOG_INFO = 0,
	LOG_ERROR,
    LOG_PARTIAL_SUCCESS,
	LOG_SUCCESS,
	LOG_WARNING
};

enum SYSTEM_SELECTION_GUI
{
	SYS_RGA_RTGA = 0,
	SYS_SEASPRAY
};

enum WAVE_SELECTION // old
{
	WAVE_INVALID = -1,
	WAVE_SINE = 1,
	WAVE_RAMP,
	WAVE_SQUARE,
	WAVE_DC,
	WAVE_CIRCULAR
};

/*** Waveform Input Selection */
#if 0
enum WAVEINPUT_TYPE
{
	E_WAVEINP_DIGITAL = 0,
	E_WAVEINP_SINE,
	E_WAVEINP_RAMP,
	E_WAVEINP_SQUARE,
	E_WAVEINP_DC,
	E_WAVEINP_TOTAL_COUNT
};
#endif
enum WAVEINPUT_TYPE
{
    E_WAVEINP_SINE = 0,
    E_WAVEINP_RAMP,
    E_WAVEINP_SQUARE,
    E_WAVEINP_TOTAL_COUNT
};

/******************************/


enum PAGE_INDEX
{
	PAGE_INVALID = -1,
	PAGE_INIT,
	PAGE_CONFIG_RS422,
	PAGE_PBIT,
	PAGE_SELF_TEST,
	PAGE_FLASH_PROGRAMMING,
	PAGE_CONFIG_CTRL_LOOP_CONST,
	PAGE_MOTOR_CONTROL,
	PAGE_CBIT,
	PAGE_RESPONSE_MONITORING,
	PAGE_SYSTEM_DETAILS,
	PAGE_DIAG_MONITORING,
	PAGE_FPGA_RW,
    PAGE_COMMAND_RESPONSE_DEBUG,
    PAGE_ARRAY_IDENT,
    PAGE_ARRAY_IDENT_DIAG,
    PAGE_SEASPRAY_OPERATION
};

enum BIT_STATUS
{
	BIT_RESET = -1,
    BIT_SUCCESS,
    BIT_FAIL
};

enum DIAGNOSTIC_ID
{
	ID_00 = 0,
	ID_01,
	ID_02,
	ID_03,
	ID_04,
	ID_05,
	ID_06,
	ID_07,
    ID_08,
    ID_09,
    ID_10,
    ID_11,
    ID_12,
    ID_13,
    ID_14,
    ID_15,
	ID_16,
    ID_17,
    ID_18,
    ID_19,
    ID_20,
    ID_21,
    ID_22,
    ID_23,
    ID_24,
    ID_25,
    ID_26,
    ID_27,
    ID_28,
    ID_29,
    ID_30,
    ID_31,
    ID_32,
    ID_33,
    ID_34,
    ID_35,
    ID_36,
	ID_38 = 38,
	ID_39,
	ID_40,
	ID_41,
    ID_42,
	ID_43,
	ID_44,
	ID_45,
	ID_46,
	ID_47,
	ID_48,
	ID_49,
	ID_50,
	ID_51,
	ID_54 = 54,
	ID_55,
	ID_56,
	ID_57,
	ID_58,
	ID_59,
	ID_60,
	ID_61,
	ID_62,
	ID_63,
	ID_64,
	ID_65,
	ID_66,
	ID_67,
	ID_68,
	ID_69,
	ID_70,
	ID_71,
	ID_72,
	ID_73,
	ID_74,
	ID_75,
	ID_76,
    ID_77,
    ID_78,
    ID_79,
    ID_80,
    ID_81
};

#define DIAGDATA_MAX_VOL_28V_48V    100.0f
#define DIAGDATA_MIN_VOL_28V_48V    50.0f
#define DIAGDATA_MAX_VOL            100.0f
#define DIAGDATA_MIN_VOL            4.0f
#define DIAGDATA_CURR_MIN           5.0f
#define DIAGDATA_CURR_MAX           100.0f
#define DIAGDATA_TEMP_RESOLUTION    1.22
#define DIAGDATA_TEMP_CYCLE         -55
#define DIAGDATA_POWER_CYCLE        0
#define DIAGDATA_POWER_RESOLUTION   0.1
/************************** TEST CASES **************************/
#if 0
enum TEST_CASES
{
	TC_INVALID = -1,
	TC_OPEN_LOOP_BW_TEST,
	TC_CLOSED_LOOP_BW_TEST,
	TC_LRG_ANG_SLEW,
	TC_BIDIRECT_SCAN,
	TC_CONT_RATE_MODE,
	TC_RATE_MODE_ALT_SCAN,
	TC_TORQUE_SPEED
};
#endif

enum TEST_CASES
{
	E_TC_INVALID = -1,
	E_TC_SERVO_MODE,
	E_TC_DIAGNOSTICS_MODE,
	E_TC_CLOSED_LOOP_TEST,
	E_TC_MOTOR_AMP_TEST,
	E_TC_TFA_TEST_LOOP,
	E_TC_TFA_TEST_PLANT,
	E_TC_DIAG_DEM_MODE
};

enum DIAG_DEM_MODE_TEST
{
	DDTEST_INVALID = -1,
	DDTEST_LARGE_ANGLE_SLEW,
	DDTEST_BIDIR_SCAN,
	DDTEST_RATEMODE_ALT_SCAN,
	DDTEST_CONT_RATEMODE
};

/********** UART COMMAND ID **********/
#define CMDID_GET_FW_VERSION		0x00
#define CMDID_MOTOR_AMP_TEST		0x01
#define CMDID_TFA_TEST_LOOP_TEST	0x02
#define CMDID_TFA_TEST_PLANT_TEST	0x03
#define CMDID_DIAGNOSTICS_DEMAND	0x04
#define CMDID_CLOSELOOP_POS_TEST	0x05
#define CMDID_CLOSELOOP_RATE_TEST	0x06
#define CMDID_LOOP_CONST_UPDATE     0x07
#define CMDID_LOOP_CONST_READ		0x08
#define CMDID_DIAGNOSTICS_REG_READ	0x09
#define CMDID_TFA_OPEN_LOOP_TEST	0x10

/** Encoder Calibration Command ID */
#define CMDID_ENCODER_READ_VALUE	0x2021
#define CMDID_POSITION_READ_VALUE	0x2022
#define ENCODER_TIMEOUT			3

#define CMDCONV_AZ_POS			(180 / 32768)
#define CMDCONV_EL_POS			(22.5 / 256)
#define CMDCONV_AZ_RATE			(150 / 4096)
#define CMDCONV_MOTOR_CURRENT		(5 / 4096)
#define CMDCONV_MOTOR_CONTROL		(5 / 4096)
#define CMDCONV_MOTOR_ANGLE		(200 / 65536)
#define CMDCONV_PAYLOAD_ANGLE		(200 / 65536)
#define CMDCONV_GIMBAL_DEMAND		(200 / 65536)
#define CMDCONV_ANGLE_DEMAND		(200 / 65536)
#define CMDCONV_RATE_DEMAND		(200 / 65536)

#define DP_SCM_ARRAY_ID_5000_E      0x00
#define DP_SCM_ARRAY_ID_OSPREY_20   0x01
#define DP_SCM_ARRAY_ID_OSPREY_30   0x02
#define DP_SCM_ARRAY_ID_OSPREY_40   0x03
#define DP_SCM_ARRAY_ID_OSPREY_50   0x04

/***************************************************************/

/********** SOFTWARE PROGRAMMING FLASH **********/
#define BOOT_CMD_SYNC		0x55
#define BOOT_CMD_ERASE		0x01

#define BOOT_TIMEOUT		13000

#define RS232_TX_HEADER_1       0xAA
#define RS232_TX_HEADER_2       0x55
//#define RS232_TX_HEADER_3       0x12
//#define RS232_TX_HEADER_4       0xDB

#define RS232_RX_HEADER_1		0xFA
#define RS232_RX_HEADER_2		0x05
#define RS232_RX_HEADER_3		0xDB
#define RS232_RX_HEADER_4		0x5A

#define RS232_MAX_TX_PKT_LEN    512 + 12
#define RS232_MAX_RX_PKT_LEN    (RS232_MAX_TX_PKT_LEN + 2)
#define RS232_UART_BUFF_LEN     1024

#define WORD_SWAP(x)   ((((x)&0x0001)<<15) | (((x)&0x0002)<<13) | (((x)&0x0004)<<11) | (((x)&0x0008)<<9) | (((x)&0x00010)<<7) | (((x)&0x0020)<<5) | (((x)&0x0040)<<3) | (((x)&0x0080)<<1) | (((x)&0x8000)>>15) |\
	(((x)&0x4000)>>13) | (((x)&0x2000)>>11) | (((x)&0x1000)>>9) | (((x)&0x0800)>>7) | (((x)&0x0400)>>5) | (((x)&0x0200)>>3) | (((x)&0x0100)>>1))

#define BYTE_SWAP(x) ((((x)&0x01)<<7) | (((x)&0x02)<<5) | (((x)&0x04)<<3) | (((x)&0x08)<<1) | (((x)&0x80)>>7) | (((x)&0x40)>>5) | (((x)&0x20)>>3) | (((x)&0x10)>>1))
#define HTONS(x)	((((x)&0xff)<<8)|(((x) & 0xff00)>>8))
#define HTONL(x)    ((((x) & 0xff) << 24) |\
	(((x) & 0xff00) << 8) | \
	(((x) & 0xff0000UL) >> 8) | \
	(((x) & 0xff000000UL) >> 24))
/************************************************/

/********** SOFTWARE PROGRAMMING FLASH **********/
#define OPEN    1
#define CLOSE   0
#define DP_ERROR_BASE				-1000
#define DP_COM_PORT_ERROR			(DP_ERROR_BASE + 1)
#define DP_CHECKSUM_ERROR			(DP_ERROR_BASE + 2)
#define DP_INVALID_RX_STATE_ERROR	(DP_ERROR_BASE + 3)
#define DP_CMD_ID_MISMATCH_ERROR	(DP_ERROR_BASE + 4)
#define DP_TIMEOUT_ERROR			(DP_ERROR_BASE + 5)
#define DP_INVALID_CMD_ID			(DP_ERROR_BASE + 6)
#define DP_NULL_PTR_ERROR -1
#define DP_RESET			0
#define DP_SET				1

#define CLEAR_MSB			0x00FF
#define CLEAR_LSB			0xFF00

#define PRINT_LOG_FAILURE  -1
#define PRINT_LOG_SUCCESS  0
#define PRINT_LOG_MESSAGE  1


#define HEADER_1_STATE		0
#define HEADER_2_STATE		1
#define CMD_ID_1_STATE		2
#define CMD_ID_2_STATE		3
#define STATUS_1_STATE		4
#define STATUS_2_STATE		5
#define DATA_LEN_1_STATE	6
#define DATA_LEN_2_STATE	7
#define DATA_STATE			8
#define CHECKSUM_1_STATE	9
#define CHECKSUM_2_STATE	10

#define PRGMODE_FLASH_WRITE         0
#define PRGMODE_FLASH_READ          1
#define PRGMODE_FLASH_VERIFY        2
#define PRGMODE_FLASH_ERASE_SIZE	 3


#define DP_ERR_NO                                   -1000
#define DP_COM_PORT_NOT_OPENED                      (DP_ERR_NO + 1)
#define DP_CMD_NOT_TRANSMITED                       (DP_ERR_NO + 2)
#define DP_INVALID_BAUDRATE                         (DP_ERR_NO + 3)
#define DP_INVALID_DATABITS                         (DP_ERR_NO + 4)
#define DP_INVALID_PARITY                           (DP_ERR_NO + 5)
#define DP_INVALID_FLOW_CONTROL                     (DP_ERR_NO + 6)
#define ERROR_UART_RX_TIMED_OUT                     (DP_ERR_NO + 7)
#define DP_COM_PORT_CLOSED                          (DP_ERR_NO + 8)

#define DP_SCM_RS422_CMD_BASE            0
#define DP_SCM_FLASH_ERASE_CMD          (DP_SCM_RS422_CMD_BASE + 1)
#define DP_SCM_FLASH_START_CMD          (DP_SCM_RS422_CMD_BASE + 2)
#define DP_SCM_FLASH_LOAD_CMD           (DP_SCM_RS422_CMD_BASE + 3)
#define DP_SCM_FLASH_STOP_CMD           (DP_SCM_RS422_CMD_BASE + 4)
#define DP_SCM_FLASH_VERIFY_CMD         (DP_SCM_RS422_CMD_BASE + 5)
#define DP_SCM_FLASH_CKSM_READ_CMD      (DP_SCM_RS422_CMD_BASE + 6)

#define DP_SCM_FLASH_SIZE           9730652
#define DP_SCM_FLASH_PAGE_SIZE      256
#define DP_SCM_FLASH_PROGRESS_SLICE (1024 * 1024)

#define SCM_BOOTLOAD_TX_SIZE_BYTES          256
#define SCM_MAX_READBACK_DATASIZE           84478      //write data is around 247044 Expected read data max size as 250000
#define SCM_BOOTLOAD_RX_DATA_BYTES          (512*1024*1024) // Read full chip

#define SCM_UART_BUFF_LENGTH        1056
#define SCM_MAX_TX_PACKET_LENGTH    525
#define SCM_MAX_RX_PACKET_LENGTH   (SCM_MAX_TX_PACKET_LENGTH+2)
#define SCM_ADC_BUFF_SLICE_LENGTH   512
#define SCM_ADC_FIFO_LENGTH         (4096*4)
#define SCM_ADC_MAX_PACKET_COUNT     SCM_ADC_FIFO_LENGTH/(SCM_ADC_BUFF_SLICE_LENGTH/4)

#define SCM_FFT_BUFF_SLICE_LENGTH   512

#define SCM_FFT_BUFF_SLICE_LENGTH   512
#define SCM_FFT_FIFO_LENGTH         (8*1024*2)
#define SCM_FFT_MAX_PACKET_COUNT     SCM_FFT_FIFO_LENGTH/(SCM_FFT_BUFF_SLICE_LENGTH/4)

#define DP_SCM_FLASH_DATA_SIZE      11626

#define DP_SCM_FPGA_FLASH_SECTOR_ERASE_SIZE   (256)
#define DP_EW_ERROR_BUFF_SIZE       256
#define DP_SCM_FPGA_FLASH_SIZE					(9730652)
#define DP_SCM_FPGA_FLASH_PROGRESS_SLICE		(1024 * 1024)
#define DP_SCM_FPGA_FLASH_PAGE_WRITE_SIZE		 (256)
#define DP_SCM_FPGA_FLASH_PAGE_READ_SIZE		DP_SCM_FPGA_FLASH_PAGE_WRITE_SIZE
#define DP_SCM_FPGA_PACKET_SIZE				256

#define HEADER1				0xAA
#define HEADER2				0x55
#define FIXED_FRAME_LENGTH	8
#define FOOTER_SIZE			2
#define DATA_SIZE			262
#define DATA_BUFFER_SIZE	(FIXED_FRAME_LENGTH + FOOTER_SIZE + DATA_SIZE)
/************************************************/

/********** FPGA FLASH PROGRAMMING **********/
//#define DP_SCM_FPGA_FLASH_SECTOR_ERASE_SIZE		256
//#define DP_EW_ERROR_BUFF_SIZE					256
//#define DP_SCM_FPGA_FLASH_SIZE				9730652
//#define DP_SCM_FPGA_FLASH_PROGRESS_SLICE		(1024 * 1024)
//#define DP_SCM_FPGA_FLASH_PAGE_WRITE_SIZE		256
//#define DP_SCM_FPGA_FLASH_PAGE_READ_SIZE		DP_SPL_6996A_FPGA_FLASH_PAGE_WRITE_SIZE
//#define DP_FPGA_PACKET_SIZE       256

#define DP_SCM_FPGA_WRITE_CMD				0x11
#define DP_SCM_FPGA_READ_CMD				0x12
#define DP_SCM_FPGA_FLASH_ERASE_CMD          0x13
#define DP_SCM_FPGA_FLASH_PAGE_WRITE_CMD     0x14
#define DP_SCM_FPGA_FLASH_READ_CMD           0x15
/********************************************/

/********** EEPROM COMMAND ID **********/
#define TOTAL_EEPROM_LOCATIONS  32768

#define DP_SCM_EEPROM_BRD_INFO_WR_CMD    0x07
#define DP_SCM_EEPROM_BRD_INFO_RD_CMD    0x08
#define DP_SCM_EEPROM_CKSM_TST_CMD       0x09
#define DP_SCM_EEPROM_PTTRN_TST_CMD      0x0A
#define DP_SCM_EEPROM_WR_CMD             0x0B
#define DP_SCM_EEPROM_RD_CMD             0x0C
#define DP_SCM_EEPROM_CNTR_DATA_TST_CMD  0x0D
#define DP_SCM_EEPROM_WR_PRTCT_CMD       0x0E
#define DP_SCM_EEPROM_FULL_MEM_TST_CMD   0x0F

#define EEPROM_ENCAL_AZ_WRITE_ADDR			0x20
#define EEPROM_ENCAL_EL_WRITE_ADDR			0x21
#define EEPROM_ENCAL_AZ_READ_ADDR			EEPROM_ENCAL_AZ_WRITE_ADDR
#define EEPROM_ENCAL_EL_READ_ADDR			EEPROM_ENCAL_EL_WRITE_ADDR

#define EEPROM_CLC_INVERSION_WORD				0x10
#define EEPROM_CLC_ENABLE_ENDSTOP				0x10
#define EEPROM_CLC_ENABLE_NOISE_FILTER			0x10
#define EEPROM_CLC_ENABLE_RATE_FEED_FRWRD		0x10
#define EEPROM_CLC_ENABLE_LAG_CONTROLLER		0x10
#define EEPROM_CLC_MINIMUM_ENDSTOP				0x10
#define EEPROM_CLC_MAXIMUM_ENDSTOP				0x10
#define EEPROM_CLC_RATE_LIMIT					0x10
#define EEPROM_CLC_ACC_LIMIT					0x10
#define EEPROM_CLC_CUR_LIMIT					0x10
#define EEPROM_CLC_RATE_DEAD_ZONE				0x10
#define EEPROM_CLC_NOISEFILTER_CUTOFF_RATEMODE	0x10
#define EEPROM_CLC_NOISEFILTER_CUTOFF_POSMODE	0x10
#define EEPROM_CLC_DAMPING_FACTOR				0x10
#define EEPROM_CLC_PREFILTER_DISCOUNT			0x10
#define EEPROM_CLC_PREFILTER_LINEARZONE			0x10
#define EEPROM_CLC_RATE_FEEDFRWRD_BW			0x10
#define EEPROM_CLC_TOTAL_GEAR_RATIO			0x10
#define EEPROM_CLC_PROP_GAIN_LOADED			0x10
#define EEPROM_CLC_DERV_GAIN_LOADED			0x10
#define EEPROM_CLC_PROP_GAIN_UNLOADED			0x10
#define EEPROM_CLC_DERV_GAIN_UNLOADED			0x10
#define EEPROM_CLC_NORM_GAIN_LOADED			0x10
#define EEPROM_CLC_NORM_GAIN_UNLOADED			0x10
#define EEPROM_CLC_LAGFILTER_LAG_BREAKPOINT		0x10
#define EEPROM_CLC_LAGFILTER_LEAD_BREAKPOINT		0x10
#define EEPROM_CLC_LOWPASS_FILTER_BW			0x10
/***************************************/

/********** MOTOR CONTROL CONFIGURATION **********/
#define MOTOR_CTRL_DIGITAL      0	// Temp - old selection for SCM Control Page
#define MOTOR_CTRL_ANALOG       1	// Temp - old selection for SCM Control Page

#define FRA_MIN_FREQUENCY       0.0002f  // Hz
#define FRA_MAX_FREQUENCY       2000.0f  // Hz

#define FRA_MIN_STEP_FREQ       0.0f     // Hz
#define FRA_MIN_STEP_LOG        2.0f    // Log

#define FRA_MIN_NO_OF_CYCLES    0
#define FRA_MAX_NO_OF_CYCLES    1000

#define FRA_MIN_ANGLE           0
#define FRA_MAX_ANGLE           359

#define FRA_MIN_DELAY_SEC       0       // sec
#define FRA_MAX_DELAY_SEC       1000    // sec
#define FRA_MIN_DELAY_CYC       0       // cycles
#define FRA_MAX_DELAY_CYC       20      // cycles

#define FRA_ADCCONV_CONST_VOLT  0.005f  // Volts
#define FRA_ADCCONV_CONST_RMS   0.005f  // RMS

#define FRA_MIN_RMS_AMP         -7.07f  // V
#define FRA_MAX_RMS_AMP         7.07f   // V
#define FRA_MIN_VOLT            -10.0f  // V
#define FRA_MAX_VOLT            10.0f   // V
#define FRA_MIN_RMS_BIAS         -7.07f  // V
#define FRA_MAX_RMS_BIAS         7.07f   // V

#define FRA_ADC_CHN_COUNT       2
#define FRA_ADC_1               0
#define FRA_ADC_2               1

#define FRA_GAIN_TYPE_RATIO		0
#define FRA_GAIN_TYPE_DB		1
#define FRA_GAIN_TYPE_DBV		2
#define FRA_GAIN_TYPE_DBmV		3

#define DPPCI755_FREQUENCY          0
#define DPPCI755_GAIN_WITH_RATIO    1
#define DPPCI755_GAIN_WITH_DB       2
#define DPPCI755_GAIN_WITH_DBV      3
#define DPPCI755_GAIN_WITH_DBmV     4
#define DPPCI755_PHASE              5

#define MOTORCONTROL_PAGE_COUNT	2
#define MOTORCONTROL_PAGE_TESTCASE	0
#define MOTORCONTROL_PAGE_FRA		1

#define GRAPHTYPE_INVALID       -1
#define GRAPHTYPE_VS_RATE        0
#define GRAPHTYPE_VS_POSITION   1
#define GRAPHTYPE_GAIN_PHASE    2

#define DPPCI755_POLAR_COORDINATES      1
#define DPPCI755_CARTESIAN_COORDINATES  2

/*** Newly Added ***/
#define DP_SCM_RATE_MODE 0
#define DP_SCM_POS_MODE  1

#define DP_SCM_POS_MIN  -180.0
#define DP_SCM_POS_MAX  179.99
#define DP_SCM_RATE_MIN -200.0
#define DP_SCM_RATE_MAX 200.0
/*******************/
#define RAW_DATA_MAX_COUNT      5440

enum GAIN_VALUES
{
	GAIN_1,
	GAIN_10,
	GAIN_100,
	GAIN_1000
};

/*************************************************/

/********** CONTROL LOOP CONSTANTS CONFIG **********/
#define CLC_PARAM_COUNT     27
#define WRITE_CLC_PARAM_HEADER(qstrWriteData) {\
	qstrWriteData.append("Inversion Word,");\
	qstrWriteData.append("Enable Endstop,");\
	qstrWriteData.append("Enable Noise Filter,");\
	qstrWriteData.append("Enable Rate Feed Forward,");\
	qstrWriteData.append("Enable Lag Controller,");\
	qstrWriteData.append("Minimum Endstop,");\
	qstrWriteData.append("Maximum Endstop,");\
	qstrWriteData.append("Rate Limit,");\
	qstrWriteData.append("Acceleration Limit,");\
	qstrWriteData.append("Current Limit,");\
	qstrWriteData.append("Rate Dead Zone,");\
	qstrWriteData.append("Rate Mode Noise Filter Cutoff,");\
	qstrWriteData.append("Noise Filter Damping Factor,");\
	qstrWriteData.append("Pre-filter Discount Factor,");\
	qstrWriteData.append("Pre-filter Linear Zone,");\
	qstrWriteData.append("Rate Feed Forward Bandwidth,");\
	qstrWriteData.append("Total Gear Ratio,");\
	qstrWriteData.append("Loaded Proportional Gain,");\
	qstrWriteData.append("Loaded Derivative Gain,");\
	qstrWriteData.append("Unloaded Proportional Gain,");\
	qstrWriteData.append("Unloaded Derivative Gain,");\
	qstrWriteData.append("Loaded Normalization Gain,");\
	qstrWriteData.append("Unloaded Normalization Gain,");\
	qstrWriteData.append("Lag Filter Lag Breakpoint,");\
	qstrWriteData.append("Lag Filter Lead Breakpoint,");\
    qstrWriteData.append("Lowpass Filter Bandwidth,");\
    qstrWriteData.append("Current P Gain,");\
    qstrWriteData.append("Current I Gain");\
	qstrWriteData.append("\r\n");\
	}

enum CTRL_LOOP_CONFIG
{
	CLC_INVERSION_WORD,
	CLC_ENABLE_ENDSTOP,
	CLC_ENABLE_NOISE_FILTER,
	CLC_ENABLE_RATE_FEED_FRWRD,
	CLC_ENABLE_LAG_CONTROLLER,
	CLC_MINIMUM_ENDSTOP,
	CLC_MAXIMUM_ENDSTOP,
	CLC_RATE_LIMIT,
	CLC_ACC_LIMIT,
	CLC_CUR_LIMIT,
	CLC_RATE_DEAD_ZONE,
	CLC_NOISEFILTER_CUTOFF_RATEMODE,
	CLC_DAMPING_FACTOR,
	CLC_PREFILTER_DISCOUNT,
	CLC_PREFILTER_LINEARZONE,
	CLC_RATE_FEEDFRWRD_BW,
	CLC_TOTAL_GEAR_RATIO,
	CLC_PROP_GAIN_LOADED,
	CLC_DERV_GAIN_LOADED,
	CLC_PROP_GAIN_UNLOADED,
	CLC_DERV_GAIN_UNLOADED,
	CLC_NORM_GAIN_LOADED,
	CLC_NORM_GAIN_UNLOADED,
	CLC_LAGFILTER_LAG_BREAKPOINT,
	CLC_LAGFILTER_LEAD_BREAKPOINT,
	CLC_LOWPASS_FILTER_BW,
    CLC_CURRLOOP_P_GAIN,
    CLC_CURRLOOP_I_GAIN,
	CLC_TOTAL_NO_OF_PARAMETERS
};

#define CMDID_MOTOR_AMP_TEST    0x01
#define CMDID_TESTLOOP_TEST     0x02
#define CMDID_TESTLOOP_PLANT    0x03
#define CMDID_DIAGDEM_RATE      0x04
#define CMDID_DIAGDEM_POS       0x05
#define CMDID_CLOSED_POS        0x06
#define CMDID_CLOSED_RATE       0x07
#define CMDID_CLCCONFIG_UPDATE  0x08
#define CMDID_CLCCONFIG_READ    0x09
#define CMDID_DIAGMON_READ      0x0A
#define CMDID_ZERO_POS_CALIB    0x0B
#define CMDID_ARRAY_IDENT       0x0C
#define CMDID_OPERATION_MODE    0x0D

/***************************************************/

/*************** GRAPH *********************/
#define _QSS_DARK_        /** define _QSS_DARK_ for Dark Mode, undef for Light Mode */

enum GRAPH_SELECTION
{
	GRAPH_FREQ_GAIN_PHASE,
	GRAPH_POS_MODE_BIDIR_SCAN_DEM,
	GRAPH_RATE_MODE_ALT_SCAN_RES
};

#ifdef _QSS_DARK_    /* APPEARANCE FOR DARK MODE */

#define GRAPH_BACKGROUND_COLOR          QColor(0x00, 0x00, 0x00)        /* BLACK */
#define LEGEND_TEXT_COLOR               QColor(0xFF, 0xFF, 0xFF)        /* WHITE */
#define GRID_COLOR                      QColor(0xA0, 0xA0, 0xA4)        /* GRAY */
#define XAXIS_BASE_TICK_COLOR           QColor(0xFF, 0xFF, 0xFF)        /* WHITE */
#define YAXIS2_BASE_TICK_COLOR          QColor(0x00, 0xFF, 0xFF)        /* CYAN */
#define TRACER2_COLOR                   QColor(0x00, 0x80, 0x80)        /* DARK CYAN */

#else           /* APPEARANCE FOR LIGHT MODE */

#define GRAPH_BACKGROUND_COLOR          QColor(0xFF, 0xFF, 0xFF)        /* WHITE */
#define LEGEND_TEXT_COLOR               QColor(0x00, 0x00, 0x00)        /* BLACK */
#define GRID_COLOR                      QColor(0x00, 0x00, 0x00)        /* BLACK */
#define XAXIS_BASE_TICK_COLOR           QColor(0x00, 0x00, 0x00)        /* BLACK */
#define YAXIS2_BASE_TICK_COLOR          QColor(0x00, 0x00, 0xFF)        /* BLUE */
#define TRACER2_COLOR                   QColor(0x00, 0x00, 0x80)        /* DARK BLUE */

#endif

/* APPEARANCE WITH NO CHANGE FOR DARK AND LIGHT MODE */
#define SUBGRID_COLOR                   QColor(0x80, 0x80, 0x80)        /* DARK GRAY */

#define YAXIS_BASE_TICK_COLOR           QColor(0xFF, 0x00, 0x00)        /* RED */
#define PEN_WIDTH                       3

#define LEGEND_COLOR                    GRAPH_BACKGROUND_COLOR
#define LEGEND_BORDER_COLOR             QColor(0xC0, 0xC0, 0xC0)        /* LIGHT GRAY */

#define LABEL_FONT                      QFont("Arial", 13)

#define TRACER_STYLE                    QCPItemTracer::tsCircle
#define TRACER_SIZE                     10.0
#define TRACER_LINE_COLOR               QColor(0x80, 0x80, 0x00)        /* DARK YELLOW */

#define TRACER1_COLOR                   QColor(0x80, 0x00, 0x00)        /* DARK RED */
#define TRACER1_LABEL_POSITION          Qt::AlignLeft | Qt::AlignRight

#define TRACER2_LABEL_POSITION          Qt::AlignRight | Qt::AlignBottom

#define TRACER3_COLOR                   QColor(0x02, 0xFF, 0x02)        /* GREEN */
#define TRACER3_LABEL_POSITION          Qt::AlignRight | Qt::AlignTop

#define MOUSE_TRACER_LABEL_COLOR        LEGEND_TEXT_COLOR
#define MOUSE_TRACER_COLOR              QColor(0x00, 0x80, 0x80)        /* DARK CYAN */
#define MOUSE_TRACER2_COLOR             QColor(0x80, 0x00, 0x80)        /* DARK MAGENTA */
#define MOUSE_TRACER3_COLOR             QColor(0x00, 0x80, 0x00)        /* DARK GREEN */

#define ENABLE_BODE_GRAPH(graph) {\
    QSharedPointer<QCPAxisTickerLog> ticker(new QCPAxisTickerLog);\
    graph->xAxis->setTicker(ticker);\
    graph->xAxis->setScaleType(QCPAxis::stLogarithmic);\
    graph->yAxis->ticker().data()->setTickCount(10);\
    graph->yAxis2->ticker().data()->setTickCount(10);\
    graph->xAxis->grid()->setSubGridVisible(true);\
    }

#define DISABLE_BODE_GRAPH(graph) {\
    QSharedPointer<QCPAxisTicker> ticker(new QCPAxisTicker);\
    graph->xAxis->setTicker(ticker);\
    graph->xAxis->setScaleType(QCPAxis::stLinear);\
    graph->yAxis->ticker().data()->setTickCount(4);\
    graph->yAxis2->ticker().data()->setTickCount(4);\
    graph->xAxis->grid()->setSubGridVisible(false);\
    }

#define SET_TRACING_STATE(state) {\
    /* if (m_bIsGraphPlotted) {*/\
	m_pTracer->setVisible(state);\
	m_pTracer2->setVisible(state);\
    /*m_pTracer3->setVisible(m_bPlot3Tracers);*/\
	m_pTracerLine->setVisible(state);\
	m_pTracerLabel->setVisible(state);\
	m_pTracerLabel2->setVisible(state);\
    /*m_pTracerLabel3->setVisible(m_bPlot3Tracers);*/\
	ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);\
    /*}*/\
	}

/********* RS232 **********/
#define RS232_GET_ERR(sRetval, ucPort) {\
	if (sRetval != DPRS232_SUCCESS)\
{\
	QString qstrErrMsg = QString("");\
	sRetval = g_SGlobal.m_objRS232[ucPort].DPRS232Wrap_GetLastError(sRetval, qstrErrMsg);\
	if (sRetval != DPRS232_SUCCESS || qstrErrMsg.isEmpty())\
{\
	qstrErrMsg.sprintf("Cannot get error details");\
	}\
	DISPLAY_MESSAGE_BOX(this, "RS422 Communication", qstrErrMsg);\
	emit sig_updateActionLog("RS422 Configuration failed : " + qstrErrMsg, LOG_ERROR);\
	return;\
	}\
	}

/********** CONTROL LOOP CONSTANTS **********/
#undef _BIN_FILE_  // Undef _BIN_FILE_ to store control loop constant in CSV, define to store in BIN file
typedef struct _S_CTRL_LOOP_CONFIG
{
		int m_iInversionWord;
		unsigned char m_ucEnableEndstops;
		unsigned char m_ucEnableNoiseFilter;
		unsigned char m_ucEnableRateFeedFrwrd;
		unsigned char m_ucEnableLagController;
        double m_dEndstopMin;
        double m_dEndstopMax;
		double m_dRateLimit;
		double m_dAccLimit;
        double m_dCurLimit;
        double m_dRateDeadZone;
		double m_dNoiseFilterCutoff_Rate;
		double m_dNoiseFilterDamping;
		double m_dPrefilterDiscount;
		double m_dPrefilterLinearZone;
		double m_dRateFeedFrwrdBW;
		double m_dTotalGearRatio;
		double m_dPropGain_Loaded;
		double m_dDervGain_Loaded;
		double m_dPropGain_Unload;
		double m_dDervGain_Unload;
		double m_dNormGain_Loaded;
		double m_dNormGain_Unload;
		double m_dLagFilterLagBP;
		double m_dLagFilterLeadBP;
		double m_dLowpassBW;
        double m_dCurrPGain;
        double m_dCurrIGain;
} S_CTRL_LOOP_CONFIG, *PS_CTRL_LOOP_CONFIG;

/********** CBIT **********/
#define SCM_CBIT_ERR_GIMBAL_STS         0x10
#define SCM_CBIT_ERR_RS422_COMM         0x11
#define SCM_CBIT_ERR_SERVO_LOOP         0x12
#define SCM_CBIT_ERR_I2T_TEMP           0x13
#define SCM_CBIT_ERR_INTERNAL           0x14

#define SCM_CBIT_ERR_AZ_CCW_LIM         0x100
#define SCM_CBIT_ERR_AZ_CW_LIM          0x101
#define SCM_CBIT_ERR_EL_POS_DEM         0x102
#define SCM_CBIT_ERR_EL_NEG_DEM         0x103
#define SCM_CBIT_ERR_EL_ZETSTS          0x104
#define SCM_CBIT_ERR_AZ_ZETSTS          0x105

#define SCM_CBIT_ERR_RS422_CHKSUM       0x110
#define SCM_CBIT_ERR_RS422_FORMAT       0x111
#define SCM_CBIT_ERR_RS422_PARTIALMSG   0x112
#define SCM_CBIT_ERR_RS422_COMMLOSS     0x113
#define SCM_CBIT_ERR_RS422_AZ_RATE      0x114
#define SCM_CBIT_ERR_TS422_EL_RATE      0x115

#define SCM_CBIT_ERR_AZ_POSITION        0x120
#define SCM_CBIT_ERR_EL_POSITION        0x121

#define SCM_CBIT_ERR_EL_INTERNAL        0x130
#define SCM_CBIT_ERR_AZ_INTERNAL        0x131

#define SCM_CBIT_ERR_I2T_EL_EXCEED      0x140
#define SCM_CBIT_ERR_I2T_AZ_EXCEED      0x141
#define SCM_CBIT_ERR_TEMP_EL_FAULT      0x142
#define SCM_CBIT_ERR_TEMP_AZ_FAULT      0x143
/**************************/

/********** PBIT **********/
#define SCM_PBIT_ERR_EL_PROGMEMCRC      0x20
#define SCM_PBIT_ERR_EL_EPROMCRC        0x21
#define SCM_PBIT_ERR_EL_RAMFAULT        0x22
#define SCM_PBIT_ERR_AZ_PROGMEMCRC      0x23
#define SCM_PBIT_ERR_AZ_EPROMCRC        0x24
#define SCM_PBIT_ERR_AZ_RAMFAULT        0x24
/**************************/

/********** BIT **********/
#define CHECK_BIT_STATUS(n,p) {\
	unsigned long d = n;\
	if(!(d && (!(d & (d-1)))))\
	return;\
	while(!(d&1)){\
	d = d >> 1;\
	++p;\
	}\
	}

#define GET_DIAG_ID(tok,ID) {\
	switch(tok) {\
    case 0x10: ID = 3; break;\
    case 0x11: ID = 4; break;\
    case 0x12: ID = 5; break;\
    case 0x13: ID = 7; break;\
    case 0x14: ID = 6; break;\
    \
    case 0x103: ID = 40; break;\
    case 0x104: ID = 41; break;\
    \
	case 0x123: ID = 14; break;\
	case 0x1234: ID = 14; break;\
	default: ID = 15;\
	}\
	}
/*************************/

/******************** REPORT GENERATION MACROS AND TEMPLATES ********************/
#define LOGFNAME_ACTIVITY	"activity_log_%s.txt"
#define LOGFNAME_BITSTATUS	"bitstatus_%s.csv"
#define LOGFNAME_OPEN_LOOP	"testlog_openloop_%s.csv"
#define LOGFNAME_CLOSED_LOOP	"testlog_closedloop_%s.csv"
#define LOGFNAME_ANGLESKEW	"testlog_angleskew_%s.csv"
#define LOGFNAME_BIDIRSCAN	"testlog_biscan_%s.csv"
#define LOGFNAME_CONT_RATE	"testlog_ratecont_%s.csv"
#define LOGFNAME_ALTSCAN_RATE	"testlog_ratealter_%s.csv"
#define LOGFNAME_DIAG_LOG   "diag_port_log_%s.csv"
#define LOGFNAME_DEM_LOG   "demand_port_log_%s.csv"
#define LOGFNAME_DEBUG_LOG  "debug_data_%s.csv"

#define LOGFNAME_DATETIMEFORMAT	"yyyy-MM-dd_HH-mm-ss"
#define REPORTFILE_DATETIMEFORMAT	"yyyy-MM-dd_HH-mm-ss"
#define REPORT_DATEFORMAT		"MMM dd, yyyy"
#define REPORT_TIMEFORMAT		"HH:mm:ss.zzz"
#define REPORT_DATETIMEFORMAT		QString(REPORT_DATEFORMAT).append(" ").append (REPORT_TIMEFORMAT);

#define LOGFILE_MAX_SIZE		2.0	/* in MB */

#define LOGFNAME_SETFNAME(var, fname, fpath) {\
	var.sprintf (fname, QDateTime::currentDateTime ().toString (LOGFNAME_DATETIMEFORMAT).toStdString ().c_str ());\
	var.prepend (fpath);\
}

enum E_REPORT_FILE_SELECT
{
	E_REPORT_BIT_FILE = 0
};

#define REPORT_FOLDER_PATH	QString("./Reports/")
#define REPORT_BIT_PATH		REPORT_FOLDER_PATH + QString("/BIT_Status")
#define REPORT_BIT_FNAME		"report_bitstatus_%s.html"

// //// control loop constants
#define DP_SCM_CONFIG_ST            1
#define DP_SCM_EN_ENDSTOP           1
#define DP_SCM_EN_NLP               1
#define DP_SCM_EN_RFF               1
#define DP_SCM_EN_LAG               1
#define DP_SCM_THETA_MIN_PREC       7.6699E-4
#define DP_SCM_THETA_MAX_PREC       7.6699E-4
#define DP_SCM_LIM_R_PREC			2.1293E-4
#define DP_SCM_LIM_A_PREC			1.2783E-4
#define DP_SCM_LIM_I_PREC			0.002
#define DP_SCM_RATE_DZ_PREC			2.1293E-4
#define DP_SCM_OMG_NLP_PREC			9.587E-3
#define DP_SCM_ZETA_NLP_PREC		7.8125E-3
#define DP_SCM_ALPHA_PREC			7.8125E-3
#define DP_SCM_DELTA_PREC			8.545E-6
#define DP_SCM_OMG_RFF_PREC			9.587E-3
#define DP_SCM_N_PREC				5.9505E-5
#define DP_SCM_KPL_PREC				7.4506E-5
#define DP_SCM_KDL_PREC				7.4506E-5
#define DP_SCM_KPM_PREC				7.4506E-5
#define DP_SCM_KDM_PREC				7.4506E-5
#define DP_SCM_WL_PREC				1.1921E-7
#define DP_SCM_WM_PREC				1.1921E-7
#define DP_SCM_OMG_1_PREC			7.669E-3
#define DP_SCM_OMG_2_PREC			7.669E-3
#define DP_SCM_OMG_LP_PREC			9.587E-3
#define DP_SCM_CURR_P_GAIN_PREC     0.0001
#define DP_SCM_CURR_I_GAIN_PREC     0.0001

#define DP_SCM_DSP_CODE  0xAA
#define DP_SCM_FPGA_CODE 0x55

#define DP_SCM_ERRLOG_CNT 100
#define DP_SCM_BITSTS_CNT 50

#define CHECK_PORT_OPEN(port) {\
if (port == DIAGNOSTIC_PORT_IDX)\
{\
    if (g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].getPortStatus() == DPSCM_FAILURE)\
    {\
        DISPLAY_MESSAGE_BOX(this, "Port Status", "Diagnostics Port is not Open\nPlease open the port to Continue");\
        return;\
    }\
}\
else\
{\
    if (g_SGlobal.m_objRS232[COMMAND_PORT_IDX].getPortStatus() == DPSCM_FAILURE)\
    {\
        DISPLAY_MESSAGE_BOX(this, "Port Status", "Real Time Port is not Open\nPlease open the port to Continue");\
        return;\
    }\
}\
}


/* Header format
 * 1 - %s :: Title - Filename
 */
#define REPORT_HEADER	"<!DOCTYPE html>\
<meta charset = 'UTF-8'>\
<html>\
<head>\
<title>%s</title>\
<style>\
body\
{\
font-size: 18px;\
}\
\
.Pass,\
.PASS,\
.pass\
{\
color: green;\
text-align: center;\
text-transform: capitalize;\
}\
\
.Fail,\
.fail,\
.FAIL\
{\
color: red;\
text-align: center;\
text-transform: capitalize;\
}\
\
table\
{\
border: 1px solid black;\
border-collapse: collapse;\
}\
\
td, th {\
padding: 5px 3px;\
border: 2px solid black;\
border-collapse:collapse;\
}\
\
td\
{\
text-align: center;\
}\
\
th.front_page {\
padding: 10px 20px;\
font-size: 24px;\
}\
\
th\
{\
font-size: 1.05em;\
}\
\
h1\
{\
font-size: 32px;\
}\
\
hr\
{\
border: 0.1em solid black;\
border-radius: 50%%;\
}\
\
div.testcase_div\
{\
\
}\
\
div.testcase_title\
{\
color: darkblue;\
text-align: center;\
}\
\
div.testcase_subtitle\
{\
color: darkblue;\
text-align: center;\
font-size: 20px;\
}\
\
div.testcase_report\
{\
\
}\
\
.overall-status\
{\
font-weight: bold;\
font-size: 19px;\
text-transform: capitalize;\
}\
\
.MainTest,\
.maintest,\
.MAINTEST\
{\
text-align: left;\
font-weight: bolder;\
}\
\
.SubTest,\
.subtest,\
.SUBTEST\
{\
text-align: left;\
padding-left: 1em;\
}\
\
.SubTest:before,\
.subtest:before,\
.SUBTEST:before\
{\
content: '☛  ';\
white-space: pre;\
position: relative;\
}\
\
@media print\
{\
table {\
border: solid #000 !important;\
border-width: 1px 0 0 1px !important;\
page-break-inside: auto;\
}\
\
tr\
{\
page-break-inside: avoid;\
page-break-after: auto;\
}\
\
td, th {\
border: solid #000 !important;\
border-width: 0 1px 1px 0 !important;\
}\
\
hr.front_page {\
page-break-after: always;\
}\
\
#print_btn\
{\
visibility: hidden;\
}\
}\
</style>\
</head>\
<body>"

/* Format
 * No parameters
 */
#define REPORT_FOOTER "<br/>\
</body>\
</html>"

/* Format
 * 1 - %s		:: Image path
 * 2 - %s		:: Image path
 * 3 - %s		:: Selected System (Seaspray, Osprey 50, RTGA Az/RGA, RTGA El)
 * 4 - %d		:: Software Major Version (1) (As in 1V00)
 * 5 - %02d	:: Software Minor Version (00) (As in 1V00)
 * 6 - %d		:: System Major Version (1) (As in 1V00)
 * 7 - %02d	:: System Minor Version (00) (As in 1V00)
 * 8 - %d		:: Firmware Major Version (1) (As in 1V00)
 * 9 - %02d	:: Firmware Minor Version (00) (As in 1V00)
 * 10 - %s	:: Current Date (Feb 24, 2023)
 * 11 - %X	:: Checksum (9846870) (As in 0x9846870)
 * 12 - %s	:: Current Time (14:10:10)
 * 13 - %s	:: Build Date (Feb 24, 2023)
 * 14 - %s	:: Build Time (14:10:10)
 * 15 - %s	:: Logged-in User (Administrator)
 */
#define REPORT_SYS_SW_DETAILS "<div><img src='file:/%s/images/DP_Logo.png' style='width: 180px; height: 56px; float:left' alt='DP_logo'><img src='file:/%s/images/Leonardo_Logo.png' alt='Leonardo_logo' style='width: 180px; height: 56px; float: right'></div>\
<br/><br/><br/><br/>\
<input type='button' id='print_btn' onclick='window.print()' style='font-size: 28px; float: right; border: 3pt ridge darkgray; height: 50px; width: 50px;' value='&#128438;'>\
<h1 align = center>SERVO CONTROL MODULE TEST REPORT</h1>\
<h2 align = center>BIT Status Report</h2><br/>\
<table width=90%% height=30%% align=center>	<!-- Details (header) table -->\
<tr height=30%%>\
<th class='front_page' colspan=2>SCM Details</th>\
<th class='front_page' colspan=2>Software Details</th>\
</tr>\
<tr>\
<td style='text-align: left'>Selected System</td>\
<td style='text-align: left'>%s</td>\
<td style='text-align: left'>Software Version</td>\
<td style='text-align: left'>%dV%02d</td>\
</tr>\
<tr>\
<td style='text-align: left'>System Version</td>\
<td style='text-align: left'>%dV%02d</td>\
<td style='text-align: left'>Firmware Version</td>\
<td style='text-align: left'>%dV%02d</td>\
</tr>\
<tr>\
<td style='text-align: left'>Test Date</td>\
<td style='text-align: left'>%s</td>\
<td style='text-align: left'>Checksum</td>\
<td style='text-align: left'>0x%X</td>\
</tr>\
<tr>\
<td style='text-align: left'>Test Time</td>\
<td style='text-align: left'>%s</td>\
<td style='text-align: left'>Build Date</td>\
<td style='text-align: left'>%s</td>\
</tr>\
<tr>\
<td colspan=2></td>\
<td style='text-align: left'>Build Time</td>\
<td style='text-align: left'>%s</td>\
</tr>\
</table>\
<br/><br/><br/>\
\
<table style='font-size: 16px' align=center>	<!-- Tester and approver table -->\
<tr style='font-size: 16px; text-align: left;'>\
<td style='font-size: 16px; text-align: left;' width=20%%>Tested by</td>\
<td style='font-size: 16px; text-align: center;'>%s</td>\
<td style='font-size: 16px; text-align: left' width=20%%>Verified by</td>\
<td style='font-size: 16px; text-align: left'>________________________</td>\
<td style='font-size: 16px; text-align: left' width=20%%>Approved by</td>\
<td style='font-size: 16px; text-align: left'>________________________</td></tr>\
<tr style='font-size: 16px; text-align: left'>\
<td style='font-size: 16px; text-align: left'>Signature</td>\
<td style='font-size: 16px; text-align: left'>________________________</td>\
<td style='font-size: 16px; text-align: left'>Signature</td>\
<td style='font-size: 16px; text-align: left'>________________________</td>\
<td style='font-size: 16px; text-align: left'>Signature</td>\
<td style='font-size: 16px; text-align: left'>________________________</td></tr>\
<tr style='font-size: 16px; text-align: left'>\
<td style='font-size: 16px; text-align: left'>Date</td>\
<td style='font-size: 16px; text-align: left'>________________________</td>\
<td style='font-size: 16px; text-align: left'>Date</td>\
<td style='font-size: 16px; text-align: left'>________________________</td>\
<td style='font-size: 16px; text-align: left'>Date</td>\
<td style='font-size: 16px; text-align: left'>________________________</td></tr>\
</table>\
<br>\
<hr class='front_page'>"\

/********************************************************************************/

#endif // MACROS
