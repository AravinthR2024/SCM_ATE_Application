/**
* \file dpxmc5775_12_pro.h
* \brief This file contains the function prototypes of all the functions or API's are available for the DP-XMC-5775
*
*	The prototypes of all the functions or API's are available in this file
*
*	Copyright (C) 2023 Data Patterns (India) Ltd. \n
*
*/

#ifndef DPXMC5775_12_PRO_H_
#define DPXMC5775_12_PRO_H_

#include "dp_types.h"

#if defined(__cplusplus) || defined(__cplusplus__)
extern "C" {
#endif

//PRAGMA_PACK_PUSH(1)
#pragma pack(push, 1)
/***********************************Structures************************/

/**
*\struct    _SDPXMC5775_12_DEVICE_LOCATION
*\brief  	This structure contains members to hold the device locations details such as bus number, slot number and function number.
*
*/
typedef struct _SDPXMC5775_12_DEVICE_LOCATION
{
    union
    {
        struct
        {
            U8BIT m_u8BusNo;		/*!< This member holds the bus number of the pci device */
            U8BIT m_u8SlotNo;		/*!< This member holds the slot number of the pci device */
            U8BIT m_u8FunctionNo;	/*!< This member holds the function number of the pci device */
        }pci;
    }u;
	
}PACK_ATTRIBUTE SDPXMC5775_12_DEVICE_LOCATION, *PSDPXMC5775_12_DEVICE_LOCATION;

/**
*\struct    _SDPXMC5775_12_DRIVER_DETAILS
*\brief  	This structure contains members to hold the driver details which includes the driver type ID and driver version details.
*
*/
typedef struct _SDPXMC5775_12_DRIVER_DETAILS
{
    U16BIT m_u16DriverTypeId;			/*!< This member holds the driver type Id.*/
    U16BIT m_u16DriverVersion;			/*!< This member holds the driver version. Higher word (bit 8 to 15) contains driver version and lower word (bit 0 to 7) contains revision values (version format : <highword>.<low word>).*/
	
}PACK_ATTRIBUTE SDPXMC5775_12_DRIVER_DETAILS, *PSDPXMC5775_12_DRIVER_DETAILS;

/**
*\struct 	:_SDPXMC5775_12_DEVICE_DETAILS
*\brief  	:This structure contains members to hold the device details. The device details includes the device ID and device version details.
*
*/
typedef struct _SDPXMC5775_12_DEVICE_DETAILS
{
    U16BIT m_u16DeviceId;			/*!<This member holds the device ID*/
	U16BIT m_u16DeviceVersion;		/*!<This member holds the device version. Higher word (bit 8 to 15) contains device version and lower word (bit 0 to 7) contains revision values (version format : <highword>.<low word>).*/
	
}PACK_ATTRIBUTE SDPXMC5775_12_DEVICE_DETAILS, *PSDPXMC5775_12_DEVICE_DETAILS;

/**
*\struct    _SDPXMC5775_12_GLUE_LOGIC_DETAILS
*\brief  	This structure contains members to hold the glue logic details which includes FPGA type ID and FPGA revision number.
*
*/
typedef struct _SDPXMC5775_12_GLUE_LOGIC_DETAILS
{	
	U16BIT 	m_u16FPGATypeId;		/*!< This member holds the FPGA type ID */
	U16BIT 	m_u16FPGARevisonNo;		/*!< This member holds the FPGA revision number*/
	
}PACK_ATTRIBUTE SDPXMC5775_12_GLUE_LOGIC_DETAILS, *PSDPXMC5775_12_GLUE_LOGIC_DETAILS;

/**
*\struct    _SDPXMC5775_12_HDLC_FRAME_CONFIG
*\brief  	This structure contains members to hold the HDLC frame configuration details which includes idel flag, slave address, command data, velocity data, spare1 data and spare2 data.
*
*/
typedef struct _DPXMC5775_12_HDLC_FRAME_CONFIG
{	
	U8BIT 	m_u8IdelFlag;		/*!< This member holds the idel flag value. Every time, when no data is sent the HDLC link sends IDLE. When, idel flag value describes the header / footer value of HDLC frame packet */
	U8BIT 	m_u8SlaveAddress;	/*!< This member holds the address of slave device (0x0 to 0xFF)*/
	U8BIT 	m_u8Command;		/*!< This member holds the command value (0x0 to 0xFF)*/
	U16BIT 	m_u16Velocity;		/*!< This member holds the velocity data */
	U16BIT 	m_u16Spare1;		/*!< This member holds the spare1 data */
	U8BIT 	m_u8Spare2;			/*!< This member holds the spare2 data */
	
}PACK_ATTRIBUTE SDPXMC5775_12_HDLC_FRAME_CONFIG, *PSDPXMC5775_12_HDLC_FRAME_CONFIG;

//PRAGMA_PACK_POP()
#pragma pack(pop)

/****************************function  prototypes ******************************/
/*!
* \addtogroup Common_Functions List of common driver functions
* \brief This section details the general API implementations.
* @{
*/

/**
*\brief		  This function is used to find the total number of DP-XMC-5775 devices present in the system. The appropriate device can be opened and further operations can be performed for that particular device.
*
*\param[out]  out_pu16TotalDevices	It specifies the output data pointer to hold the number of DP-XMC-5775 devices present in the system
*
*\retval	  ::DPXMC5775_12_SUCCESS is returned upon success
*\retval	  ::DP_DRV_ERR_INVALID_POINTER is returned if the specified output data pointer to hold the number of DP-XMC-5775 devices present in the system is null
*
*\par Pre-requisite Functions and it's sequence:
*		      This function does not have any pre-requisite function and can be called at any time if needed.
*/
S32BIT STDCALL DPXMC5775_12_GetTotalDeviceFound(PU16BIT out_pu16TotalDevices);

/**
*\brief 	  This function is used to get pci details such as bus number, slot number and function number for the DP-XMC-5775 devices. These location details can be used to open the device.
*
*\param[out]  out_pSAllDevLocDetails	It specifies the output structure pointer to device location information of all detected boards. See ::_SDPXMC5775_12_DEVICE_LOCATION for structure member description. This pointer should be capable of holding device locations specified in in_u16MaxDevices parameter.
*\param[in]   in_u16MaxDevices			It specifies the maximum number of device locations that can be stored in the buffer.
*
*\retval	  ::DPXMC5775_12_SUCCESS is returned upon success
*\retval	  ::DP_DRV_ERR_INVALID_POINTER is returned if the specified output structure pointer to device location information of all detected boards is null
*
*\par Pre-requisite Functions and it's sequence:
*			  -# ::DPXMC5775_12_GetTotalDeviceFound( )
*/
S32BIT STDCALL DPXMC5775_12_GetAllDeviceLocations(PSDPXMC5775_12_DEVICE_LOCATION out_pSAllDevLocDetails, U16BIT in_u16MaxDevices);

/**
*\brief 	 This function is used to open the DP-XMC-5775 device and obtain the handle for that specified device. Further operations on the device can be performed by using this handle. All the other operations related to the particular device can be performed only after this function is called successfully. A device once opened cannot be opened again before closing it (if it is not initialized as shared device). If the the device is initialized as shared after open by using ::DPXMC5775_12_SetDeviceShare( ) function, multiple open can be performed.
*\n \n Note: Multiple applications should not use same functionality in one device.
*
*\param[in]	 in_pSDeviceOpenInfo	It specifies the input structure pointer to hold the location details of the board number, which is to be opened. See ::_SDPXMC5775_12_DEVICE_LOCATION for structure member description. The location details can be get from ::DPXMC5775_12_GetAllDeviceLocations( ) function.
*\param[out] out_phDeviceHandle		It specifies the output void pointer to hold device handle of opened device.
*
*\retval	 ::DPXMC5775_12_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_POINTER is returned if the specified input structure pointer to hold the location details of the board number, which is to be opened is null
*\retval	 ::DPXMC5775_12_ERR_DEVICE_BUSY is returned if the the device is already opened
*
*\par Pre-requisite Functions and it's sequence:
*		     -# ::DPXMC5775_12_GetTotalDeviceFound( )
*		     -# ::DPXMC5775_12_GetAllDeviceLocations( )
*/
S32BIT STDCALL DPXMC5775_12_Open(PSDPXMC5775_12_DEVICE_LOCATION in_pSDeviceOpenInfo, DP_DRV_HANDLE out_phDeviceHandle);

/**
*\brief 	 This function is used to close the device with the handle obtained during ::DPXMC5775_12_Open( ) function. If the device is initialized as shared device the number of close should be matched with the number open is called for the device.
*			\n \n Note: The device has to be closed at the time of terminating the application
*
*\param[in]	 in_hHandle		It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*
*\retval	 ::DPXMC5775_12_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	 ::DP_DRV_ERR_DEVICE_NOT_OPEN is returned if the device is not opened
*
*\par Pre-requisite Functions and it's Sequence:
*		    -# ::DPXMC5775_12_GetTotalDeviceFound( )
*			-# ::DPXMC5775_12_GetAllDeviceLocations( )
*			-# ::DPXMC5775_12_Open( )
*/
S32BIT STDCALL DPXMC5775_12_Close(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	 This function is used to reset all the registers of the specified device. On reset, the device comes to the default state (as power on state).
*
*\param[in]	 in_hHandle		It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*
*\retval	 ::DPXMC5775_12_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\par Pre-requisite Functions and it's Sequence:
*		    -# ::DPXMC5775_12_GetTotalDeviceFound( )
*			-# ::DPXMC5775_12_GetAllDeviceLocations( )
*			-# ::DPXMC5775_12_Open( )
*/
S32BIT STDCALL DPXMC5775_12_Reset(DP_DRV_HANDLE in_hHandle);
 
/**
*\brief		 This function is used to get the device location information (bus number, slot number and function number) of the specified device.
*
*\param[in]	 in_hHandle				It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[out] out_pSDeviceLocation	It specifies the output structure pointer to hold the device location details. See ::_SDPXMC5775_12_DEVICE_LOCATION for structure member description.
*
*\retval	 ::DPXMC5775_12_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	 ::DP_DRV_ERR_INVALID_POINTER is returned if the output structure pointer to hold the device location details is null
*
*\par Pre-requisite Functions and it's Sequence:
*		    -# ::DPXMC5775_12_GetTotalDeviceFound( )
*			-# ::DPXMC5775_12_GetAllDeviceLocations( )
*			-# ::DPXMC5775_12_Open( )
*/
S32BIT STDCALL DPXMC5775_12_GetDeviceLocation(DP_DRV_HANDLE in_hHandle, PSDPXMC5775_12_DEVICE_LOCATION out_pSDeviceLocation);

/**
*\brief 	  This function is used to get the error message corresponding to the error code. The error message specify briefly the cause of the error.
*
*\param[in]   in_s32ErrCode		It specifies the error code for which error message to be fetched
*\param[out]  out_ps8ErrMsg		It specifies the output data pointer to hold the address of the character array to get the error message of the given error code(size:in_u16BufSize)
*\param[in]   in_u16BufSize		It specifies the size (in bytes) of the buffer which includes string termination character ('\0').
*
*\retval	  ::DPXMC5775_12_SUCCESS is returned upon success
*\retval	  ::DP_DRV_ERR_INVALID_POINTER is returned if the output data pointer to hold the address of the character array to get the error message of the given error code is null
*
*\par Pre-requisite Functions and it's Sequence:
*             This function does not have any pre-requisite function and can be called at any time if needed. Usually this function will be called whenever other driver function returns with error.
*/
S32BIT STDCALL DPXMC5775_12_GetErrorMessage(S32BIT in_s32ErrCode, PS8BIT out_ps8ErrMsg, U16BIT in_u16BufSize);

/**
*\brief 	  This function is used to get the driver details which includes the driver type ID and driver version details.
*
*\param[out]  out_pSDriverDetails	It specifies the output structure pointer to read the driver details(Driver type ID and Driver version). See ::_SDPXMC5775_12_DRIVER_DETAILS for structure member description.
*
*\retval	  ::DPXMC5775_12_SUCCESS is returned upon success
*\retval	  ::DP_DRV_ERR_INVALID_POINTER is returned if the specified output structure pointer to read the driver details is null
*
*\par Pre-requisite Functions and it's Sequence:
*			  This function does not have any pre-requisite function and can be called at any time if needed.
*/
S32BIT STDCALL DPXMC5775_12_GetDriverDetails(PSDPXMC5775_12_DRIVER_DETAILS out_pSDriverDetails);

/**
*\brief		   This function is used to get the device details which includes the device ID and device version details.
*
*\param[in]    in_hHandle			It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[out]   out_pSDeviceDetails	It specifies the output structure pointer to hold the device details(Device ID & Device version). See ::_SDPXMC5775_12_DEVICE_DETAILS for structure member description.
*
*\retval	   ::DPXMC5775_12_SUCCESS is returned upon success
*\retval	   ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	   ::DP_DRV_ERR_INVALID_POINTER is returned if the specified output structure pointer to hold the device details is null
*
*\par Pre-requisite Functions and it's Sequence:
*			-# ::DPXMC5775_12_GetTotalDeviceFound( )
*           -# ::DPXMC5775_12_GetAllDeviceLocations( )
*           -# ::DPXMC5775_12_Open( )
*/
S32BIT STDCALL DPXMC5775_12_GetDeviceDetails(DP_DRV_HANDLE in_hHandle, PSDPXMC5775_12_DEVICE_DETAILS out_pSDeviceDetails);

/**
*\brief 	 This function is used to get the glue logic details which includes the FPGA type ID and FPGA version details.
*
*\param[in]	 in_hHandle				It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[out] out_pSGlueLogicDetails	It specifies the output structure pointer to hold the glue logic details(FPGA type ID & FPGA version). See ::_SDPXMC5775_12_GLUE_LOGIC_DETAILS structure for member description.
*
*\retval	::DPXMC5775_12_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output structure pointer to hold the glue logic details is null
* 
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPXMC5775_12_GetTotalDeviceFound( )
*		-# ::DPXMC5775_12_GetAllDeviceLocations( )
*		-# ::DPXMC5775_12_Open( )
*/
S32BIT STDCALL DPXMC5775_12_GetGlueLogicDetails(DP_DRV_HANDLE in_hHandle, PSDPXMC5775_12_GLUE_LOGIC_DETAILS out_pSGlueLogicDetails);

/**
*\brief		 This function is used to write the data into the specified FPGA register offset.
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from ::DPXMC5775_12_Open( ) function
*\param[in]	 in_u32Offset		It specifies the FPGA register offset value of opened device
*\param[in]  in_u32WriteData	It specifies the write data to write the specified FPGA register offset
*
*\retval	::DPXMC5775_12_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPXMC5775_12_GetTotalDeviceFound( )
*		-# ::DPXMC5775_12_GetAllDeviceLocations( )
*		-# ::DPXMC5775_12_Open( )
*/
S32BIT STDCALL DPXMC5775_12_WriteReg(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, U32BIT in_u32WriteData);

/**
*\brief 	 This function is used to read the data from the specified FPGA register offset.
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from ::DPXMC5775_12_Open( ) function 
*\param[in]	 in_u32Offset		It specifies the FPGA register offset value of opened device
*\param[out] out_pu32ReadData	It specifies the output data pointer to hold the read data from specified FPGA register offset
*
*\retval	::DPXMC5775_12_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output data pointer to hold the read data from specified FPGA register offset is null
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPXMC5775_12_GetTotalDeviceFound( )
*		-# ::DPXMC5775_12_GetAllDeviceLocations( )
*		-# ::DPXMC5775_12_Open( )
*/
S32BIT STDCALL DPXMC5775_12_ReadReg(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, PU32BIT out_pu32ReadData);

/**
*\brief			This function is used to enable or disable the device share option(opening same device more than one time).
*
*\param[in]		in_hHandle		It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[in]		in_u8EnaDis		It specifies the device share enable / disable value(min:0 to max:1).
*								\n Where,
*								\n 0 - Disable,
*								\n 1 - Enable.
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DPXMC5775_12_ERR_INVALID_ENADIS is returned if the specified device share enable / disable value is out of limit(0 to 1)
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*/
S32BIT STDCALL DPXMC5775_12_SetDeviceShare(DP_DRV_HANDLE in_hHandle, U8BIT in_u8EnaDis);
/*!
* @}
*/

/******************************* Board Specific ************************************/
/*!
* \addtogroup Board_Functions List of device specific driver functions
* \brief This section details the device specific API implementations.
* @{
*/

/**
*\brief			This function is used to enable / disable the firmware file loading. 
*
*\param[in]		in_hHandle		It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[in]		in_u8EnaDis		It specifies the firmware file loading enable / disable (min:0 to max:1).
*								\n Where,
*								\n 0 - Disable,
*								\n 1 - Enable.
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DPXMC5775_12_ERR_INVALID_ENADIS is returned if the firmware file loading enable / disable is out of limit (0 to 1)
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*/
S32BIT STDCALL DPXMC5775_12_EnableFirmwareLoad(DP_DRV_HANDLE in_hHandle, U8BIT in_u8EnaDis);

/**
*\brief			This function is used to configure the mode(HDLC or UART protocol) for channel 2. By default the channel is configured as UART protocol. 
*
*\param[in]		in_hHandle		It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[in]		in_u8ModeSel	It specifies the mode selection (max:3) (0,1,2 - UART protocol, 3 - HDLC protocol)
*								\n Where,
*								\n 0 - RGA or RTGA AZ mode,
*								\n 1 - Legacy RTGA EL mode,
*								\n 2 - Osprey50 mode,
*								\n 3 - Seaspray (HDLC) mode.
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DPXMC5775_12_ERR_INVALID_MODESEL is returned if the mode selection is out of limit (0 to 3)
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*/
S32BIT STDCALL DPXMC5775_12_ModeConfiguration(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ModeSel);

/**
*\brief			This function is used to configure the master(DP-XMC-5775) address. By defualt the master address is configured as 0.
*
*\param[in]		in_hHandle		It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[in]		in_u8Address	It specifies the address of master device (0x0 to 0xFF)
*								\n Where,
*								\n 0x0 - Accept the response data of all devices,
*								\n 0x1 to 0xFF - Accept the response data only if specified address matches
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*				-# ::DPXMC5775_12_ModeConfiguration( )
*/
S32BIT STDCALL DPXMC5775_12_HDLC_SetMasterAddress(DP_DRV_HANDLE in_hHandle, U8BIT in_u8Address);

/**
*\brief			This function is used to configure the HDLC transmission frame packet. The packet configuration details include the idel flag, slave address, command, velocity data, spare1 and spare2 data.
*
*\param[in]		in_hHandle				It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function
*\param[in]		in_pSHDLCFrameConfig	It specifies the input structure pointer which holds the HDLC transmission frame packet configuration details. See ::_SDPXMC5775_12_HDLC_FRAME_CONFIG for structure member description.
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DP_DRV_ERR_INVALID_POINTER is returned if the input structure pointer which holds the HDLC transmission frame packet configuration details is null
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*				-# ::DPXMC5775_12_ModeConfiguration( )
*				-# ::DPXMC5775_12_HDLC_SetMasterAddress( )
*/
S32BIT STDCALL DPXMC5775_12_HDLC_FrameConfig(DP_DRV_HANDLE in_hHandle, PSDPXMC5775_12_HDLC_FRAME_CONFIG in_pSHDLCFrameConfig);

/**
*\brief			This function is used to start the HDLC protocol by sending the HDLC transmission frame packet to specified slave device.
*
*\param[in]		in_hHandle			It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[in]		in_u8RepeatCount	It specifies the number of times to send the HDLC frame packets (max:255)
*									\n Where,
*									\n 0 - Continuous transmission
*									\n 1 to 255 - Repeate the frame as per count
*\param[in]		in_u16FrameGapTime	It specifies the frame gap time in micro seconds(min:1 to max:5000)
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DPXMC5775_12_ERR_INVALID_REPEATCOUNT is returned if the repeat count to send the HDLC frame packets is out of limit (0 to 255)
*\retval		::DPXMC5775_12_ERR_INVALID_FRAMEGAPTIME is returned if the frame gap time in micro seconds is out of limit (1 to 5000)
*\retval		::DPXMC5775_12_ERR_FRAMEPKT_NOT_CONFIGURED is returned if the HDLC transmission frame packet is not configured
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*				-# ::DPXMC5775_12_ModeConfiguration( )
*				-# ::DPXMC5775_12_HDLC_SetMasterAddress( )
*				-# ::DPXMC5775_12_HDLC_FrameConfig( )
*/
S32BIT STDCALL DPXMC5775_12_HDLC_StartFrame(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RepeatCount, U16BIT in_u16FrameGapTime);

/**
*\brief			This function is used to stop the transmission of HDLC protocol.
*
*\param[in]		in_hHandle		It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*				-# ::DPXMC5775_12_ModeConfiguration( )
*				-# ::DPXMC5775_12_HDLC_SetMasterAddress( )
*				-# ::DPXMC5775_12_HDLC_FrameConfig( )
*				-# ::DPXMC5775_12_HDLC_StartFrame( )
*/
S32BIT STDCALL DPXMC5775_12_HDLC_StopFrame(DP_DRV_HANDLE in_hHandle);

/**
*\brief			This function is used to get the total number of HDLC frame packets transmitted.
*
*\param[in]		in_hHandle			It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[out]	out_pu32FrameCount	It specifies the output data pointer to hold the total number of HDLC frame packets transmitted
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DP_DRV_ERR_INVALID_POINTER is returned if the output data pointer to hold the total number of HDLC frame packets transmitted is null
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*				-# ::DPXMC5775_12_ModeConfiguration( )
*				-# ::DPXMC5775_12_HDLC_SetMasterAddress( )
*				-# ::DPXMC5775_12_HDLC_FrameConfig( )
*				-# ::DPXMC5775_12_HDLC_StartFrame( )
*/
S32BIT STDCALL DPXMC5775_12_HDLC_GetFrameCount(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32FrameCount);

/**
*\brief			This function is used to configure the response timeout. If response data is not received with in the configured timeout, the response timeout error shall be set.
*
*\param[in]		in_hHandle			It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[out]	in_u16RespTimeOut	It specifies the timeout value to wait untill the response data to receive(In terms of micro seconds)(min:1 to max:1000) 
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DPXMC5775_12_ERR_INVALID_RESPTIMEOUT is returned if the timeout value to wait untill the response data to receive is out of limit(1 to 1000)
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*				-# ::DPXMC5775_12_ModeConfiguration( )
*				-# ::DPXMC5775_12_HDLC_SetMasterAddress( )
*/
S32BIT STDCALL DPXMC5775_12_HDLC_SetRespTimeout(DP_DRV_HANDLE in_hHandle, U16BIT in_u16RespTimeOut);

/**
*\brief			This function is used to configure the FIFO threshold value. If the threshold interrupt is enabled using ::DPXMC5775_12_EnableInterrupt( ) function then the threshold interrupt shall be generated based on the threshold value.
*
*\param[in]		in_hHandle				It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[in]		in_u16ThresholdCount	It specifies the FIFO threshold value (min:1 to max:1023)
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DPXMC5775_12_ERR_INVALID_THRESHOLDCOUNT is returned if the FIFO threshold value is out of limit(1 to 1023)
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*				-# ::DPXMC5775_12_ModeConfiguration( )
*				-# ::DPXMC5775_12_HDLC_SetMasterAddress( )
*/
S32BIT STDCALL DPXMC5775_12_SetFifoThreshold(DP_DRV_HANDLE in_hHandle, U16BIT in_u16ThresholdCount);

/**
*\brief			This function is used to enable the FIFO (FIFO Empty, Full and Threshold) and reponse timeout interrupts. The enabled interrupts shall be captured in ::DPXMC5775_12_WaitForEvents( ) function. In case of FIFO threshold interrupt has to be enabled, the threshold value has to be configured before enabling it. In case of response timeout interrupt has to be enabled, the reponse timeout value has to be configured before enabling it. 
*
*\param[in]		in_hHandle			It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[in]		in_u16IntType		It specifies the interrupt type to mask(min:0x1 to max: 0xF)
*									\n Where,
*									\n Bit0 - represents the FIFO empty,
*									\n Bit1 - represents the FIFO full,
*									\n Bit2 - represents the FIFO threshold,
*									\n Bit3 - represents the response timeout error.
*\param[in]		in_u8IntPropagate	It specifies the interrupt propagation enable / disable value(max:1). It is applicable only for xenomai OS.
*									\n Where,
*									\n 0 - No Propagation,
*									\n 1 - Propagate Interrupt.
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DPXMC5775_12_ERR_INVALID_INTTYPE is returned if the interrupt type to mask is out of limit(0x1 to 0xF)
*\retval		::DPXMC5775_12_ERR_INVALID_INTPROPAGATE is returned if the interrupt propagation enable / disable value is out of limit(0 to 1)
*\retval		::DPXMC5775_12_ERR_RESPTIMEOUT_NOT_CONFIGURED is returned if the response timeout value is not configured
*\retval		::DPXMC5775_12_ERR_THRESHOLDVALUE_NOT_CONFIGURED is returned if the threshold value is not configured 
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*				-# ::DPXMC5775_12_ModeConfiguration( )
*				-# ::DPXMC5775_12_HDLC_SetMasterAddress( )
*				-# ::DPXMC5775_12_HDLC_SetRespTimeout( ) - if only applicable for response timeout interrupt has to be enabled
*				-# ::DPXMC5775_12_SetFifoThreshold( ) - if only applicable for FIFO threshold interrupt has to be enabled
*/
S32BIT STDCALL DPXMC5775_12_EnableInterrupt(DP_DRV_HANDLE in_hHandle, U16BIT in_u16IntType, U8BIT in_u8IntPropagate);

/**
*\brief			This function is used to disable the interrupt which are interrupts is enabled.
*
*\param[in]		in_hHandle		It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DPXMC5775_12_ERR_INT_NOT_ENABLED is returned if the interrupt is not enabled
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*				-# ::DPXMC5775_12_ModeConfiguration( )
*				-# ::DPXMC5775_12_HDLC_SetMasterAddress( )
*				-# ::DPXMC5775_12_HDLC_SetRespTimeout( ) - if only applicable for response timeout interrupt has to be enabled
*				-# ::DPXMC5775_12_SetFifoThreshold( ) - if only applicable for FIFO threshold interrupt has to be enabled
*				-# ::DPXMC5775_12_EnableInterrupt( )
*/
S32BIT STDCALL DPXMC5775_12_DisableInterrupt(DP_DRV_HANDLE in_hHandle);

/**
*\brief			This function is used to clear the FIFO.
*
*\param[in]		in_hHandle		It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*/
S32BIT STDCALL DPXMC5775_12_ClearFifo(DP_DRV_HANDLE in_hHandle);

/**
*\brief			This function is used to get the total number of data available in FIFO.
*
*\param[in]		in_hHandle			It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[out]	out_pu32FIFOCount	It specifies the output data pointer to hold the total number of FIFO data count
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DP_DRV_ERR_INVALID_POINTER is returned if the output data pointer to hold the total number of FIFO data count is null
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*/
S32BIT STDCALL DPXMC5775_12_GetFifoCount(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32FIFOCount);

/**
*\brief			This function is used to start or stop the reception of response data receive.
*
*\param[in]		in_hHandle			It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[in]		in_u8StartStop		It specifies the start/stop the response data receive.(max:1)
*									\n Where,
*									\n 0 - Stop reception,
*									\n 1 - Start reception.
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DPXMC5775_12_ERR_INVALID_STARTSTOP is returned if the start/stop the response data receive is out of limit(0 to 1)
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*				-# ::DPXMC5775_12_ModeConfiguration( )
*				-# ::DPXMC5775_12_HDLC_SetMasterAddress( )
*				-# ::DPXMC5775_12_HDLC_SetRespTimeout( ) - if only applicable for FIFO threshold interrupt has to be enabled
*				-# ::DPXMC5775_12_SetFifoThreshold( ) - if only applicable for response timeout interrupt has to be enabled
*				-# ::DPXMC5775_12_EnableInterrupt( )
*				-# ::DPXMC5775_12_SetFifoThreshold( )
*/
S32BIT STDCALL DPXMC5775_12_HDLC_StartStopReception(DP_DRV_HANDLE in_hHandle, U8BIT in_u8StartStop);

/**
*\brief       This function is used to monitor and read the interrupt status. It will wait(block / non-block / timeout) until the specified events / interrupts occurs. It shall unblock once the particular event or all events occured based on the option selection. This function can be used only if the interrupt(s) are enabled.
*
*\param[in]	  in_hHandle			It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function 
*\param[in]   in_u16EventMask 		It specifies the event mask value(min:0x1 to max:0xF)
*									\n Where,
*									\n Bit3 - represents the response timeout error.
*\param[in]   in_u16Option 			It specifies the option to wait for all events or any events. Whether the function to be unblocked if any events occurred or all specified events.(max:1)
*									\n Where,
*									\n 0 - wait for any event, 
*									\n 1 - wait for all event.
*\param[in]   in_pu32Timeout 		It specifies the input data pointer to hold the interrupt timeout value(in milliseconds)
*									\n Where,
*									\n NULL Pointer - Block (Infinite Time Wait),
*									\n Data 0 - Non-block (Immediate Release),
*									\n Data other than 0 - Timed Block (Release based on timeout value).
*\param[out]  out_pu32EventStatus 	It specifies the output data pointer to hold the current interrupt events status.
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DPXMC5775_12_ERR_INT_NOT_ENABLED is returned if the interrupt is not enabled
*\retval		::DPXMC5775_12_ERR_INVALID_EVENTMASK is returned if the event mask value is out of limit or interrupt is not enabled for current event mask value(0x1 to 0xFF)
*\retval		::DPXMC5775_12_ERR_INVALID_OPTION is returned if the option to wait for all events or any events is out of limit(0 to 1)
*\retval		::DP_DRV_ERR_INVALID_POINTER is returned if the output data pointer to hold the current interrupt events status is null
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*				-# ::DPXMC5775_12_ModeConfiguration( )
*				-# ::DPXMC5775_12_HDLC_SetMasterAddress( )
*				-# ::DPXMC5775_12_HDLC_FrameConfig( )
*				-# ::DPXMC5775_12_HDLC_StartFrame( )
*				-# ::DPXMC5775_12_HDLC_SetRespTimeout( ) - if only applicable for response timeout interrupt has to be enabled
*				-# ::DPXMC5775_12_SetFifoThreshold( ) - if only applicable for FIFO threshold interrupt has to be enabled
*				-# ::DPXMC5775_12_EnableInterrupt( )
*/
S32BIT STDCALL DPXMC5775_12_WaitForEvents(DP_DRV_HANDLE in_hHandle, U16BIT in_u16EventMask, U16BIT in_u16Option, PU32BIT in_pu32Timeout, PU32BIT out_pu32EventStatus);

/**
*\brief			This function is used to get the slave response data.
*
*\param[in]		in_hHandle				It specifies the device handle which obtained from ::DPXMC5775_12_Open( ) function
*\param[in]   	in_pu32Timeout 			It specifies the input data pointer to hold the timeout value(in milliseconds) to wait the specified FIFO interrupt events.
*										\n Where,
*										\n NULL Pointer - Block (Infinite Time Wait),
*										\n Data 0 - Non-block (Immediate Release),
*										\n Data other than 0 - Timed Block (Release based on timeout value).
*\param[in]   	in_u32CountToRead 		It specifies the total count to read the response data from FIFO.
*\param[out]	out_pu32ResponseData	It specifies the output data pointer to hold the response data (size:in_u32CountToRead).
*\param[out]	out_pu32ActualReadCount	It specifies the output data pointer to hold the actual read count.
*
*\retval		::DPXMC5775_12_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DPXMC5775_12_ERR_INT_NOT_ENABLED is returned if the interrupt is not enabled
*\retval		::DP_DRV_ERR_INVALID_POINTER is returned if the specified output data pointer to hold the response data is null
*\retval		::DP_DRV_ERR_INVALID_POINTER is returned if the specified output data pointer to hold the actual read count is null
*
*\par Pre-requisite Functions and it's Sequence:
*				-# ::DPXMC5775_12_GetTotalDeviceFound( )
*				-# ::DPXMC5775_12_GetAllDeviceLocations( )
*				-# ::DPXMC5775_12_Open( )
*				-# ::DPXMC5775_12_ModeConfiguration( )
*				-# ::DPXMC5775_12_HDLC_SetMasterAddress( )
*				-# ::DPXMC5775_12_HDLC_FrameConfig( )
*				-# ::DPXMC5775_12_HDLC_StartFrame( )
*				-# ::DPXMC5775_12_HDLC_SetRespTimeout( ) - if only applicable for response timeout interrupt has to be enabled
*				-# ::DPXMC5775_12_SetFifoThreshold( ) - if only applicable for FIFO threshold interrupt has to be enabled
*				-# ::DPXMC5775_12_EnableInterrupt( )
*				-# ::DPXMC5775_12_ClearFifo( )
*/
S32BIT STDCALL DPXMC5775_12_HDLC_ReadData(DP_DRV_HANDLE in_hHandle, PU32BIT in_pu32Timeout, U32BIT in_u32CountToRead, PU32BIT out_pu32ResponseData, PU32BIT out_pu32ActualReadCount);

/*!
* @}
*/
#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif

#endif
