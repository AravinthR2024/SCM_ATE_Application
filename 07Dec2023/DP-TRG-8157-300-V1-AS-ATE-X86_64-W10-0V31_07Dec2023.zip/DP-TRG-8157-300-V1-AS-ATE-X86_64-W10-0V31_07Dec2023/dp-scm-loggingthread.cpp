#include "dp-scm-loggingthread.h"
extern S_GLOBAL g_SGlobal;

CLoggingThread::CLoggingThread(QObject *parent) : QThread(parent)
{
    qRegisterMetaType<S_RESP_DEBUG_DATA>("S_RESP_DEBUG_DATA");
}

void CLoggingThread::createNewLogFile(unsigned char in_ucLogType)
{
    QString m_qstrtempLogFileName;
    QString qstrPath;
    QDir qLogDir;
    QString  qstrTemp;
    QString qstrTemp2 = "";

    switch (in_ucLogType)
    {
    case LOGTYPE_DEM_PORT :
    {
        qstrPath = LOG_DEMPORT_PATH;
        qLogDir.setPath (qstrPath);
        if (!qLogDir.exists ())
        {
            qLogDir.mkpath (".");
        }
        if (m_qfDemPortLog.isOpen ())
        {
            m_qfDemPortLog.close ();
        }
        LOGFNAME_SETFNAME(m_qstrtempLogFileName, LOGFNAME_DEM_LOG, qstrPath);
        m_qfDemPortLog.setFileName(m_qstrtempLogFileName);
        if (!m_qfDemPortLog.open (QIODevice::Append))
        {
            emit sig_updateActionLog("Error creating Demand port log file : " + m_qfDemPortLog.errorString(), LOG_ERROR);
            break;
        }
        else
        {
            // Mode, PosRateCmd, PosResp, BIT Fault, DiagId, DiagData
            qstrTemp.sprintf("Time,Mode,Command,Position Response,BIT Fault,Diagnostics ID,Diagnostics Data\n");
            m_qfDemPortLog.write(CONV_QSTR_TO_SZ(qstrTemp));
            m_qtDemTime = QTime::currentTime();
        }
    } break;

    case LOGTYPE_DIAG_PORT :
    {
        qstrPath = LOG_DIAGPORT_PATH;
        qLogDir.setPath (qstrPath);
        if (!qLogDir.exists ())
        {
            qLogDir.mkpath (".");
        }
        if (m_qfDiagPortLog.isOpen ())
        {
            m_qfDiagPortLog.close ();
        }
        LOGFNAME_SETFNAME(m_qstrtempLogFileName, LOGFNAME_DIAG_LOG, qstrPath);
        m_qfDiagPortLog.setFileName(m_qstrtempLogFileName);
        if (!m_qfDiagPortLog.open (QIODevice::Append))
        {
            emit sig_updateActionLog("Error creating Diagnostics port log file : " + m_qfDiagPortLog.errorString(), LOG_ERROR);
            break;
        }
        else
        {
            // CommandID, PosRateCmd,   PosResp, RateResp, DiagId, DiagData
            qstrTemp.sprintf("Time,Command ID,Position/Rate Value,Position Value,Rate Value,Diagnostics ID,Diagnostics Data/n");
            m_qfDiagPortLog.write(CONV_QSTR_TO_SZ(qstrTemp));
            m_qtDiagTime = QTime::currentTime();
        }
    } break;

    case LOGTYPE_ACTIONLOG:
    {
        qstrPath = LOG_ACTIVITY_PATH;
        qLogDir.setPath(qstrPath);
        if(!qLogDir.exists())
        {
            qLogDir.mkpath(".");
        }
        if(m_qfActionLog.isOpen())
        {
            m_qfActionLog.close();
        }
        LOGFNAME_SETFNAME(m_qstrtempLogFileName, LOGFNAME_ACTIVITY, qstrPath);
        m_qfActionLog.setFileName(m_qstrtempLogFileName);
        if (!m_qfActionLog.open (QIODevice::Append))
        {
            emit sig_updateActionLog("Error creating activity log file : " + m_qfActionLog.errorString(), LOG_ERROR);
            break;
        }
    } break;

    case LOGTYPE_DEBUGDATA:
    {
        qstrPath = LOG_DEBUGDATA_PATH;
        qLogDir.setPath(qstrPath);
        if(!qLogDir.exists())
        {
            qLogDir.mkpath(".");
        }
        if(m_qfDebugDataLog.isOpen())
        {
            m_qfDebugDataLog.close();
        }

        qstrTemp2 = g_SGlobal.m_qstrSelectedTC + "_%s.csv";
        LOGFNAME_SETFNAME(m_qstrtempLogFileName, CONV_QSTR_TO_SZ(qstrTemp2), qstrPath);
        m_qfDebugDataLog.setFileName(m_qstrtempLogFileName);
        if (!m_qfDebugDataLog.open (QIODevice::Append))
        {
            emit sig_updateActionLog("Error creating Debug Data log file : " + m_qfDebugDataLog.errorString(), LOG_ERROR);
            break;
        }
        else
        {
            // Motor Current, Cycle Count, Motor Control Demand, Motor Angle, Payload Angle, Gimbal Demand, Angle Demand, Rate Demand, Position Demand
            qstrTemp.sprintf("Time,Cycle Count,Motor Current,Motor Control Demand,Motor Angle,Payload Rate,Payload Angle,Gimbal Demand,Position Demand,Rate Demand\n");
            m_qfDebugDataLog.write(CONV_QSTR_TO_SZ(qstrTemp));
            m_qtDebugTime = QTime::currentTime();
        }
    } break;
    case LOGTYPE_HDLCDATA:
    {
        qstrPath = LOG_HDLCDATA_PATH;
        qLogDir.setPath(qstrPath);
        if (!qLogDir.exists())
        {
            qLogDir.mkpath(".");
        }

        if (m_qfHDLCDataLog.isOpen())
        {
            m_qfHDLCDataLog.close();
        }

        qstrTemp2 = g_SGlobal.m_qstrSelectedTC + "_%s.csv";
        LOGFNAME_SETFNAME(m_qstrtempLogFileName, CONV_QSTR_TO_SZ(qstrTemp2), qstrPath);
        m_qfHDLCDataLog.setFileName(m_qstrtempLogFileName);
        if (!m_qfHDLCDataLog.open(QIODevice::Append))
        {
            emit sig_updateActionLog("Error creating HDLC Data Log file : " + m_qfHDLCDataLog.errorString(), LOG_WARNING);
            break;
        }
        else
        {
            qstrTemp.sprintf("Time,Frame Counter,BITE Status (hex),Encoder Data\n");
            m_qfHDLCDataLog.write(CONV_QSTR_TO_SZ(qstrTemp));
            m_qtHDLCTime = QTime::currentTime();
        }
    } break;
    default: break;
    }

}

void CLoggingThread::Start()
{
    if(!isRunning())
    {
        m_bIsRunning = true;
        this->start();
    }
}

void CLoggingThread::Stop()
{
    if(isRunning())
    {
        m_bIsRunning = false;

        if(!isFinished())
        {
            this->terminate();
        }
    }

    if (m_qfActionLog.isOpen())
    {
        m_qfActionLog.close();
    }

    if (m_qfDemPortLog.isOpen())
    {
        m_qfDemPortLog.close();
    }

    if (m_qfDiagPortLog.isOpen())
    {
        m_qfDiagPortLog.close();
    }

    if (m_qfDebugDataLog.isOpen())
    {
        m_qfDebugDataLog.close();
    }

    if (m_qfHDLCDataLog.isOpen())
    {
        m_qfHDLCDataLog.close();
    }
}

void CLoggingThread::run()
{
    U_CMDRESP_DATA UCmdRespData;
    S_DIAG_DATA_RESP SDiagInfo;
    S_HDLC_Response_Data SHDLCData;
    char szActionLogData[100] = { DPSCM_INIT_0 };
    QString qstrTemp = QString();
    int iRetval = DPSCM_INIT_0;
    unsigned char ucHDLC_timeCounter = DPSCM_INIT_0;

    memset (&UCmdRespData, 0, sizeof(U_CMDRESP_DATA));
    memset (&SDiagInfo, 0, sizeof(S_DIAG_DATA_RESP));

    while(m_bIsRunning)
    {
        iRetval = g_SGlobal.m_qActionLogMsgQ->Receive(&szActionLogData, 100, 0);
        if (iRetval > DPSCM_INIT_0)
        {
            if (m_qfActionLog.isOpen())
            {
                m_qfActionLog.write(szActionLogData);
            }
            else
            {
                createNewLogFile(LOGTYPE_ACTIONLOG);
                m_qfActionLog.write(szActionLogData);
            }
        }
        else
        {
            // Do nothing
        }

        iRetval = g_SGlobal.m_qDemPortLogMsgQ->Receive(&UCmdRespData, sizeof(U_CMDRESP_DATA), 0);
        if (iRetval > DPSCM_INIT_0)
        {
            if (!m_qfDemPortLog.isOpen())
            {
                createNewLogFile(LOGTYPE_DEM_PORT);
            }
            // Mode, PosRateCmd, PosResp, BIT Fault, DiagId, DiagData
            qstrTemp.sprintf("%s,%d,%0.04lf,%0.04lf,%d,%d,%d\n",\
                             CONV_QSTR_TO_SZ(m_qtDemTime.toString("HH:mm:ss.zzz")),\
                             UCmdRespData.m_UCmdData.m_SCmd_RGA.m_ucAzMode,\
                             UCmdRespData.m_UCmdData.m_SCmd_RGA.m_dAzRatePos,\
                             UCmdRespData.m_URespData.m_SResp_RGA.m_dAzPosition,\
                             UCmdRespData.m_URespData.m_SResp_RGA.m_ucBITFault,\
                             UCmdRespData.m_URespData.m_SResp_RGA.m_ucDiagId,\
                             UCmdRespData.m_URespData.m_SResp_RGA.m_ucDiagData);

            m_qfDemPortLog.write(CONV_QSTR_TO_SZ(qstrTemp));

            m_qtDemTime = m_qtDemTime.addMSecs(10);
        }
        else
        {
            // Do nothing
        }

        iRetval = g_SGlobal.m_qDiagPortLogMsgQ->Receive(&UCmdRespData, sizeof(U_CMDRESP_DATA), 0);
        if (iRetval > DPSCM_INIT_0)
        {
            if (!m_qfDiagPortLog.isOpen())
            {
                createNewLogFile(LOGTYPE_DIAG_PORT);
            }
            // CommandID, PosRateCmd,   PosResp, RateResp, DiagId, DiagData
            qstrTemp.sprintf("%s,%d,%0.04lf,%0.04lf,%0.04lf,%d,%d\n",\
                             CONV_QSTR_TO_SZ(m_qtDiagTime.toString("HH:mm:ss.zzz")),\
                             UCmdRespData.m_UCmdData.m_SCmd_Diag.m_ucCommandId,\
                             UCmdRespData.m_UCmdData.m_SCmd_Diag.m_dPosRateData,\
                             UCmdRespData.m_URespData.m_SResp_Diag.m_dPositionData,\
                             UCmdRespData.m_URespData.m_SResp_Diag.m_dRateData,\
                             UCmdRespData.m_URespData.m_SResp_Diag.m_ucDiagId,\
                             UCmdRespData.m_URespData.m_SResp_Diag.m_ucDiagData);

            m_qfDiagPortLog.write(CONV_QSTR_TO_SZ(qstrTemp));

            m_qtDiagTime = m_qtDiagTime.addMSecs(10);

        }
        else
        {
            // Do nothing
        }

        iRetval = g_SGlobal.m_qDebugDataLogMsgQ->Receive(&UCmdRespData, sizeof(U_CMDRESP_DATA), 0);
        if (iRetval > DPSCM_INIT_0)
        {
            if (!m_qfDebugDataLog.isOpen())
            {
                createNewLogFile(LOGTYPE_DEBUGDATA);
            }

            // Motor Current, Cycle Count, Motor Control Demand, Motor Angle, Payload Rate, Payload Angle, Gimbal Demand, Position Demand, Rate Demand
            qstrTemp.sprintf("%s,%d,%0.04lf,%0.04lf,%0.04lf,%0.04lf,%0.04lf,%0.04lf,%0.04lf,%0.04lf\n",\
                             CONV_QSTR_TO_SZ(m_qtDebugTime.toString("HH:mm:ss.zzz")),\
                             UCmdRespData.m_URespData.m_SResp_DebugData.m_usTimeCount,\
                             UCmdRespData.m_URespData.m_SResp_DebugData.m_dMotorCurrent,\
                             UCmdRespData.m_URespData.m_SResp_DebugData.m_dMotorCtrlDemand,\
                             UCmdRespData.m_URespData.m_SResp_DebugData.m_dMotorAngle,\
                             UCmdRespData.m_URespData.m_SResp_DebugData.m_dPayloadRate,\
                             UCmdRespData.m_URespData.m_SResp_DebugData.m_dPayloadAngle,\
                             UCmdRespData.m_URespData.m_SResp_DebugData.m_dGimbalDemand,\
                             UCmdRespData.m_URespData.m_SResp_DebugData.m_dPositionDemand,\
                             UCmdRespData.m_URespData.m_SResp_DebugData.m_dRateDemand);

            m_qfDebugDataLog.write(CONV_QSTR_TO_SZ(qstrTemp));

            emit sig_updateDiagParams(UCmdRespData.m_URespData.m_SResp_DebugData);
            m_qtDebugTime = m_qtDebugTime.addMSecs(10);
        }
        else
        {
            // Do nothing
        }

        iRetval = g_SGlobal.m_qHDLCDataLogMsgQ->Receive(&SHDLCData, sizeof(S_HDLC_Response_Data), 0);
        if (iRetval > DPSCM_INIT_0)
        {
            ucHDLC_timeCounter++;
            if (!m_qfHDLCDataLog.isOpen())
            {
                createNewLogFile(LOGTYPE_HDLCDATA);
            }

            // Time,Frame Counter,BITE Status,Encoder Data
            qstrTemp.sprintf("%s,%d,%X,%0.04lf\n",\
                             CONV_QSTR_TO_SZ(m_qtHDLCTime.toString("HH:mm:ss.zzz")),\
                             SHDLCData.m_ucFrameCounter,\
                             SHDLCData.m_ucBITEStatus,\
                             SHDLCData.m_dEncoderData);
            m_qfHDLCDataLog.write(CONV_QSTR_TO_SZ(qstrTemp));

            if (ucHDLC_timeCounter == 20)   // HDLC Running in 50us, so 20*50 gives 1ms
            {
                m_qtHDLCTime = m_qtHDLCTime.addMSecs(1);
                ucHDLC_timeCounter = 0;
            }
        }
    }
}
