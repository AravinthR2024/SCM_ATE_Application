/**
* \file dpxmc5775wrapper.cpp
* \brief This file contains the wrapper functions for DP-XMC-5775
*
* \author aravinth.rajalingam
* \date 21 November, 2022
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dpxmc5775wrapper.h"


S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_Initialize( U16BIT in_u16NoOfBoards, SDPXMC5775APP_DEVICELOC in_pSDeviceLocation[], SDPXMC5775APP_DEVICELOC out_pSDeviceLocation[])
{
    PSDPXMC5775_12_DEVICE_LOCATION pSAllDevLoc;

#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(pSAllDevLoc);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    m_s32RetVal = DPXMC5775_12_GetTotalDeviceFound(&m_u16NoOfBoards);
    DPXMC5775_CHECK_RETVAL;

    if (m_u16NoOfBoards <= 0)
    {
        sprintf(m_szErrMsg, "No devices found");
        return DPXMC5775_FAILURE;
    }

    pSAllDevLoc = (PSDPXMC5775_12_DEVICE_LOCATION) calloc(m_u16NoOfBoards, sizeof(SDPXMC5775_12_DEVICE_LOCATION));
    m_s32RetVal = DPXMC5775_12_GetAllDeviceLocations(pSAllDevLoc, m_u16NoOfBoards);
    DPXMC5775_CHECK_RETVAL;


    if(in_u16NoOfBoards > m_u16NoOfBoards)
    {
        in_u16NoOfBoards = m_u16NoOfBoards;
    }

    if((in_u16NoOfBoards == 0) || (in_pSDeviceLocation == NULL))
    {
        for(int iIdx =0 ; iIdx < m_u16NoOfBoards; iIdx++)
        {
            m_s32RetVal = DPXMC5775_12_Open(&pSAllDevLoc[iIdx], &m_vpHandle[iIdx]);
            if(m_s32RetVal != DPXMC5775_SUCCESS)
            {
                DPXMC5775_12_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
                free(pSAllDevLoc);
                return DPXMC5775_FAILURE;
            }

            m_s32RetVal = DPXMC5775_12_Reset(m_vpHandle[iIdx]);
            if(m_s32RetVal != DPXMC5775_SUCCESS)
            {
                DPXMC5775_12_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
                free(pSAllDevLoc);
                return DPXMC5775_FAILURE;
            }

            out_pSDeviceLocation[iIdx].m_u8BusNo = pSAllDevLoc[iIdx].u.pci.m_u8BusNo;
            out_pSDeviceLocation[iIdx].m_u8SlotNo = pSAllDevLoc[iIdx].u.pci.m_u8SlotNo;
            out_pSDeviceLocation[iIdx].m_u8FunctionNo = pSAllDevLoc[iIdx].u.pci.m_u8FunctionNo;
            out_pSDeviceLocation[iIdx].m_s8BoardSts = true;
        }
    }
    else
    {
        for(int iIdx = 0; iIdx < in_u16NoOfBoards; iIdx++)
        {
            if((pSAllDevLoc[iIdx].u.pci.m_u8BusNo == in_pSDeviceLocation[iIdx].m_u8BusNo) && \
                    (pSAllDevLoc[iIdx].u.pci.m_u8SlotNo == in_pSDeviceLocation[iIdx].m_u8SlotNo) && \
                    (pSAllDevLoc[iIdx].u.pci.m_u8FunctionNo == in_pSDeviceLocation[iIdx].m_u8FunctionNo))
            {
                m_s32RetVal = DPXMC5775_12_Open(&pSAllDevLoc[iIdx], &m_vpHandle[iIdx]);
                if(m_s32RetVal != DPXMC5775_SUCCESS)
                {
                    DPXMC5775_12_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
                    free(pSAllDevLoc);
                    return DPXMC5775_FAILURE;
                }

                m_s32RetVal = DPXMC5775_12_Reset(m_vpHandle[iIdx]);
                if(m_s32RetVal != DPXMC5775_SUCCESS)
                {
                    DPXMC5775_12_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
                    free(pSAllDevLoc);
                    return DPXMC5775_FAILURE;
                }

                out_pSDeviceLocation[iIdx].m_u8BusNo = pSAllDevLoc[iIdx].u.pci.m_u8BusNo;
                out_pSDeviceLocation[iIdx].m_u8SlotNo = pSAllDevLoc[iIdx].u.pci.m_u8SlotNo;
                out_pSDeviceLocation[iIdx].m_u8FunctionNo = pSAllDevLoc[iIdx].u.pci.m_u8FunctionNo;
                out_pSDeviceLocation[iIdx].m_s8BoardSts = true;
            }
        }
    }
	
    free(pSAllDevLoc);
#endif

    return DPXMC5775_SUCCESS;
}


S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_Close(U8BIT in_u8BoardId)
{
    U8BIT u8Loop = DPXMC5775_INIT_0;
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(u8Loop);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    if (in_u8BoardId != DPXMC5775_MAX_BOARDS)   /* Close all the boards */
    {
        DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

        //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

        m_s32RetVal = DPXMC5775_12_Close(m_vpHandle[in_u8BoardId]);
        DPXMC5775_CHECK_RETVAL;
    }
    else    /* Close only the specified board */
    {
        for (u8Loop = DPXMC5775_INIT_0; u8Loop < m_u16NoOfBoards; u8Loop++)
        {
            DPXMC5775_VALIDATE_BRDID(u8Loop);

            //DPXMC5775_VALIDATE_BRDOPEN(u8Loop);

            m_s32RetVal = DPXMC5775_12_Close(m_vpHandle[u8Loop]);
            DPXMC5775_CHECK_RETVAL;
        }
    }
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_Reset(U8BIT in_u8BoardId)
{
    U8BIT u8Loop = DPXMC5775_INIT_0;
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(u8Loop);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    if (in_u8BoardId != DPXMC5775_MAX_BOARDS)   /* Reset all the boards */
    {
        DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

        //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

        m_s32RetVal = DPXMC5775_12_Reset(m_vpHandle[in_u8BoardId]);
        DPXMC5775_CHECK_RETVAL;
    }
    else    /* Reset only the specified board */
    {
        for (u8Loop = DPXMC5775_INIT_0; u8Loop < m_u16NoOfBoards; u8Loop++)
        {
            DPXMC5775_VALIDATE_BRDID(u8Loop);

            //DPXMC5775_VALIDATE_BRDOPEN(u8Loop);

            m_s32RetVal = DPXMC5775_12_Reset(m_vpHandle[u8Loop]);
            DPXMC5775_CHECK_RETVAL;
        }
    }
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_ProgramEnable(U8BIT in_u8BoardId, U8BIT in_u8Enable)
{
    U8BIT u8Loop = DPXMC5775_INIT_0;
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(u8Loop);
    Q_UNUSED(in_u8Enable);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    if (in_u8BoardId != DPXMC5775_MAX_BOARDS)
    {
        DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

        m_s32RetVal = DPXMC5775_12_EnableFirmwareLoad(m_vpHandle[in_u8BoardId], in_u8Enable);
        DPXMC5775_CHECK_RETVAL;
    }
    else
    {
        for (u8Loop = DPXMC5775_INIT_0; u8Loop < m_u16NoOfBoards; u8Loop++)
        {
            DPXMC5775_VALIDATE_BRDID(u8Loop);

            m_s32RetVal = DPXMC5775_12_EnableFirmwareLoad(m_vpHandle[u8Loop], in_u8Enable);
            DPXMC5775_CHECK_RETVAL;
        }
    }

#endif

    return DPXMC5775_SUCCESS;
}

void CDPXMC5775Wrapper::DPXMC5775Wrap_GetLastError(PS32BIT out_ps32ErrCode, PS8BIT out_szErrMsg)
{
#if 0
    if (out_ps32ErrCode)
    {
        *out_ps32ErrCode = m_s32RetVal;
    }

    if (out_szErrMsg)
    {
        sprintf(out_szErrMsg, m_szErrMsg);
    }
#endif
//    DPXMC5775_12_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
    if (out_ps32ErrCode)
    {
        *out_ps32ErrCode = m_s32RetVal;
    }

    if (out_szErrMsg)
    {
        sprintf(out_szErrMsg, m_szErrMsg);
    }
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_GetDriverDetails(PSDPXMC5775_12_DRIVER_DETAILS out_pSDriverDetails)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(out_pSDriverDetails);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    if (!out_pSDriverDetails)
    {
        out_pSDriverDetails = (PSDPXMC5775_12_DRIVER_DETAILS) malloc(sizeof(SDPXMC5775_12_DRIVER_DETAILS));
    }

    m_s32RetVal = DPXMC5775_12_GetDriverDetails(out_pSDriverDetails);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_GetDeviceDetails(U8BIT in_u8BoardId, PSDPXMC5775_12_DEVICE_DETAILS out_pSDeviceDetails)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(out_pSDeviceDetails);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    if (!out_pSDeviceDetails)
    {
        out_pSDeviceDetails = (PSDPXMC5775_12_DEVICE_DETAILS) malloc(sizeof(SDPXMC5775_12_DEVICE_DETAILS));
    }

    m_s32RetVal = DPXMC5775_12_GetDeviceDetails(m_vpHandle[in_u8BoardId], out_pSDeviceDetails);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_GetGlueLogicDetails(U8BIT in_u8BoardId, PSDPXMC5775_12_GLUE_LOGIC_DETAILS out_pSGlueLogicDetails)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(out_pSGlueLogicDetails);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    if (!out_pSGlueLogicDetails)
    {
        out_pSGlueLogicDetails = (PSDPXMC5775_12_GLUE_LOGIC_DETAILS) malloc(sizeof(SDPXMC5775_12_GLUE_LOGIC_DETAILS));
    }

    m_s32RetVal = DPXMC5775_12_GetGlueLogicDetails(m_vpHandle[in_u8BoardId], out_pSGlueLogicDetails);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_WriteRegister(U8BIT in_u8BoardId, U32BIT in_u32Address, U32BIT in_u32WriteData)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_u32Address);
    Q_UNUSED(in_u32WriteData);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    m_s32RetVal = DPXMC5775_12_WriteReg(m_vpHandle[in_u8BoardId], in_u32Address, in_u32WriteData);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_ReadRegister(U8BIT in_u8BoardId, U32BIT in_u32Address, PU32BIT out_pu32ReadData)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_u32Address);
    Q_UNUSED(out_pu32ReadData);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    if (!out_pu32ReadData)
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid memory to store Read data");
        return DPXMC5775_FAILURE;
    }

    m_s32RetVal = DPXMC5775_12_ReadReg(m_vpHandle[in_u8BoardId], in_u32Address, out_pu32ReadData);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_SetDeviceShare(U8BIT in_u8BoardId, bool in_bEnableDeviceShare)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_bEnableDeviceShare);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

//    DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    m_s32RetVal = DPXMC5775_12_SetDeviceShare(m_vpHandle[in_u8BoardId], (U8BIT) in_bEnableDeviceShare);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_ConfigureSystemMode(U8BIT in_u8BoardId, U8BIT in_u8Mode)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_u8Mode);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    if (!((in_u8Mode <= SYSTEM_RGA_RTGA_AZ) && (in_u8Mode >= SYSTEM_SEASPRAY_HDLC)))
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid Mode. Valid modes between %d and %d", SYSTEM_SEASPRAY_HDLC, SYSTEM_RGA_RTGA_AZ);
        return DPXMC5775_FAILURE;
    }

    m_s32RetVal = DPXMC5775_12_ModeConfiguration(m_vpHandle[in_u8BoardId], in_u8Mode);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_ConfigureHDLCFrame(U8BIT in_u8BoardId, PSDPXMC5775_12_HDLC_FRAME_CONFIG in_pSHDLCFrameConfig)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_pSHDLCFrameConfig);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    if (!in_pSHDLCFrameConfig)
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid HDLC Frame configuration data");
        return DPXMC5775_FAILURE;
    }

    m_s32RetVal = DPXMC5775_12_HDLC_FrameConfig(m_vpHandle[in_u8BoardId], in_pSHDLCFrameConfig);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_SetMasterAddress(U8BIT in_u8BoardId, U8BIT in_u8MasterAddress)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_u8MasterAddress);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    m_s32RetVal = DPXMC5775_12_HDLC_SetMasterAddress(m_vpHandle[in_u8BoardId], in_u8MasterAddress);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

#if 0
S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_SetCommand(U8BIT in_u8BoardId, U8BIT in_u8Command)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_u8Command);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    if (!((in_u8Command >= 0x0) && (in_u8Command <= 0xFF)))
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid HDLC Command. Valid command is between 0x0 and 0xFF");
        return DPXMC5775_FAILURE;
    }

    m_s32RetVal = DPXMC5775_12_HDLC_SetCommand(m_vpHandle[in_u8BoardId], in_u8Command);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}
#endif

#if 0
S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_WriteData(U8BIT in_u8BoardId, U32BIT in_u32DataCount, PU32BIT in_pu32Data)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_u32DataCount);
    Q_UNUSED(in_pu32Data);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    m_s32RetVal = DPXMC5775_12_HDLC_WriteData(m_vpHandle[in_u8BoardId], in_u32DataCount, in_pu32Data);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}
#endif

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_ReadData(U8BIT in_u8BoardId, PU32BIT in_pu32Timeout, U32BIT in_u32CountToRead, PU32BIT out_pu32RespData, PU32BIT out_pu32ReadCount)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_pu32Timeout);
    Q_UNUSED(in_u32CountToRead);
    Q_UNUSED(out_pu32RespData);
    Q_UNUSED(out_pu32ReadCount);
    *out_pu32RespData = 0x2024;
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    if (!out_pu32RespData)
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid memory to store Response Data");
        return DPXMC5775_FAILURE;
    }

    if (!out_pu32ReadCount)
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid memory to store actual read data count");
        return DPXMC5775_FAILURE;
    }

    m_s32RetVal = DPXMC5775_12_HDLC_ReadData(m_vpHandle[in_u8BoardId], in_pu32Timeout, in_u32CountToRead, out_pu32RespData, out_pu32ReadCount);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

#if 0
S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_EnableLatch(U8BIT in_u8BoardId)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    m_s32RetVal = DPXMC5775_12_HDLC_LatchEnable(m_vpHandle[in_u8BoardId]);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}
#endif

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_SetResponseTimeout(U8BIT in_u8BoardId, U16BIT in_u16Timeout)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_u16Timeout);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    if (!((in_u16Timeout >= 1) && (in_u16Timeout <= 1000)))
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid Response Timeout. Valid Timeout value is between 1 and 1000");
        return DPXMC5775_FAILURE;
    }

    m_s32RetVal = DPXMC5775_12_HDLC_SetRespTimeout(m_vpHandle[in_u8BoardId], in_u16Timeout);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_StartTransmission(U8BIT in_u8BoardId, U8BIT in_u8RepeatCount, U16BIT in_u16FrameGap)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_u8RepeatCount);
    Q_UNUSED(in_u16FrameGap);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    if (!((in_u16FrameGap >= 1) && (in_u16FrameGap <= 5000)))
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid Frame Gap. Valid value is between 1 and 5000");
        return DPXMC5775_FAILURE;
    }

    m_s32RetVal = DPXMC5775_12_HDLC_StartFrame(m_vpHandle[in_u8BoardId], in_u8RepeatCount, in_u16FrameGap);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_StopTransmission(U8BIT in_u8BoardId)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    m_s32RetVal = DPXMC5775_12_HDLC_StopFrame(m_vpHandle[in_u8BoardId]);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_GetFrameCount(U8BIT in_u8BoardId, PU32BIT out_pu32FrameCount)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(out_pu32FrameCount);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    if (!out_pu32FrameCount)
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid memory to store frame count");
        return DPXMC5775_FAILURE;
    }

    m_s32RetVal = DPXMC5775_12_HDLC_GetFrameCount(m_vpHandle[in_u8BoardId], out_pu32FrameCount);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

#if 0
S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_EnableFIFO(U8BIT in_u8BoardId, bool in_bEnableFIFO, U8BIT in_u8ThresholdCount)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_bEnableFIFO);
    Q_UNUSED(in_u8ThresholdCount);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    if (!((in_u8ThresholdCount >= 0) && (in_u8ThresholdCount <= 255)))
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid Threshold. Valid range is between 0 and 255");
        return DPXMC5775_FAILURE;
    }

    m_s32RetVal = DPXMC5775_12_FifoEnable(m_vpHandle[in_u8BoardId], (U8BIT) in_bEnableFIFO);
    DPXMC5775_CHECK_RETVAL;

    m_s32RetVal = DPXMC5775_12_SetFifoThreshold(m_vpHandle[in_u8BoardId], in_u8ThresholdCount);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}
#endif

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_SetFIFOThreshold(U8BIT in_u8BoardId, U16BIT in_u16Threshold)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_u16Threshold);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    if (!(in_u16Threshold <= 1023))
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid Threshold. Valid range is between 0 and 1023");
        return DPXMC5775_FAILURE;
    }
    m_s32RetVal = DPXMC5775_12_SetFifoThreshold(m_vpHandle[in_u8BoardId], in_u16Threshold);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_StartStopReception(U8BIT in_u8BoardId, bool in_bStartStop)
{
    U8BIT u8StartStop = DPXMC5775_INIT_0;
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_bStartStop);
    Q_UNUSED(u8StartStop);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    u8StartStop = in_bStartStop ? 1 : 0;

    m_s32RetVal = DPXMC5775_12_HDLC_StartStopReception(m_vpHandle[in_u8BoardId], u8StartStop);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_ClearFIFO(U8BIT in_u8BoardId)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    m_s32RetVal = DPXMC5775_12_ClearFifo(m_vpHandle[in_u8BoardId]);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_GetFIFOCount(U8BIT in_u8BoardId, PU32BIT out_pu32FIFOCount)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(out_pu32FIFOCount);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    if (!out_pu32FIFOCount)
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid memory to store FIFO count");
        return DPXMC5775_FAILURE;
    }

    m_s32RetVal = DPXMC5775_12_GetFifoCount(m_vpHandle[in_u8BoardId], out_pu32FIFOCount);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_SetInterrupt(U8BIT in_u8BoardId, U8BIT in_u8IntType, bool in_bPropagateInt)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_u8IntType);
    Q_UNUSED(in_bPropagateInt);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    m_s32RetVal = DPXMC5775_12_EnableInterrupt(m_vpHandle[in_u8BoardId], in_u8IntType, (U8BIT) in_bPropagateInt);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_ReadInterruptStatus(U8BIT in_u8BoardId, PU16BIT out_pu16IntStatus)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(out_pu16IntStatus);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    if (!out_pu16IntStatus)
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid memory to store Interrupt status.");
        return m_s32RetVal;
    }

    //	m_s32RetVal = DPXMC5775_12_ReadInterruptStatus(m_vpHandle[in_u8BoardId], out_pu16IntStatus);
    //	DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_WaitForEvent(U8BIT in_u8BoardId, U16BIT in_u16EventMask, U16BIT in_u16Option, PU32BIT in_pu32Timeout, PU32BIT out_pu32EventStatus)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(in_u16EventMask);
    Q_UNUSED(in_u16Option);
    Q_UNUSED(in_pu32Timeout);
    Q_UNUSED(out_pu32EventStatus);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    if (!(in_u16EventMask >= 0x1))
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid Event Mask. Valid range is from 0x1 to 0xFFFF");
        return DPXMC5775_FAILURE;
    }

    if (!(in_u16Option <= 1))
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid option. Valid values are 0 and 1");
        return DPXMC5775_FAILURE;
    }

    if (!in_pu32Timeout)
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid pointer to Timeout.");
        return DPXMC5775_FAILURE;
    }

    if (!out_pu32EventStatus)
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid memory to store Event Status");
        return DPXMC5775_FAILURE;
    }

    m_s32RetVal = DPXMC5775_12_WaitForEvents(m_vpHandle[in_u8BoardId], in_u16EventMask, in_u16Option, in_pu32Timeout, out_pu32EventStatus);
    DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}

S32BIT CDPXMC5775Wrapper::DPXMC5775Wrap_GetHDLCErrorStatus(U8BIT in_u8BoardId, PU16BIT out_u16ErrorStatus)
{
#ifndef _DPXMC5775_DRV_ENABLE_
    Q_UNUSED(in_u8BoardId);
    Q_UNUSED(out_u16ErrorStatus);
#endif

#ifdef _DPXMC5775_DRV_ENABLE_
    DPXMC5775_VALIDATE_BRDID(in_u8BoardId);

    //DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId);

    if (!out_u16ErrorStatus)
    {
        m_s32RetVal = DPXMC5775_FAILURE;
        sprintf(m_szErrMsg, "Invalid memory to store Error status");
        return DPXMC5775_FAILURE;
    }

    //	m_s32RetVal = DPXMC5775_12_GetErrorMessage(m_vpHandle[in_u8BoardId], out_u16ErrorStatus);
    //	DPXMC5775_CHECK_RETVAL;
#endif

    return DPXMC5775_SUCCESS;
}
