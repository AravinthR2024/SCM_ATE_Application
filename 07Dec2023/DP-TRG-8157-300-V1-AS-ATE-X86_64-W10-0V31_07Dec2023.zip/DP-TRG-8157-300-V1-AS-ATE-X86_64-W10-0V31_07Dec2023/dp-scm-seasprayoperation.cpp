#include "dp-scm-seasprayoperation.h"
#include "ui_dp-scm-seasprayoperation.h"
#include "dp-scm-mainwindow.h"

extern S_GLOBAL g_SGlobal;

CSeasprayOperation::CSeasprayOperation(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CSeasprayOperation)
{
    ui->setupUi(this);

    m_pthHDLCRxThread = new CHDLCRxThread(this);

    memset (&m_UCommand, 0, sizeof(U_DEM_PORT_TX));
    memset (&m_UResponse, 0, sizeof(U_DEM_PORT_RX));
}

CSeasprayOperation::~CSeasprayOperation()
{
    delete ui;
}

void CSeasprayOperation::fetchHDLCFrame()
{
    U8BIT u8Command = DPSCM_INIT_0;
    U8BIT u8Temp = DPSCM_INIT_0;
    DOUBLE dVelocityData = DPSCM_INIT_0;
    U16BIT u16Velocity = DPSCM_INIT_0;
    memset (&m_UCommand, 0, sizeof(U_DEM_PORT_TX));

    u8Temp = ui->rbErr_Reset->isChecked() ? SEASPRAY_RESET : SEASPRAY_NO_RESET;
    u8Command = (u8Temp & 0x01) << 1;

    u8Temp = ui->rbPedestal_ON->isChecked() ? SEASPRAY_PEDESTAL_ON : SEASPRAY_PEDESTAL_OFF;
    u8Command |= u8Temp & 0x01;

    dVelocityData = ui->dsbVelocityData->value();
    u16Velocity = (dVelocityData * BIT_RESOLUTION_16BIT) / BIT_RESOLUTION_RATE;

    m_UCommand.m_S_HDLCCmd.m_u8IdelFlag = SEASPRAY_IDLE_FLAG;
    m_UCommand.m_S_HDLCCmd.m_u8SlaveAddress = SEASPRAY_ADDR_TX;
    m_UCommand.m_S_HDLCCmd.m_u8Command = u8Command;
    m_UCommand.m_S_HDLCCmd.m_u16Velocity = u16Velocity;
}

void CSeasprayOperation::on_pbSend_clicked()
{
    unsigned char ucRepeatCount = DPSCM_INIT_0;
    char szErrMsg[100] = { 0 };
    int iRetval = DPSCM_INIT_0;
    QString qstrTemp = QString();

    CHECK_TC_RUNNING;

    if (!ui->pbSend->text().contains("o", Qt::CaseInsensitive)) // Not equal to Stop
    {
        fetchHDLCFrame();

        if (ui->cbContinuousTx->isChecked())
        {
            ucRepeatCount = ui->sbTxCount->value();
        }
        else
        {
            ucRepeatCount = SEASPRAY_SINGLE_TX;
        }

        iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_SetMasterAddress (XMC_BRD_IDX, SEASPRAY_ALL_DEVICE_MASTER);
        if (iRetval != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
            qstrTemp.sprintf ("XMC Master Address Configuration Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
            emit sig_updateActionLog (qstrTemp, LOG_ERROR);
            DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
            return;
        }

        iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_SetResponseTimeout(XMC_BRD_IDX, 50);
        if (iRetval != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
            qstrTemp.sprintf ("XMC Set Response Timeout Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
            emit sig_updateActionLog (qstrTemp, LOG_ERROR);
            DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
            return;
        }

        iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_SetFIFOThreshold(XMC_BRD_IDX, SCM_RESP_CNT);
        if (iRetval != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
            qstrTemp.sprintf ("XMC Set FIFO Threshold Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
            emit sig_updateActionLog (qstrTemp, LOG_ERROR);
            DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
            return;
        }

        iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_SetInterrupt(XMC_BRD_IDX, SCM_FIFO_FULL_INT|SCM_FIFO_EMPTY_INT|SCM_FIFO_THRESHOLD_INT|SCM_RESP_TIMEOUT_INT, true);
        if (iRetval != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
            qstrTemp.sprintf ("XMC Set Interrupt Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
            emit sig_updateActionLog (qstrTemp, LOG_ERROR);
            DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
            return;
        }

        iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_ConfigureHDLCFrame (XMC_BRD_IDX, &m_UCommand.m_S_HDLCCmd);
        if (iRetval != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
            qstrTemp.sprintf ("XMC Frame Packet Configuration Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
            emit sig_updateActionLog (qstrTemp, LOG_ERROR);
            DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
            return;
        }

        iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_StartTransmission (XMC_BRD_IDX, ucRepeatCount);
        if (iRetval != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
            qstrTemp.sprintf ("XMC Transmission Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
            emit sig_updateActionLog (qstrTemp, LOG_ERROR);
            DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
            return;
        }

        m_pthHDLCRxThread->m_usRepeatCount = ucRepeatCount;
        emit sig_start_stop_hdlc(true);

        if (ui->cbContinuousTx->isChecked())
        {
            sig_updateActionLog("Command Transmission Started", LOG_SUCCESS);
            ui->pbSend->setText("S&top");
        }
        else // If Single command is transmitted
        {
            iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_StopTransmission(XMC_BRD_IDX);
            if (iRetval != DPSCM_SUCCESS)
            {
                g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError(&iRetval, szErrMsg);
                qstrTemp.sprintf("Error Stopping Transmission : %s [ErrCode: %d] ", szErrMsg, iRetval);
                sig_updateActionLog(qstrTemp, LOG_ERROR);
                return;
            }

            emit sig_start_stop_hdlc(false);

            sig_updateActionLog("Command Transmitted Successfully", LOG_SUCCESS);
        }
    }
    else
    {
        iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_StopTransmission(XMC_BRD_IDX);
        if (iRetval != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError(&iRetval, szErrMsg);
            qstrTemp.sprintf("Error Stopping Transmission : %s [ErrCode: %d] ", szErrMsg, iRetval);
            sig_updateActionLog(qstrTemp, LOG_ERROR);
            return;
        }

        ui->pbSend->setText("S&tart");

        emit sig_start_stop_hdlc(false);
    }
}

void CSeasprayOperation::on_cbContinuousTx_clicked(bool checked)
{
    ui->lbDisp_TxCount->setEnabled(checked);
    ui->sbTxCount->setEnabled(checked);
    ui->pbSend->setText(checked ? "S&tart" : "S&end");
}

