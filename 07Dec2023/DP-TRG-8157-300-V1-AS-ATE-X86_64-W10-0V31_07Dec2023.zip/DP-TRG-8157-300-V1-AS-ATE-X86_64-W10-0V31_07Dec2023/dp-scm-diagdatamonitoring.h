#ifndef DPSCMDIAGDATAMONITORING_H
#define DPSCMDIAGDATAMONITORING_H

#include <QWidget>

#include <QTableWidgetItem>
#include <QThread>
#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "checksum.h"

enum DIAG_LIST
{
    E_MESSAGE_TX_COUNT = 0,
    E_BIT_FAULT_01,
    E_BIT_FAULT_02,
    E_GIMBAL_STATUS,
    E_COMMUNICATION_ERROR,
    E_SERVO_CONTROL_LOOP_ERROR,
    E_INTERNAL_SCM_FAULT,
    E_I2T_AND_TEMP_FAULT,
    E_EL_VOLTAGE_FAULT,
    E_AZ_VOLTAGE_FAULT,
    E_BITE_AND_STATUS,
    E_PBIT_FAULT,
    E_MOTOR_TEMPERATURE_FAULT,
    E_HALL_SENSOR_FAULT,
    E_MOTOR_ENCODER_FAULT,
    E_ARRAY_IDENTIFIED_FLAG,
    E_AZIMUTH_AND_ELEVATION_INDEPENDEND_SENSOR_POSITION,
    E_1V_MONITORIOING_STATUS,
    E_1P2V_MONITORIOING_STATUS,
    E_1P8V_MONITORIOING_STATUS,
    E_2P5V_MONITORIOING_STATUS,
    E_3p3V_MONITORIOING_STATUS,
    E_28V_48V_MONITORIOING_STATUS,
    E_EL_1V_VALUE,
    E_AZ_1V_VALUE,
    E_EL_1_2V_VALUE,
    E_AZ_1_2V_VALUE,
    E_EL_1_8V_VALUE,
    E_AZ_1_8V_VALUE,
    E_EL_2_5V_VALUE,
    E_AZ_2_5V_VALUE,
    E_EL_3_3V_VALUE,
    E_AZ_3_3V_VALUE,
    E_EL_28V_48V_VALUE,
    E_AZ_28V_48V_VALUE,
    E_EL_CURRENT_VALUE,
    E_AL_CURRENT_VALUE,
    E_ELEVATION_INTERNAL_FAULT,
    E_AZIMUTH_INTERNAL_FAULT,
    E_ELEVATION_ZETTLEX_STATUS,
    E_AZIMUTH_ZETTLEX_STATUS,\
    E_ELEVATION_TEMPERATURE,
    E_AZIMUTH_TEMPERATURE,
    E_ELEVATION_I2T_AVERAGE_POWER,
    E_AZIMUTH_I2T_AVERAGE_POWER,
    E_ELEVATION_SOFTWARE_VERSION,
    E_AZIMUTH_SOFTWARE_VERSION,
    E_ELEVATION_FIRMWARE_VERSION,
    E_AZIMUTH_FIRMWARE_VERSION,
    E_ELEVATION_SCM_VERSION,
    E_AZIMUTH_SCM_VERSION,
    E_ELEVATION_OFFSET_MSH,
    E_ELEVATION_OFFSET_LSH,
    E_ELEVATION_UPPER_ENDSTOP_MSH,
    E_ELEVATION_UPPER_ENDSTOP_LSH,
    E_AZIMUTH_CW_ENDSTOP_MSH,
    E_AZIMUTH_CW_ENDSTOP_LSH,
    E_ELEVATION_LOWER_ENDSTOP_MSH,
    E_ELEVATION_LOWER_ENDSTOP_LSH,
    E_AZIMUTH_CCW_ENDSTOP_MSH,
    E_AZIMUTH_CCW_ENDSTOP_LSB,
    E_ANTENNA_CHECKSUM_COUNT,
    E_ANTENNA_INCORRECT_MESSAGE,
    E_ANTENNA_PARTIAL_FORMAT,
    E_ANTENNA_LOSS_OF_COMMUNICATION,
    E_MESSAGE_RX_COUNT,
    E_EL_TO_AZ_CHECKSUM_COUNT,
    E_EL_TO_AZ_INCORRECT_MESSAGE,
    E_EL_TO_AZ_PARTIAL_FORMAT,
    E_AZ_TO_EL_CHECKSUM_COUNT,
    E_AZ_TO_EL_INCORRECT_MESSAGE,
    E_AZ_TO_EL_PARTIAL_FORMAT,
    E_DIAG_PORT_CHECKSUM_COUNT,
    E_DIAG_PORT_INCORRECT_MESSAGE,
    E_DIAG_PORT_PARTIAL_FORMAT,
    E_ELEVATION_MOTOR_TEMPERATURE,
    E_AZIMUTH_MOTOR_TEMPERATURE,
    E_ELEVATION_INVBRD_TEMPERATURE,
    E_AZIMUTH_INVBRD_TEMPERATURE,
    TOTAL_DIAG_LIST // To store the number of Diagnostics Registers
};

typedef struct _S_TABLE_INDEX
{
        int m_iRow;
        int m_iCol;
} S_TABLE_INDEX, *PS_TABLE_INDEX;

namespace Ui {
class CDiagDataMonitoring;
}

class CDiagDataMonThread : public QThread
{
    Q_OBJECT

public:
    CDiagDataMonThread(QObject *parent = 0);

    bool m_bIsRunning;
    unsigned char m_arrucValues[TOTAL_DIAG_LIST];
    QTableWidgetItem *m_pobjarrNameItem[TOTAL_DIAG_LIST];
    QTableWidgetItem *m_pobjarrValueItem[TOTAL_DIAG_LIST];

    void Start();
    void Stop();
    void run() override;

signals:
    void sig_threadCompleted();
    void sig_setValue(int, QString);
    void sig_updateActionLog(QString, int);
};

class CDiagDataMonitoring : public QWidget
{
    Q_OBJECT

public:
    explicit CDiagDataMonitoring(QWidget *parent = 0);
    ~CDiagDataMonitoring();
    unsigned char m_arrucValues[TOTAL_DIAG_LIST];

    CDiagDataMonThread *m_pthDataMon;

private :
    S_TABLE_INDEX m_arrSNameIndex[TOTAL_DIAG_LIST];
    S_TABLE_INDEX m_arrSValueIndex[TOTAL_DIAG_LIST];

    QTableWidgetItem *m_pobjarrNameItem[TOTAL_DIAG_LIST];
    QTableWidgetItem *m_pobjarrValueItem[TOTAL_DIAG_LIST];

    void loadIndices();

signals:
    void sig_updateActionLog(QString, int);

    void sig_showLoadingScreen (bool);

private slots:
    void on_pbDiagData_Read_clicked();

    void on_tblwidDiagData_itemClicked(QTableWidgetItem *item);

    void on_cbSelectAll_clicked();

    void on_pbDiagDataClear_clicked();

public slots:
    void slot_setValue (int in_iIndex, QString in_qstrValue);

    void slot_threadCompleted();

private:
    Ui::CDiagDataMonitoring *ui;
};

#endif // DPSCMDIAGDATAMONITORING_H
