/**
* \file dp-scm-modinitstatus.h
* \brief This is the header file for dp-scm-modinitstatus.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef MODINITSTATUS_H
#define MODINITSTATUS_H

#include <QWidget>
#include <QFileInfo>
#include <QSettings>
#include <QLabel>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "dprs232_wrapper.h"
#include "dppci755_wrapper.h"

namespace Ui {
	class CModInitStatus;
}

class CModInitStatus : public QWidget
{
		Q_OBJECT

	public:
		explicit CModInitStatus(QWidget *parent = 0);
		~CModInitStatus();

		SMODULE_LOC_DETAILS m_SModuleInfo[MAX_MODULES];

		//    CDPRS232Wrapper m_pobjRS232;

		unsigned char m_ucModInitSts;
        bool m_bIsFirstInitialization;

        QPushButton *pbPCI_Close;
        QPushButton *pbXMC_Close;
        QPushButton *pbPCI_Reset;
        QPushButton *pbXMC_Reset;

        void updateModulesTable();
		void readDeviceDetails();
        void initModules();

	private:
		Ui::CModInitStatus *ui;

	signals:
		void sig_updateActionLog(QString, int);
		void sig_changePage(int);
		void sig_setEnDisMenuBar(bool);
		void sig_append_BIT_HTMLReport (QString);

	private slots:
		void on_pbModDetProceed_clicked();

        void slot_PCI_Close_Clicked();
        void slot_XMC_Close_Clicked();
        void slot_PCI_Reset_Clicked();
        void slot_XMC_Reset_Clicked();
};

#endif // MODINITSTATUS_H
