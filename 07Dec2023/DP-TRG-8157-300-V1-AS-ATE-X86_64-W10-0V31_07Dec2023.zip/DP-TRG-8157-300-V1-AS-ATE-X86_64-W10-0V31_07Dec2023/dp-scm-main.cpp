/**
* \file dp-scm-main.cpp
* \brief This file contains the main function to initialize the application
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-mainwindow.h"
#include <QApplication>
#include <QDir>

short gsReturn;
extern S_GLOBAL g_SGlobal;
QString g_qstrAppPath;

/*******************************************************************************
 * Name					: main
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Main function
 ***************************************************************************//**
 * @brief	This function is the entry point of this project
 *
 * @param[in]	argc	Holds the number of command-line arguments
 * @param[in]	argv	Holds all the command-line arguments
 *
 * @return	DPSCM_SUCCESS	if program completed successfully
 *			DPSCM_FAILURE	if any error occurred
 ******************************************************************************/
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    int iRetval = 0;
    bool bLoop = false;
    Authentication objAuth;
#if 0
    if (!objAuth.lock())
    {
         QMessageBox::warning(&objAuth, "Error", "Another instance of application is already running.");
         return DPSCM_SUCCESS;
    }
#endif
	do
	{
		objAuth.exec();

		if (!gsReturn)
		{
			return DPSCM_SUCCESS;
		}
        g_SGlobal.g_qstrAppPath = qApp->applicationDirPath();
        g_SGlobal.m_iUserPrivil = objAuth.m_iPrivil;

        Crc32_ComputeFile(argv[0], &g_SGlobal.g_ulAppChecksum);
        g_SGlobal.g_qdatetimeRun = QDateTime::currentDateTime();

        MainWindow w;
        w.m_qstrLoggedinUserName = objAuth.m_strUsrname;
        w.m_iLoggedinUserPrevil = objAuth.m_iPrivil;

        w.showAppScreen();

        iRetval = a.exec();
		if (!w.m_bIsLoggedIn)
		{
			gsReturn = 0;
			bLoop = true;
		}
		else
		{
			bLoop = false;
		}
	} while(bLoop);

    return iRetval;
}
