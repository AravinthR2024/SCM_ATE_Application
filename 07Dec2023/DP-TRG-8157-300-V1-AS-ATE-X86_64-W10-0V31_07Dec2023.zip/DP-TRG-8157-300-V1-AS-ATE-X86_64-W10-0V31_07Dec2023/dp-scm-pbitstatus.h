/**
* \file dp-scm-pbitstatus.h
* \brief This is the header file for dp-scm-pbitstatus.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef PBITSTATUS_H
#define PBITSTATUS_H

#include <QWidget>
#include <QGroupBox>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"

namespace Ui {
	class CPBITStatus;
}

typedef struct _S_PBIT_DISPLAY
{
    BIT_STATUS m_ePrgmMemCRC;
    BIT_STATUS m_eEEPROMCRC;
    BIT_STATUS m_eFPGA_RW_Test;
    BIT_STATUS m_eHallStatus;
    BIT_STATUS m_eVoltMonitoring;
    BIT_STATUS m_eCurrMonitoring;
    BIT_STATUS m_eTempMonitoring;
} S_PBIT_DISPLAY;

#define CHECK_PBIT(out, val) {\
if ((val & 0x01) != 0)\
{\
out = BIT_FAIL;\
}\
else\
{\
out = BIT_SUCCESS;\
    }\
}

class CPBITStatus : public QWidget
{
		Q_OBJECT

	public:
		explicit CPBITStatus(QWidget *parent = 0);
		~CPBITStatus();

        S_PBIT_DISPLAY m_SPBITStatusDisplay;
        U_DEM_PORT_TX m_UTxCommand;
        U_DEM_PORT_RX m_URxResponse;

		void setLEDStatus(QLabel *in_pLabel, U8BIT in_u8Sts);
		void resetLEDinGB(QGroupBox *in_pgbGroupbox);
        int sendCommand(unsigned char in_ucCmdID);
private slots:
		void on_pbCheck_clicked();

	public slots:
		void slot_resetPBITStatus();
        void slot_updatePBITStatus();

	private:
		Ui::CPBITStatus *ui;

	signals:
		void sig_changePage(int);
		void sig_updateActionLog(QString, int);
};

#endif // PBITSTATUS_H
