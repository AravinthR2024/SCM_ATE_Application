#ifndef USR_MANAGEMENT_H
#define USR_MANAGEMENT_H

#include "QString"
#include "QCryptographicHash"
#include "DP_UML_Error.h"
#include "DP_UML_FunMacro.h"
#include "DP_UML_Macro.h"
#include <QDebug>
#include <QCryptographicHash>
#include <QFile>

typedef struct
{
       char m_szUserName[32];                        /*!< user name */
       char  m_userprevilage[16];
       char m_szPassword[65];                        /*!< Password  */
}S_USER_ACCOUNTS;

class Usr_management
{

public:

		QString m_qstrMatchedUsername;

    char DP_UML_GetNoOfUsers(int *iNoofusers);

    char DP_UML_Validate_User(char *cUsername, char *cPassword, char in_ucPrivilage);

    char DP_UML_AddNew_User(char *cUsername, char *in_cNewPassword, char *in_cConfirmPassword, const char *in_cPrivilage);

    char DP_UML_Change_Password(char *cUsername, char *cOldPassword, char *cNewPassword, char *cConfPassword);

    char DP_UML_Admin_Change_Password(char *cUsername, char *cNewPassword, char *cConfPassword);

    char DP_UML_Delete_User(char *cUsername);

    void Encrypt(char *in_array, int array_size, char *out_array);

    void Decrypt(char *in_array, int array_size, char *out_array);

    int EncryptData(S_USER_ACCOUNTS  *UserDetailsTemp,S_USER_ACCOUNTS *UserDetailsEncoded);

    int DecryptData(S_USER_ACCOUNTS  *UserDetailsTemp ,S_USER_ACCOUNTS *UserDetailsDecoded );

    int IsAlreadyExists(char *cUsername);

    char  DP_UML_GetUserPrivilage(char *cUsername);

    char DP_UML_GetNoOfUserNames(S_USER_ACCOUNTS in_objArrUsers[]);

    char DP_UML_Init_UMLLib(char in_ucMaxUsers, char in_ucMaxUsernamelen, char in_ucMaxPasslen, char in_ucMinUsernamelen, char in_ucMinPasslen, const char *AuthFilename);

    void UpdateAuthfile();

    int IsSpclCharExist(char *cData);

    int IsDigitExist(char *cData);

    int check_file_checksum(const char *cfilename);

    int update_file_checksum(const char *cfilename, int iNoOfUsers);

};

#endif // USR_MANAGEMENT_H
