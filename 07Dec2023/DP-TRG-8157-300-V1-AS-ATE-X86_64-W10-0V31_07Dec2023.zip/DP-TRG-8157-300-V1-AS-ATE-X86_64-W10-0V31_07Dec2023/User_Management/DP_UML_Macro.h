/**
*	\file dp_uml_macro.h
*	\brief Contains the Library API macros
*
*	This file contains the UML library API structure
	\author
*	\date 
*
*	\revision 
*	- Initial version
*	
*	\copyright Copyright (C) 2011 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
*	All Rights Reserved.\n
*	Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
*   Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
*   Chennai-603103 | India\n
*	Website : http://www.datapatternsindia.com/\n
*	Phone: 91-44-4741-4000\n
*	FAX: 91-44-4741-4444 \n
*	
*/

#ifndef MACRO_H
#define MACRO_H

#define KE_ROTWORD(x) ( ((x) << 8) | ((x) >> 24) )

#define ADMIN_USER              0
#define SUPER_USER              1
#define NORMAL_USER             2

#define DP_UML_INIT_VALUE		0
#define DP_UML_SUCCESS			0
#define DP_UML_FAILURE			-1
#define DP_UML_NORMAL_USER		1
#define DP_UML_SUPER_USER		0

#define DP_UML_AES_KEY			32
#define DP_UML_AES256			256

#endif // MACRO_H
