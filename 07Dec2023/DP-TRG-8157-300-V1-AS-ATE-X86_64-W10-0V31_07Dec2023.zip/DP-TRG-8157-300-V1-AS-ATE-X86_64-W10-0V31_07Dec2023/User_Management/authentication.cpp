/*******************************************************************************
// File Name    : authentication.cpp
// Author       : Kishore kumar A
// Created Date : Mar 11,2019
// Description  : To validate the user name and password of the User to provide/ restrict access to application.
*******************************************************************************/

/*******************************************************************************
// Company Name : DATA PATTERNS INDIA PRIVATE LIMITED
// Address      : No. H9,4th MainRoad,SIPCOT IT Park,Siruseri,Chennai-603103
// Email        : support@datapatterns.co.in
// Phone        : +91 44 47414000
// Fax          : +91 44 47414444
*******************************************************************************/

/******************************************************************************
// Copyright (c) 2019 DATA PATTERNS
//
// All rights reserved. These materials are confidential and proprietary to
// DATA PATTERNS and no part of these materials should be reproduced or published
// in any form by any means, electronic or mechanical, including photocopy, on any
// information storage or retrieval system, nor should the materials be disclosed
// to third parties without the explicit written authorization of DATA PATTERNS.
//
*******************************************************************************/

#include "ui_authentication.h"
#include "authentication.h"
#include <QSplashScreen>
#include "QMessageBox"
#include <QFile>
#include <QDir>

char g_arrAuthfileName[500];
extern short gsReturn;
S_GLOBAL_HANDLES g_Handles;

Authentication::Authentication(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Authentication)
{
    ui->setupUi(this);
    m_bAuthSuccess = false;

    this->setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);

    ui->LE_Pwd->setToolTip("Enter the Password");
    ui->le_Username->setToolTip("Enter the Username");
    ui->le_Username->setText("Administrator");
    ui->le_Username->setFocus();
    ui->le_Username->selectAll();

    ui->LE_Pwd->setText("admin");       // temp Remove this line on final release
    ui->PB_Login->setDisabled(false);   // temp Remove this line on final release

    strcpy(g_arrAuthfileName, QString(qApp->applicationDirPath()+"/config/authfile").toStdString().c_str());    //to provide filename for storing user details.

    Usr_management manage;
    int iRetVal = manage.DP_UML_Init_UMLLib(255, 32, 32, 6, 6, g_arrAuthfileName);
    if (iRetVal == -77)
    {
        QMessageBox :: information(this, "Error", "Authentication file corrupted", QMessageBox::Ok);
        exit(0);
    }
    //update_file_checksum();
    _singular = new QSharedMemory("DP-SCM-ATE_", this);
    m_bAuth_Sts = false;
}

Authentication::~Authentication()
{
    if(_singular->isAttached())
        _singular->detach();

    delete ui;
}

/*******************************************************************************
 * Name                      : on_PB_Exit_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NLL
 ***************************************************************************//**
 * To close the login window.
 * \param NIL
 * * \return No return values.
*******************************************************************************/
void Authentication::on_PB_Exit_clicked()
{
    ui->le_Username->clear();
    ui->LE_Pwd->clear();
    ui->le_Username->setFocus();
    this->close();
}

/*******************************************************************************
 * Name                      : on_PB_Login_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : gUsername, g_arrAuthfileName
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NLL
 ***************************************************************************//**
 * To verify the username and password and display error message incase of error.
 *  * \param NIL
 * * \return No return values.
*******************************************************************************/
void Authentication::on_PB_Login_clicked()
{
    int RetVal = 0;
    char cPrevilege = 0;
    Usr_management manage;

    g_Handles.m_UserDetails.m_sUserName = ui->le_Username->text();

    QFile file(g_arrAuthfileName);
    if (file.size() != 0)
    {
        int iRetval = manage.check_file_checksum(g_arrAuthfileName);
        if (iRetval == -77 || iRetval == -76)
        {
            if (iRetval == -77)
            {
                QMessageBox :: information(this, "Error", "Authentication file corrupted", QMessageBox::Ok);
                exit(0);
            }
            else
            {
                QMessageBox :: information(this, "Error", "Authentication file not found", QMessageBox::Ok);
                exit(0);
            }
        }
    }

    RetVal = manage.DP_UML_Validate_User(ui->le_Username->text().toLatin1().data(), ui->LE_Pwd->text().toLatin1().data(), 0);

    if(RetVal)
    {
        ui->LE_Pwd->clear();
        Msg_display(RetVal);
    }
    else
    {
        cPrevilege = manage.DP_UML_GetUserPrivilage(ui->le_Username->text().toLatin1().data());
        m_strUsrname = manage.m_qstrMatchedUsername;

        if(cPrevilege == ADMIN_USER || cPrevilege == SUPER_USER)
        {
            m_iPrivil = SUPER_USER;
            g_Handles.m_UserDetails.m_sUserprevilage = "Super User";
        }
        else
        {
            m_iPrivil = NORMAL_USER;
            g_Handles.m_UserDetails.m_sUserprevilage = "User";
        }
        gsReturn = 1;
        on_PB_Exit_clicked();
    }
}

bool Authentication::lock()
{
    if(_singular->attach(QSharedMemory::ReadOnly)){
        _singular->detach();
        return false;
    }

    if(_singular->create(1))
        return true;

    return false;
}

/*******************************************************************************
 * Name                      : on_LE_Pwd_textEdited
 * Author                    : Manoj
 * Global Variables affected : NIL
 * Created Date              : Mar 09, 2020
 * Revision Date             : NIL
 * Reason for Revising       : NLL
 ***************************************************************************//**
  * This function(slot for pwd line editor) will be used to enable the
  * ok button on non empty input in user and password.
  * \return No Return values.
*******************************************************************************/
void Authentication::on_LE_Pwd_textEdited()
{
    LoginButtonEnaDis();
}

/*******************************************************************************
 * Name                      : on_le_Username_textChanged
 * Author                    : Manoj
 * Global Variables affected : NIL
 * Created Date              : Jul 06, 2021
 * Revision Date             : NIL
 * Reason for Revising       : NLL
 ***************************************************************************//**
  * This function(slot for username line editor) will be used to restrict spaces
  * on starting.
  * \return No Return values.
*******************************************************************************/
void Authentication::on_le_Username_textChanged(const QString &in_str)
{
    if(in_str == " ")
    {
        ui->le_Username->setText("");
        return;
    }
    LoginButtonEnaDis();
}

/*******************************************************************************
 * Name                      : LoginButtonEnaDis
 * Author                    : Manoj
 * Global Variables affected : NIL
 * Created Date              : Jul 06, 2021
 * Revision Date             : NIL
 * Reason for Revising       : NLL
 ***************************************************************************//**
  * This function shall be used to enable/disable Login Push Button based on
  * text is present or not on username and password field.
  * \return No Return values.
*******************************************************************************/
void Authentication::LoginButtonEnaDis()
{
    if(ui->le_Username->text().isEmpty() || ui->LE_Pwd->text().isEmpty())
    {
        ui->PB_Login->setDisabled(true);
    }
    else
    {
        ui->PB_Login->setEnabled(true);
    }
}

/*******************************************************************************
 * Name                      : Msg_display
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NLL
 ***************************************************************************//**
 * To display corresponding error message for the error.
 *  * \param iErrorCode - Error Code to get error message.
 * * \return No return values.
*******************************************************************************/
void Authentication::Msg_display(int iErrorCode)
{
    switch(iErrorCode)
    {
    case -99:
        QMessageBox :: information(this, "Error", "Invalid Username");
        break;
    case -98:
        QMessageBox :: information(this, "Error", "Invalid Password");
        break;
    case -97:
        QMessageBox :: information(this, "Error", "Invalid Old Password");
        break;
    case -96:
        QMessageBox :: information(this, "Error", "Invalid Confirm Password");
        break;
    case -94:
        QMessageBox :: information(this, "Error", "User already exists");
        break;
    case -90:
        QMessageBox :: information(this, "Error", "Username must be of minimum 6 characters");
        break;
    case -89:
        QMessageBox :: information(this, "Error", "Username must be less than 32 characters");
        break;
    case -88:
        QMessageBox :: information(this, "Error", "Invalid Password");
        break;
    case -87:
        QMessageBox :: information(this, "Error", "Password must be less than 32 characters");
        break;
    case -86:
        QMessageBox :: information(this, "Error", "Maximum number of users reached");
        break;
    case -85:
        QMessageBox :: information(this, "Error", "Password must contain atleast one special character");
        break;
    case -84:
        QMessageBox :: information(this, "Error", "Password must contain atleast one numeric character");
        break;
    case -82:
        QMessageBox :: information(this, "Error", "Username must not contain any special characters other than '.'");
        break;
    case -81:
        QMessageBox :: information(this, "Error", "Username field is empty");
        break;
    case -80:
        QMessageBox :: information(this, "Error", "Password field is empty");
        break;
    case -79:
        QMessageBox :: information(this, "Error", "NewPassword field is empty");
        break;
    case -78:
        QMessageBox :: information(this, "Error", "ConfirmPassword field is empty");
        break;
    case -77:
        QMessageBox :: information(this, "Error", "Authentication file corrupted", QMessageBox::Ok);
        break;
    case -76:
        QMessageBox :: information(this, "Error", "Authentication file not found", QMessageBox::Ok);
        break;
    default:
        break;
    }
}

/************************************ END OF FILE *****************************/
