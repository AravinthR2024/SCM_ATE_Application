/*******************************************************************************
// File Name    : cadminauthentication.cpp
// Author       : Kishore kumar A
// Created Date : Mar 11,2019
// Description  : To validate the user name and password of the Admin to provide/ restrict access to application.
*******************************************************************************/

/*******************************************************************************
// Company Name : DATA PATTERNS INDIA PRIVATE LIMITED
// Address      : No. H9,4th MainRoad,SIPCOT IT Park,Siruseri,Chennai-603103
// Email        : support@datapatterns.co.in
// Phone        : +91 44 47414000
// Fax          : +91 44 47414444
*******************************************************************************/

/******************************************************************************
// Copyright (c) 2019 DATA PATTERNS
//
// All rights reserved. These materials are confidential and proprietary to
// DATA PATTERNS and no part of these materials should be reproduced or published
// in any form by any means, electronic or mechanical, including photocopy, on any
// information storage or retrieval system, nor should the materials be disclosed
// to third parties without the explicit written authorization of DATA PATTERNS.
//
*******************************************************************************/

#include "cadminauthentication.h"
#include "cusermanagement.h"
#include "ui_cadminauthentication.h"

CAdminAuthentication::CAdminAuthentication(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CAdminAuthentication)
{
    ui->setupUi(this);
    iPwdCrt = 0;
    setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);
}

CAdminAuthentication::~CAdminAuthentication()
{
    delete ui;
}

/*******************************************************************************
 * Name                      : on_pb_Cancel_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NLL
 ***************************************************************************//**
 * To cancel the admin authentication.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CAdminAuthentication::on_pb_Cancel_clicked()
{
    ui->le_AdminPwd->clear();
    this->close();
}

/*******************************************************************************
 * Name                      : on_pb_Ok_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NLL
 ***************************************************************************//**
 * To validate the username and password and display error message incase of error.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CAdminAuthentication::on_pb_Ok_clicked()
{
    int cRetVal = 0;
    iPwdCrt = 0;
    Usr_management manage;
    cRetVal = manage.DP_UML_Validate_User(ui->le_SuperUserName->text().toLatin1().data(), ui->le_AdminPwd->text().toLatin1().data(), 0);
    if(cRetVal)
    {
        ui->le_AdminPwd->clear();
        QMessageBox::information(this, "Error", "Invalid Administrator Password", QMessageBox::Ok);
    }
    else
    {
        ui->le_AdminPwd->clear();
        iPwdCrt  = 1;
        usrName = ui->le_SuperUserName->text();
        this->close();
    }
}

/*******************************************************************************
 * Name                      : closeEvent
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NLL
 ***************************************************************************//**
 * To clear the password field on closing.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CAdminAuthentication::closeEvent(QCloseEvent *)
{
    ui->le_AdminPwd->clear();
}

/************************************ END OF FILE *****************************/
