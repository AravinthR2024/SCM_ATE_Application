#ifndef CUSERMANAGEMENT_H
#define CUSERMANAGEMENT_H

#include <QDialog>
#include "cadminauthentication.h"
#include <QDebug>
#include <QMessageBox>
#include<QCryptographicHash>
#include <QTableWidgetItem>
#include <QFile>
#include <QLineEdit>
#include "usr_management.h"


namespace Ui {
class CUserManagement;
}

class CUserManagement : public QDialog
{
    Q_OBJECT

public:
    explicit CUserManagement(QWidget *parent = 0);
    ~CUserManagement();
    class CAdminAuthentication *window;
    QLineEdit *usrName;
    QString m_qstrLoggedinUser;
    int m_iLoggedinUserPrevil;
    QString m_qstrSelectedUser;
    char  m_strMsg[256];
    void updateuser();
    void Msg_display(int);
    void execChangePassword();
    void execUserMgmt();


private slots:
    void on_pb_AddUser_clicked();

    void on_pb_Close_clicked();

    void on_pb_AddUsrCnfirmNewUsrPwd_clicked();

    void on_pb_AddUsrCancel_clicked();

    void on_pb_ChngPwd_clicked();

    void on_pb_AdChgCnfirmPwd_clicked();

    void on_pb_AdminChgCancel_clicked();

    void on_pb_DeleteUser_clicked();

    void on_tw_UserDetails_cellClicked(int iRow);

    void closeEvent(QCloseEvent *in_CloseEvent);

    void on_le_NewUsrName_textChanged(const QString &in_str);

    void on_tw_UserDetails_itemSelectionChanged();

    void on_tw_UserDetails_itemClicked(QTableWidgetItem *item);

private:
    Ui::CUserManagement *ui;
};

#endif // CUSERMANAGEMENT_H
