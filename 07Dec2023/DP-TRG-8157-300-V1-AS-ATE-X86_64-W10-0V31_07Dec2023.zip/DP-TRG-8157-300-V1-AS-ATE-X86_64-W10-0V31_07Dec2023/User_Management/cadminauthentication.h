#ifndef CADMINAUTHENTICATION_H
#define CADMINAUTHENTICATION_H

#include <QDialog>
#include "cusermanagement.h"
#include <QCryptographicHash>
#include "usr_management.h"
#include <QDir>

namespace Ui {
class CAdminAuthentication;
}

class CAdminAuthentication : public QDialog
{
    Q_OBJECT

public:
    explicit CAdminAuthentication(QWidget *parent = 0);
    ~CAdminAuthentication();
    int iPwdCrt;
    QString usrName;


private slots:
    void on_pb_Cancel_clicked();

    void on_pb_Ok_clicked();

    void closeEvent(QCloseEvent *in_CloseEvent);

private:
    Ui::CAdminAuthentication *ui;
};

#endif // CADMINAUTHENTICATION_H
