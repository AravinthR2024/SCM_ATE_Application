#ifndef AUTHENTICATION_H
#define AUTHENTICATION_H

#include <QDialog>
#include "QMessageBox"
#include <QCryptographicHash>
#include <QSharedMemory>
#include "structures.h"
#include "usr_management.h"


namespace Ui {
class Authentication;
}

class Authentication : public QDialog
{
    Q_OBJECT

private:
    FILE *Afp;

public:
    bool m_bAuthSuccess;
    explicit Authentication(QWidget *parent = 0);
    bool m_bAuth_Sts;
    bool lock();
    int m_iPrivil;
    QString  m_strUsrname, m_strPwd;
    QMessageBox msgBox;

    ~Authentication();

private slots:

    void on_PB_Exit_clicked();

    void on_PB_Login_clicked();

    void Msg_display(int iErrorCode);

    void on_LE_Pwd_textEdited();

    void on_le_Username_textChanged(const QString &in_str);

    void LoginButtonEnaDis();

private:
    Ui::Authentication *ui;
    QSharedMemory *_singular;
};

#endif // AUTHENTICATION_H
