/**
*	\file DP_UML_Error.h
*	\brief Error codes 
*
*	This file contains all error codes of UML

	\author 
*	\date 
*
*	\revision 
*	- Initial version
*	
*	\copyright Copyright (C) 2011 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
*	All Rights Reserved.\n
*	Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
*   Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
*   Chennai-603103 | India\n
*	Website : http://www.datapatternsindia.com/\n
*	Phone: 91-44-4741-4000\n
*	FAX: 91-44-4741-4444 \n
*	
*/

#ifndef _DP_UML_ERROR_H_
#define _DP_UML_ERROR_H_

enum
{
	DP_UML_NOT_VALID_USERNAME = -99,	/*!< Invalid username*/
	DP_UML_NOT_VALID_PASSWORD,		/*!< Invalid password*/
	DP_UML_NOT_VALID_OLDPASSWORD,		/*!< Invalid old password*/
	DP_UML_NOT_VALID_CONFPASSWORD,		/*!<Invalid confirmed password*/
	DP_UML_NOT_VALID_PRIVILAGE,		/*!<Invalid privilage*/
	DP_UML_USER_ALREADY_EXIST,		/*!<User already exists*/
	
	DP_UML_ERR_MALLOC,			/*!<Error during memory allocation*/
	DP_UML_ERR_DECRYPT,			/*!<Error while decrypt data*/
	DP_UML_ERR_ENCRYPT,			/*!<Error while encrypt data*/
	DP_UML_USERNAME_LEN_MINERR,		/*!<Invalid username length */
	DP_UML_USERNAME_LEN_MAXERR,		/*!<Invalid username length */
	DP_UML_PASS_LEN_MINERR,			/*!<Invlaid Password length*/
	DP_UML_PASS_LEN_MAXERR,			/*!<Invlaid Password length*/
	
	DP_UML_USER_MAX_ERR,			/*!<Max User Error*/
	DP_UML_PASS_SPLCHAR_ERR,		/*!<Special charecter not found*/
	DP_UML_PASS_DIGIT_ERR,			/*!<Digit not found*/
	DP_UML_PRIVILAGE_ERR,	
	DP_UML_SPLCHAR_NAME_ERR,
	DP_UML_USERNAME_LEN_EMPTY,
	DP_UML_PASS_LEN_EMPTY,
	DP_UML_NEWPASS_LEN_EMPTY,
	DP_UML_CONFPASS_LEN_EMPTY,
	
    Dp_UML_FILE_CORRUPTED,
    Dp_UML_FILE_NOT_FOUND
};
#endif 
