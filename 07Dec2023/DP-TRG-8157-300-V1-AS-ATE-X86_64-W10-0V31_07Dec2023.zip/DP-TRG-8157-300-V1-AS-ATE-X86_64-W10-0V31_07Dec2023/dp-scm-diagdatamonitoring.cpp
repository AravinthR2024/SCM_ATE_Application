#include "dp-scm-diagdatamonitoring.h"
#include "ui_dp-scm-diagdatamonitoring.h"
#include "dp-scm-mainwindow.h"
extern S_GLOBAL g_SGlobal;

CDiagDataMonitoring::CDiagDataMonitoring(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CDiagDataMonitoring)
{
    ui->setupUi(this);

    ui->tblwidDiagData->resizeColumnsToContents();
    ui->tblwidDiagData->horizontalHeader()->setVisible(false);
    ui->tblwidDiagData->verticalHeader()->setVisible(false);

    m_pthDataMon = new CDiagDataMonThread(this);

    loadIndices();

    ui->cbSelectAll->setCheckState (Qt::Checked);
}

CDiagDataMonitoring::~CDiagDataMonitoring()
{
    delete ui;
}

void CDiagDataMonitoring::loadIndices()
{
    // Get all the indices from the ENUM and load the appropriate row and col values from the table.
    unsigned char ucLoop = DPSCM_INIT_0;
    unsigned char ucColCounter = DPSCM_INIT_0;
    unsigned char ucRowCounter = DPSCM_INIT_0;

    for (ucLoop = DPSCM_INIT_0; ucLoop < TOTAL_DIAG_LIST; ucLoop++)
    {
        m_arrSNameIndex[ucLoop].m_iRow = ucRowCounter;
        m_arrSNameIndex[ucLoop].m_iCol = ucColCounter;

        m_arrSValueIndex[ucLoop].m_iRow = ucRowCounter;
        m_arrSValueIndex[ucLoop].m_iCol = ucColCounter + 1;

        m_pobjarrNameItem[ucLoop] = ui->tblwidDiagData->item(ucRowCounter, ucColCounter);
        m_pobjarrValueItem[ucLoop] = ui->tblwidDiagData->item(ucRowCounter, ucColCounter + 1);

        ucRowCounter++;

        if ((ucLoop == E_ARRAY_IDENTIFIED_FLAG) || (ucLoop == E_EL_3_3V_VALUE)\
                || (ucLoop == E_ELEVATION_FIRMWARE_VERSION) || (ucLoop == E_ANTENNA_PARTIAL_FORMAT))
        {
            ucRowCounter = DPSCM_INIT_0;    /* Row will now again start from 0 */
            ucColCounter += 2;              /* Take from 3rd column [ColIdx = 2] */
        }
    }
}

void CDiagDataMonitoring::on_pbDiagData_Read_clicked()
{
    CHECK_TC_RUNNING;

    CHECK_PORT_OPEN(DIAGNOSTIC_PORT_IDX);

    if (g_SGlobal.m_ucConfiguredMode != DIAGNOSTICS_MODE)
    {
        DISPLAY_MESSAGE_BOX (this, "Mode Configuration", "Please switch to Diagnostics Mode to Read Diagnostics Registers.");
        return;
    }

    if (ui->cbSelectAll->checkState() == Qt::Unchecked)
    {
        DISPLAY_MESSAGE_BOX(this, "Diagnostics Monitoring", "Select atleast 1 Diagnostics ID to read");
        return;
    }

    memcpy(m_pthDataMon->m_pobjarrNameItem, m_pobjarrNameItem, sizeof(m_pobjarrNameItem));
    memcpy(m_pthDataMon->m_pobjarrValueItem, m_pobjarrValueItem, sizeof(m_pobjarrValueItem));

    on_pbDiagDataClear_clicked();
    emit sig_showLoadingScreen(true);
    m_pthDataMon->Start();
}

void CDiagDataMonitoring::on_tblwidDiagData_itemClicked(QTableWidgetItem *item)
{
    unsigned char ucRow = DPSCM_INIT_0;
    unsigned char ucCol = DPSCM_INIT_0;
    unsigned char ucLoop = DPSCM_INIT_0;
    unsigned char ucCheckedCount = DPSCM_INIT_0;

    if (item->column() % 2 != DPSCM_INIT_0)
    {
        return;
    }

    ucRow = item->row();
    ucCol = item->column();

    if (item->isSelected())
    {
        if (item->checkState () == Qt::Checked)
        {
            item->setCheckState (Qt::Unchecked);
            ui->tblwidDiagData->item(ucRow, ucCol + 1)->setFlags(ui->tblwidDiagData->item(ucRow, ucCol + 1)->flags() & ~Qt::ItemIsEnabled);
        }
        else
        {
            item->setCheckState (Qt::Checked);
            ui->tblwidDiagData->item(ucRow, ucCol + 1)->setFlags(ui->tblwidDiagData->item(ucRow, ucCol + 1)->flags() | Qt::ItemIsEnabled);
        }
    }

    ucCheckedCount = DPSCM_INIT_0;
    for (ucLoop = DPSCM_INIT_0; ucLoop < TOTAL_DIAG_LIST; ucLoop++)
    {
        ucRow = m_arrSNameIndex[ucLoop].m_iRow;
        ucCol = m_arrSNameIndex[ucLoop].m_iCol;

        if (ui->tblwidDiagData->item(ucRow, ucCol)->checkState() == Qt::Checked)
        {
            ucCheckedCount++;
        }
    }

    if (ucCheckedCount == DPSCM_INIT_0)
    {
        ui->cbSelectAll->setCheckState (Qt::Unchecked);
    }
    else if (ucCheckedCount == TOTAL_DIAG_LIST)
    {
        ui->cbSelectAll->setCheckState (Qt::Checked);
    }
    else
    {
        ui->cbSelectAll->setCheckState (Qt::PartiallyChecked);
    }
}

void CDiagDataMonitoring::on_cbSelectAll_clicked()
{
    unsigned char ucRowCount = DPSCM_INIT_0;
    unsigned char ucColCount = DPSCM_INIT_0;
    unsigned char ucRowLoop = DPSCM_INIT_0;
    unsigned char ucColLoop = DPSCM_INIT_0;

    if (ui->cbSelectAll->checkState () == Qt::PartiallyChecked)
    {
        ui->cbSelectAll->setCheckState (Qt::Checked);
    }

    ui->cbSelectAll->setEnabled(false);

    ucRowCount = ui->tblwidDiagData->rowCount ();
    ucColCount = ui->tblwidDiagData->columnCount ();

    for (ucRowLoop = DPSCM_INIT_0; ucRowLoop < ucRowCount; ucRowLoop++)
    {
        for (ucColLoop = DPSCM_INIT_0; ucColLoop < ucColCount; ucColLoop++)
        {
            if ((ucColLoop % 2) != DPSCM_INIT_0)
            {
                continue;
            }

            if (((ucColLoop >= 8) && (ucRowLoop == 15)))
            {
                continue;
            }

            if (ui->cbSelectAll->checkState () == Qt::Checked)
            {
                ui->tblwidDiagData->item (ucRowLoop, ucColLoop)->setCheckState (Qt::Checked);
                ui->tblwidDiagData->item(ucRowLoop, ucColLoop + 1)->setFlags(ui->tblwidDiagData->item(ucRowLoop, ucColLoop + 1)->flags() | Qt::ItemIsEnabled);
            }
            else
            {
                ui->tblwidDiagData->item (ucRowLoop, ucColLoop)->setCheckState (Qt::Unchecked);
                ui->tblwidDiagData->item(ucRowLoop, ucColLoop + 1)->setFlags(ui->tblwidDiagData->item(ucRowLoop, ucColLoop + 1)->flags() & ~Qt::ItemIsEnabled);
            }
        }
    }

    ui->cbSelectAll->setEnabled(true);
}

void CDiagDataMonitoring::on_pbDiagDataClear_clicked()
{
    unsigned char ucLoop = DPSCM_INIT_0;
    int iRow = DPSCM_INIT_0;
    int iCol = DPSCM_INIT_0;

    for (ucLoop = DPSCM_INIT_0; ucLoop < TOTAL_DIAG_LIST; ucLoop++)
    {
        iRow = m_arrSValueIndex[ucLoop].m_iRow;
        iCol = m_arrSValueIndex[ucLoop].m_iCol;

        ui->tblwidDiagData->item(iRow, iCol)->setText("");
        ui->tblwidDiagData->item(iRow, iCol)->setToolTip("");
    }

    ui->tblwidDiagData->resizeColumnsToContents();

    for (ucLoop = DPSCM_INIT_0; ucLoop < TOTAL_DIAG_LIST; ucLoop++)
    {
         m_arrucValues[ucLoop]=0;
    }
}

void CDiagDataMonitoring::slot_setValue(int in_iIndex, QString in_qstrValue)
{
    if (m_pobjarrNameItem[in_iIndex]->checkState() != Qt::Checked)
    {
        in_qstrValue.clear();
    }

    m_pobjarrValueItem[in_iIndex]->setText(in_qstrValue);
}

void CDiagDataMonitoring::slot_threadCompleted()
{
    m_pthDataMon->Stop();
    emit sig_showLoadingScreen(false);
    emit sig_updateActionLog("Diagnostics data Read Completed", LOG_SUCCESS);
}

CDiagDataMonThread::CDiagDataMonThread(QObject *parent) : QThread(parent)
{
    memset (m_arrucValues, 0, sizeof(m_arrucValues));
    memset (m_pobjarrNameItem, 0, sizeof(m_pobjarrNameItem));
    memset (m_pobjarrValueItem, 0, sizeof(m_pobjarrValueItem));
}

void CDiagDataMonThread::Start()
{
    m_bIsRunning = true;
    this->start();
}

void CDiagDataMonThread::Stop()
{
    m_bIsRunning = false;
    this->terminate();
}

void CDiagDataMonThread::run()
{
    unsigned char ucLoop = DPSCM_INIT_0;
    unsigned char ucTemp1 = DPSCM_INIT_0;
    unsigned char ucTemp2 = DPSCM_INIT_0;
    unsigned char ucChecksum = DPSCM_INIT_0;
    unsigned char ucData = DPSCM_INIT_0;
    unsigned int uiBytesRead = DPSCM_INIT_0;
    float fData = 0.0f;
    QString qstrErrMsg = QString();
    QString qstrTemp = QString();
    QString qstrValue = QString();
    int iRetVal = DPSCM_INIT_0;
    U_DEM_PORT_TX UTxCommand = { 0 };
    U_DEM_PORT_RX URxResponse = { 0 };
    unsigned char ucarrDiagIDs[] = {
        ID_00,
        ID_01,
        ID_02,
        ID_03,
        ID_04,
        ID_05,
        ID_06,
        ID_07,
        ID_08,
        ID_09,
        ID_10,
        ID_11,
        ID_12,
        ID_13,
        ID_14,
        ID_15,
        ID_16,
        ID_17,
        ID_18,
        ID_19,
        ID_20,
        ID_21,
        ID_22,
        ID_23,
        ID_24,
        ID_25,
        ID_26,
        ID_27,
        ID_28,
        ID_29,
        ID_30,
        ID_31,
        ID_32,
        ID_33,
        ID_34,
        ID_35,
        ID_36,
        ID_38,
        ID_39,
        ID_40,
        ID_41,
        ID_42,
        ID_43,
        ID_44,
        ID_45,
        ID_46,
        ID_47,
        ID_48,
        ID_49,
        ID_50,
        ID_51,
        ID_54,
        ID_55,
        ID_56,
        ID_57,
        ID_58,
        ID_59,
        ID_60,
        ID_61,
        ID_62,
        ID_63,
        ID_64,
        ID_65,
        ID_66,
        ID_67,
        ID_68,
        ID_69,
        ID_70,
        ID_71,
        ID_72,
        ID_73,
        ID_74,
        ID_75,
        ID_76,
        ID_77,
        ID_78,
        ID_79,
        ID_80,
        ID_81
    };

    memset (m_arrucValues, 0, sizeof(m_arrucValues));
    memset (&UTxCommand, 0, sizeof(U_DEM_PORT_TX));
    memset (&URxResponse, 0, sizeof(U_DEM_PORT_RX));

    for (ucLoop = DPSCM_INIT_0; ucLoop < TOTAL_DIAG_LIST; ucLoop++)
    {
        if (m_pobjarrNameItem[ucLoop]->checkState() != Qt::Checked)
        {
            continue;
        }

        UTxCommand.m_S_DiagCmd.m_ucByte0_Bit6_0 = 0;
        UTxCommand.m_S_DiagCmd.m_ucByte0_Bit7 = 1;

        UTxCommand.m_S_DiagCmd.m_ucByte1_CmdID = CMDID_DIAGMON_READ & 0x1F;
        UTxCommand.m_S_DiagCmd.m_ucByte1_TestInit = 0;
        UTxCommand.m_S_DiagCmd.m_ucByte1_ElorAz = 0;

        UTxCommand.m_S_DiagCmd.m_ucByte1_Bit7 = 0;

        UTxCommand.m_S_DiagCmd.m_ucByte2_Bit6_0 = ucarrDiagIDs[ucLoop] & 0x7F;

        dp_scm_7bit_xor_checksum((unsigned char *)&UTxCommand.m_S_DiagCmd, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);

        UTxCommand.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;
        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *)UTxCommand.m_arrucData, sizeof(S_DIAG_CMDRESP));
        if (iRetVal != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Error Send Command : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_ERROR);
            continue;
        }

        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_DIAG_CMDRESP), (char *) &URxResponse.m_S_DiagResp, &uiBytesRead, 200);
        if (iRetVal != DPSCM_INIT_0)
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Error Receiving Response for DiagID-%d : %s [ErrCode: %d]", ucarrDiagIDs[ucLoop], CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_ERROR);
        }

        ucData = (URxResponse.m_S_DiagResp.m_ucByte3_Bit6_0 & 0x7F);
        qstrValue.clear();

        switch (ucLoop)
        {
        case E_MESSAGE_TX_COUNT:
        {
            qstrValue.sprintf("%d", ucData);
        } break;
        case E_BIT_FAULT_01:
        case E_BIT_FAULT_02:
        case E_GIMBAL_STATUS:
        case E_COMMUNICATION_ERROR:
        case E_SERVO_CONTROL_LOOP_ERROR:
        case E_INTERNAL_SCM_FAULT:
        case E_I2T_AND_TEMP_FAULT:
        case E_EL_VOLTAGE_FAULT:
        case E_AZ_VOLTAGE_FAULT:
        case E_BITE_AND_STATUS:
        case E_PBIT_FAULT:
        case E_MOTOR_TEMPERATURE_FAULT:
        case E_HALL_SENSOR_FAULT:
        case E_MOTOR_ENCODER_FAULT:
        case E_ARRAY_IDENTIFIED_FLAG:
        case E_AZIMUTH_AND_ELEVATION_INDEPENDEND_SENSOR_POSITION:
        case E_1V_MONITORIOING_STATUS:
        case E_1P2V_MONITORIOING_STATUS:
        case E_1P8V_MONITORIOING_STATUS:
        case E_2P5V_MONITORIOING_STATUS:
        case E_3p3V_MONITORIOING_STATUS:
        case E_28V_48V_MONITORIOING_STATUS:
        {
            qstrValue.sprintf("%X", ucData);
        } break;
        case E_EL_1V_VALUE:
        case E_AZ_1V_VALUE:
        case E_EL_1_2V_VALUE:
        case E_AZ_1_2V_VALUE:
        case E_EL_1_8V_VALUE:
        case E_AZ_1_8V_VALUE:
        case E_EL_2_5V_VALUE:
        case E_AZ_2_5V_VALUE:
        case E_EL_3_3V_VALUE:
        case E_AZ_3_3V_VALUE:
        {
            fData = (ucData * DIAGDATA_MIN_VOL) / DIAGDATA_MAX_VOL;
            qstrValue.sprintf("%0.06f V", fData);
        } break;
        case E_EL_28V_48V_VALUE:
        case E_AZ_28V_48V_VALUE:
        {
            fData = (ucData * DIAGDATA_MIN_VOL_28V_48V) / DIAGDATA_MAX_VOL_28V_48V;
            qstrValue.sprintf("%0.06f V", fData);
        } break;
        case E_EL_CURRENT_VALUE:
        {
            if (g_SGlobal.m_ucSystem == SYSTEM_RTGA_EL)
            {
                fData = (ucData * DIAGDATA_CURR_MIN) / DIAGDATA_CURR_MAX;
                fData -= DIAGDATA_CURR_MIN;
            }
            else
            {
                fData = 0.0f;
            }

            qstrValue.sprintf("%0.06f A", fData);
        } break;
        case E_AL_CURRENT_VALUE:
        {
            if (g_SGlobal.m_ucSystem == SYSTEM_RGA_RTGA_AZ)
            {
                fData = (ucData * DIAGDATA_CURR_MIN) / DIAGDATA_CURR_MAX;
                fData -= DIAGDATA_CURR_MIN;
            }
            else
            {
                fData = 0.0f;
            }

            qstrValue.sprintf("%0.06f A", fData);
        } break;
        case E_ELEVATION_INTERNAL_FAULT:
        case E_AZIMUTH_INTERNAL_FAULT:
        case E_ELEVATION_ZETTLEX_STATUS:
        case E_AZIMUTH_ZETTLEX_STATUS:
        {
            qstrValue.sprintf("%02X", ucData);
        } break;
        case E_ELEVATION_TEMPERATURE:
        case E_ELEVATION_INVBRD_TEMPERATURE:
        {
            if (g_SGlobal.m_ucSystem == SYSTEM_RTGA_EL)
            {
                fData = DIAGDATA_TEMP_CYCLE + (ucData * DIAGDATA_TEMP_RESOLUTION);
            }
            else
            {
                fData = 0.0f;
            }
            qstrValue.sprintf("%0.02f°C", fData);
        }break;
        case E_AZIMUTH_TEMPERATURE:
        case E_AZIMUTH_INVBRD_TEMPERATURE:
        {
            if (g_SGlobal.m_ucSystem == SYSTEM_RGA_RTGA_AZ)
            {
                fData = DIAGDATA_TEMP_CYCLE + (ucData * DIAGDATA_TEMP_RESOLUTION);
            }
            else
            {
                fData = 0.0f;
            }
            qstrValue.sprintf("%0.02f°C", fData);
        } break;
        case E_ELEVATION_I2T_AVERAGE_POWER:
        case E_AZIMUTH_I2T_AVERAGE_POWER:
        {
            fData = DIAGDATA_POWER_CYCLE + (ucData * DIAGDATA_POWER_RESOLUTION);
            qstrValue.sprintf("%0.06f W", fData);
        } break;
        case E_ELEVATION_SOFTWARE_VERSION:
        case E_AZIMUTH_SOFTWARE_VERSION:
        case E_ELEVATION_FIRMWARE_VERSION:
        case E_AZIMUTH_FIRMWARE_VERSION:
        {
            ucTemp1 = ucData & 0x0F;
            ucTemp2 = (ucData >> 4) & 0x0F;
            qstrValue.sprintf("%d.%02d", ucTemp2, ucTemp1);
        } break;
        case E_ELEVATION_SCM_VERSION:
        case E_AZIMUTH_SCM_VERSION:
        {
            qstrValue.sprintf("%02d", ucData);
        } break;
        case E_ELEVATION_OFFSET_MSH:
        case E_ELEVATION_OFFSET_LSH:
        case E_ELEVATION_UPPER_ENDSTOP_MSH:
        case E_ELEVATION_UPPER_ENDSTOP_LSH:
        case E_AZIMUTH_CW_ENDSTOP_MSH:
        case E_AZIMUTH_CW_ENDSTOP_LSH:
        case E_ELEVATION_LOWER_ENDSTOP_MSH:
        case E_ELEVATION_LOWER_ENDSTOP_LSH:
        case E_AZIMUTH_CCW_ENDSTOP_MSH:
        case E_AZIMUTH_CCW_ENDSTOP_LSB:
        case E_ANTENNA_CHECKSUM_COUNT:
        case E_ANTENNA_INCORRECT_MESSAGE:
        case E_ANTENNA_PARTIAL_FORMAT:
        case E_ANTENNA_LOSS_OF_COMMUNICATION:
        case E_MESSAGE_RX_COUNT:
        {
            qstrValue.sprintf("%d", ucData);
        } break;
        case E_EL_TO_AZ_CHECKSUM_COUNT:
        case E_EL_TO_AZ_INCORRECT_MESSAGE:
        case E_EL_TO_AZ_PARTIAL_FORMAT:
        case E_AZ_TO_EL_CHECKSUM_COUNT:
        case E_AZ_TO_EL_INCORRECT_MESSAGE:
        case E_AZ_TO_EL_PARTIAL_FORMAT:
        case E_DIAG_PORT_CHECKSUM_COUNT:
        case E_DIAG_PORT_INCORRECT_MESSAGE:
        case E_DIAG_PORT_PARTIAL_FORMAT:
        {
            qstrValue.sprintf("%02X", ucData);
        } break;
        case E_ELEVATION_MOTOR_TEMPERATURE:
        {
            if (g_SGlobal.m_ucSystem == SYSTEM_RTGA_EL)
            {
                fData = ucData * DIAGDATA_TEMP_RESOLUTION;
            }
            else
            {
                fData = 0.0f;
            }
            qstrValue.sprintf("%0.02f°C", fData);
        }break;

        case E_AZIMUTH_MOTOR_TEMPERATURE:
        {
            if (g_SGlobal.m_ucSystem == SYSTEM_RGA_RTGA_AZ)
            {
                fData = ucData * DIAGDATA_TEMP_RESOLUTION;
            }
            else
            {
                fData = 0.0f;
            }
            qstrValue.sprintf("%0.02f°C", fData);
        }break;
        default: break;
        }

        emit sig_setValue(ucLoop, qstrValue);
    }

    emit sig_threadCompleted();
}
