/**
* \file dp-scm-fra_acq.cpp
* \brief This file contains the code for Analysed data read thread, Data read thread and
*		RAW Data FIFO Read thread
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-fra_acq.h"

#undef _TXT_FILE_WRITE_ // define _TXT_FILE_WRITE_ to write ana data to .txt file, undef to store ana data in .ana file

SDPPCI755_ANALYZEDDATABUFFER g_SCurrentDataBuffer;

extern S_GLOBAL g_SGlobal;
//extern CDPPCI755Wrapper g_objPCI755;

/*******************************************************************************
 * Name					: CANADataReadThread
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CANADataReadThread class
 *
 * @param[in]	parent	Holds the reference to the parent
 * @param[in]	in_u16BrdNo	Holds the board number
 *
 * @return	NA
 ******************************************************************************/
CANADataReadThread::CANADataReadThread(QObject * parent, U16BIT in_u16BrdNo) :QThread(parent)
{
    m_u16BrdNo = in_u16BrdNo;
    g_u16CurrentDataReadFlg = false;
    g_u16AnalysedDataReadFlg = false;
    m_fpAnalyzedDataFile = NULL;
}

/*******************************************************************************
 * Name					: run
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To execute the thread
 ***************************************************************************//**
 * @brief	This function hold the repeated execution of this thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CANADataReadThread::run()
{
#if 1
    bool bIsSweepFinish[SCM_ATE_MAX_PCI755_BRDS] = {true};
    char cType = 0;
    U16BIT u16BrdIndex = 0;
    U32BIT u32AnaDataCount = 0;
    S32BIT s32RetVal = 0;

#ifdef _TXT_FILE_WRITE_
    FILE *fpAnaSample = NULL;
    FILE *fpADCSample = NULL;
    U32BIT u32Index = 0;
#endif
    SDPPCI755_CONFIG ScfgDataDetails;		//	Configuration details structure
    QString	qstrLabel = "";
    QString qstrTemp = "";
    S8BIT s8FileName[200] = {0};
    char  szErrMsg[200];		//  Used to store the error string
    FSINGLE fStep = 0;
    FSINGLE fNext = 0;
    U32BIT uiFreqIndx = 0;
    FSINGLE dCurrFreq;
    FSINGLE dLogStartFreq = 0.0;
    FSINGLE  dLogStopFreq = 0.0;
    FSINGLE dStepFreq	  = 0.0;
    FSINGLE dLogConst	  = 0.0;
    FSINGLE fTemp;
    U8BIT  u8Log = 0;
    char szArr[15] = {0};
    memset(&ScfgDataDetails, 0, sizeof(SDPPCI755_CONFIG));

    u16BrdIndex = m_u16BrdNo;

    m_u8FlgSweepFinished = false;

    // Get the configuration details to the running board
    ScfgDataDetails =  g_SGlobal.m_SFRAConfig;
    if(ScfgDataDetails.m_u32WaveformType == E_WAVEINP_SINE)
    {
        if(!g_SGlobal.g_SthInfo[u16BrdIndex].m_qFileName.endsWith(".ana"))
        {
            qstrTemp.sprintf("%s.ana", g_SGlobal.g_SthInfo[u16BrdIndex].m_qFileName.toLatin1().data());
        }
        else
        {
            qstrTemp = g_SGlobal.g_SthInfo[u16BrdIndex].m_qFileName.toLatin1().data();
        }
        strcpy(s8FileName,qstrTemp.toLatin1().data());

        if(m_fpAnalyzedDataFile !=NULL )
        {
            fclose(m_fpAnalyzedDataFile);
            m_fpAnalyzedDataFile= NULL;
        }

        //Open file to store analysed data
        m_fpAnalyzedDataFile = fopen(s8FileName,"wb");
        if(m_fpAnalyzedDataFile == NULL)
        {
            emit Set_Adc_Text(qstrLabel);
            emit Set_Status("File Creation error or OutputFiles folder is not available in the Appdata path");
            return;
        }

        cType = 'S';
        fwrite(&cType, sizeof(char), 1, m_fpAnalyzedDataFile);


#ifdef _TXT_FILE_WRITE_
        QString qstrPath = QString();
        qstrPath.sprintf("%s/%s", CONV_QSTR_TO_SZ(g_SGlobal.g_qstrAppPath), CONV_QSTR_TO_SZ(LOG_FRADATA_PATH));
        qstrTemp.sprintf("%sGainPhase_%s.csv", CONV_QSTR_TO_SZ(qstrPath), CONV_QSTR_TO_SZ(QDateTime::currentDateTime().toString("dd_MM_yyyy-hh_mm_ss")));

        QDir dir;
        dir.setPath(qstrPath);
        if (!dir.exists())
        {
            dir.mkdir(qstrPath);
        }

        fpAnaSample = fopen(CONV_QSTR_TO_SZ(qstrTemp),"w");
        if(fpAnaSample == NULL)
        {
            return;
        }

        fprintf(fpAnaSample,"Time,Frequency,Gain,Phase\n");

        /* For Voltage logging */
        qstrTemp.sprintf("%sVoltage_%s.csv", CONV_QSTR_TO_SZ(qstrPath), CONV_QSTR_TO_SZ(QDateTime::currentDateTime().toString("dd_MM_yyyy-hh_mm_ss")));
        dir.setPath(qstrPath);
        if (!dir.exists())
        {
            dir.mkdir(qstrPath);
        }

        fpADCSample = fopen(CONV_QSTR_TO_SZ(qstrTemp),"w");
        if(fpADCSample == NULL)
        {
            qDebug() << "Error creating ADC Sample Log File : " << strerror(errno);
            return;
        }

        fprintf(fpADCSample,"Time,Voltage\n");
#endif
    }

    if(!ScfgDataDetails.m_bLog)
    {
        //calculation of next frequency for continue in linear sweep
        fStep = ScfgDataDetails.m_fStepSize;
        fNext = g_fLastFreq + fStep;
    }
    else
    {
        //calculation of next frequency for continue in log sweep
        dCurrFreq = ScfgDataDetails.m_fStartFreq;

        dLogStartFreq = pow(10.0, floor(log10(ScfgDataDetails.m_fStartFreq)));
        dLogStopFreq = pow(10.0, ceil(log10(ScfgDataDetails.m_fEndFreq)));
        dStepFreq = ceil(log10(dLogStopFreq / dLogStartFreq)) * ScfgDataDetails.m_fStepSize;

        dLogConst = ((log10(dLogStopFreq) - log10(dLogStartFreq)) / (dStepFreq - 1));

        //changing to 5 digit precision
        sprintf(szArr,"%4.5f", g_fLastFreq);
        g_fLastFreq = atof(szArr);

        //Calculating the last current pause frequency
        while(dCurrFreq < g_fLastFreq)
        {
            uiFreqIndx++;
            dCurrFreq = log10(dLogStartFreq) + uiFreqIndx * dLogConst;
            dCurrFreq = exp((dCurrFreq * log(10)));
            //changing to 5 digit precision
            sprintf(szArr,"%4.3lf", dCurrFreq);
            dCurrFreq = atof(szArr);
        }

        //calculating the next frequency.
        uiFreqIndx++;
        dCurrFreq = log10(dLogStartFreq) + uiFreqIndx * dLogConst;
        dCurrFreq = exp((dCurrFreq * log(10)));

        fNext = dCurrFreq ;
        fStep = ScfgDataDetails.m_fStepSize;
        u8Log=true;

        //changing to 5 digit precision
        sprintf(szArr,"%4.5lf", fNext);
        fNext = atof(szArr);

        sprintf(szArr,"%4.5f", ScfgDataDetails.m_fEndFreq);
        fTemp = (float) atof(szArr);

        if(fNext > fTemp)
        {
            fStep=0;
            fNext=fTemp;
            u8Log=false;
        }
    }

    sprintf(szArr,"%4.5f", ScfgDataDetails.m_fEndFreq);
    fTemp = (float) atof(szArr);

    if(fNext== fTemp)
    {
        fStep=0;
        u8Log=false;
    }

    //configure all the waveform parameters for continue option.
    s32RetVal = ConfigureFrequency(u16BrdIndex, fNext, fStep, u8Log);
    if(s32RetVal != DPPCI755_SUCCESS)
    {
        if(m_fpAnalyzedDataFile !=NULL )
        {
            fclose(m_fpAnalyzedDataFile);
            m_fpAnalyzedDataFile= NULL;
        }
        g_SGlobal.g_SthInfo[u16BrdIndex].m_cSemaStartStop.release(u16BrdIndex + 1);

        emit sig_updateActionLog("Pause frequency configuration failed", LOG_ERROR);

        g_SGlobal.g_u8ThreadAcqStop[u16BrdIndex] = true;

        emit Acq_Start(false);
        emit Stop_Acq();

        return;
    }

    msleep(1000); // Sleep is added to avoid immediate data acquisition

    s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_StartStopAcquisition(u16BrdIndex, true);
    if((s32RetVal != DPPCI755_SUCCESS))
    {
        g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);

        emit sig_DisplayMessage(szErrMsg);

        return;
    }
    else
    {
        emit sig_acqStarted();
        g_SGlobal.g_SthInfo[u16BrdIndex].m_cSemaStartStop.release(u16BrdIndex + 1);
    }

    msleep(1000); //Sleep added to avoid immediate data read after immediate acquisition

    while((bIsSweepFinish[u16BrdIndex]) && (g_u16AnalysedDataReadFlg))
    {
        s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_ReadSineWaveData(u16BrdIndex, &u32AnaDataCount, SAnalyzedDataBuffer);
        if(u32AnaDataCount == 0) //If data not available wait and read
        {
            msleep(1); //Apporx
        }

        if(u32AnaDataCount)
        {
            if(m_fpAnalyzedDataFile != NULL)
            {
                fwrite(SAnalyzedDataBuffer, sizeof(SDPPCI755_ANALYZEDDATABUFFER), u32AnaDataCount, m_fpAnalyzedDataFile);
            }

#ifdef _TXT_FILE_WRITE_
            for(u32Index = 0; u32Index < u32AnaDataCount; u32Index++)
            {
                if(fpAnaSample != NULL)
                {
                    fprintf(fpAnaSample,"%s,%f,%f,%f\n",CONV_QSTR_TO_SZ(QDateTime::currentDateTime().toString("HH:mm:ss.zzz")),\
                            SAnalyzedDataBuffer[u32Index].m_fFrequency,SAnalyzedDataBuffer[u32Index].m_fGain,SAnalyzedDataBuffer[u32Index].m_fPhase);\
                }

                if (fpADCSample != NULL)
                {
                    fprintf(fpADCSample, "%s, %f\n", CONV_QSTR_TO_SZ(QDateTime::currentDateTime().toString("HH:mm:ss.zzz")), fADCVoltage);
                }
            }
#endif
            u32AnaDataCount = 0;
            g_SGlobal.Sflag.m_bIsDataLoad  = true;
            g_SGlobal.g_SData.m_bIsDataReady[u16BrdIndex] = true;
        }

        if(s32RetVal == DPPCI755_ERR_SWEEP_FINISH)
        {
            msleep(500);//Sleep added to avoid last data miss in (DPPCI755_ReadCurrentData)

            emit Current_Data_Display(u16BrdIndex, 0);

            bIsSweepFinish[u16BrdIndex] = false;
            m_u8FlgSweepFinished = true;
            g_SGlobal.Sflag.m_bIsDataLoad  = true;
            g_SGlobal.g_SData.m_bIsDataReady[u16BrdIndex] = true;

            emit Acq_Start(false);
            emit Stop_Acq();


#ifdef _TXT_FILE_WRITE_
            if(fpAnaSample != NULL)
            {
                fclose(fpAnaSample);
                fpAnaSample = NULL;
            }

            if (fpADCSample != NULL)
            {
                fclose(fpADCSample);
                fpADCSample = NULL;
            }
#endif
        }
        emit MainWin_Ongraph_Draw(u16BrdIndex);
    }
#endif  // If 1
}

/*******************************************************************************
 * Name					: ConfigureFrequency
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To configure the frequency parameters
 ***************************************************************************//**
 * @brief	This function is used to configure the frequency with given parameters
 *
 * @param[in]	in_u16BoardNo	Specifies the board number
 * @param[in]	in_fStrtFreq	Specifies the Starting frequency
 * @param[in]	in_fStep	Specifies the step value for frequency
 * @param[in]	in_u8Log	Specifies if the frequency is in log
 *
 * @return
 ******************************************************************************/
S32BIT CANADataReadThread::ConfigureFrequency(U16BIT in_u16BoardNo, FSINGLE in_fStrtFreq, FSINGLE in_fStep, U8BIT in_u8Log)
{
    S32BIT s32RetVal = 0;
    char szErrMsg[200] = "";
    SDPPCI755_CONFIG SConfig;
    QString qstrErrMsg = QString();

    g_SGlobal.g_SthInfo[in_u16BoardNo].m_scfgData.m_u32GainIndex[0] = 0;
    g_SGlobal.g_SthInfo[in_u16BoardNo].m_scfgData.m_u32GainIndex[1] = 0;

    memcpy(&SConfig, &g_SGlobal.g_SthInfo[in_u16BoardNo].m_scfgData, sizeof(SDPPCI755_CONFIG));

    msleep(50);
    s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_SetMasterMode(in_u16BoardNo, SConfig.m_u32Mode);
    if (s32RetVal)
    {
        g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);
        qDebug("Error while configuring frequency : %s [ErrCode: %d]", szErrMsg, s32RetVal);
        return DPSCM_FAILURE;
    }

    if (in_fStrtFreq > SConfig.m_fEndFreq)
    {
        in_fStrtFreq = SConfig.m_fEndFreq;
    }

    SConfig.m_fStartFreq = in_fStrtFreq;
    SConfig.m_fStepSize = in_fStep;
    SConfig.m_bLog = in_u8Log;

    s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_ConfigureWaveform(in_u16BoardNo, SConfig);
    if (s32RetVal)
    {
        g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);
        qstrErrMsg.sprintf("Error while configuring Waveform : %s [ErrCode: %d]", szErrMsg, s32RetVal);
        qDebug("Error while configuring waveform : %s [ErrCode: %d]", szErrMsg, s32RetVal);
        emit sig_updateActionLog(qstrErrMsg, LOG_ERROR);
        return DPSCM_FAILURE;
    }

    s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_ConfigureAnaParameters(in_u16BoardNo, SConfig);
    if (s32RetVal)
    {
        g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);
        qstrErrMsg.sprintf("Error while configuring Analytical Parameters : %s [ErrCode: %d]", szErrMsg, s32RetVal);
        qDebug("Error while configuring Analytical Parameters : %s [ErrCode: %d]", szErrMsg, s32RetVal);
        emit sig_updateActionLog(qstrErrMsg, LOG_ERROR);
        return DPSCM_FAILURE;
    }

    return DPSCM_SUCCESS;
}

/*******************************************************************************
 * Name					: CDataReadThread
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CDataReadThread class
 *
 * @param[in]	parent	Holds the reference to the parent
 * @param[in] in_u16BrdNo	Holds the board number
 *
 * @return	NA
 ******************************************************************************/
CDataReadThread::CDataReadThread(QObject * parent, U16BIT in_u16BrdNo) :QThread(parent)
{
    m_u16BrdNo = in_u16BrdNo;
}

/*******************************************************************************
 * Name					: run
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To execute the thread
 ***************************************************************************//**
 * @brief	This function holds the repeated executions of the thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CDataReadThread::run()
{
    U16BIT u16BrdIndex = 0;
    S32BIT s32RetVal = 0;
    SDPPCI755_CONFIG ScfgDataDetails;		//	Configuration details structure
    QString	qstrLabel = QString();
    QString qstrTemp = QString();
    QString qstrTemp2 = QString();
    QFileInfo qfInfo;
    char  szErrMsg[200];		//  Used to store the error string

    memset(&ScfgDataDetails, 0, sizeof(SDPPCI755_CONFIG));
    float fFreqPrev = 0.0f;
    qstrLabel.sprintf("ADC &Value");

    u16BrdIndex = m_u16BrdNo;

    emit UpdatePauseSte(2);

    ScfgDataDetails =  g_SGlobal.g_SthInfo[u16BrdIndex].m_scfgData;
    ScfgDataDetails.m_u32BoardNo = u16BrdIndex;
    g_SCurrentDataBuffer.m_fFrequency = ScfgDataDetails.m_fStartFreq;
    g_SGlobal.g_SData.m_u32nDataCount[u16BrdIndex]	= 0;

    //Initial data
    g_SCurrentDataBuffer.m_fFrequency  = ScfgDataDetails.m_fStartFreq;
    g_SCurrentDataBuffer.m_fGain		= 0;
    g_SCurrentDataBuffer.m_fPhase		= 0;
    memset(&g_SCurrentDataBuffer, 0, sizeof(SDPPCI755_ANALYZEDDATABUFFER));

    //If Acquisition started then read the data
    g_SGlobal.g_SthInfo[u16BrdIndex].m_cSemaStartStop.acquire(u16BrdIndex + 1);
    emit sig_updateActionLog("FRA Testcase started", LOG_PARTIAL_SUCCESS);

    g_SGlobal.g_SRawDataThreadInfo[m_u16BrdNo].m_u8semStartExitEvent = 1;

    while(g_SGlobal.g_u16CurrentDataReadFlg)
    {
        if(!g_SGlobal.g_u16RandomDataReadFlg)
        {
            if(ScfgDataDetails.m_u32WaveformType == E_WAVEINP_SINE)
            {
                s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_ReadCurrentAnaData(u16BrdIndex, &g_SCurrentDataBuffer);
                if((s32RetVal != DPPCI755_SUCCESS))
                {
                    g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);

                    emit sig_DisplayMessage(szErrMsg);

                    g_SGlobal.g_SthInfo[u16BrdIndex].m_u32semStopEvent = 1;
                    break;
                }
                else
                {
                    if(g_SGlobal.g_u8RandomSts[u16BrdIndex]) // If random data read all completed stop the thread read
                    {
                        g_SGlobal.g_u8RandomSts[u16BrdIndex] = 0;
                        g_SGlobal.g_u8FlgSweepFinished[u16BrdIndex] = false;
                        g_SGlobal.g_SData.m_bIsDataReady[u16BrdIndex] = true;

                        qstrLabel.sprintf("ADC &Value");

                        g_SGlobal.g_u8ThreadAcqStop[u16BrdIndex] = true;

                        emit Acq_Start( false);
                        emit Stop_Acq();

                        emit MainWin_Ongraph_Draw(u16BrdIndex);

                        emit sig_updateActionLog("FRA Testcase Completed", LOG_SUCCESS);
                        break;
                    }

                    //To avoid reading continously from the Buffer
                    //Hint: To avoid Max(eg:92% taken in Core 2 Duo Processor,4GB Ram) CPU usage for this process
                    if(fFreqPrev == g_SCurrentDataBuffer.m_fFrequency)//If data not available wait and read
                    {
                        msleep(1);
                    }

                    if(g_SCurrentDataBuffer.m_fFrequency > 0)
                    {
                        if(fFreqPrev != g_SCurrentDataBuffer.m_fFrequency)
                        {
                            fFreqPrev = g_SCurrentDataBuffer.m_fFrequency;
                            g_fLastFreq = g_SCurrentDataBuffer.m_fFrequency;
                            emit Current_Data_Display(u16BrdIndex, 0);
                        }
                    }
                    if((g_SGlobal.g_u8FlgSweepFinished[u16BrdIndex] == true))
                    {
                        g_SGlobal.g_SData.m_bIsBoardSelected[u16BrdIndex] = false;
                        g_SGlobal.Sflag.m_bIsDataLoad  = true;
                        g_SGlobal.g_u8ThreadAcqStop[u16BrdIndex] = true;

                        emit Acq_Start( false);
                        emit Stop_Acq();
                        qstrLabel.sprintf("ADC &Value");
                        emit Set_Adc_Text(qstrLabel);
                        g_SGlobal.g_u8FlgSweepFinished[u16BrdIndex] = false;
                        g_SGlobal.g_SData.m_bIsDataReady[u16BrdIndex] = true;

                        emit MainWin_Ongraph_Draw(u16BrdIndex);

                        emit sig_updateActionLog("FRA Testcase Completed", LOG_SUCCESS);
                        if(((ScfgDataDetails.m_fOffset != 0)  || (ScfgDataDetails.m_u32StopAngle != 0)))
                        {
                            qDebug("PostMsg1");
                            emit sig_ResetBias(u16BrdIndex);
                        }
                        break;
                    }
                }
            }
            else
            {
                if(g_SGlobal.g_u8FlgSweepFinished[u16BrdIndex])
                {
                    g_SGlobal.Sflag.m_bIsDataLoad  = true;
                    g_SGlobal.g_SData.m_bIsBoardSelected[u16BrdIndex] = false;

                    qstrLabel.sprintf("A&bort");
                    emit Set_Adc_Text(qstrLabel);

                    g_SGlobal.g_u8ThreadAcqStop[u16BrdIndex] = true;

                    emit Acq_Start( false);
                    emit Stop_Acq();
                    qstrLabel.sprintf("ADC &Value");
                    emit Set_Adc_Text(qstrLabel);
                    if(((ScfgDataDetails.m_fOffset != 0)  || (ScfgDataDetails.m_u32StopAngle != 0)))
                    {
                        emit sig_ResetBias(u16BrdIndex);
                    }
                    g_SGlobal.g_SData.m_bIsDataReady[u16BrdIndex] = true;


                    emit MainWin_Ongraph_Draw(u16BrdIndex);

                    emit sig_updateActionLog("FRA Testcase Completed", LOG_SUCCESS);

                    return;
                }
            }
        }

        else
        {
            break;
        }
    }


    if(g_SGlobal.g_SthInfo[u16BrdIndex].m_u32semStopEvent)
    {
        qfInfo.setFile(g_SGlobal.m_qfFRALog);
        qstrTemp2 = qfInfo.absoluteFilePath();
        qstrTemp.sprintf("FRA Log data store in <a href=\"file:///%s\">%s</a>", CONV_QSTR_TO_SZ(qstrTemp2), CONV_QSTR_TO_SZ(qstrTemp2));
        emit sig_updateActionLog("FRA Testcase Completed", LOG_SUCCESS);
        emit sig_updateActionLog(qstrTemp, LOG_SUCCESS);
        g_SGlobal.m_bIsGraphBeingPlotted = false;
        emit sig_changeButtonName("S&tart");
    }
    emit Set_Adc_Text(qstrLabel);

    return ;
}

/*******************************************************************************
 * Name					: CReadRawDataFIFO
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CReadRawDataFIFO class
 *
 * @param[in]	parent	Holds the reference to the parent
 * @param[in]	in_u16BrdNo	Holds the board number
 *
 * @return	NA
 ******************************************************************************/
CReadRawDataFIFO::CReadRawDataFIFO(QObject * parent, U16BIT in_u16BrdNo) :QThread(parent)
{
    m_u16BrdNo = in_u16BrdNo;
}

/*******************************************************************************
 * Name					: run
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To execute the operation is thread
 ***************************************************************************//**
 * @brief	This function holds the repeated operations to be executed in thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CReadRawDataFIFO::run()
{
    FILE * fpRawDataFile = NULL;
    U16BIT u16BoardNo = 0;
    QString	strLabel = "";
    U32BIT	u32RawDataCount = 0;
    SDPPCI755_CONFIG ScfgDataDetails;		//	Configuration details structure
    U32BIT	u32TotalCnt = 0;
    SDPPCI755_RAWDATABUFFER SRawData[RAW_DATA_MAX_COUNT];
    QString qstrTemp = "";
    S32BIT s32RetVal = 0;
    S8BIT s8FileName[200] = {0};
    S8BIT  s8ErrStr[200] = "";		//  Used to store the error string
    memset(&ScfgDataDetails, 0, sizeof(SDPPCI755_CONFIG));

    u16BoardNo = m_u16BrdNo;

    ScfgDataDetails =  g_SGlobal.g_SthInfo[u16BoardNo].m_scfgData;

    if(!g_SGlobal.g_SRawDataThreadInfo[m_u16BrdNo].m_qFileName.endsWith(".raw"))
    {
        qstrTemp.sprintf("%s.raw", g_SGlobal.g_SRawDataThreadInfo[m_u16BrdNo].m_qFileName.toLatin1().data());
    }
    else
    {
        qstrTemp.sprintf("%s", g_SGlobal.g_SRawDataThreadInfo[m_u16BrdNo].m_qFileName.toLatin1().data());
    }

    strcpy(s8FileName,qstrTemp.toLatin1().data());
    qstrTemp.clear();
    strLabel.sprintf("ADC &Value");

    emit sig_updateActionLog("Read RawData Thread started successfully", LOG_INFO);

    if(g_u8RawDataFileSel)
    {
        fpRawDataFile = fopen(s8FileName,"wb");
        if(fpRawDataFile == NULL)
        {
            emit sig_DisplayMessage("Raw data File Creation error.");
            emit sig_updateActionLog("File Creation error or OutputFiles folder not available in the Appdata path", LOG_ERROR);
            return;
        }
    }

    s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_StartStopAcquisition(u16BoardNo, true);
    if(s32RetVal != DPPCI755_SUCCESS)
    {
        g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, s8ErrStr);
        g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, s8ErrStr);
        emit sig_DisplayMessage(s8ErrStr);
        if(fpRawDataFile != NULL)
        {
            fclose(fpRawDataFile);
            fpRawDataFile = NULL;
        }
        return;
    }


    while(g_SGlobal.g_u16RawDataReadFlg[u16BoardNo])
    {
        if(g_SGlobal.g_SRawDataThreadInfo[u16BoardNo].m_u8semStartExitEvent != 1)
        {
            continue;
        }

        s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_ReadRawData(u16BoardNo, &u32RawDataCount, SRawData);
        if (s32RetVal != DPSCM_SUCCESS)
        {
            g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, s8ErrStr);
            emit sig_updateActionLog(QString("Error Reading RawData : %1").arg(s8ErrStr), LOG_ERROR);
        }

        //To avoid reading continously from the Buffer
        //Hint: To avoid Max(eg:92% taken in Core 2 Duo Processor,4GB Ram) CPU usage for this process
        if(u32RawDataCount == 0) //If data not available wait and read
        {
            emit sig_updateActionLog("ReadRawData NA", LOG_PARTIAL_SUCCESS);
            msleep(100);
        }

        u32TotalCnt += u32RawDataCount;
        if(u32RawDataCount)
        {
            if(g_u8RawDataFileSel)
            {
                if(fpRawDataFile != NULL)
                {
                    fwrite(SRawData, sizeof(SDPPCI755_RAWDATABUFFER), u32RawDataCount, fpRawDataFile);
                }
            }

            u32RawDataCount = DPSCM_INIT_0;
            g_SGlobal.Sflag.m_bIsDataLoad = true;
        }

        if(s32RetVal == DPPCI755_ERR_SWEEP_FINISH)
        {
            g_SGlobal.Sflag.m_bIsDataLoad = 1;
            g_SGlobal.g_u8ThreadAcqStop[u16BoardNo] = true;

            if((ScfgDataDetails.m_fOffset != 0) || ((ScfgDataDetails.m_u32StopAngle != 0) && (ScfgDataDetails.m_u32WaveformType == WAVE_SQUARE)))
            {
                emit sig_ResetBias(u16BoardNo); //Alert Message
                g_SGlobal.g_u32SweepSts = true;
            }

            strLabel.sprintf("ADC &Value");
            emit Set_Adc_Text(strLabel);
            if(g_u8RawDataFileSel)
            {
                if(fpRawDataFile != NULL)
                {
                    fwrite(&ScfgDataDetails, sizeof(SDPPCI755_CONFIG), 1, fpRawDataFile);
                }

                if(fpRawDataFile != NULL)
                {
                    fclose(fpRawDataFile);
                    fpRawDataFile = NULL;
                }
            }
            emit Stop_Acq();
            break;
        }
    }

    return;
}
