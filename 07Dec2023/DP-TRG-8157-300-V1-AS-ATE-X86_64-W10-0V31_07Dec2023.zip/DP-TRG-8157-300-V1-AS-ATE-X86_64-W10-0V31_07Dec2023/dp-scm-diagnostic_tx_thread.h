/**
* \file dp-scm-diagnostics_tx_thread.h
* \brief This is the header file for dp-scm-diagnostics_tx_thread.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef CDIAGNOSTICTX_H
#define CDIAGNOSTICTX_H

#include <QThread>
#include <QDebug>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "dprs232_wrapper.h"
#include "includes/dp_qt_msgqueue.h"
#include "checksum.h"

class CDiagnosticTx : public QThread
{
    Q_OBJECT

public:
      CDiagnosticTx(QObject *parent = 0, int in_iTimeout = 0);
      bool m_bDiagTxSts;
      int m_iTimeout;

      PSSCM_RTGA_RESP_PKT m_pSRespTxData;

      void setTimeout(int in_iTimeout);
      void Start();
      void Stop();

protected:
      void run();

signals:
    void sig_updateActionLog(QString, int);
};

#endif // CDIAGNOSTICTX_H
