/**
* \file dp-scm-modinitstatus.cpp
* \brief This file contains the code for Module Initialization Status panel
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-modinitstatus.h"
#include "ui_dp-scm-modinitstatus.h"

extern S_GLOBAL g_SGlobal;

/*******************************************************************************
 * Name					: CModInitStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CModInitStatus class
 *
 * @param[in]	parent	Holds the reference to the parent
 *
 * @return	NA
 ******************************************************************************/
CModInitStatus::CModInitStatus(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CModInitStatus)
{
    ui->setupUi(this);

    m_bIsFirstInitialization = true;

    g_SGlobal.m_DPPCI755Details.m_s8BoardSts = false;
    g_SGlobal.m_DPXMC5775Details.m_s8BoardSts = false;

    m_ucModInitSts = false;
}

/*******************************************************************************
 * Name					: ~CModInitStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief	This function is the destructor of CModInitStatus class
 *
 * @param		NIL
 * @return	NA
 ******************************************************************************/
CModInitStatus::~CModInitStatus()
{
    delete ui;
}

/*******************************************************************************
 * Name					: loadModules
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To load the modules details
 ***************************************************************************//**
 * @brief	This function is used to display the modules details and status
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CModInitStatus::updateModulesTable()
{
    unsigned char ucIndex = DPSCM_INIT_0;
    QTableWidgetItem *pCenteredItem;
    QString qstrBtnStyle = "QPushButton { border: none; background-color: transparent; }";

    pbPCI_Close = new QPushButton("");
    pbPCI_Close->setToolTip("Close FRA Board");
    pbPCI_Close->setIcon(QIcon(":/images/images/img_close_black.png"));
    pbPCI_Close->setIconSize(QSize(24, 24));
    pbXMC_Close = new QPushButton("");
    pbXMC_Close->setToolTip("Close XMC Board");
    pbXMC_Close->setIcon(QIcon(":/images/images/img_close_black.png"));
    pbXMC_Close->setIconSize(QSize(24, 24));
    pbPCI_Reset = new QPushButton("");
    pbPCI_Reset->setToolTip("Reset FRA Board");
    pbPCI_Reset->setIcon(QIcon(":/images/images/img_reset.png"));
    pbPCI_Reset->setIconSize(QSize(24, 24));
    pbXMC_Reset = new QPushButton("");
    pbXMC_Reset->setToolTip("Reset XMC Board");
    pbXMC_Reset->setIcon(QIcon(":/images/images/img_reset.png"));
    pbXMC_Reset->setIconSize(QSize(24, 24));
    pbPCI_Close->setStyleSheet(qstrBtnStyle);
    pbPCI_Reset->setStyleSheet(qstrBtnStyle);
    pbXMC_Close->setStyleSheet(qstrBtnStyle);
    pbXMC_Reset->setStyleSheet(qstrBtnStyle);
    connect (pbPCI_Close, SIGNAL(clicked(bool)), this, SLOT(slot_PCI_Close_Clicked()));
    connect (pbXMC_Close,SIGNAL(clicked(bool)),this, SLOT(slot_XMC_Close_Clicked()));
    connect (pbPCI_Reset, SIGNAL(clicked(bool)), this, SLOT(slot_PCI_Reset_Clicked()));
    connect (pbXMC_Reset,SIGNAL(clicked(bool)),this, SLOT(slot_XMC_Reset_Clicked()));

    pCenteredItem = new QTableWidgetItem;
    pCenteredItem->setTextAlignment(Qt::AlignCenter);

    ui->tblwidModuleStatus->setFocusPolicy(Qt::NoFocus);
    ui->tblwidModuleStatus->horizontalHeader()->setVisible(true);
    ui->tblwidModuleStatus->verticalHeader()->setVisible(false);
    ui->tblwidModuleStatus->horizontalHeader()->setSectionsClickable(false);
    ui->tblwidModuleStatus->setSelectionMode(QAbstractItemView::NoSelection);
    ui->tblwidModuleStatus->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tblwidModuleStatus->setColumnWidth(MODTBL_COL_BRDNAME, 240);
    ui->tblwidModuleStatus->setColumnWidth(MODTBL_COL_BUSNO, 100);
    ui->tblwidModuleStatus->setColumnWidth(MODTBL_COL_SLOTNO, 100);
    ui->tblwidModuleStatus->setColumnWidth(MODTBL_COL_FUNCNO, 120);
    ui->tblwidModuleStatus->setColumnWidth(MODTBL_COL_STATUS, 60);
    ui->tblwidModuleStatus->setColumnWidth(MODTBL_COL_RESET, 40);
    ui->tblwidModuleStatus->setColumnWidth(MODTBL_COL_CLOSE, 40);
    ui->tblwidModuleStatus->removeRow(MODTBL_ROW_XMC_5775);
    ui->tblwidModuleStatus->removeRow(MODTBL_ROW_PCI_755);

    m_ucModInitSts = false;

#ifndef _HIDE_PCI_
    /* DP-PCI-755 Status */
    ui->tblwidModuleStatus->insertRow(ucIndex);
    ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_BRDNAME, new QTableWidgetItem(PCI_BRD_NAME));

    if(g_SGlobal.m_DPPCI755Details.m_s8BoardSts)
    {
        pCenteredItem->setData (Qt::DisplayRole, g_SGlobal.m_DPPCI755Details.m_u8BusNo);
        pCenteredItem->setIcon(QIcon());
        ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_BUSNO, pCenteredItem->clone());

        pCenteredItem->setData (Qt::DisplayRole, g_SGlobal.m_DPPCI755Details.m_u8SlotNo);
        pCenteredItem->setIcon(QIcon());
        ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_SLOTNO, pCenteredItem->clone());

        pCenteredItem->setData (Qt::DisplayRole, g_SGlobal.m_DPPCI755Details.m_u8FunctionNo);
        pCenteredItem->setIcon(QIcon());
        ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_FUNCNO, pCenteredItem->clone());

        pbPCI_Reset->setEnabled(true);
        ui->tblwidModuleStatus->setCellWidget(ucIndex, MODTBL_COL_RESET, (QWidget *)pbPCI_Reset);
        pbPCI_Close->setEnabled(true);
        ui->tblwidModuleStatus->setCellWidget(ucIndex, MODTBL_COL_CLOSE, (QWidget *)pbPCI_Close);
    }
    else
    {
        pCenteredItem->setText ("NA");
        pCenteredItem->setIcon(QIcon());
        ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_BUSNO, pCenteredItem->clone());

        pCenteredItem->setText ("NA");
        pCenteredItem->setIcon(QIcon());
        ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_SLOTNO, pCenteredItem->clone());

        pCenteredItem->setText ("NA");
        pCenteredItem->setIcon(QIcon());
        ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_FUNCNO, pCenteredItem->clone());

        pbPCI_Reset->setEnabled(false);
        ui->tblwidModuleStatus->setCellWidget(ucIndex, MODTBL_COL_RESET, (QWidget *)pbPCI_Reset);
        pbPCI_Close->setEnabled(true);
        pbPCI_Close->setIcon(QIcon(":/images/images/img_open.png"));
        pbPCI_Close->setToolTip("Open FRA Board");
        ui->tblwidModuleStatus->setCellWidget(ucIndex, MODTBL_COL_CLOSE, (QWidget *)pbPCI_Close);
    }

    QLabel *lbl = new QLabel();
    lbl->setPixmap(g_SGlobal.m_DPPCI755Details.m_s8BoardSts ? QPixmap(ICON_SUCCESS).scaled(QSize(24, 24), Qt::KeepAspectRatio, Qt::SmoothTransformation) : QPixmap(ICON_FAILURE).scaled(QSize(24, 24), Qt::KeepAspectRatio, Qt::SmoothTransformation));
    lbl->setStyleSheet ("background-color: transparent;");
    lbl->setAlignment(Qt::AlignHCenter | Qt::AlignVCenter | Qt::AlignCenter);
    ui->tblwidModuleStatus->setCellWidget (ucIndex, MODTBL_COL_STATUS, lbl);
    ucIndex++;
#endif

    /* DP-XMC-5775 Status */
    ui->tblwidModuleStatus->insertRow(ucIndex);
    ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_BRDNAME, new QTableWidgetItem(XMC_BRD_NAME));

    if(g_SGlobal.m_DPXMC5775Details.m_s8BoardSts)
    {
        pCenteredItem->setData (Qt::DisplayRole, g_SGlobal.m_DPXMC5775Details.m_u8BusNo);
        pCenteredItem->setIcon(QIcon());
        ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_BUSNO, pCenteredItem->clone());

        pCenteredItem->setData (Qt::DisplayRole, g_SGlobal.m_DPXMC5775Details.m_u8SlotNo);
        pCenteredItem->setIcon(QIcon());
        ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_SLOTNO, pCenteredItem->clone());

        pCenteredItem->setData (Qt::DisplayRole, g_SGlobal.m_DPXMC5775Details.m_u8FunctionNo);
        pCenteredItem->setIcon(QIcon());
        ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_FUNCNO, pCenteredItem->clone());

        pbXMC_Reset->setEnabled(true);
        ui->tblwidModuleStatus->setCellWidget(ucIndex, MODTBL_COL_RESET, (QWidget *)pbXMC_Reset);
        pbXMC_Close->setEnabled(true);
        ui->tblwidModuleStatus->setCellWidget(ucIndex, MODTBL_COL_CLOSE, (QWidget *)pbXMC_Close);
    }
    else
    {
        pCenteredItem->setText ("NA");
        pCenteredItem->setIcon(QIcon());
        ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_BUSNO, pCenteredItem->clone());

        pCenteredItem->setText ("NA");
        pCenteredItem->setIcon(QIcon());
        ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_SLOTNO, pCenteredItem->clone());

        pCenteredItem->setText ("NA");
        pCenteredItem->setIcon(QIcon());
        ui->tblwidModuleStatus->setItem(ucIndex, MODTBL_COL_FUNCNO, pCenteredItem->clone());

        pbXMC_Reset->setEnabled(false);
        ui->tblwidModuleStatus->setCellWidget(ucIndex, MODTBL_COL_RESET, (QWidget *)pbXMC_Reset);
        pbXMC_Close->setEnabled(true);
        pbXMC_Close->setIcon(QIcon(":/images/images/img_open.png"));
        pbXMC_Close->setToolTip("Open XMC Board");
        ui->tblwidModuleStatus->setCellWidget(ucIndex, MODTBL_COL_CLOSE, (QWidget *)pbXMC_Close);
    }

    QLabel *lbl_2 = new QLabel();
    lbl_2->setPixmap(g_SGlobal.m_DPXMC5775Details.m_s8BoardSts ? QPixmap(ICON_SUCCESS).scaled(QSize(24, 24), Qt::KeepAspectRatio, Qt::SmoothTransformation) : QPixmap(ICON_FAILURE).scaled(QSize(24, 24), Qt::KeepAspectRatio, Qt::SmoothTransformation));
    lbl_2->setStyleSheet ("background-color: transparent;");
    lbl_2->setAlignment(Qt::AlignHCenter | Qt::AlignVCenter | Qt::AlignCenter);
    ui->tblwidModuleStatus->setCellWidget (ucIndex, MODTBL_COL_STATUS, lbl_2);

    if (m_bIsFirstInitialization)
    {
#ifndef _HIDE_PCI_
        if (g_SGlobal.m_DPPCI755Details.m_s8BoardSts && g_SGlobal.m_DPXMC5775Details.m_s8BoardSts)
#else
        if (g_SGlobal.m_DPXMC5775Details.m_s8BoardSts)
#endif
        {
            emit sig_updateActionLog("Module Initialization Success", LOG_SUCCESS);
            emit sig_setEnDisMenuBar (true);
            m_ucModInitSts = true;
            m_bIsFirstInitialization = false;
            ui->pbModDetProceed->setText("&Proceed");
        }
        else
        {
            emit sig_updateActionLog("Module Initialization Failed", LOG_ERROR);
            emit sig_setEnDisMenuBar (false);
            m_ucModInitSts = false;
            ui->pbModDetProceed->setText("&Retry");
        }
    }

    /* Sorting based on Bus No. */
#ifndef _HIDE_PCI_
    if (g_SGlobal.m_DPPCI755Details.m_s8BoardSts && g_SGlobal.m_DPXMC5775Details.m_s8BoardSts)
#else
    if (g_SGlobal.m_DPXMC5775Details.m_s8BoardSts)
#endif
    {
        ui->tblwidModuleStatus->sortByColumn (MODTBL_COL_BUSNO, Qt::AscendingOrder);
    }
    else
    {
        // Do nothing
    }
}

/*******************************************************************************
 * Name					: detectModules
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To detect the modules connected
 ***************************************************************************//**
 * @brief	This function is used to detect and read status of the modules
 *			connected to the system
 *
 * @param		NIL
 *
 * @return	DPSCM_SUCCESS	if modules detected successfully
 *			DPSCM_FAILURE	if any error occurred
 ******************************************************************************/
void CModInitStatus::initModules()
{
    S32BIT s32Retval = DPSCM_SUCCESS;
    char szErrMsg[200] = { 0 };
    QString qstrMsg = QString("");
#ifndef _HIDE_PCI_
    if (g_SGlobal.m_DPPCI755Details.m_s8BoardSts != true)
    {
        memset(&g_SGlobal.m_DPPCI755Details, 0, sizeof(g_SGlobal.m_DPPCI755Details));
        s32Retval = g_SGlobal.g_objPCI755.DPPCI755Wrap_Initialize(PCI_BRD_IDX, NULL, &g_SGlobal.m_DPPCI755Details);
        if (s32Retval != DPSCM_SUCCESS)
        {
            g_SGlobal.m_DPPCI755Details.m_s8BoardSts = false;
            g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32Retval, szErrMsg);
            qstrMsg.sprintf("Error detecting PCI Board : %s [ErrCode: %d]", szErrMsg, s32Retval);
            emit sig_updateActionLog(qstrMsg, LOG_ERROR);
        }
        else
        {
            g_SGlobal.m_DPPCI755Details.m_s8BoardSts = true;
        }
    }
    else
    {
        // Do nothing
    }
#endif
    if (g_SGlobal.m_DPXMC5775Details.m_s8BoardSts != true)
    {
        memset(&g_SGlobal.m_DPXMC5775Details, 0, sizeof(g_SGlobal.m_DPXMC5775Details));
        s32Retval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_Initialize(XMC_BRD_IDX, NULL, &g_SGlobal.m_DPXMC5775Details);
        if (s32Retval != DPSCM_SUCCESS)
        {
            g_SGlobal.m_DPXMC5775Details.m_s8BoardSts = false;
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError(&s32Retval, szErrMsg);
            qstrMsg.sprintf("Error detecting XMC Board : %s [ErrCode: %d]", szErrMsg, s32Retval);
            emit sig_updateActionLog(qstrMsg, LOG_ERROR);
        }
        else
        {
            g_SGlobal.m_DPXMC5775Details.m_s8BoardSts = true;
        }
    }
    else
    {
        // Do nothing
    }
}

/*******************************************************************************
 * Name					: on_pbModDetProceed_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To change page or retry detection
 ***************************************************************************//**
 * @brief	This function is used to change the page to Communication configuration
 *			or retry module detection based on the detection pass/fail status
 *			+ if Module Detection passed - Proceed button is display to change next page
 *			+ if Modules Detection failed - Retry button is displayed to retry
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CModInitStatus::on_pbModDetProceed_clicked()
{
    if (m_ucModInitSts)
    {
        emit sig_changePage(PAGE_CONFIG_RS422);
    }
    else
    {
        initModules();
        updateModulesTable();
    }
}

void CModInitStatus::slot_PCI_Close_Clicked()
{
    S32BIT s32RetVal;
    char szErrMsg[100] = { DPSCM_INIT_0 };
    QString qstrTemp = QString("");

    CHECK_TC_RUNNING;

    if (g_SGlobal.m_DPPCI755Details.m_s8BoardSts)
    {
        s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_Close(PCI_BRD_IDX);
        if((s32RetVal != DPPCI755_SUCCESS))
        {
            g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);
            qstrTemp.sprintf("Error Closing DP-PCI-755 : %s [ErrCode: %d]", szErrMsg, s32RetVal);
            DISPLAY_MESSAGE_BOX(this, "DP-PCI-755 Close", qstrTemp);
        }
        else
        {
            qstrTemp.sprintf("DP-PCI-755 Closed");
            g_SGlobal.m_DPPCI755Details.m_s8BoardSts = false;
            DISPLAY_MESSAGE_BOX(this, "DP-PCI-755 Close", qstrTemp);
        }
    }
    else
    {
        s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_Initialize(PCI_BRD_IDX, NULL, &g_SGlobal.m_DPPCI755Details);
        if((s32RetVal != DPPCI755_SUCCESS))
        {
            g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);
            qstrTemp.sprintf("Error Opening DP-PCI-755 : %s [ErrCode: %d]", szErrMsg, s32RetVal);
            DISPLAY_MESSAGE_BOX(this, "DP-PCI-755 Open", qstrTemp);
        }
        else
        {
            qstrTemp.sprintf("DP-PCI-755 Opened");
            g_SGlobal.m_DPPCI755Details.m_s8BoardSts = true;
            DISPLAY_MESSAGE_BOX(this, "DP-PCI-755 Opened", qstrTemp);
        }
    }

    updateModulesTable();
}

void CModInitStatus::slot_XMC_Close_Clicked()
{
    S32BIT s32RetVal;
    char szErrMsg[100] = { DPSCM_INIT_0 };
    QString qstrTemp = QString("");

    CHECK_TC_RUNNING;

    if (g_SGlobal.m_DPXMC5775Details.m_s8BoardSts)
    {
        s32RetVal = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_Close(XMC_BRD_IDX);
        if (s32RetVal != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError(&s32RetVal, szErrMsg);
            qstrTemp.sprintf("Error Closing DP-XMC-5775 : %s [ErrCode: %d]", szErrMsg, s32RetVal);
            DISPLAY_MESSAGE_BOX(this, "DP-XMC-5775 Close", qstrTemp);
        }
        else
        {
            qstrTemp.sprintf("DP-XMC-5775 Closed");
            g_SGlobal.m_DPXMC5775Details.m_s8BoardSts = false;
            DISPLAY_MESSAGE_BOX(this, "DP-XMC-5775 Close", qstrTemp);
        }
    }
    else
    {
        s32RetVal = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_Initialize(XMC_BRD_IDX, NULL, &g_SGlobal.m_DPXMC5775Details);
        if (s32RetVal != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError(&s32RetVal, szErrMsg);
            qstrTemp.sprintf("Error Opening DP-XMC-5775 : %s [ErrCode: %d]", szErrMsg, s32RetVal);
            DISPLAY_MESSAGE_BOX(this, "DP-XMC-5775 Open", qstrTemp);
        }
        else
        {
            qstrTemp.sprintf("DP-XMC-5775 Opened");
            g_SGlobal.m_DPXMC5775Details.m_s8BoardSts = true;
            DISPLAY_MESSAGE_BOX(this, "DP-XMC-5775 Open", qstrTemp);
        }
    }

    updateModulesTable();
}

void CModInitStatus::slot_PCI_Reset_Clicked()
{
    S32BIT s32RetVal;
    char szErrMsg[100] = { DPSCM_INIT_0 };
    QString qstrTemp = QString("");

    CHECK_TC_RUNNING;

    s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_Reset(PCI_BRD_IDX);
    if((s32RetVal != DPPCI755_SUCCESS))
    {
        g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);
        qstrTemp.sprintf("Error Resetting DP-PCI-755 : %s [ErrCode: %d]", szErrMsg, s32RetVal);
        DISPLAY_MESSAGE_BOX(this, "DP-PCI-755 Reset", szErrMsg);
    }
    else
    {
        qstrTemp.sprintf("DP-PCI-755 Reset Successful");
        DISPLAY_MESSAGE_BOX(this, "DP-PCI-755 Reset", qstrTemp);
    }

    updateModulesTable();
}

void CModInitStatus::slot_XMC_Reset_Clicked()
{
    S32BIT s32RetVal;
    char szErrMsg[100] = { DPSCM_INIT_0 };
    QString qstrTemp = QString("");

    CHECK_TC_RUNNING;

    s32RetVal = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_Reset(XMC_BRD_IDX);
    if (s32RetVal != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError(&s32RetVal, szErrMsg);
        qstrTemp.sprintf("Error Resetting DP-XMC-5775 : %s [ErrCode: %d]", szErrMsg, s32RetVal);
        DISPLAY_MESSAGE_BOX(this, "XMC Reset", qstrTemp);
    }
    else
    {
        qstrTemp.sprintf("DP-XMC-5775 Reset Successful");
        DISPLAY_MESSAGE_BOX(this, "DP-XMC-5775 Reset", qstrTemp);
    }

    updateModulesTable();
}
