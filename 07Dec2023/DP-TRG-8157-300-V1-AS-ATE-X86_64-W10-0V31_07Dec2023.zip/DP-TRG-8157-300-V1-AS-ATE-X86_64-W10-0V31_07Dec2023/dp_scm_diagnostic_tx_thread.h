/**
* \file dp-scm-diagnostics_tx_thread.h
* \brief This is the header file for dp-scm-diagnostics_tx_thread.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef DP_SCM_DIAGNOSTIC_TX_THREAD_H
#define DP_SCM_DIAGNOSTIC_TX_THREAD_H


#ifndef CDIAGNOSTICRX_H
#define CDIAGNOSTICRX_H

#include <QThread>
#include <QDebug>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "dprs232_wrapper.h"
#include "includes/dp_qt_msgqueue.h

class dp_scm_diagnostic_tx_thread : public QObject
{
    Q_OBJECT
public:
    explicit dp_scm_diagnostic_tx_thread(QObject *parent = 0);
    CDiagnosticRx(QObject *parent = 0, int in_iTimeout = 0);

    bool m_bRespRxSts;
    int m_iTimeout;

    PSSCM_RTGA_RESP_PKT m_pSRespRxData;

    void setTimeout(int in_iTimeout);
    void Start();
    void Stop();
    void run();

signals:

public slots:
};

#endif // DP_SCM_DIAGNOSTIC_TX_THREAD_H
