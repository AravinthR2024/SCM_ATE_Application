#ifndef DPSCMARRAY_IDENT_H
#define DPSCMARRAY_IDENT_H

#include <QObject>
#include <QWidget>
#include <QDebug>
#include <QThread>
#include <QTimer>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"

#define ARRIDENT_MODE_AZ_IDENT  0
#define ARRIDENT_MODE_EL_IDENT 1

namespace Ui {
class CArrayIdentVerification;
}

class CArrayIdentThread : public QThread
{
    Q_OBJECT

public:
    CArrayIdentThread(QObject *parent = 0, unsigned char in_ucSystem = 0);

    bool m_bIsRunning;
    unsigned char m_ucSystem;
    U_DEM_PORT_RX m_UResponse;
    U_DEM_PORT_TX m_UCommand;

    void setSystem(unsigned char in_ucSystem);
    void setTxCommand (U_DEM_PORT_TX in_UCommand);
    void setRxCommand (U_DEM_PORT_RX in_UResponse);
    void Start();
    void Stop();
    void run() override;

signals:
    void sig_updateActionLog(QString, int);
    void sig_updateRGAResponse (U_DEM_PORT_RX in_UResponse);
    void sig_updateRTGAResponse (U_DEM_PORT_TX in_UResponse);
    void sig_updateRTGAResponse_Display (U_DEM_PORT_RX in_UResponse);
    void sig_updateRTGACommand_Display (U_DEM_PORT_TX in_UCommand);
    void sig_updateButtonName (QString);
};

class CArrayIdentVerification : public QWidget
{
    Q_OBJECT

public:
    explicit CArrayIdentVerification(QWidget *parent = 0);
    ~CArrayIdentVerification();

    U_DEM_PORT_RX m_UResponse[2];
    U_DEM_PORT_TX m_UCommand[2];
    CArrayIdentThread *m_pthArrayIdent_RGA;
    bool m_bIsThread;
    QTimer m_qTimerRGA;
    QTimer m_qTimerRTGA;

    void setRGAResponse(S_RGA_RESPONSE in_SRGAResponse);
    void setRTGAResponse(S_RTGA_RESPONSE in_SRTGAResponse);
    void RGA_WR_RD(U_DEM_PORT_TX in_UCommand);
    void RTGA_WR_RD(U_DEM_PORT_TX in_UCommand);
    void RTGA_AZ_Simulation();
public slots:
    void slot_updateRGAResponse (U_DEM_PORT_RX in_UResponse);

    void slot_updateRTGAResponse(U_DEM_PORT_TX in_UResponse);

    void slot_updateRTGAResponse_Display (U_DEM_PORT_RX in_UResponse);

    void slot_updateButtonName (QString in_qstrName);

private slots:
    void on_pbStart1_clicked();

    void on_cmbRGACmd_Mode_currentIndexChanged(int index);

    void on_pbStart2_clicked();

    void on_pbSend3_clicked();

    void on_pbSend4_clicked();

    void on_rbRGA_toggled(bool checked);

signals:
    void sig_updateActionLog(QString, int);

private:
    Ui::CArrayIdentVerification *ui;
};

#endif // DPSCMARRAY_IDENT_H
