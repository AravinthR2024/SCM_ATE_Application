    /**
* \file dp-scm-command_tx_thread.h
* \brief This is the header file for dp-scm-command_tx_thread.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef CCOMMANDTX_H
#define CCOMMANDTX_H

#include <QThread>
#include <QDebug>
#include <QElapsedTimer>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "dprs232_wrapper.h"
#include "includes/dp_qt_msgqueue.h"

class CCommandTx : public QThread
{
		Q_OBJECT

	public:
		CCommandTx(QObject *parent = 0);

        bool m_bCmdTxRunning;
		volatile U8BIT m_u8DiagID;
		PSSCM_RTGA_CMD_PKT m_pSCmdTxData;
        U8BIT m_u8PortNo;


		void Start();
		void Stop();
		void updateCmdTxPkt(PSSCM_RTGA_CMD_PKT in_pSCmdTxData);
		void run();

signals:
        void sig_updateActionLog(QString, int);
};

#endif // CCOMMANDTX_H
