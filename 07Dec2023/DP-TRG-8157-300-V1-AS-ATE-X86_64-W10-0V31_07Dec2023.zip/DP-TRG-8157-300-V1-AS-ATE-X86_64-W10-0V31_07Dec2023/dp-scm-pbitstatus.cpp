/**
* \file dp-scm-pbitstatus.cpp
* \brief This file contains the code for PBIT Status panel
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-pbitstatus.h"
#include "ui_dp-scm-pbitstatus.h"
#include "dp-scm-mainwindow.h"

extern S_GLOBAL g_SGlobal;

/*******************************************************************************
 * Name					: CPBITStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CPBITStatus class
 *
 * @param[in]	parent	Holds the reference to the parent
 *
 * @return	NA
 ******************************************************************************/
CPBITStatus::CPBITStatus(QWidget *parent) :
	QWidget(parent),
	ui(new Ui::CPBITStatus)
{
	ui->setupUi(this);

    memset (&m_SPBITStatusDisplay, 0, sizeof(S_PBIT_DISPLAY));

	slot_resetPBITStatus();
}

/*******************************************************************************
 * Name					: ~CPBITStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief	This function is the destructor of CPBITStatus class
 *
 * @param		NIL
 * @return	NA
 ******************************************************************************/
CPBITStatus::~CPBITStatus()
{
	delete ui;
}

/*******************************************************************************
 * Name					: setLEDStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set the status of LED
 ***************************************************************************//**
 * @brief	This function is used to set the LED Status colour
 *
 * @param[in]	in_pLabel	Holds the reference to the label
 * @param[in]	in_u8Sts	Specifies the BIT Status
 *					BIT_SUCCESS	-	Green LED
 *					BIT_FAIL		-	Red LED
 *					BIT_RESET		-	Gray LED
 *
 * @return	NIL
 ******************************************************************************/
void CPBITStatus::setLEDStatus(QLabel *in_pLabel, U8BIT in_u8Sts)
{
	if (in_u8Sts == BIT_SUCCESS)
	{
		in_pLabel->setPixmap(QPixmap(LED_GREEN));
	}
	else if (in_u8Sts == BIT_FAIL)
	{
		in_pLabel->setPixmap(QPixmap(LED_RED));
	}
	else
	{
		in_pLabel->setPixmap(QPixmap(LED_GRAY));
	}
}

/*******************************************************************************
 * Name					: on_pbCheck_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To change to the next page
 ***************************************************************************//**
 * @brief	This function is used to change display to Servo Control Operations page
 *		This function is called when Proceed button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CPBITStatus::on_pbCheck_clicked()
{
    int iRetVal = DPSCM_INIT_0;
    unsigned char ucDiagDataValue = DPSCM_INIT_0;

    CHECK_TC_RUNNING;

    CHECK_PORT_OPEN(DIAGNOSTIC_PORT_IDX);

    if (g_SGlobal.m_ucConfiguredMode != DIAGNOSTICS_MODE)
    {
        DISPLAY_MESSAGE_BOX (this, "Mode Configuration", "Please switch to Diagnostics Mode to Monitor PBIT Status.");
        return;
    }

    iRetVal = sendCommand(ID_11);
    ucDiagDataValue = m_URxResponse.m_S_DiagResp.m_ucByte3_Bit6_0;
    if (iRetVal == DPSCM_SUCCESS)
    {
        if (g_SGlobal.m_ucSystem == SYSTEM_RGA_RTGA_AZ)
        {
            CHECK_PBIT(m_SPBITStatusDisplay.m_ePrgmMemCRC, ((ucDiagDataValue & 0x08) >> 3));
            CHECK_PBIT(m_SPBITStatusDisplay.m_eEEPROMCRC, ((ucDiagDataValue & 0x10) >> 4));
            CHECK_PBIT(m_SPBITStatusDisplay.m_eFPGA_RW_Test, ((ucDiagDataValue & 0x20) >> 5));
        }
        else
        {
            CHECK_PBIT(m_SPBITStatusDisplay.m_ePrgmMemCRC, ((ucDiagDataValue & 0x01) >> 0));
            CHECK_PBIT(m_SPBITStatusDisplay.m_eEEPROMCRC, ((ucDiagDataValue & 0x02) >> 1));
            CHECK_PBIT(m_SPBITStatusDisplay.m_eFPGA_RW_Test, ((ucDiagDataValue & 0x04) >> 2));
        }
    }
    else
    {
        m_SPBITStatusDisplay.m_ePrgmMemCRC = BIT_RESET;
        m_SPBITStatusDisplay.m_eEEPROMCRC = BIT_RESET;
        m_SPBITStatusDisplay.m_eFPGA_RW_Test = BIT_RESET;
    }

    iRetVal = sendCommand(ID_13);
    ucDiagDataValue = m_URxResponse.m_S_DiagResp.m_ucByte3_Bit6_0;
    if (iRetVal == DPSCM_SUCCESS)
    {
        CHECK_PBIT(m_SPBITStatusDisplay.m_eHallStatus, ((ucDiagDataValue & 0x01) >> 0));
    }
    else
    {
        m_SPBITStatusDisplay.m_eHallStatus = BIT_RESET;
    }

    if (g_SGlobal.m_ucSystem == SYSTEM_RGA_RTGA_AZ)
    {
        iRetVal = sendCommand(ID_09);
    }
    else if (g_SGlobal.m_ucSystem == SYSTEM_RTGA_EL)
    {
        iRetVal = sendCommand(ID_08);
    }
    ucDiagDataValue = m_URxResponse.m_S_DiagResp.m_ucByte3_Bit6_0;
    if (iRetVal == DPSCM_SUCCESS)
    {
        CHECK_PBIT(m_SPBITStatusDisplay.m_eVoltMonitoring, ((ucDiagDataValue & 0x01) >> 0));
    }
    else
    {
        m_SPBITStatusDisplay.m_eVoltMonitoring = BIT_RESET;
    }

    iRetVal = sendCommand(ID_12);
    ucDiagDataValue = m_URxResponse.m_S_DiagResp.m_ucByte3_Bit6_0;
    if (iRetVal == DPSCM_SUCCESS)
    {
        CHECK_PBIT(m_SPBITStatusDisplay.m_eTempMonitoring, ((ucDiagDataValue & 0x01) >> 0));
    }
    else
    {
        m_SPBITStatusDisplay.m_eTempMonitoring = BIT_RESET;
    }

    iRetVal = sendCommand(ID_38);
    ucDiagDataValue = m_URxResponse.m_S_DiagResp.m_ucByte3_Bit6_0;
    if (iRetVal == DPSCM_SUCCESS)
    {
        CHECK_PBIT(m_SPBITStatusDisplay.m_eCurrMonitoring, ((ucDiagDataValue & 0x08) >> 3));
    }
    else
    {
        m_SPBITStatusDisplay.m_eCurrMonitoring = BIT_RESET;
    }

    slot_updatePBITStatus();
}

/*******************************************************************************
 * Name					: slot_resetPBITStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To reset PBIT Status
 ***************************************************************************//**
 * @brief	This function is used to reset the status of PBIT
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CPBITStatus::slot_resetPBITStatus()
{
    resetLEDinGB(ui->gbPBITStatus);
}

/*******************************************************************************
 * Name					:
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				:
 ***************************************************************************//**
 * @brief	This function is used to reset all LED in the Groupbox
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CPBITStatus::resetLEDinGB(QGroupBox *in_pgbGroupbox)
{
	QLabel *pLabel = NULL;

	foreach(QObject *pObj, in_pgbGroupbox->children())
	{
		if (pObj->objectName().startsWith("lbPBIT"))
		{
			pLabel = (QLabel *)pObj;
			setLEDStatus(pLabel, BIT_RESET);
		}
		if (pObj->objectName().startsWith("gb"))
		{
			resetLEDinGB((QGroupBox *)pObj);
		}
    }
}

int CPBITStatus::sendCommand(unsigned char in_ucCmdID)
{
    int iRetVal = DPSCM_INIT_0;
    unsigned int uiBytesRead = DPSCM_INIT_0;
    unsigned char ucChecksum = DPSCM_INIT_0;
    QString qstrErrMsg = QString();
    QString qstrTemp = QString();

    memset (&m_UTxCommand, 0, sizeof(U_DEM_PORT_TX));
    memset (&m_URxResponse, 0, sizeof(U_DEM_PORT_RX));

    if (g_SGlobal.m_ucConfiguredMode == DIAGNOSTICS_MODE)
    {
        m_UTxCommand.m_S_DiagCmd.m_ucByte0_Bit6_0 = 0;
        m_UTxCommand.m_S_DiagCmd.m_ucByte0_Bit7 = 1;

        m_UTxCommand.m_S_DiagCmd.m_ucByte1_CmdID = CMDID_DIAGMON_READ & 0x1F;
        m_UTxCommand.m_S_DiagCmd.m_ucByte1_TestInit = 0;
        m_UTxCommand.m_S_DiagCmd.m_ucByte1_Bit7 = 0;

        m_UTxCommand.m_S_DiagCmd.m_ucByte2_Bit6_0 = in_ucCmdID & 0x7F;

        dp_scm_7bit_xor_checksum((unsigned char *)&m_UTxCommand.m_S_DiagCmd, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);

        m_UTxCommand.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;

        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *)m_UTxCommand.m_arrucData, sizeof(S_DIAG_CMDRESP));
        if (iRetVal != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Error Send Command : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_ERROR);
            return iRetVal;
        }

        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_DIAG_CMDRESP), (char *) &m_URxResponse.m_S_DiagResp, &uiBytesRead, 2);
        if (iRetVal != DPSCM_INIT_0)
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Error Receiving Response : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_ERROR);
            return iRetVal;
        }
    }
    else if (g_SGlobal.m_ucConfiguredMode == SERVO_MODE)
    {
        m_UTxCommand.m_S_RGACmd.m_ucByte0_MsgLength = sizeof(S_RGA_COMMAND) & 0x7F;
        m_UTxCommand.m_S_RGACmd.m_ucByte0_Bit7 = 1;

        m_UTxCommand.m_S_RGACmd.m_ucByte5_DiagnosticsID = in_ucCmdID & 0x7F;

        dp_scm_crc6_checksum((unsigned char *)&m_UTxCommand.m_S_RGACmd, (sizeof(S_RGA_COMMAND) - 1), &ucChecksum);
        m_UTxCommand.m_S_RGACmd.m_ucByte6_Crc6_CS = ucChecksum & 0x3F;

        iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_WriteData((char *) m_UTxCommand.m_arrucData, sizeof(S_RGA_COMMAND));
        if (iRetVal != DPSCM_SUCCESS)
        {
            emit sig_updateActionLog("Command Send Failed", LOG_ERROR);
            return DPSCM_FAILURE;
        }
        else
        {
            // Do nothing
        }

        iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_RGA_RESPONSE), (char *) &m_URxResponse.m_S_RGAResp, &uiBytesRead, 2);
        if (iRetVal != DPSCM_SUCCESS)
        {
            emit sig_updateActionLog("Response Receive Failed : Bytes Read = " + QString::number(uiBytesRead), LOG_ERROR);
            return DPSCM_FAILURE;
        }
        else
        {
            // Do nothing
        }
    }
    else
    {
        // Do nothing
    }

    return DPSCM_SUCCESS;
}

/*******************************************************************************
 * Name					: slot_updatePBITStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To update the PBIT Status
 ***************************************************************************//**
 * @brief	This function is used to update and display the PBIT Status
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CPBITStatus::slot_updatePBITStatus()
{
    setLEDStatus(ui->lbLED_ProgramMemCRCStatus, m_SPBITStatusDisplay.m_ePrgmMemCRC);
    setLEDStatus(ui->lbLED_EEPROMCRCStatus, m_SPBITStatusDisplay.m_eEEPROMCRC);
    setLEDStatus(ui->lbLED_FPGARWStatus, m_SPBITStatusDisplay.m_eFPGA_RW_Test);
    setLEDStatus(ui->lbLED_HallStatus, m_SPBITStatusDisplay.m_eHallStatus);
    setLEDStatus(ui->lbLED_VoltageMonitoring, m_SPBITStatusDisplay.m_eVoltMonitoring);
    setLEDStatus(ui->lbLED_CurrMonitoringTest, m_SPBITStatusDisplay.m_eCurrMonitoring);
    setLEDStatus(ui->lbLED_TempMonitoringTest, m_SPBITStatusDisplay.m_eTempMonitoring);

    emit sig_updateActionLog("PBIT Status Read", LOG_SUCCESS);
}
