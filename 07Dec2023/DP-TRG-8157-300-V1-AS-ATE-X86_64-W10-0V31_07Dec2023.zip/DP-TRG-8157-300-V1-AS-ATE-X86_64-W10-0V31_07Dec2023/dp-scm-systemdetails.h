/**
* \file dp-scm-systemdetails.h
* \brief This is the header file for dp-scm-systemdetails.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef SYSTEMDETAILS_H
#define SYSTEMDETAILS_H

#include <QWidget>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "checksum.h"

#include "dppci755_wrapper.h"

namespace Ui {
class CSystemDetails;
}

class CSystemDetails : public QWidget
{
    Q_OBJECT

public:
    explicit CSystemDetails(QWidget *parent = 0);
    ~CSystemDetails();

    void displaySystemDetails();
    void fetchSystemDetails();

private:
    Ui::CSystemDetails *ui;

    S_SCM_SYSTEM_DETAILS m_SSystemDetails;

signals:
    void sig_updateActionLog(QString, int);
    void sig_changePage(int);

private slots:
    void on_pbFetch_clicked();
};

#endif // SYSTEMDETAILS_H
