/**
* \file dp-scm-control_loop_config.h
* \brief This is the header file for dp-scm-control_loop_config.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef CONTROL_LOOP_CONFIG_H
#define CONTROL_LOOP_CONFIG_H

#include <QDebug>
#include <QWidget>
#include <QThread>
#include <QFileDialog>
#include <QDebug>
#include <QFile>
#include <QCheckBox>
#include <QDoubleSpinBox>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "checksum.h"

#define CLCTHREAD_MODE_INVALID  -1
#define CLCTHREAD_MODE_WRITE    0
#define CLCTHREAD_MODE_READ     1

namespace Ui {
	class CControlLoopConfig;
}

class CControlLoopConfigThread : public QThread
{
    Q_OBJECT

public:
    explicit CControlLoopConfigThread(QObject *parent = 0);

    bool m_bIsRunning;
    char m_cRunningMode;
    QList<QCheckBox *> m_liCheckbox;
    QList<QDoubleSpinBox *> m_liDSB;

    void Delay(unsigned long in_ulTime_usec);

    void Start();
    void Stop();
    void setOperation(char in_cMode);
    void run() override;
    void writeEEPROM();
    void readEEPROM();

signals:
    void sig_updateActionLog(QString, int);
    void sig_threadCompleted();
};

class CControlLoopConfig : public QWidget
{
		Q_OBJECT

	public:
		explicit CControlLoopConfig(QWidget *parent = 0);
		~CControlLoopConfig();

    CControlLoopConfigThread *m_pthControlLoopConfig;
		S_CTRL_LOOP_CONFIG m_SCtrlLoopConfig;
        quint64 m_uiSelectedConstants;
		QList<QCheckBox *> m_liCheckbox;
        QList<QDoubleSpinBox *> m_liDSB;

		void setDefaultConfig();
		void getConfigValues();
		void setConfigValues();
		int readConfigFile(QString in_qstrFile);
		int writeConfigFile(QString in_qstrFile);

private:
		Ui::CControlLoopConfig *ui;
		void initializeConfig();

	public slots:
		void slot_getSelectedConstants();

        void slot_threadCompleted();

	signals:
		void sig_updateActionLog(QString, int);
		void sig_changePage(int);
        void sig_showLoadingScreen (bool);

	private slots:
		void on_pbReadEEPROM_clicked();
		void on_pbWriteEEPROM_clicked();
		void on_pbLoadFile_clicked();
		void on_pbSaveFile_clicked();
        void on_cbSelectAll_clicked();
};

#endif // CONTROL_LOOP_CONFIG_H
