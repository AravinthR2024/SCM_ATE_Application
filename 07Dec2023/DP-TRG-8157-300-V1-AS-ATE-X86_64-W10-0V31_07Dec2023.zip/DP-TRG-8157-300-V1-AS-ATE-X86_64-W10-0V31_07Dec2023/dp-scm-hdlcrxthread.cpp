#include "dp-scm-hdlcrxthread.h"

extern S_GLOBAL g_SGlobal;

CHDLCRxThread::CHDLCRxThread(QObject *parent) : QThread(parent)
{
    m_bIsRunning = false;
    m_usRepeatCount = DPSCM_INIT_0;
}

void CHDLCRxThread::Start()
{
    if (!isRunning())
    {
        m_bIsRunning = true;
        start(QThread::HighestPriority);
    }
}

void CHDLCRxThread::Stop()
{
    if(isRunning())
    {
        m_bIsRunning = false;

        msleep(100);

        if(!isFinished())
        {
            terminate();
        }
    }
}

void CHDLCRxThread::run()
{
    unsigned short usCurrentCount = DPSCM_INIT_0;
    unsigned int uiResponseData = DPSCM_INIT_0;
    unsigned int uiActualReadCnt = DPSCM_INIT_0;
    char szErrMsg[100] = { 0 };
    unsigned int uiWaitTime = 1;
    int iRetval = DPSCM_INIT_0;
    unsigned char ucErr = 1;
    QString qstrTemp = QString();

    usleep(50);
    while (m_bIsRunning)
    {
        iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_ReadData (XMC_BRD_IDX, &uiWaitTime, 1, &uiResponseData, &uiActualReadCnt);
        if ((iRetval != DPSCM_SUCCESS) || (uiActualReadCnt != 1))
        {
            ucErr++;
            if (ucErr == DP_SCM_ERRLOG_CNT)
            {
                ucErr = 1;
                g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
                qstrTemp.sprintf ("XMC Reception Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
                emit sig_updateActionLog (qstrTemp, LOG_ERROR);
            }

            continue;
        }

        iRetval = g_SGlobal.m_objHDLCDataMsgQ->Send((void *)&uiResponseData, sizeof(unsigned int));
        if (iRetval != DPSCM_SUCCESS)
        {
            g_SGlobal.m_pobjResponseMsgQ->GetErrorMsg(iRetval, szErrMsg, 100);
            qstrTemp.sprintf("Error sending response data into queue : %s [Err: %d]", szErrMsg, iRetval);
            emit sig_updateActionLog(qstrTemp, LOG_WARNING);
            continue;
        }

        usCurrentCount++;
        if (m_usRepeatCount != SEASPRAY_CONTINUOUS_TX)
        {
            if (usCurrentCount == m_usRepeatCount)
            {
                usCurrentCount = DPSCM_INIT_0;
                m_bIsRunning = false;
                break;
            }
        }
    }
}
