/**
* \file dp-scm-rs422configuration.cpp
* \brief This file contains the code for Serial Communication Configuration panel
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-rs422configuration.h"
#include "ui_dp-scm-rs422configuration.h"

#undef _TEMP_ // TEMP undef after port is connected

extern S_GLOBAL g_SGlobal;

/*******************************************************************************
 * Name					: CRS422Configuration
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ************************************************************~***************//**
 * @brief	This function is the constructor of CRS422Configuration class
 *
 * @param[in]	parent	Holds the reference to the parent
 *
 * @return	NA
 ******************************************************************************/
CRS422Configuration::CRS422Configuration(QWidget *parent) :
	QWidget(parent),
	ui(new Ui::CRS422Communication)
{
	ui->setupUi(this);
    m_bConfigured = false;

    ui->cmbCmd_PortNo->clear();
    ui->cmbDiag_PortNo->clear();

    ui->cmbCmd_PortNo->addItems(g_SGlobal.m_objRS232[COMMAND_PORT_IDX].m_qsAllComport);
    ui->cmbCmd_PortNo->setCurrentIndex(0);

    ui->cmbDiag_PortNo->addItems(g_SGlobal.m_objRS232[COMMAND_PORT_IDX].m_qsAllComport);
    ui->cmbDiag_PortNo->setCurrentIndex(1);

	m_lbComSts[COMMAND_PORT_IDX] = ui->lbSts_CmdPortComStatus;
    m_cmbPort[COMMAND_PORT_IDX] = ui->cmbCmd_PortNo;
    m_cmbBaudRate[COMMAND_PORT_IDX] = ui->cmbCmd_BaudRate;
    m_cmbDataBits[COMMAND_PORT_IDX] = ui->cmbCmd_DataBits;
    m_cmbStopBit[COMMAND_PORT_IDX] = ui->cmbCmd_StopBit;
    m_cmbParity[COMMAND_PORT_IDX] = ui->cmbCmd_Parity;
    m_cmbFlowCtrl[COMMAND_PORT_IDX] = ui->cmbCmd_Flowcontrol;

    m_lbComSts[DIAGNOSTIC_PORT_IDX] = ui->lbSts_DiagPortComStatus;
    m_cmbPort[DIAGNOSTIC_PORT_IDX] = ui->cmbDiag_PortNo;
    m_cmbBaudRate[DIAGNOSTIC_PORT_IDX] = ui->cmbDiag_BaudRate;
    m_cmbDataBits[DIAGNOSTIC_PORT_IDX] = ui->cmbDiag_DataBits;
    m_cmbStopBit[DIAGNOSTIC_PORT_IDX] = ui->cmbDiag_StopBit;
    m_cmbParity[DIAGNOSTIC_PORT_IDX] = ui->cmbDiag_Parity;
    m_cmbFlowCtrl[DIAGNOSTIC_PORT_IDX] = ui->cmbDiag_Flowcontrol;

    ui->gbCmdPortConfig->setTitle("Real Time Port");
    ui->gbDiagPortConfig->setTitle("Diagnostics Port");

	readCommSettingIni();
    ui->cmbSystemSel->setCurrentIndex(SYSTEM_SEASPRAY_HDLC);
    on_cmbSystemSel_currentIndexChanged(SYSTEM_SEASPRAY_HDLC);
}

/*******************************************************************************
 * Name					: ~CRS422Configuration
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief	This function is the destructor of CRS422Configuration class
 *
 * @param		NA
 * @return	NA
 ******************************************************************************/
CRS422Configuration::~CRS422Configuration()
{
	delete ui;
}

/*******************************************************************************
 * Name					: readCommSettingIni
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To read the defalt configuration
 ***************************************************************************//**
 * @brief	This function is used to read the default communication configuration
 *			from the INI file (ComConfigDetails.ini)
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CRS422Configuration::readCommSettingIni()
{
	unsigned char ucSystem = DPSCM_INIT_0;
	unsigned char ucPort = DPSCM_INIT_0;
	QSettings *psettingsComCfg = NULL;
	QFileInfo checkComCfgFile = QFileInfo();
	QString qstrTemp = QString();
	QStringList qstrliValues;

	QString qstrComDetails = qApp->applicationDirPath() + "/config/ComConfigDetails.ini";
	checkComCfgFile.setFile(qstrComDetails);
	if (checkComCfgFile.exists() && checkComCfgFile.isFile())
	{
		psettingsComCfg = new(QSettings)(qstrComDetails, QSettings::IniFormat);
	}

	for (ucSystem = DPSCM_INIT_0; ucSystem < NO_OF_SYSTEMS; ucSystem++)
	{
		for (ucPort = DPSCM_INIT_0; ucPort < NO_OF_PORTS; ucPort++)
		{
			// Do the retrival and storing
			qstrTemp.sprintf("System_%d/Port_%d", ucSystem, ucPort);
			qstrTemp = psettingsComCfg->value(qstrTemp).toString();
			qstrliValues = qstrTemp.split(",");
			m_SPortInfo[ucSystem][ucPort].m_qstrPortName = QString(qstrliValues.at(0));
			m_SPortInfo[ucSystem][ucPort].m_ulBaudRate = qstrliValues.at(1).toULong();
			m_SPortInfo[ucSystem][ucPort].m_ucDataBits = qstrliValues.at(2).toUInt();
			m_SPortInfo[ucSystem][ucPort].m_ucStopBits = qstrliValues.at(3).toUInt();
			qstrTemp = qstrliValues.at(4);
			if (qstrTemp.compare("Even", Qt::CaseInsensitive) == DPSCM_SUCCESS)
			{
				m_SPortInfo[ucSystem][ucPort].m_ucParity = QSerialPort::EvenParity;
			}
			else if (qstrTemp.compare("Odd", Qt::CaseInsensitive) == DPSCM_SUCCESS)
			{
				m_SPortInfo[ucSystem][ucPort].m_ucParity = QSerialPort::OddParity;
			}
			else
			{
				m_SPortInfo[ucSystem][ucPort].m_ucParity = QSerialPort::NoParity;
			}

			qstrTemp = qstrliValues.at(5);
			if (qstrTemp.compare("Hardware", Qt::CaseInsensitive) == DPSCM_SUCCESS)
			{
				m_SPortInfo[ucSystem][ucPort].m_ucFlowcontrol = QSerialPort::HardwareControl;
			}
			else if (qstrTemp.compare("Software", Qt::CaseInsensitive) == DPSCM_SUCCESS)
			{
				m_SPortInfo[ucSystem][ucPort].m_ucFlowcontrol = QSerialPort::SoftwareControl;
			}
			else
			{
				m_SPortInfo[ucSystem][ucPort].m_ucFlowcontrol = QSerialPort::NoFlowControl;
			}

			m_SPortInfo[ucSystem][ucPort].m_sPortStatus = DPSCM_FAILURE;
		}
	}
}

/*******************************************************************************
 * Name					: displayComStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To display the communication status
 ***************************************************************************//**
 * @brief	This function is used to display the communication details and
 *			communication establishment status
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CRS422Configuration::displayComStatus()
{
	unsigned char ucPort = DPSCM_INIT_0;
	unsigned char ucSystem = DPSCM_INIT_0;
	int iIdx = DPSCM_INIT_0;
	QString qstrTemp = QString();

	ucSystem = ui->cmbSystemSel->currentIndex();

	for (ucPort = COMMAND_PORT_IDX; ucPort < NO_OF_PORTS; ucPort++)
	{
		qstrTemp = m_SPortInfo[ucSystem][ucPort].m_qstrPortName;
		m_cmbPort[ucPort]->setCurrentText(qstrTemp);

		iIdx = (m_SPortInfo[ucSystem][ucPort].m_ulBaudRate == QSerialPort::Baud115200) ? 1 : ((m_SPortInfo[ucSystem][ucPort].m_ulBaudRate == Baud921600) ? 0 : 2);
		m_cmbBaudRate[ucPort]->setCurrentIndex(iIdx);

		switch(m_SPortInfo[ucSystem][ucPort].m_ucDataBits)
		{
			case QSerialPort::Data5: iIdx = 0; break;
			case QSerialPort::Data6: iIdx = 1; break;
			case QSerialPort::Data7: iIdx = 2; break;
			case QSerialPort::Data8: iIdx = 3; break;
			default: break;
		}

		m_cmbDataBits[ucPort]->setCurrentIndex(iIdx);

		switch(m_SPortInfo[ucSystem][ucPort].m_ucStopBits)
		{
			case QSerialPort::OneStop: iIdx = 0; break;
			case QSerialPort::OneAndHalfStop: iIdx = 1; break;
			case QSerialPort::TwoStop: iIdx = 2; break;
			default: break;
		}

		m_cmbStopBit[ucPort]->setCurrentIndex(iIdx);

		switch(m_SPortInfo[ucSystem][ucPort].m_ucParity)
		{
			case QSerialPort::NoParity: iIdx = 0; break;
			case QSerialPort::OddParity: iIdx = 1; break;
			case QSerialPort::EvenParity: iIdx = 2; break;
			default: break;
		}

		m_cmbParity[ucPort]->setCurrentIndex(iIdx);

		switch(m_SPortInfo[ucSystem][ucPort].m_ucFlowcontrol)
		{
			case QSerialPort::NoFlowControl: iIdx = 0; break;
			case QSerialPort::HardwareControl: iIdx = 1; break;
			case QSerialPort::SoftwareControl: iIdx = 2; break;
			default: break;
		}

		m_cmbFlowCtrl[ucPort]->setCurrentIndex(iIdx);

		if (m_SPortInfo[ucSystem][ucPort].m_sPortStatus == DPSCM_SUCCESS)
		{
			m_lbComSts[ucPort]->setPixmap(QPixmap(ICON_SUCCESS));
		}
		else
		{
			m_lbComSts[ucPort]->setPixmap(QPixmap(ICON_FAILURE));
		}
	}
}

void CRS422Configuration::closeAllPorts()
{
	int iRetval = DPSCM_INIT_0;
	QString qstrErrMsg = QString();
	QString qstrTemp = QString();

	iRetval = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_Close ();
	if (iRetval != DPSCM_SUCCESS)
	{
		g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_GetLastError(&iRetval, qstrErrMsg);
		qstrTemp.sprintf("Error closing Real Time Port : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetval);
		emit sig_updateActionLog (qstrTemp, LOG_ERROR);
	}

	emit sig_updateActionLog("Real Time Port Closed", LOG_INFO);

	iRetval = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_Close ();
	if (iRetval != DPSCM_SUCCESS)
	{
		g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetval, qstrErrMsg);
		qstrTemp.sprintf("Error closing Real Time Port : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetval);
		emit sig_updateActionLog (qstrTemp, LOG_ERROR);
	}

	emit sig_updateActionLog("Diagnostics Port Closed", LOG_INFO);
}

/*******************************************************************************
 * Name					: getConfigValues
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To get configuration values
 ***************************************************************************//**
 * @brief	This function is used to get the configured values from GUI and
 *			store them in the port info structure
 *
 * @param[in]	in_pSPortInfo	Specifies the location to store port information
 * @param[in]	in_ucPort	Specifies the selected port
 *
 * @return	NIL
 ******************************************************************************/
void CRS422Configuration::getConfigValues(PSDRS232_PORT_INFO in_pSPortInfo, unsigned char in_ucPort)
{
	in_pSPortInfo->m_qstrPortName = m_cmbPort[in_ucPort]->currentText() /*+ 1*/;

	switch (m_cmbBaudRate[in_ucPort]->currentIndex())
	{
		case 0:
		{
			in_pSPortInfo->m_ulBaudRate = Baud921600;
		} break;
		case 1:
		{
			in_pSPortInfo->m_ulBaudRate = QSerialPort::Baud115200;
		} break;
		default:
		{
			in_pSPortInfo->m_ulBaudRate = QSerialPort::UnknownBaud;
		} break;
	}

	switch (m_cmbDataBits[in_ucPort]->currentIndex())
	{
		case 0:
		{
			in_pSPortInfo->m_ucDataBits = QSerialPort::Data5;
		} break;
		case 1:
		{
			in_pSPortInfo->m_ucDataBits = QSerialPort::Data6;
		} break;
		case 2:
		{
			in_pSPortInfo->m_ucDataBits = QSerialPort::Data7;
		} break;
		case 3:
		{
			in_pSPortInfo->m_ucDataBits = QSerialPort::Data8;
		} break;
		default:
		{
			in_pSPortInfo->m_ucDataBits = QSerialPort::UnknownDataBits;
		}
	}

	switch (m_cmbParity[in_ucPort]->currentIndex())
	{
		case 0:
		{
			in_pSPortInfo->m_ucParity = QSerialPort::NoParity;
		} break;
		case 1:
		{
			in_pSPortInfo->m_ucParity = QSerialPort::OddParity;
		} break;
		case 2:
		{
			in_pSPortInfo->m_ucParity = QSerialPort::EvenParity;
		} break;
		default:
		{
			in_pSPortInfo->m_ucParity = QSerialPort::UnknownParity;
		} break;
	}

	switch (m_cmbStopBit[in_ucPort]->currentIndex())
	{
		case 0:
		{
			in_pSPortInfo->m_ucStopBits = QSerialPort::OneStop;
		} break;
		case 1:
		{
			in_pSPortInfo->m_ucStopBits = QSerialPort::OneAndHalfStop;
		} break;
		case 2:
		{
			in_pSPortInfo->m_ucStopBits = QSerialPort::TwoStop;
		} break;
		default:
		{
			in_pSPortInfo->m_ucStopBits = QSerialPort::UnknownStopBits;
		} break;
	}

	switch (m_cmbFlowCtrl[in_ucPort]->currentIndex())
	{
		case 0:
		{
			in_pSPortInfo->m_ucFlowcontrol = QSerialPort::NoFlowControl;
		} break;
		case 1:
		{
			in_pSPortInfo->m_ucFlowcontrol = QSerialPort::HardwareControl;
		} break;
		case 2:
		{
			in_pSPortInfo->m_ucFlowcontrol = QSerialPort::SoftwareControl;
		} break;
		default:
		{
			in_pSPortInfo->m_ucFlowcontrol = QSerialPort::UnknownFlowControl;
		} break;
	}

	in_pSPortInfo->m_sPortStatus = DPSCM_FAILURE;
}

/*******************************************************************************
 * Name					: on_pbConfigure_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To configure the ports
 ***************************************************************************//**
 * @brief	This function is used to configure the port with selected values and
 *			display the communication establishment status
 *		This function is called when Configure button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CRS422Configuration::on_pbConfigure_clicked()
{
	int iRetval = DPSCM_SUCCESS;
	unsigned char ucSystem = DPSCM_INIT_0;
    char szErrMsg[100] = "";
	QString qstrErrMsg = QString();
	QString qstrTemp = QString();
    QString qstrMotor = QString();

    CHECK_TC_RUNNING;

    emit sig_startDiagCMDTx(false);

#ifndef _TEMP_
    if ((ui->cmbCmd_PortNo->count() == DPSCM_INIT_0) || (ui->cmbDiag_PortNo->count() == DPSCM_INIT_0))
	{
        DISPLAY_MESSAGE_BOX(this, "RS422 Configuration", "No ports available");
		return;
	}
#endif

	ucSystem = ui->cmbSystemSel->currentIndex ();
    switch (ucSystem)
    {
    case SYSTEM_SEASPRAY_HDLC:
    {
        qstrMotor.sprintf("Seaspray Motor");
    } break;
    case SYSTEM_OSPREY50:
    case SYSTEM_RTGA_EL:
    case SYSTEM_RGA_RTGA_AZ:
    {
        qstrMotor.sprintf("Osprey Motor");
    } break;
    default:
        break;
    }

    if (ui->cmbCmd_PortNo->currentIndex() == ui->cmbDiag_PortNo->currentIndex())
	{
		DISPLAY_MESSAGE_BOX(this, "RS422 Configuration", "Real Time and Diagnostics port cannot be configured in the same port");
		return;
	}

	if (g_SGlobal.m_objRS232[COMMAND_PORT_IDX].getPortStatus() == DPSCM_SUCCESS)  /* Check and close if port is already open */
	{
		g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_Close();
	}
	if (g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].getPortStatus() == DPSCM_SUCCESS)  /* Check and close if port is already open */
	{
		g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_Close();
	}

    ui->pbOpen_CmdPort->setText("Open (&1)");
    ui->pbOpen_DbgPort->setText("Open (&2)");

    on_pbOpen_CmdPort_clicked();
    on_pbOpen_DbgPort_clicked();

	displayComStatus();
	m_bConfigured = true;

    qstrTemp.sprintf("Please ensure %s is connected\nand then Press \"Ok\"", CONV_QSTR_TO_SZ(qstrMotor));
    DISPLAY_MESSAGE_BOX(this, "Motor Configuration", qstrTemp);

	if ((m_SPortInfo[ucSystem][COMMAND_PORT_IDX].m_sPortStatus == DPSCM_SUCCESS) &&\
			(m_SPortInfo[ucSystem][DIAGNOSTIC_PORT_IDX].m_sPortStatus == DPSCM_SUCCESS))
    {
		emit sig_updateActionLog("RS422 Communication configured successfully", LOG_SUCCESS);

        iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_ConfigureSystemMode(XMC_BRD_IDX, ucSystem);
        if (iRetval != DPSCM_INIT_0)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError(&iRetval, szErrMsg);
            qstrErrMsg.sprintf("System Selection Error");
            emit sig_updateActionLog(qstrErrMsg, LOG_ERROR);
            qstrErrMsg.sprintf("Error Configuring System : %s [ErrCode: %d]", szErrMsg, iRetval);
            DISPLAY_MESSAGE_BOX(this, "System Selection", qstrErrMsg);
            return;
        }
        else
        {
            g_SGlobal.m_ucSystem = ui->cmbSystemSel->currentIndex();
            qstrTemp.sprintf("Selected System : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(ui->cmbSystemSel->currentText()), g_SGlobal.m_ucSystem);
            emit sig_changePageTitle(ui->cmbSystemSel->currentText(), true);
            emit sig_updateActionLog(qstrTemp, LOG_SUCCESS);
        }
	}
	else
	{
		emit sig_EnDisSync (false, true);
		if (m_SPortInfo[ucSystem][COMMAND_PORT_IDX].m_sPortStatus != DPSCM_SUCCESS)
		{
            emit sig_updateActionLog("RS422 Communication Establishment for Real Time Port has failed", LOG_ERROR);
		}
		else
		{
			emit sig_updateActionLog("RS422 Communication Establishment for Diagnostics Port has failed", LOG_ERROR);
		}

        return;
	}

    emit sig_EnDisAzimuth((g_SGlobal.m_ucSystem == SYSTEM_RGA_RTGA_AZ));
}

/*******************************************************************************
 * Name					: on_cmbSystemSel_currentIndexChanged
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To change the system selection
 ***************************************************************************//**
 * @brief	This function is used to enable/disable the configuration parameter
 *			modification provision based on the system selected
 *		This function is called when value of System selection combobox is changed
 *
 * @param[in]	index	Specifies the selected index in System selection combobox
 *
 * @return	NIL
 ******************************************************************************/
void CRS422Configuration::on_cmbSystemSel_currentIndexChanged(int index)
{
	SHOW_BAUDRATE_CONFIG_ONLY((index == SYSTEM_SEASPRAY_HDLC));
	displayComStatus();
    if(ui->cmbSystemSel->currentIndex() == SYSTEM_SEASPRAY_HDLC)
    {
        /** Disable or Enable Labels for Seaspray System */
        ui->lbDisp_Cmd_DataBits->setEnabled(false);
        ui->lbDisp_Cmd_StopBit->setEnabled(false);
        ui->lbDisp_Cmd_Parity->setEnabled(false);
        ui->lbDisp_Cmd_Flowcontrol->setEnabled(false);

        ui->lbDisp_Diag_BaudRate->setEnabled(false);
        ui->lbDisp_Diag_DataBits->setEnabled(false);
        ui->lbDisp_Diag_StopBit->setEnabled(false);
        ui->lbDisp_Diag_Parity->setEnabled(false);
        ui->lbDisp_Diag_Flowcontrol->setEnabled(false);

        /** Disable or Enable Combo-box for Seaspray System */
        ui->cmbCmd_BaudRate->setEnabled(true);
        ui->cmbCmd_DataBits->setEnabled(false);
        ui->cmbCmd_StopBit->setEnabled(false);
        ui->cmbCmd_Parity->setEnabled(false);
        ui->cmbCmd_Flowcontrol->setEnabled(false);

        ui->cmbDiag_BaudRate->setEnabled(false);
        ui->cmbDiag_DataBits->setEnabled(false);
        ui->cmbDiag_StopBit->setEnabled(false);
        ui->cmbDiag_Parity->setEnabled(false);
        ui->cmbDiag_Flowcontrol->setEnabled(false);
    }
    else
    {
        ui->lbDisp_Diag_BaudRate->setEnabled(true);
        ui->lbDisp_Cmd_DataBits->setEnabled(true);
        ui->lbDisp_Diag_DataBits->setEnabled(true);
        ui->lbDisp_Cmd_StopBit->setEnabled(true);
        ui->lbDisp_Diag_StopBit->setEnabled(true);
        ui->lbDisp_Cmd_Parity->setEnabled(true);
        ui->lbDisp_Diag_Parity->setEnabled(true);
        ui->lbDisp_Cmd_Flowcontrol->setEnabled(true);
        ui->lbDisp_Diag_Flowcontrol->setEnabled(true);

        ui->cmbCmd_BaudRate->setEnabled(false);
        ui->cmbDiag_BaudRate->setEnabled(false);
        ui->cmbCmd_DataBits->setEnabled(false);
        ui->cmbDiag_DataBits->setEnabled(false);
        ui->cmbCmd_StopBit->setEnabled(false);
        ui->cmbDiag_StopBit->setEnabled(false);
        ui->cmbCmd_Parity->setEnabled(false);
        ui->cmbDiag_Parity->setEnabled(false);
        ui->cmbCmd_Flowcontrol->setEnabled(false);
        ui->cmbDiag_Flowcontrol->setEnabled(false);
    }

}

void CRS422Configuration::on_pbOpen_CmdPort_clicked()
{
    int iRetVal = DPSCM_INIT_0;
    QString qstrErrMsg = QString();
    QString qstrTemp = QString();
    unsigned char ucSystem = ui->cmbSystemSel->currentIndex ();

    CHECK_TC_RUNNING;

    if (ui->pbOpen_CmdPort->text().contains("Open"))
    {
        if (ui->cmbCmd_PortNo->currentIndex () == ui->cmbDiag_PortNo->currentIndex ())
        {
            DISPLAY_MESSAGE_BOX(this, "RS422 Configuration", "Real Time and Diagnostics Port cannot be configured in the same port.");
            return;
        }

        getConfigValues (&m_SPortInfo[ucSystem][COMMAND_PORT_IDX], COMMAND_PORT_IDX);

        iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_Open(m_SPortInfo[ucSystem][COMMAND_PORT_IDX]);
        if (iRetVal != DPSCM_SUCCESS)
        {
            m_SPortInfo[ucSystem][COMMAND_PORT_IDX].m_sPortStatus = DPSCM_FAILURE;
            g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Error Opening %s Port : %s [Err: %d]", \
                             CONV_QSTR_TO_SZ(g_SGlobal.m_objRS232[COMMAND_PORT_IDX].m_objqserialportUART.portName()),\
                             CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_WARNING);
        }
        else
        {
            m_SPortInfo[ucSystem][COMMAND_PORT_IDX].m_sPortStatus = DPSCM_SUCCESS;
            qstrTemp.sprintf("%s is opened as Real Time Port", CONV_QSTR_TO_SZ(g_SGlobal.m_objRS232[COMMAND_PORT_IDX].m_objqserialportUART.portName()));
            emit sig_updateActionLog(qstrTemp, LOG_PARTIAL_SUCCESS);
            ui->pbOpen_CmdPort->setText("Close (&1)");
        }
    }
    else
    {
        iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_Close();
        if (iRetVal != DPSCM_SUCCESS)
        {
            m_SPortInfo[ucSystem][COMMAND_PORT_IDX].m_sPortStatus = DPSCM_SUCCESS;
            g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Error Closing %s Port : %s [Err: %d]", \
                             CONV_QSTR_TO_SZ(g_SGlobal.m_objRS232[COMMAND_PORT_IDX].m_objqserialportUART.portName()),\
                             CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_WARNING);
        }
        else
        {
            m_SPortInfo[ucSystem][COMMAND_PORT_IDX].m_sPortStatus = DPSCM_FAILURE;
            qstrTemp.sprintf("%s is Closed", CONV_QSTR_TO_SZ(g_SGlobal.m_objRS232[COMMAND_PORT_IDX].m_objqserialportUART.portName()));
            emit sig_updateActionLog(qstrTemp, LOG_PARTIAL_SUCCESS);
            ui->pbOpen_CmdPort->setText("Open (&1)");
        }
    }

    displayComStatus();
}

void CRS422Configuration::on_pbOpen_DbgPort_clicked()
{
    int iRetVal = DPSCM_INIT_0;
    QString qstrErrMsg = QString();
    QString qstrTemp = QString();
    unsigned char ucSystem = ui->cmbSystemSel->currentIndex ();

    CHECK_TC_RUNNING;

    if (ui->pbOpen_DbgPort->text().contains("Open"))
    {
        if (ui->cmbCmd_PortNo->currentIndex () == ui->cmbDiag_PortNo->currentIndex ())
        {
            DISPLAY_MESSAGE_BOX(this, "RS422 Configuration", "Real Time and Diagnostics Port cannot be configured in the same port.");
            return;
        }

        getConfigValues (&m_SPortInfo[ucSystem][DIAGNOSTIC_PORT_IDX], DIAGNOSTIC_PORT_IDX);

        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_Open(m_SPortInfo[ucSystem][DIAGNOSTIC_PORT_IDX]);
        if (iRetVal != DPSCM_SUCCESS)
        {
            m_SPortInfo[ucSystem][DIAGNOSTIC_PORT_IDX].m_sPortStatus = DPSCM_FAILURE;
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Error Opening %s Port : %s [Err: %d]", \
                             CONV_QSTR_TO_SZ(g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].m_objqserialportUART.portName()),\
                             CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_WARNING);
        }
        else
        {
            m_SPortInfo[ucSystem][DIAGNOSTIC_PORT_IDX].m_sPortStatus = DPSCM_SUCCESS;
            qstrTemp.sprintf("%s is opened as Diagnostics Port", CONV_QSTR_TO_SZ(g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].m_objqserialportUART.portName()));
            emit sig_updateActionLog(qstrTemp, LOG_PARTIAL_SUCCESS);
            ui->pbOpen_DbgPort->setText("Close (&2)");
        }

    }
    else
    {
        emit sig_startDiagCMDTx(false);
        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_Close();
        if (iRetVal != DPSCM_SUCCESS)
        {
            m_SPortInfo[ucSystem][DIAGNOSTIC_PORT_IDX].m_sPortStatus = DPSCM_SUCCESS;
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Error Closing %s Port : %s [Err: %d]", \
                             CONV_QSTR_TO_SZ(g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].m_objqserialportUART.portName()),\
                             CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_WARNING);
        }
        else
        {
            m_SPortInfo[ucSystem][DIAGNOSTIC_PORT_IDX].m_sPortStatus = DPSCM_FAILURE;
            qstrTemp.sprintf("%s is Closed", CONV_QSTR_TO_SZ(g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].m_objqserialportUART.portName()));
            emit sig_updateActionLog(qstrTemp, LOG_PARTIAL_SUCCESS);
            ui->pbOpen_DbgPort->setText("Open (&2)");
        }
    }

    displayComStatus();
}
