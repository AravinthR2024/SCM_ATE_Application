/**
* \file dp-scm-command_tx_thread.cpp
* \brief This file contains the code for Command Transmissin thread
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-command_tx_thread.h"

extern S_GLOBAL g_SGlobal;

/*******************************************************************************
 * Name					: CCommandTx
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CCommandTx class
 *
 * @param[in]	parent	Holds the reference to the parent (QObject*)
 * @return	NA
 ******************************************************************************/
CCommandTx::CCommandTx(QObject *parent) : QThread(parent)
{
    m_bCmdTxRunning = false;
    m_u8DiagID = 0x15;

   m_u8PortNo = COMMAND_PORT_IDX;
}

/*******************************************************************************
 * Name					: Start
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To start the thread
 ***************************************************************************//**
 * @brief	This function will start the CommandTx thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CCommandTx::Start()
{
    if(!isRunning())
    {
        m_bCmdTxRunning = true;
        this->start(QThread::TimeCriticalPriority);
    }
}

/*******************************************************************************
 * Name					: Stop
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To stop the thread
 ***************************************************************************//**
 * @brief	This function will terminate the CommandTx thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CCommandTx::Stop()
{
    if(isRunning())
    {
        m_bCmdTxRunning = false;

        msleep(100);

        if(!isFinished())
        {
            this->terminate();
        }
    }
}

/*******************************************************************************
 * Name					: updateCmdTxPkt
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To update Tx command packet
 ***************************************************************************//**
 * @brief	This function is used to update the transmission command packet
 *
 * @param[in]	in_pSCmdTxData	Holds the new transmission command data (PSSCM_RTGA_CMD_PKT)
 * @return	NIL
 ******************************************************************************/
void CCommandTx::updateCmdTxPkt(PSSCM_RTGA_CMD_PKT in_pSCmdTxData)
{
    m_pSCmdTxData = in_pSCmdTxData;

    memset(m_pSCmdTxData, 0, sizeof(SSCM_RTGA_CMD_PKT));
    m_pSCmdTxData->m_u8By1EndBit = 1;
    m_pSCmdTxData->m_u8By2EndBit = 0;
    m_pSCmdTxData->m_u8By3EndBit = 0;
    m_pSCmdTxData->m_u8By4EndBit = 0;
    m_pSCmdTxData->m_u8By5EndBit = 0;
    m_pSCmdTxData->m_u8By6EndBit = 0;
    m_pSCmdTxData->m_u8Spare_01 = 0;
    m_pSCmdTxData->m_u8StoreParam = 0;    // Temp
    m_pSCmdTxData->m_u8AzDemRateMSB = 0;    // Temp
    m_pSCmdTxData->m_u8AzDemRateLSB = 0;    // Temp
    m_pSCmdTxData->m_u8ConfigOffset = 0;    // Temp
    m_pSCmdTxData->m_u8CCWEndStop = 0;    // Temp
    m_pSCmdTxData->m_u8CWEndStop = 0;    // Temp
    m_pSCmdTxData->m_u8ElDemPositionMSB = 0;    // Temp
    m_pSCmdTxData->m_u8ElDemPositionLSB = 0;    // Temp
    m_pSCmdTxData->m_u8DiagnosticsID = m_u8DiagID;
    m_pSCmdTxData->m_u8Checksum = 0;    // Temp
}

/*******************************************************************************
 * Name					: run
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To execute the thread
 ***************************************************************************//**
 * @brief	This function contains the repeated execution of CommandTx thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CCommandTx::run()
{

    int iRetval = DPSCM_INIT_0;
    PSSCM_DIAG_READ_CMD pSTxcommand;
    QString qstrErrMsg = QString("");
    QString qstrTemp = QString();
    unsigned char ucErr = 0;


    pSTxcommand = (PSSCM_DIAG_READ_CMD) malloc(1 * sizeof(SSCM_DIAG_READ_CMD));

    while(m_bCmdTxRunning)
    {
        iRetval = g_SGlobal.m_objRS232[m_u8PortNo].DPRS232Wrap_WriteData((char *) pSTxcommand, sizeof(SSCM_DIAG_READ_CMD));
        if (iRetval != DPSCM_SUCCESS)

        {
            ucErr++;
            if((ucErr%DP_SCM_ERRLOG_CNT) == 0)
            {
                ucErr = 0;
                g_SGlobal.m_objRS232[m_u8PortNo].DPRS232Wrap_GetLastError(&iRetval, qstrErrMsg);
                qstrTemp.sprintf("Error sending Transmitting : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetval);
                emit sig_updateActionLog(qstrTemp, LOG_ERROR);
            }

            usleep(100);
            continue;
        }

        ucErr = 0;
        msleep(400);
    }
}


