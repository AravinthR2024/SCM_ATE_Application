/**
* \file dp-scm-ateselftest.h
* \brief This is the header file for dp-scm-ateselftest.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef ATESELFTEST_H
#define ATESELFTEST_H

#include <QWidget>
#include <QFileDialog>
#include <QDebug>
#include <QDateTime>
#include <QFile>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "dprs232_wrapper.h"
#include "dpxmc5775wrapper.h"
#include "dp_qt_dragndropwidget.h"

#define TESTMODE_INPUT  0
#define TESTMODE_AUTO   1

#define SELFTEST_SIZE   256

namespace Ui {
	class CATESelftest;
}

class CATESelftest : public QWidget
{
		Q_OBJECT

	public:
		explicit CATESelftest(QWidget *parent = 0);
		~CATESelftest();

		bool m_bIsSelfTestDone;
		bool m_bIsSelftestPass;

        short executeSelftest(unsigned char in_ucPortNo, unsigned char in_ucTestMode);

	private:
		Ui::CATESelftest *ui;

	signals:
		void sig_updateActionLog(QString, int);
		void sig_changePage(int);
		void sig_changePageTitle(QString);

	private slots:
		void on_pbSelfTest_clicked();
		void on_rbTestMode_Input_toggled(bool in_bIsChecked);
		void on_rbATESelfTest_toggled(bool in_bChecked);
		void on_pbXMC_Send_clicked();
		void on_pbXMC_Recv_clicked();
};

#endif // ATESELFTEST_H
