/**
* \file DPRS232_wrapper.h
* \brief This file contains the members declaration of wrapper for RS232
*
* \author aravinth.rajalingam
* \date 21 November, 2022
*
* \version   1.00
*
* \copyrights Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef UART_WRAPPER_H
#define UART_WRAPPER_H

#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QDebug>
#include <QThread>

/* Constants */
#define DPRS232_INIT_0      0

#define READ_READY_DELAY    100
#define READ_DATA_COUNTDOWN 500
#define WRITE_WAIT_DELAY    -1      // No timeout

#define Baud921600          921600

//QStringList g_qstrliComports;
#define SET_RS232_LAST_ERROR(code, msg) {\
    m_iErrCode = code;\
    m_qstrErrMsg = msg;\
}

#define QSTR_PORT_NAME   m_objqserialportUART.portName() + " Port"
#define QSTR_PORT_ERROR m_objqserialportUART.errorString() + " [Err: " + QString::number(m_objqserialportUART.error()) + "]"

typedef struct _SDPRS232_PORT_CONFIG
{
//		unsigned int  m_ucPortNo;
		QString m_qstrPortName;
		unsigned long m_ulBaudRate;
		unsigned char m_ucDataBits;
		unsigned char m_ucParity;
		unsigned char m_ucStopBits;
		unsigned char m_ucFlowcontrol;
		short m_sPortStatus;
} SDPRS232_PORT_INFO, *PSDRS232_PORT_INFO;

/*Error Code*/
#define DPRS232_SUCCESS     0
#define DPRS232_FAILURE     -1

enum DPRS232_ERROR_NO
{
	DPRS232ERR_COM_PORT_NOT_AVAILABLE = -999,
    DPRS232ERR_COM_PORT_NOT_OPEN,
	DPRS232ERR_INVALID_BAUDRATE,
	DPRS232ERR_INVALID_DATABITS,
	DPRS232ERR_INVALID_PARITY,
	DPRS232ERR_INVALID_FLOW_CONTROL,
	DPRS232ERR_INVALID_STOP_BIT,
	DPRS232ERR_DATA_WR_FAILED,
	DPRS232ERR_DATA_RD_FAILED,
	DPRS232ERR_IP_BUFF_CLEAR_FAILED,
	DPRS232ERR_OP_BUFF_CLEAR_FAILED,
	DPRS232ERR_IP_OP_BUFF_CLEAR_FAILED
};

#define VALIDATE_RETVAL {\
	if (sRetVal != DPRS232_SUCCESS)\
    {\
        m_iErrCode = sRetVal;\
        return DPRS232_FAILURE;\
	}\
}

class CDPRS232Wrapper
{
	public:

		CDPRS232Wrapper();

		QSerialPort m_objqserialportUART;
		QStringList m_qsAllComport;

        unsigned char m_ucPortStatus;

		int m_iErrCode;
        QString m_qstrErrMsg;

public slots:
        int WaitForData(unsigned char *ucData, unsigned short usExpectedSize);
		short DPRS232Wrap_Open(SDPRS232_PORT_INFO in_SPortInfo);

		short DPRS232Wrap_Configure(SDPRS232_PORT_INFO in_SPortInfo);

		short DPRS232Wrap_Close();

		short DPRS232Wrap_WriteData(char *in_pcBuffData, long long in_lliDataLen);

        short DPRS232Wrap_ReadData(char *out_pcRxBuffer);

        short DPRS232Wrap_ReadData(unsigned int in_uiTotalBytesToRead, char *out_pcRxBuffer, unsigned int *out_puiBytesRead,unsigned int in_uiMilliSecTOut);

        short DPRS232Wrap_ReadAll(char *out_pcRxBuffer);

        short DPRS232Wrap_GetLastError(int *out_iErrCode, QString &out_qstrErrMsg);

		short getAvailComports(QStringList &out_qslPortName);

		void setComportName(QString in_qsComName);

		short setBaudrate(unsigned long in_ulBaudRate);

		short setDataBit(unsigned char in_ucDataBits);

		short setParityBit(unsigned char in_ucParity);

		short setFlowControl(unsigned char in_ucFlowControl);

		short setStopBit(unsigned char in_ucStopBit);

		short getPortStatus();

		short openUARTPort();

		void closeUARTPort();

		short DPRS232Wrap_ClearUARTInputs();

		short DPRS232Wrap_ClearUARTOutputs();

		short DPRS232Wrap_ClearAll();
};

#endif
