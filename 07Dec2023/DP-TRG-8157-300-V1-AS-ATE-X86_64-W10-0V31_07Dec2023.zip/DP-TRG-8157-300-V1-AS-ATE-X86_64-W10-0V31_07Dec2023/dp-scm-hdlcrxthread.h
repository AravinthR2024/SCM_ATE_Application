#ifndef CHDLCRXTHREAD_H
#define CHDLCRXTHREAD_H

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "checksum.h"

#include "dppci755_wrapper.h"

class CHDLCRxThread : public QThread
{
    Q_OBJECT

public:
    CHDLCRxThread(QObject *parent = 0);

    bool m_bIsRunning;
    unsigned short m_usRepeatCount;

    void Start();
    void Stop();
    void run();

signals:
    void sig_threadCompleted();

    void sig_updateActionLog(QString, int);
};


#endif // CHDLCRXTHREAD_H
