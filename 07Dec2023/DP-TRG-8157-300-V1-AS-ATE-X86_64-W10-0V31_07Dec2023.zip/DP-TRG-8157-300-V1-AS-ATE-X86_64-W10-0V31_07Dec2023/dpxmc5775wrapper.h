/**
* \file dpxmc5775wrapper.h
* \brief This file contains the members declaration of wrapper for DP-XMC-5775
*
* \author aravinth.rajalingam
* \date 21 November, 2022
*
* \version   1.00
*
* \copyrights Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef CDPXMC5775WRAPPER_H
#define CDPXMC5775WRAPPER_H

#include "includes/dpxmc5775_12_pro.h"
#include "includes/dp_types.h"
#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-ate_signals.h"

#include <QDebug>

#define DPXMC5775_MAX_BOARDS    SCM_ATE_MAX_XMC5775_BRDS

#define DPXMC5775_INIT_0        0
#define DPXMC5775_SUCCESS       0
#define DPXMC5775_FAILURE       -1

#define DPXMC5775_PRGM_EN       0
#define DPXMC5775_PRGM_DIS      1

#define DPXMC5775_CHECK_RETVAL {\
	if (m_s32RetVal != DPXMC5775_SUCCESS)\
{\
	DPXMC5775_12_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));\
	return DPXMC5775_FAILURE;\
	}\
	}

#define DPXMC5775_VALIDATE_BRDID(u8BoardId) {\
    if (u8BoardId > m_u16NoOfBoards)\
{\
	sprintf(m_szErrMsg, "Invalid Board ID to reset");\
	m_s32RetVal = DPXMC5775_FAILURE;\
	return DPXMC5775_FAILURE;\
	}\
	}

#define DPXMC5775_VALIDATE_BRDOPEN(in_u8BoardId) {\
	if (!m_SDeviceInfo[in_u8BoardId].m_bBoardStatus)\
{\
	m_s32RetVal = DPXMC5775_FAILURE;\
	sprintf(m_szErrMsg, "Board %d is not open", in_u8BoardId);\
	return DPXMC5775_FAILURE;\
	}\
	}

typedef struct _SDPXMC5775Wrap_DeviceInfo
{
		SDPXMC5775_12_DEVICE_LOCATION m_SDeviceLocation;
		bool m_bBoardStatus;
} SDPXMC5775Wrap_DeviceInfo, *PSDPXMC5775Wrap_DeviceInfo;

typedef struct _SDPXMC5775APP_DEVICELOC
{
		U8BIT m_u8BusNo;
		U8BIT m_u8SlotNo;
		U8BIT m_u8FunctionNo;
        U8BIT m_s8BoardSts;
} SDPXMC5775APP_DEVICELOC, *PSDPXMC5775APP_DEVICELOC;

class CDPXMC5775Wrapper
{
	private:
		U16BIT m_u16NoOfBoards;
		S32BIT m_s32RetVal;
		S8BIT m_szErrMsg[100];
		SDPXMC5775Wrap_DeviceInfo m_SDeviceInfo[DPXMC5775_MAX_BOARDS];
		DP_DRV_HANDLE m_vpHandle[DPXMC5775_MAX_BOARDS];

	public:
        S32BIT DPXMC5775Wrap_Initialize( U16BIT in_u16NoOfBoards, SDPXMC5775APP_DEVICELOC in_pSDeviceLocation[], SDPXMC5775APP_DEVICELOC out_pSDeviceLocation[]);
        S32BIT DPXMC5775Wrap_Close(U8BIT in_u8BoardId = DPXMC5775_MAX_BOARDS);
        S32BIT DPXMC5775Wrap_Reset(U8BIT in_u8BoardId = DPXMC5775_MAX_BOARDS);
        S32BIT DPXMC5775Wrap_ProgramEnable(U8BIT in_u8BoardId = DPXMC5775_MAX_BOARDS, U8BIT in_u8Enable = DPSCM_INIT_0);
		S32BIT DPXMC5775Wrap_GetDriverDetails(PSDPXMC5775_12_DRIVER_DETAILS out_pSDriverDetails);
		S32BIT DPXMC5775Wrap_GetDeviceDetails(U8BIT in_u8BoardId, PSDPXMC5775_12_DEVICE_DETAILS out_pSDeviceDetails);
		S32BIT DPXMC5775Wrap_GetGlueLogicDetails(U8BIT in_u8BoardId, PSDPXMC5775_12_GLUE_LOGIC_DETAILS out_pSGlueLogicDetails);
		S32BIT DPXMC5775Wrap_WriteRegister(U8BIT in_u8BoardId, U32BIT in_u32Address, U32BIT in_u32WriteData);
		S32BIT DPXMC5775Wrap_ReadRegister(U8BIT in_u8BoardId, U32BIT in_u32Address, PU32BIT out_pu32ReadData);
        S32BIT DPXMC5775Wrap_SetDeviceShare(U8BIT in_u8BoardId, bool in_bEnableDeviceShare);
		void DPXMC5775Wrap_GetLastError(PS32BIT out_ps32ErrCode, PS8BIT out_szErrMsg);

		S32BIT DPXMC5775Wrap_ConfigureSystemMode(U8BIT in_u8BoardId, U8BIT in_u8Mode);
		S32BIT DPXMC5775Wrap_ConfigureHDLCFrame(U8BIT in_u8BoardId, PSDPXMC5775_12_HDLC_FRAME_CONFIG in_pSHDLCFrameConfig);
		S32BIT DPXMC5775Wrap_SetMasterAddress(U8BIT in_u8BoardId, U8BIT in_u8MasterAddress);
		S32BIT DPXMC5775Wrap_ReadData(U8BIT in_u8BoardId, PU32BIT in_pu32Timeout, U32BIT in_u32CountToRead, PU32BIT out_pu32RespData, PU32BIT out_pu32ReadCount);
		S32BIT DPXMC5775Wrap_SetResponseTimeout(U8BIT in_u8BoardId, U16BIT in_u16Timeout);
		S32BIT DPXMC5775Wrap_StartTransmission(U8BIT in_u8BoardId, U8BIT in_u8RepeatCount = 0, U16BIT in_u16FrameGap = 1);
		S32BIT DPXMC5775Wrap_StopTransmission(U8BIT in_u8BoardId);
		S32BIT DPXMC5775Wrap_GetFrameCount(U8BIT in_u8BoardId, PU32BIT out_pu32FrameCount);
		S32BIT DPXMC5775Wrap_SetFIFOThreshold(U8BIT in_u8BoardId, U16BIT in_u16Threshold);
		S32BIT DPXMC5775Wrap_StartStopReception(U8BIT in_u8BoardId, bool in_bStartStop);
		S32BIT DPXMC5775Wrap_ClearFIFO(U8BIT in_u8BoardId);
		S32BIT DPXMC5775Wrap_GetFIFOCount(U8BIT in_u8BoardId, PU32BIT out_pu32FIFOCount);
		S32BIT DPXMC5775Wrap_SetInterrupt(U8BIT in_u8BoardId, U8BIT in_u8IntType = 0, bool in_bPropagateInt = false);
		S32BIT DPXMC5775Wrap_ReadInterruptStatus(U8BIT in_u8BoardId, PU16BIT out_pu16IntStatus);
		S32BIT DPXMC5775Wrap_WaitForEvent(U8BIT in_u8BoardId, U16BIT in_u16EventMask, U16BIT in_u16Option, PU32BIT in_pu32Timeout, PU32BIT out_pu32EventStatus);
		S32BIT DPXMC5775Wrap_GetHDLCErrorStatus(U8BIT in_u8BoardId, PU16BIT out_u16ErrorStatus);
#if 0
		S32BIT DPXMC5775Wrap_SetCommand(U8BIT in_u8BoardId, U8BIT in_u8Command);
		S32BIT DPXMC5775Wrap_WriteData(U8BIT in_u8BoardId, U32BIT in_u32DataCount, PU32BIT in_pu32Data);
		S32BIT DPXMC5775Wrap_EnableLatch(U8BIT in_u8BoardId);
		S32BIT DPXMC5775Wrap_EnableFIFO(U8BIT in_u8BoardId, bool in_bEnableFIFO, U8BIT in_u8ThresholdCount);
#endif
};

#endif // CDPXMC5775WRAPPER_H
