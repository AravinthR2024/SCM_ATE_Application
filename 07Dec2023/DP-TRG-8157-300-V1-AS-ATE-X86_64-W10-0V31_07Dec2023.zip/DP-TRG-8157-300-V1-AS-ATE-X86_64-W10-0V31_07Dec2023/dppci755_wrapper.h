/**
* \file dp_pci755_wrapper.h
* \brief This file contains the members declaration of wrapper for DP-PCI-755
*
* \author aravinth.rajalingam
* \date 21 November, 2022
*
* \version   1.00
*
* \copyrights Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef CDPPCI755WRAPPER_H
#define CDPPCI755WRAPPER_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <QDebug>

#include "includes/dppci755_pro.h"
#include "includes/dppci755_err.h"
#include "includes/dp_types.h"
#include "includes/dp-scm-macros.h"
//#include "includes/dp-scm-structures.h"
#include "includes/dp-scm-ate_signals.h"

#define DPPCI755_INIT_0         0

#define DPPCI755_SUCCESS        0
#define DPPCI755_FAILURE        -1

#define DPPCI755_BRD_STS_DIS    0
#define DPPCI755_BRD_STS_EN     1

#define DPPCI755_MAX_BOARDS     SCM_ATE_MAX_PCI755_BRDS

#define DPPCI755_CH_1           1
#define DPPCI755_CH_2           2

#define DPPCI755_ADC_CH_1_IDX   DPPCI755_CH_1 - 1
#define DPPCI755_ADC_CH_2_IDX   DPPCI755_CH_2 - 1

#define DPPCI755_DACTYPE_OFFSET 0
#define DPPCI755_DACTYPE_RAM    1

#define CALIB_INTERNAL_MODE     0
#define CALIB_EXTERNAL_MODE     1

#define BIAS_RESET_ENABLE       1
#define BIAS_RESET_DISABLE      0

#define MAX_SEGMENTS            63

#define CHECK_RETVAL    {\
	if (m_s32RetVal != DPPCI755_SUCCESS)\
{\
	DPPCI755_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));\
	return DPPCI755_FAILURE;\
	}\
	}

typedef struct _SDPPCI755APP_DEVICELOC
{
        U8BIT m_u8BusNo;
        U8BIT m_u8SlotNo;
        U8BIT m_u8FunctionNo;
        S8BIT m_s8BoardSts;
} SDPPCI755APP_DEVICELOC, *PSDPPCI755APP_DEVICELOC;

typedef struct _SDPPCI755_DeviceLocation
{
		U8BIT u8BusNo;
		U8BIT u8SlotNo;
		U8BIT u8FunctionNo;
} SDPPCI755_DeviceLocation, *PSDPPCI755_DeviceLocation;

typedef struct _SDPPCI755_CONFIG
{
		U32BIT m_u32BoardNo;
		U32BIT m_u32Mode;
		U32BIT m_u32WaveformType;
		FSINGLE m_fStartFreq;
		FSINGLE m_fEndFreq;
		FSINGLE m_fStepSize;
		FSINGLE m_fTime;
		FSINGLE m_fAmplitude;
		FSINGLE m_fOffset;
		FSINGLE m_fDelay;
		U32BIT m_u32NoOfCycles;
		U32BIT m_u32GainIndex[FRA_ADC_CHN_COUNT];
		U32BIT m_u32StopAngle;
		U32BIT m_u32StartAngle;
		bool m_bLog;
		U8BIT m_u8Reserved1[3];
		bool m_bRMS;
		U8BIT m_u8Reserved2[3];
		bool m_bDelayInSec;
} SDPPCI755_CONFIG, *PSDPPCI755_CONFIG;

#if 0
typedef struct _SDPPCI755_CONFIG
{
		U32BIT m_u32BoardNo;
		U32BIT m_u32Mode;
		U32BIT m_u32WaveformType;
		FSINGLE m_fStartFreq;
		FSINGLE m_fEndFreq;
		FSINGLE m_fStepSize;
		FSINGLE m_fTime;
		FSINGLE m_fAmplitude;
		FSINGLE m_fOffset;
		FSINGLE m_fDelay;
		U32BIT m_u32NoOfCycles;
		U32BIT m_u32GainIndex[DPPCI755_MAX_BOARDS];
		U32BIT m_u32StopAngle;
		U32BIT m_u32StartAngle;
		bool m_bLog;
		U8BIT m_u8Reserved1[3];
		bool m_bRMS;
		U8BIT m_u8Reserved2[3];
		bool m_bDelayInSec;
		U8BIT m_u8Reserved3[3];
		U32BIT m_u32nNoOfSegments;
		SDPPCI755_ARBITRARYWAVEFORM   m_SArbitWave[MAX_SEGMENTS];

} SDPPCI755_CONFIG,*PSDPPCI755_CONFIG;
#endif

class CDPPCI755Wrapper
{
	private:
		U16BIT m_u16NoOfBoards;
		S32BIT m_s32RetVal;
		S8BIT m_szErrMsg[100];
		DP_DRV_HANDLE m_vpHandle[DPPCI755_MAX_BOARDS];
	public:
        S32BIT DPPCI755Wrap_Initialize( U16BIT in_u16NoOfBoards, SDPPCI755_DeviceLocation in_pSDeviceLocation[], SDPPCI755APP_DEVICELOC out_pSDeviceLocation[]);
        S32BIT DPPCI755Wrap_Close(U8BIT in_u8BoardNo = SCM_ATE_MAX_PCI755_BRDS);
        S32BIT DPPCI755Wrap_Reset(U8BIT in_u8BoardNo = SCM_ATE_MAX_PCI755_BRDS);
		S32BIT DPPCI755Wrap_GetDriverDetails(PSDPPCI755_DRIVER_DETAILS out_pSDriverDetails);
		S32BIT DPPCI755Wrap_GetDeviceLocation(U8BIT in_u8BoardNo = 0, PSDPPCI755_DEVICE_LOCATION out_pSDeviceLocation = NULL);
        S32BIT DPPCI755Wrap_GetFirmwareVersion(PU32BIT out_pu32FWVersion, U8BIT in_u8BoardNo = SCM_ATE_MAX_PCI755_BRDS);
		S32BIT DPPCI755Wrap_WriteDWord(U8BIT in_u8BoardNo, U8BIT in_u8BarNo, U32BIT in_u32Offset, U32BIT in_u32DWordData);
		S32BIT DPPCI755Wrap_ReadDWord(U8BIT in_u8BoardNo, U8BIT in_u8BarNo, U32BIT in_u32Offset, PU32BIT out_pu32DWordData);
		S32BIT DPPCI755Wrap_WriteMemBlock(U8BIT in_u8BoardNo, U8BIT in_u8BarNo, U32BIT in_u32Offset, U32BIT in_u32Bytes, PU32BIT in_pu32WrData);
		S32BIT DPPCI755Wrap_ReadMemBlock(U8BIT in_u8BoardNo, U8BIT in_u8BarNo, U32BIT in_u32Offset, U32BIT in_u32Bytes, PU32BIT out_pu32RdData);
        S32BIT DPPCI755Wrap_SetDeviceShare(U8BIT in_u8BoardNo = SCM_ATE_MAX_PCI755_BRDS, bool in_bSetShare = false);
        S32BIT DPPCI755Wrap_SetMasterMode(U8BIT in_u8BoardNo = SCM_ATE_MAX_PCI755_BRDS, bool in_bSetMaster = true);
		S32BIT DPPCI755Wrap_ConfigureAnaParameters(U8BIT in_u8BoardNo, SDPPCI755_CONFIG in_SConfigData);
		S32BIT DPPCI755Wrap_ConfigureWaveform(U8BIT in_u8BoardNo, SDPPCI755_CONFIG in_SConfigData);
		//    S32BIT DPPCI755Wrap_ConfigureFrequency(U8BIT in_u8BoardNo, FSINGLE in_fNext, FSINGLE in_fStep, U8BIT in_u8Log);
		S32BIT DPPCI755Wrap_SetReferenceVolt(U8BIT in_u8BoardNo, U8BIT in_u8ADCChannelNo, PSDPPCI755_CALIBDETAILS in_pSCalibDetails);
		S32BIT DPPCI755Wrap_CalibrationADC(U8BIT in_u8BoardNo, U8BIT in_u8ADCChannelNo, U8BIT in_u8CalibrationMode, PSDPPCI755_CALIBDETAILS in_pSCalibDetails, SDPPCI755_CONFIG in_SConfigData[]);
		S32BIT DPPCI755Wrap_CalibrationDAC(U8BIT in_u8BoardNo, U8BIT in_u8RefLvl, FSINGLE in_fInpVolt, FSINGLE in_fMesVolt, U8BIT in_u8DacType);
		S32BIT DPPCI755Wrap_StoreCalibData(U8BIT in_u8BoardNo);
		S32BIT DPPCI755Wrap_StartStopAcquisition(U8BIT in_u8BoardNo = 0, bool in_bStart = false);
		S32BIT DPPCI755Wrap_ReadAnalyzedData(U8BIT in_u8BoardNo, PU32BIT out_pu32DataCount, PSDPPCI755_ANALYZEDDATABUFFER out_pSAnaData);
		S32BIT DPPCI755Wrap_ReadRawData(U8BIT in_u8BoardNo, PU32BIT out_pu32DataCount, PSDPPCI755_RAWDATABUFFER out_pSRawData);
		S32BIT DPPCI755Wrap_ReadCurrentAnaData(U8BIT in_u8BoardNo, PSDPPCI755_ANALYZEDDATABUFFER out_pSCurrentAnaData);
		S32BIT DPPCI755Wrap_ReadADCValue(U8BIT in_u8BoardNo, PFSINGLE out_pfADCValue);
		S32BIT DPPCI755Wrap_ReadSineWaveData(U8BIT in_u8BoardNo, PU32BIT out_pu32DataCount, PSDPPCI755_ANALYZEDDATABUFFER out_pSAnaDataBuffer);
		S32BIT DPPCI755Wrap_GetStatusRegister(U8BIT in_u8BoardNo, PSDPPCI755_STATUS_REG out_pSStatusReg);
		S32BIT DPPCI755Wrap_SelfTest(U8BIT in_u8BoardNo);
        S32BIT DPPCI755Wrap_SetRelayStatus(U8BIT in_u8BoardNo = SCM_ATE_MAX_PCI755_BRDS, bool in_bRelayOn = false);
        S32BIT DPPCI755Wrap_ResetBiasVoltage(U8BIT in_u8BoardNo = SCM_ATE_MAX_PCI755_BRDS, FSINGLE in_fVoltReductionAmt = 0.0);

		void DPPCI755Wrap_GetLastErrorMessage(PS32BIT out_ps32ErrCode, PS8BIT out_ps8ErrMsg);
};

#endif // CDPPCI755WRAPPER_H
