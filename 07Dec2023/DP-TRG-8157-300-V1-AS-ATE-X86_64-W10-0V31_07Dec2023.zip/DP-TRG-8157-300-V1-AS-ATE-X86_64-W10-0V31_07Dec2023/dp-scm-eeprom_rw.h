#ifndef CEEPROM_RW_H
#define CEEPROM_RW_H

#include <QObject>
#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"

class CEEPROM_RW : public QObject
{
		Q_OBJECT

	public:
        CEEPROM_RW(QObject *parent);

		int EEPROM_Write(unsigned short in_usAddress, unsigned char in_ucData);
		int EEPROM_Read(unsigned short in_usAddress, unsigned char *out_pucData);
		int EEPROM_WriteBoardInfo(unsigned short in_usSerialNo, unsigned short in_usBoardId);
		int EEPROM_ReadBoardInfo(unsigned short *out_usSerialNo, unsigned short *out_usBoardId);
		int EEPROM_ReadChecksum(unsigned char *out_pucCalcChecksum, unsigned char *out_pucReadChecksum);

		int EEPROM_ProtectWrite();
		int EEPROM_CounterDataTest(unsigned short in_usStartAddr, unsigned short in_usNoOfLoc);
		int EEPROM_PatternDataTest(unsigned short in_usStartAddr, unsigned short in_usNoOfLoc, unsigned char in_ucPattern);
		int EEPROM_FullMemoryTest();

	signals:
		int sig_UART_WriteRead(unsigned short in_usCommandID, char *in_pucInputDataBuffer, unsigned int uiInputDataLen,
						   char *out_pucOutputDataBuffer, unsigned int uiOutputDataLen, unsigned int uiTimeout_ms);

		void sig_updateActionLog(QString, int);
};

#endif // CEEPROM_RW_H
