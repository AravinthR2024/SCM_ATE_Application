/**
* \file dp-scm-processing_thread.h
* \brief This is the header file for dp-scm-processing_thread.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef CDATAPROCESSING_H
#define CDATAPROCESSING_H

#include <QThread>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "dprs232_wrapper.h"

class CDataProcessing : public QThread
{
		Q_OBJECT

	public:
		CDataProcessing(QWidget *parent, int in_iTimeout);

        bool m_bDataProcessRunning;
        bool m_bIsDemandPortRunning;
        bool m_bIsDiagPortRunning;
        bool m_bIsDebugDataRunning;
        bool m_bIsHDLCRunning;
        int m_iTimeout;
        U_DEM_PORT_TX m_UTxData;
        U_DEM_PORT_RX m_URxData;
        U_CMDRESP_DATA m_UCmdRespData_Dem;
        U_CMDRESP_DATA m_UCmdRespData_Diag;

        S_DIAG_DATA_RESP m_SDebugData;
        S_HDLC_Response_Data m_SHDLCData;

        void extractDemPortData();
        void extractDiagPortData();
        void extractHDLCData();
        void extractDebugData();
		void Start();
		void Stop();
		void setTimeout(int in_iTimeout);
		void run();

signals:
        void sig_updateBITStatus(unsigned char,unsigned char);
        void sig_updateDiagData();
        void sig_updateLog(unsigned char, U_CMDRESP_DATA);  // Log type and log data
        void sig_drawGraph(float, float, double);
};

#endif // CDATAPROCESSING_H
