/**
* \file dp-scm-resp_rx_thread.cpp
* \brief This file contains the code for Response reception thread
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-resp_rx_thread.h"

extern S_GLOBAL g_SGlobal;

/*******************************************************************************
 * Name					: CResponseRx
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor for  CResponseRx class
 *
 * @param[in]	parent	Holds the reference to the parent
 * @param[in]	in_iTimeout	Specifies the timeout value
 *
 * @return	NA
 ******************************************************************************/
CResponseRx::CResponseRx(QObject *parent, int in_iTimeout) : QThread(parent)
{
    m_bRespRxRunning = false;
    m_iTimeout = in_iTimeout;
    m_u8PortNo = COMMAND_PORT_IDX;

    m_pSRespRxData = (PSSCM_RTGA_RESP_PKT) malloc(sizeof(SSCM_RTGA_RESP_PKT));
}

/*******************************************************************************
 * Name					: setTimeout
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set the timeout
 ***************************************************************************//**
 * @brief	This function is used to set the timeout value
 *
 * @param[in]	in_iTimeout	Specifies the timeout value
 *
 * @return	NIL
 ******************************************************************************/
void CResponseRx::setTimeout(int in_iTimeout)
{
    m_iTimeout = in_iTimeout;
}

/*******************************************************************************
 * Name					: Start
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To start the thread
 ***************************************************************************//**
 * @brief	This function is used to start the Response reception thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CResponseRx::Start()
{
    if(!isRunning())
    {
        m_bRespRxRunning = true;
        this->start();
    }
    else
    {
        // Do nothing
    }
}

/*******************************************************************************
 * Name					: Stop
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To stop the thread
 ***************************************************************************//**
 * @brief	This function is used to terminate the Response reception thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CResponseRx::Stop()
{
    if(isRunning())
    {
        m_bRespRxRunning = false;

        msleep(100);

        if(!isFinished())
        {
            this->terminate();
        }
        else
        {
            // Do nothing
        }
    }
    else
    {
        // Do nothing
    }
}

/*******************************************************************************
 * Name					: run
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To execute the thread
 ***************************************************************************//**
 * @brief	This function contains the repeating execution of the thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CResponseRx::run()
{
    char szErrMsg[100];
    int iRetval = DPSCM_SUCCESS;
    unsigned int uiBytesRead = DPSCM_INIT_0;
    QString qstrErrMsg = QString("");
    QString qstrTemp = QString();
    unsigned char ucErr = 1;

    U_DEM_PORT_RX SRxResponse;

    while (m_bRespRxRunning)
    {
        iRetval = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_ReadData(sizeof(U_DEM_PORT_RX), (char *)&SRxResponse, &uiBytesRead, 2);
        if (iRetval != DPSCM_SUCCESS)
        {
            ucErr++;
            if((ucErr%DP_SCM_ERRLOG_CNT) == 0)
            {
                ucErr = 1;
                g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_GetLastError(&iRetval, qstrErrMsg);
                qstrTemp.sprintf("Error receiving response : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetval);
                emit sig_updateActionLog(qstrTemp, LOG_ERROR);
            }

            usleep(100);
            continue;
        }
        else
        {
            // Do nothing
        }

        iRetval = g_SGlobal.m_pobjResponseMsgQ->Send(&SRxResponse, sizeof(U_DEM_PORT_RX));
        if (iRetval != DPSCM_SUCCESS)
        {
            g_SGlobal.m_pobjResponseMsgQ->GetErrorMsg(iRetval, szErrMsg, 100);
            qstrTemp.sprintf("Error sending response data into queue : %s [Err: %d]", szErrMsg, iRetval);
            emit sig_updateActionLog(qstrTemp, LOG_WARNING);
            continue;
        }
        else
        {
            // Do nothing
        }

        msleep(1);
    }
}

