/**
* \file dp-scm-fra_acq.h
* \brief This is the header file for dp-scm-fra_acq.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef CFRAACQ_H
#define CFRAACQ_H

#include <QThread>
#include <QDir>

#include "includes/dp_types.h"
#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "dppci755_wrapper.h"

class CDelay : public QThread
{
	public:
		CDelay() {}
		static void usleep(unsigned int usecs){QThread::usleep(usecs);}
		static void msleep(unsigned int msecs){QThread::msleep(msecs);}
		static void sleep(unsigned int secs){QThread::sleep(secs);}
};

class CANADataReadThread : public QThread
{
		Q_OBJECT
	public:
		//CDataReadThread(U32BIT in_u32BrdNo, U32BIT in_u32ChnNo, MainWindow *in_pMainWindow);
		CANADataReadThread(QObject * parent,U16BIT in_u16BrdNo = 0);

		U16BIT m_u16BrdNo;
		U8BIT m_u8ChnNo;
		U8BIT m_u8FlgSweepFinished;
		FSINGLE g_fLastFreq;
		FILE *m_fpAnalyzedDataFile;
		SDPPCI755_ANALYZEDDATABUFFER SAnalyzedDataBuffer[ANA_DATABUFF_SIZE];
		volatile unsigned short g_u16CurrentDataReadFlg;
		volatile unsigned short g_u16AnalysedDataReadFlg;

		void run();
		S32BIT ConfigureFrequency(U16BIT in_u16BoardNo, FSINGLE in_fStrtFreq, FSINGLE in_fStep, U8BIT in_u8Log);

	signals:
		void sig_updateActionLog(QString, int);
		void OnGraph_Add_Value(void * param);
		void Set_Adc_Text(QString in_qstrText);
		void sig_DisplayMessage(QString in_qstrText);
		void Set_Status(QString in_qstrText);
		void Acq_Start(bool in_bValue);
        void Current_Data_Display(unsigned short in_u32BoardNo, unsigned int in_uiSource/*,float * in_pfCurrentFrequency*/);
		void sig_ResetBias(unsigned int in_u32BoardNo);
		U32BIT Test_Current_Data_Generator(U16BIT in_u16BoardNo,PSDPPCI755_ANALYZEDDATABUFFER in_pSAnaDataFuffer, SDPPCI755_CONFIG in_ScfgData);
		void Stop_Acq();
		U32BIT Test_Data_Generator(PSDPPCI755_ANALYZEDDATABUFFER pSAnalyzedDataFuffer, PU32BIT in_pu32AnalyzeDataCount , PS32BIT ps32nTestDataCount , SDPPCI755_CONFIG ScfgLData , bool *IsStart);
		void Sample_Test(unsigned int in_u32BoardNo,unsigned int in_u32ChannelNo);
		void MainWin_Ongraph_Draw(unsigned int in_uiBrdNo);
        void sig_acqStarted();

};

class CDataReadThread : public QThread
{
		Q_OBJECT
	public:
		//CDataReadThread(U32BIT in_u32BrdNo, U32BIT in_u32ChnNo, MainWindow *in_pMainWindow);
		CDataReadThread(QObject * parent,U16BIT in_u16BrdNo = 0);

		U16BIT m_u16BrdNo;
		U8BIT m_u8ChnNo;
		/// SDPPCI755_ANALYZEDDATABUFFER SCurrentDataBuff;
		FSINGLE g_fLastFreq;

		void run();

	signals:
		void sig_updateActionLog(QString, int);
		void OnGraph_Add_Value(void * param);
        void sig_changeButtonName(QString);

		void Set_Adc_Text(QString in_qstrText);

		void sig_DisplayMessage(QString in_qstrText);

		void Set_Status(QString in_qstrText);
		void Acq_Start(bool in_bValue);
        void Current_Data_Display(unsigned short in_u32BoardNo, unsigned int in_uiSource/*,float * in_pfCurrentFrequency*/);
		void sig_ResetBias(unsigned int in_u32BoardNo);
		U32BIT Test_Current_Data_Generator(U16BIT in_u16BoardNo,PSDPPCI755_ANALYZEDDATABUFFER in_pSAnaDataFuffer, SDPPCI755_CONFIG in_ScfgData);
		void Stop_Acq();
		U32BIT Test_Data_Generator(PSDPPCI755_ANALYZEDDATABUFFER pSAnalyzedDataFuffer, PU32BIT in_pu32AnalyzeDataCount , PS32BIT ps32nTestDataCount , SDPPCI755_CONFIG ScfgLData , bool *IsStart);
		void Sample_Test(unsigned int in_u32BoardNo,unsigned int in_u32ChannelNo);
		void MainWin_Ongraph_Draw(unsigned int in_uiBrdNo);
		void UpdatePauseSte(unsigned int u32PauseSte);

};

#if 1
class CReadRawDataFIFO : public QThread
{
		Q_OBJECT
	public:
		CReadRawDataFIFO(QObject * parent,U16BIT in_u16BrdNo = 0);

		void run();

		U16BIT m_u16BrdNo;
		U8BIT g_u8RawDataFileSel;

		//    void DisplayStatus_OnInterrupt(QString in_qstrText);
		//    void SetStatus_OnInterrupt(QString in_qstrText);
		//    void SetAdcText_OnInterrupt(QString in_qstrText);

	signals:
		void sig_updateActionLog(QString, int);
		void Set_Adc_Text(QString in_qstrText);

		void sig_DisplayMessage(QString in_qstrText);

		void Set_Status(QString in_qstrText);

		void sig_ResetBias(unsigned int in_u32BoardNo);

		void Stop_Acq();

};
#endif

#if 0
class CRandomDataReadThread : public QThread
{
		Q_OBJECT
	public:
		CRandomDataReadThread(QObject * parent,U16BIT in_u16BrdNo);

		void run();

		U16BIT m_u16BrdNo;
		S32BIT DPPCI755_ConfigRandomFreq(U16BIT in_u16BoardNo);
	signals:
		void Set_Adc_Text(QString in_qstrText);

		void sig_DisplayMessage(QString in_qstrText);

		void Set_Status(QString in_qstrText);
		void Acq_Start(bool in_bValue);
		void Current_Data_Display(unsigned short in_u32BoardNo,unsigned int in_uiSource/*,float * in_pfCurrentFrequency*/);
		void sig_ResetBias(unsigned int in_u32BoardNo);
		U32BIT Test_Current_Data_Generator(U16BIT in_u16BoardNo, PSDPPCI755_ANALYZEDDATABUFFER in_pSAnaDataFuffer, SDPPCI755_CONFIG in_ScfgData);
		void Stop_Acq();
		U32BIT Test_Data_Generator(PSDPPCI755_ANALYZEDDATABUFFER pSAnalyzedDataFuffer, PU32BIT in_pu32AnalyzeDataCount , PS32BIT ps32nTestDataCount , SDPPCI755_CONFIG ScfgLData , bool *IsStart);
		void Sample_Test(unsigned int in_u32BoardNo);
		void MainWin_Ongraph_Draw(unsigned int in_uiBrdNo);

};
#endif

#endif // CFRAACQ_H
