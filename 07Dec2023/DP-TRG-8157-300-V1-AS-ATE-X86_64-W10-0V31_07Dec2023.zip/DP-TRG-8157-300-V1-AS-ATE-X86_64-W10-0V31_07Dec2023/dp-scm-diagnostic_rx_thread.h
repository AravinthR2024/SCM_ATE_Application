/**
* \file dp-scm-diagnostics_tx_thread.h
* \brief This is the header file for dp-scm-diagnostics_tx_thread.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef CDIAGNOSTICRX_H
#define CDIAGNOSTICRX_H

#include <QThread>
#include <QDebug>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "dprs232_wrapper.h"
#include "includes/dp_qt_msgqueue.h"

#define DIAGRX_DIAG_DATA    0
#define DIAGRX_DEBUG_DATA   1

class CDiagnosticRx : public QThread
{
		Q_OBJECT
	public:
		CDiagnosticRx(QObject *parent = 0, int in_iTimeout = 0);

		bool m_bRespRxSts;
		int m_iTimeout;
        unsigned char m_ucDiagMode;

//        PSSCM_RTGA_RESP_PKT m_pSRespRxData;

        void setMode(unsigned char in_ucMode);
		void setTimeout(int in_iTimeout);
		void Start();
		void Stop();
		void run();

	signals:
        void sig_updateDiagParam();

        void sig_updateBITStatus(unsigned char, unsigned char);

        void sig_updateActionLog(QString, int);
};

#endif // CDIAGNOSTICRX_H
