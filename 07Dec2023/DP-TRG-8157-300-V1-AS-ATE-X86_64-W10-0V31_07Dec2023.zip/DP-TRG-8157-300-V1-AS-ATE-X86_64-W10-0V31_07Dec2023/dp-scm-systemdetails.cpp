/**
* \file dp-scm-systemdetails.cpp
* \brief This file contains the code for System Version Details panel
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-systemdetails.h"
#include "ui_dp-scm-systemdetails.h"
#include "dp-scm-mainwindow.h"

extern S_GLOBAL g_SGlobal;

/*******************************************************************************
 * Name					: CSysetmDetails
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CSystemDetails class
 *
 * @param[in]	parent	Holds the reference to the parent
 *
 * @return	NA
 ******************************************************************************/
CSystemDetails::CSystemDetails(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CSystemDetails)
{
    ui->setupUi(this);
    m_SSystemDetails.m_fFirmwareVersion = 0.0f;
    m_SSystemDetails.m_fSoftwareVersion = 0.0f;
    m_SSystemDetails.m_uiSystemVersion = 0.0f;
}

/*******************************************************************************
 * Name					: ~CSystemDetails
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CSystemDetails class
 *
 * @param		NA
 * @return	NA
 ******************************************************************************/
CSystemDetails::~CSystemDetails()
{
    delete ui;
}

/*******************************************************************************
 * Name					: fetchSystemDetails
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To fetch the system details
 ***************************************************************************//**
 * @brief	This function is used to fetch the system details and store in
 *			System Details structure
 *
 * @param[in]	in_pSSysDet	Specifies the location to store system details
 * @param[in]	in_ucBoardId	Specifies the baord ID
 *
 * @return	NIL
 ******************************************************************************/
void CSystemDetails::fetchSystemDetails()
{
    int iRetVal = DPSCM_INIT_0;
    unsigned char ucTemp1 = DPSCM_INIT_0;
    unsigned char ucTemp2 = DPSCM_INIT_0;
    unsigned char ucCurrIdx = DPSCM_INIT_0;
    unsigned char ucarrDiagIds[3] = { ID_46, ID_48, ID_50 };
    unsigned char ucIsAzimuth = DPSCM_INIT_0;
    unsigned char ucData = DPSCM_INIT_0;
    unsigned int uiBytesRead = DPSCM_INIT_0;
    unsigned char ucChecksum = DPSCM_INIT_0;
    QString qstrErrMsg = QString();
    QString qstrTemp = QString();
    QString qstrValue = QString();
    U_DEM_PORT_TX UTxCommand = { 0 };
    U_DEM_PORT_RX URxResponse = { 0 };

    memset (&UTxCommand, 0, sizeof(U_DEM_PORT_TX));
    memset (&URxResponse, 0, sizeof(U_DEM_PORT_RX));

    ucIsAzimuth = (g_SGlobal.m_ucSystem == SYSTEM_RGA_RTGA_AZ) ? 1 : 0;

    for (ucCurrIdx = DPSCM_INIT_0; ucCurrIdx < 3; ucCurrIdx++)
    {
        UTxCommand.m_S_DiagCmd.m_ucByte0_Bit6_0 = 0;
        UTxCommand.m_S_DiagCmd.m_ucByte0_Bit7 = 1;

        UTxCommand.m_S_DiagCmd.m_ucByte1_CmdID = CMDID_DIAGMON_READ & 0x1F;
        UTxCommand.m_S_DiagCmd.m_ucByte1_TestInit = 0;
        UTxCommand.m_S_DiagCmd.m_ucByte1_Bit7 = 0;

        UTxCommand.m_S_DiagCmd.m_ucByte2_Bit6_0 = (ucarrDiagIds[ucCurrIdx] + ucIsAzimuth) & 0x7F;

        dp_scm_7bit_xor_checksum((unsigned char *)&UTxCommand.m_S_DiagCmd, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);

        UTxCommand.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;

        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *)UTxCommand.m_arrucData, sizeof(S_DIAG_CMDRESP));
        if (iRetVal != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Error Send Command : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_ERROR);
            continue;
        }

        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_DIAG_CMDRESP), (char *) &URxResponse.m_S_DiagResp, &uiBytesRead, 200);
        if (iRetVal != DPSCM_INIT_0)
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Error Receiving Response for DiagID-%d : %s [ErrCode: %d]", ucarrDiagIds[ucCurrIdx], CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_ERROR);
        }

        ucData = (URxResponse.m_S_DiagResp.m_ucByte3_Bit6_0 & 0x7F);
        qstrValue.clear();

        if (ucCurrIdx < 2)
        {
            ucTemp1 = ucData & 0x0F;
            ucTemp2 = (ucData >> 4) & 0x0F;
            qstrValue.sprintf("%d.%02d", ucTemp2, ucTemp1);
        }
        else
        {
            qstrValue.sprintf("%02d", ucData);
        }

        switch(ucCurrIdx)
        {
        case 0: m_SSystemDetails.m_fSoftwareVersion = qstrValue.toFloat(); break;
        case 1: m_SSystemDetails.m_fFirmwareVersion = qstrValue.toFloat(); break;
        case 2: m_SSystemDetails.m_uiSystemVersion = qstrValue.toUInt(); break;
        default: break;
        }
    }

    displaySystemDetails();
}

/*******************************************************************************
 * Name					: displaySystemDetails
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To display the system details
 ***************************************************************************//**
 * @brief	This function is used to display the system details fetched
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CSystemDetails::displaySystemDetails()
{
    QString qstrTemp;
    qstrTemp.sprintf("%0.02f", m_SSystemDetails.m_fSoftwareVersion);
    ui->leSWVersion->setText(qstrTemp);
    qstrTemp.sprintf("%0.02f", m_SSystemDetails.m_fFirmwareVersion);
    ui->leFWVersion->setText(qstrTemp);
    qstrTemp.sprintf("%02d", m_SSystemDetails.m_uiSystemVersion);
    ui->leSCMVersion->setText(qstrTemp);
}

void CSystemDetails::on_pbFetch_clicked()
{
    CHECK_TC_RUNNING;

    CHECK_PORT_OPEN(DIAGNOSTIC_PORT_IDX);

    if (g_SGlobal.m_ucConfiguredMode != DIAGNOSTICS_MODE)
    {
        DISPLAY_MESSAGE_BOX(this, "Mode Configuration", "Please switch to Diagnostics Mode to fetch System Details");
        return;
    }

    fetchSystemDetails();
}
