#include "dp_qt_dragndropwidget.h"
#include "ui_dp_qt_dragndropwidget.h"

CDragnDropWidget::CDragnDropWidget(QWidget *parent, QStringList in_qstrliAcceptedFileFormats) :
	QWidget(parent),
	ui(new Ui::CDragnDropWidget)
{
	ui->setupUi(this);

	m_qstrliAcceptedFileFormats = in_qstrliAcceptedFileFormats;
}

CDragnDropWidget::~CDragnDropWidget()
{
	delete ui;
}

void CDragnDropWidget::dragEnterEvent(QDragEnterEvent *in_pevtDragEnter)
{
	const QMimeData *pmimeData;
	QString qstrURLpath = QString();
	QString qstrExtension = QString();
	QString qstrFileName = QString();
	QList<QUrl> qliurlUrls = QList<QUrl>();
	QUrl qurlTemp = QUrl();

	pmimeData = in_pevtDragEnter->mimeData ();
	if (pmimeData->hasUrls ())
	{
		qliurlUrls = pmimeData->urls ();
	}
	else
	{
		in_pevtDragEnter->ignore ();
		return;
	}

	if (qliurlUrls.length () > 1)
	{
		in_pevtDragEnter->ignore ();
		return;
	}

	qurlTemp = qliurlUrls.at (0);
	qstrFileName = qurlTemp.fileName ();
	qstrExtension = qstrFileName.section ('.', 1);

	if (!m_qstrliAcceptedFileFormats.contains (qstrExtension, Qt::CaseInsensitive))
	{
		in_pevtDragEnter->ignore ();
		return;
	}

	emit sig_fileEntered (qstrFileName);
	in_pevtDragEnter->acceptProposedAction ();
}

void CDragnDropWidget::dropEvent(QDropEvent *in_pevtDrop)
{
	in_pevtDrop->acceptProposedAction ();
	QString qstrFPath = QString();

	const QMimeData *pmimeData;

	pmimeData = in_pevtDrop->mimeData ();
	qstrFPath = pmimeData->urls ().at (0).toLocalFile ();

	emit sig_fileDropped (qstrFPath);
}

void CDragnDropWidget::setAcceptedFileFormat(QStringList in_qstrliAcceptedFileName)
{
	m_qstrliAcceptedFileFormats.clear ();
	m_qstrliAcceptedFileFormats = in_qstrliAcceptedFileName;
}

void CDragnDropWidget::addAcceptedFileFormat(QString in_qstrAcceptedFileName)
{
	if (in_qstrAcceptedFileName.isEmpty () || m_qstrliAcceptedFileFormats.contains (in_qstrAcceptedFileName, Qt::CaseInsensitive))
	{
		return;
	}

	m_qstrliAcceptedFileFormats.append (in_qstrAcceptedFileName);
}

void CDragnDropWidget::addAcceptedFileFormat(QStringList in_qstrliAcceptedFileNames)
{
	foreach (QString qstrFName, in_qstrliAcceptedFileNames)
	{
		if (!qstrFName.isEmpty () && !m_qstrliAcceptedFileFormats.contains (qstrFName, Qt::CaseInsensitive))
		{
			m_qstrliAcceptedFileFormats.append (qstrFName);
		}
	}
}
