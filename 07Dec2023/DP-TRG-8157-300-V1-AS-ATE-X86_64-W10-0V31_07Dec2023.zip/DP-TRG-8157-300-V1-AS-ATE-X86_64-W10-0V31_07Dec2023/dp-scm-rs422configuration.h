/**
* \file dp-scm-rs422configuration.h
* \brief This is the header file for dp-scm-rs422configuration.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef RS232COMMUNICATION_H
#define RS232COMMUNICATION_H

#include <QWidget>
#include <QComboBox>
#include <QSettings>
#include <QFileInfo>
#include <QDebug>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "dprs232_wrapper.h"

#define SHOW_BAUDRATE_CONFIG_ONLY(val) {\
    ui->lbDisp_Cmd_DataBits->setDisabled(val);\
    ui->lbDisp_Cmd_StopBit->setDisabled(val);\
    ui->lbDisp_Cmd_Parity->setDisabled(val);\
    ui->lbDisp_Cmd_Flowcontrol->setDisabled(val);\
    ui->cmbCmd_DataBits->setDisabled(val);\
    ui->cmbCmd_StopBit->setDisabled(val);\
    ui->cmbCmd_Parity->setDisabled(val);\
    ui->cmbCmd_Flowcontrol->setDisabled(val);\
	}

namespace Ui {
	class CRS422Communication;
}

class CRS422Configuration : public QWidget
{
		Q_OBJECT

	public:
		explicit CRS422Configuration(QWidget *parent = 0);
		~CRS422Configuration();

		bool m_bConfigured;
		//    CDPRS232Wrapper *m_pobjRS232;
        SDPRS232_PORT_INFO m_SPortInfo[NO_OF_SYSTEMS][NO_OF_PORTS];

        QLabel *m_lbComSts[NO_OF_PORTS];
		QComboBox *m_cmbPort[NO_OF_PORTS];
		QComboBox *m_cmbBaudRate[NO_OF_PORTS];
		QComboBox *m_cmbDataBits[NO_OF_PORTS];
		QComboBox *m_cmbStopBit[NO_OF_PORTS];
		QComboBox *m_cmbParity[NO_OF_PORTS];
		QComboBox *m_cmbFlowCtrl[NO_OF_PORTS];

		void readCommSettingIni();
		void displayComStatus();
		void closeAllPorts();
		void getConfigValues(PSDRS232_PORT_INFO in_pSPortInfo, unsigned char in_ucPort);

	private slots:
		void on_pbConfigure_clicked();

#if 0
		void on_rbInit_COMMConfig_Sys_RGA_RTGA_clicked(bool checked);

		void on_rbInit_COMMConfig_Sys_Seaspray_clicked(bool checked);
#endif

		void on_cmbSystemSel_currentIndexChanged(int index);

		void on_pbOpen_CmdPort_clicked();

		void on_pbOpen_DbgPort_clicked();

	private:
		Ui::CRS422Communication *ui;

	signals:
		void sig_updateActionLog(QString, int);
		void sig_changePage(int);
		void sig_startTransmission(bool);
		void sig_EnDisSync(bool,bool);
		void sig_changePageTitle(QString, bool);
		void sig_append_BIT_HTMLReport (QString);
        void sig_startDiagCMDTx(bool);
        void sig_fetchSystemDetails();
        void sig_EnDisAzimuth(bool);
};

#endif // RS232COMMUNICATION_H
