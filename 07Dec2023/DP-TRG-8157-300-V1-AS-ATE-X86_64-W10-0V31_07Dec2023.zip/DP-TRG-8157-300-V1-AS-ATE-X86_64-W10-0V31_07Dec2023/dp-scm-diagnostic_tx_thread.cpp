/**
* \file dp-scm-diagnostic_rx_thread.cpp
* \brief This file contains the code for Diagnostics reception thread
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/
#include "dp-scm-diagnostic_tx_thread.h"

extern S_GLOBAL g_SGlobal;

/*******************************************************************************
 * Name					: CDiagnosticTx
 * Author				: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CDiagnosticTx class
 *
 * @param[in]	parent	Holds the reference to the parent	(QObject*)
 * @param[in]	in_iTimeout	Holds the timeout value for transmission	(int)
 *
 * @return	NA
 ******************************************************************************/
CDiagnosticTx::CDiagnosticTx(QObject *parent, int in_iTimeout) : QThread(parent)
{
    m_bDiagTxSts = false;
    m_iTimeout = in_iTimeout;
}

/*******************************************************************************
 * Name					: setTimeout
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set timout value
 ***************************************************************************//**
 * @brief	This function is used to set the Timeout values for reception
 *
 * @param[in]	in_iTimeout	Holds the timeout values (int)
 * @return
 ******************************************************************************/
void CDiagnosticTx::setTimeout(int in_iTimeout)
{
    m_iTimeout = in_iTimeout;
}

/*******************************************************************************
* Name					: Start
* Author					: aravinth.rajalingam
* Global Variables affected	: NIL
* Created Date			: Feb 17, 2023
* Revised By				: NA
* Revision Date			: NA
* Reason for revision		: NA
* Description				: To start the thread
***************************************************************************//**
* @brief	This function is used to start the DiagnosticTx thread
*
* @param		NIL
* @return	NIL
******************************************************************************/
void CDiagnosticTx::Start()
{
    m_bDiagTxSts = true;
    this->start(QThread::HighestPriority);
}
/*******************************************************************************
* Name					: Stop
* Author					: aravinth.rajalingam
* Global Variables affected	: NIL
* Created Date			: Feb 17, 2023
* Revised By				: NA
* Revision Date			: NA
* Reason for revision		: NA
* Description				: To stop the thread
***************************************************************************//**
* @brief	This function is used to terminate the DiagnosticTx thread
*
* @param		NIL
* @return	NIL
******************************************************************************/
void CDiagnosticTx::Stop()
{
    m_bDiagTxSts = false;
    this->terminate();
}

/*******************************************************************************
* Name					: run
* Author					: aravinth.rajalingam
* Global Variables affected	: NIL
* Created Date			: Feb 17, 2023
* Revised By				: NA
* Revision Date			: NA
* Reason for revision		: NA
* Description				: To execute the thread
***************************************************************************//**
* @brief	This function contains the repeated execution of DiagnosticsTx thread
*
* @param
* @return
******************************************************************************/
void CDiagnosticTx::run()
{
    int iRetval = DPSCM_INIT_0;
    U_DEM_PORT_TX USCM_DiagTx = { 0 };
    U_DEM_PORT_RX USCM_DiagRx = { 0 };
    unsigned char ucChecksum = DPSCM_INIT_0;
    unsigned char ucIndex = DPSCM_INIT_0;
    unsigned char ucErr = 0;
    unsigned char ucarrIDs[9] = { ID_03, ID_04, ID_05, ID_07, ID_38, ID_39, ID_40, ID_41, ID_15 };
    QString qstrErrMsg = QString("");
    QString qstrTemp = QString();

    memset (&USCM_DiagRx, 0, sizeof(U_DEM_PORT_RX));
    memset (&USCM_DiagTx, 0, sizeof(U_DEM_PORT_TX));

    USCM_DiagTx.m_S_DiagCmd.m_ucByte0_Bit6_0 = 0;
    USCM_DiagTx.m_S_DiagCmd.m_ucByte0_Bit7 = 1;
    USCM_DiagTx.m_S_DiagCmd.m_ucByte1_CmdID = CMDID_DIAGMON_READ & 0x1F;
    USCM_DiagTx.m_S_DiagCmd.m_ucByte2_Bit6_0 = ucarrIDs[ucIndex] & 0x7F;
    dp_scm_7bit_xor_checksum((unsigned char *)&USCM_DiagTx.m_S_DiagCmd, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);
    USCM_DiagTx.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;

    while(m_bDiagTxSts)
    {
        iRetval = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *) USCM_DiagTx.m_arrucData, sizeof(S_DIAG_CMDRESP));
        if (iRetval != DPSCM_SUCCESS)
        {
            ucErr++;

            if((ucErr%DP_SCM_ERRLOG_CNT) == 0)
            {
                ucErr = 0;
                g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetval, qstrErrMsg);
                qstrTemp.sprintf("Error sending Transmitting : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetval);
                emit sig_updateActionLog(qstrTemp, LOG_ERROR);
            }

            usleep(100);
            continue;
        }

        ucIndex = (ucIndex + 1) % 9;
        USCM_DiagTx.m_S_DiagCmd.m_ucByte2_Bit6_0 = ucarrIDs[ucIndex];
        dp_scm_7bit_xor_checksum((unsigned char *)&USCM_DiagTx.m_S_DiagCmd, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);
        USCM_DiagTx.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;

        msleep(10);
    }
}
