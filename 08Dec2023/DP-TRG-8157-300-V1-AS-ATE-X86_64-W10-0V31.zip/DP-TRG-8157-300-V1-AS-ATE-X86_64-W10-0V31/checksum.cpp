/**
*	\file DP_SCM_CHECKSUM.c
*	\brief DP_SCM_CHECKSUM implementation file
*
*	This file contains the definitions of the functions in DP_SCM_CHECKSUM.h file
*
*	\author Madhusudhan D
*	\date 	Jul 13,2023 12:34 PM
*
*	\revision
*	- Initial version
*	- Added keywords for copyright & revision
*
*	\copyright Copyright (C) 2023 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
*	All Rights Reserved.\n
*	Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
*   	Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
*   	Chennai-603103 | India\n
*	Website : http://www.datapatternsindia.com/\n
*	Phone: 91-44-4741-4000\n
*	FAX: 91-44-4741-4444 \n
************************************************************************************************/
//#include "../../SCM_Application/include/DP_SCM_COMMON.h"
#include "dp-scm-about.h"
#include "ui_dp-scm-about.h"
#include "dp-scm-mainwindow.h"
/*! ***********************************************************************************************************
 * \fn    dp_scm_7bit_xor_checksum
 * \brief This function computes the 7bit XOR checksum
 *
 *	\param[in] 	in_pucData		- 	Specifies the data
 *	\param[in] 	in_ucDataSize	- 	Specifies the data size
 *	\param[out] out_pucChecksum - 	Specifies checksum data
 *
 * \retval  SCM_SUCCESS
 * \author  Madhusudhan D
 * \date    13-07-2022
 * \revision
 *  -Revision   date \date
 *  -Revision   reason \brief
 * \version  Requiremnet ID
 *
 * This function is used for 7bit XOR checksum computation.
 ****************************************************************************************************************/
short dp_scm_7bit_xor_checksum(unsigned char *in_pucData, unsigned char in_ucDataSize, unsigned char *out_pucChecksum)
{
    short sRetVal =  DPSCM_SUCCESS;
    unsigned short usLooper = 0;

    if((in_pucData == NULL) || (in_pucData == NULL))
    {
        sRetVal = DPSCM_FAILURE;
    }
    else
    {
        *out_pucChecksum = CLEAR_MSB_DATA(in_pucData[0]);
        for(usLooper = 1; usLooper < in_ucDataSize; usLooper++)
        {
            *out_pucChecksum ^= CLEAR_MSB_DATA(in_pucData[usLooper]);
        }
        *out_pucChecksum = (0x7F & *out_pucChecksum);
    }

    return sRetVal;
}

/*! ***********************************************************************************************************
 * \fn    dp_scm_crc6_checksum
 * \brief This function computes the CRC6 checksum using polynomial : X^6 + X + 1
 *
 *	\param[in] 	in_pucData		- 	Specifies the data
 *	\param[in] 	in_ucDataSize	- 	Specifies the data size
 *	\param[out] out_pucChecksum - 	Specifies checksum data
 *
 * \retval  SCM_SUCCESS
 * \author  Madhusudhan D
 * \date    13-07-2022
 * \revision
 *  -Revision   date \date
 *  -Revision   reason \brief
 * \version  Requiremnet ID
 *
 * This function is used for CRC6 checksum computation.
 ****************************************************************************************************************/
short dp_scm_crc6_checksum(unsigned char *in_pucData, unsigned char in_ucDataSize, unsigned char *out_pucChecksum)
{
    short sRetVal = DPSCM_SUCCESS;
    unsigned short usLoopByte = 0;
    unsigned short usLoopBit  = 0;
    unsigned char  ucBit1	  = 0;
    unsigned char  ucBit2	  = 0;
    unsigned char  ucBit3	  = 0;
    unsigned char  ucBit4	  = 0;
    unsigned char  ucBit5	  = 0;
    unsigned char  ucBit6	  = 0;
    unsigned char  ucData	  = 0;
    unsigned char  ucInBit	  = 0;

    if((NULL == in_pucData) || (NULL == in_pucData))
    {
        sRetVal = DPSCM_FAILURE;
    }
    else
    {
        for(usLoopByte = 0; usLoopByte < in_ucDataSize; usLoopByte++)
        {
            for(usLoopBit = 0; usLoopBit < 8; usLoopBit++)
            {
                ucInBit = ((in_pucData[usLoopByte] >> usLoopBit)& 0x01);

                ucData  = ucInBit + ucBit1;
                ucBit1  = ucBit2;
                ucBit2  = ucBit3;
                ucBit3  = ucBit4;
                ucBit4  = ucBit5;
                ucBit5  = ucData + ucBit6;
                ucBit6  = ucData;
            }
        }

        *out_pucChecksum = ((ucBit1 & 0x01) << 5)|((ucBit2 & 0x01) << 4)|((ucBit3 & 0x01) << 3)|\
                           ((ucBit4 & 0x01) << 2)|((ucBit5 & 0x01) << 1)|((ucBit6 & 0x01) << 0);
    }

    return sRetVal;
}

/*! ***********************************************************************************************************
 * \fn    dp_scm_crc16_ccitt
 * \brief This function computes the CRC-ccitt 16bit checksum
 *
 *	\param[in] 	in_pucData		- 	Specifies the data
 *	\param[in] 	in_ucDataSize	- 	Specifies the data size
 *	\param[out] out_pucChecksum - 	Specifies checksum data
 *
 * \retval  SCM_SUCCESS
 * \author  Madhusudhan D
 * \date    13-07-2022
 * \revision
 *  -Revision   date \date
 *  -Revision   reason \brief
 * \version  Requiremnet ID
 *
 * This function is used for CRC16 -ccitt checksum computation.
 ****************************************************************************************************************/

short dp_scm_crc16_ccitt(unsigned char *in_pucData, unsigned char in_ucDataSize, unsigned short *out_pusChecksum)
{
    short sRetVal = DPSCM_SUCCESS;
    unsigned short usLoopByte = 0;
    unsigned short usLoopBit  = 0;
    unsigned short usCRC = 0;
    unsigned char  ucNewByte = 0;

    usCRC = *out_pusChecksum;
    if((NULL == in_pucData) || (NULL == in_pucData))
    {
        sRetVal = DPSCM_FAILURE;
    }
    else
    {
        for(usLoopByte = 0; usLoopByte < in_ucDataSize; usLoopByte++)
        {
            ucNewByte = in_pucData[usLoopByte];

            for(usLoopBit = 0; usLoopBit < 8; usLoopBit++)
            {
                if (((usCRC & 0x8000) >> 8) ^ (ucNewByte & 0x80))
                {
                    usCRC = (usCRC << 1)  ^ 0x1021;
                }
                else
                {
                    usCRC = (usCRC << 1);
                }

                ucNewByte <<= 1;
            }
        }

        *out_pusChecksum = usCRC;
    }

    return sRetVal;
}



