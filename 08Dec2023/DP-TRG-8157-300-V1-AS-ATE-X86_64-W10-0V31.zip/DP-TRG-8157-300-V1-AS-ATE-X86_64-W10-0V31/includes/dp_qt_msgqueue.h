/*******************************************************************************
// File Name            : dp_qt_msgqueue.h
// Author               : Sathishkumar K
// Created Date         : Nov 16,2010
// Revised By           : Manoj L
// Revision Date        : Jun 20,2020
// Reason for Revising  : Porting to QT
// Description          : Circular buffer declarations & type definitions.
*******************************************************************************/

/*******************************************************************************
// Company Name : DATA PATTERNS (INDIA) LTD.
// Address      : No. H9,4th MainRoad,SIPCOT IT Park,Siruseri,Chennai-603103
// Email        : support@datapatterns.co.in
// Phone        : +91 44 47414000
// Fax          : +91 44 47414444
*******************************************************************************/

/******************************************************************************
// Copyright (c) 2010 DATA PATTERNS (INDIA) LTD.
//
// All rights reserved. These materials are confidential and proprietary to
// DATA PATTERNS and no part of these materials should be reproduced or published
// in any form by any means, electronic or mechanical, including photocopy, on any
// information storage or retrieval system, nor should the materials be disclosed
// to third parties without the explicit written authorization of DATA PATTERNS.
//
*******************************************************************************/

#ifndef MSGQUEUE
#define MSGQUEUE

#include <QSemaphore>
#include <QThread>
#include <QMutex>
#include <QDebug>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* Limits */
/** Maximum number of messages can store in Queue */
#define COE_MSGQ_MAX_MESSAGES		4092
/** Parameter to receive a message in non block mode */
#define COE_MSGQ_RX_NON_BLOCK		0
/** Parameter to receive a message in block mode */
#define COE_MSGQ_RX_BLOCK			1
/** Wait infinitely for the message to receive*/
#define COE_MSGQ_WAIT_INFINITE		0

/** To share the semaphore with the process */
#define COE_MSGQ_SEM_PROCESS_SHARE		1

/* Semaphore */
#define MSGQ_SEMAPHORE_COUNT                1

/* Error Codes */
#define COE_MSGQ_SUCCESS					0                           //checked
#define COE_MSGQ_FAILURE					-1                          //macro not used in app
#define COE_MSGQ_ERR_MEM_ALLOC				(COE_MSGQ_FAILURE - 1)      //
#define COE_MSGQ_ERR_INVALID_MSG_SIZE		(COE_MSGQ_FAILURE - 2)      //checked
#define COE_MSGQ_ERR_INVALID_MSG_BUFF		(COE_MSGQ_FAILURE - 3)      //
#define COE_MSGQ_ERR_QUEUE_EMPTY            (COE_MSGQ_FAILURE - 4)      //checked
#define COE_MSGQ_ERR_QUEUE_FULL             (COE_MSGQ_FAILURE - 5)      //checked
#define COE_MSGQ_ERR_SEM_ERR				(COE_MSGQ_FAILURE - 6)      //
#define COE_MSGQ_ERR_TIMEOUT				(COE_MSGQ_FAILURE - 7)      //checked


/** This used to implement the message Queue buffer. */
typedef struct DP_BUFFER
{
    unsigned char *pucMessage;              /**< Pointer to the message content. */
    unsigned int uiMsgSize;                 /**< Size of the message. */
    struct DP_BUFFER *s_pNextMsg;           /**< Point the next message. */

}S_DP_BUFFER;

/** This is used to create the message queue, which is capable to store and retrieve different size of messages. */
class CDPMsgQueue
{
private:
    unsigned char m_ucIsInitialized;		/**< To identify whether the buffer is initialized. */
    unsigned int m_uiMsgSizeMax;            /**< The size of largest message can store in the buffer. */
    unsigned int m_uiMaxNoOfMsgs;           /**< The maximum number of message can store in the buffer. */
    unsigned int m_uiNoOfMsgs;              /**< Number of messages available in the buffer. */
    S_DP_BUFFER *m_spMsgFront;              /**< Message buffer's front pointer. */
    S_DP_BUFFER *m_spMsgRear;               /**< Message buffer's rear pointer. */
    QMutex m_thrdMutex;                     /**< Mutex for thread safe. */

public:

    QSemaphore *m_QueueRxSem;                /**< To store the semaphore handle. */
    CDPMsgQueue(unsigned int in_uiTotalMsgs, unsigned int in_uiMsgSizeMax);

    //To create circular buffer for the given message sizes. The size of the message buffer will be (in_uiTotalMsgs * in_uiMsgSizeMax).
//    short Init(unsigned int in_uiTotalMsgs, unsigned int in_uiMsgSizeMax);

    //To get the message count from the given buffer(in_s_pMsgQueue).
    short GetMsgCount(unsigned int * out_uipMsgCount);

    //To get a message from the given buffer(in_s_pMsgQueue). act as block or non block mode.
    int Receive(void * out_vpMsgBuffer, unsigned int in_uiBuffSize, int * in_ipTimeOutMS);

    //To store the messages in to the corresponding queue.
    short Send(void * in_vpMsgBuffer, unsigned int in_uiMsgSize);

    //To clear the messages from the giver circular buffer
    short Clear();

    // To destroy the circular buffer. It will deallocate the memory, which is allocated using 'Init()' function
    short Destroy();

    //To get the error message for the error code.
    void GetErrorMsg(short in_sErrorCode, char * out_szErrMsgBuf, unsigned int in_uiMaxBufSize);
};

#endif // MSGQUEUE
