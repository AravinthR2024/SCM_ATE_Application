/**
*\file dppci755_pro.h
*
*\brief	This file contains the function prototypes of all the functions or API's are available for the DP-PCI-755(Frequency Response analyzer)
*
*\version   1.00
*
*\copyright Copyright © 2020 Data Patterns (India) Pvt Ltd.
*
*/

#ifndef DPPCI755_PRO_H_
#define DPPCI755_PRO_H_

#include "dp_types.h"

#if defined(__cplusplus) || defined(__cplusplus__)
extern "C" {
#endif

PRAGMA_PACK_PUSH(1)
/***********************************Structures************************/

/**
*\struct     _SDPPCI755_DEVICE_LOCATION
*\brief  	This structure contains members to hold the device locations details
*
*			The device location details includes the bus number, slot number, function number and channel number.
*
*/
typedef struct _SDPPCI755_DEVICE_LOCATION
{
    U8BIT m_u8BusType;				/*!< Device bus type */
    U8BIT m_u8ChannelNo;			/*!< Channel number */
    union
    {
        struct
        {
            U8BIT m_u8BusNo;		/*!< Bus number */
            U8BIT m_u8SlotNo;		/*!< Slot number */
            U8BIT m_u8FunctionNo;	/*!< Function number */
        }pci;
    }u;
}PACK_ATTRIBUTE SDPPCI755_DEVICE_LOCATION, *PSDPPCI755_DEVICE_LOCATION;

/**
*\struct	_SDPPCI755_DRIVER_DETAILS
*\brief		This structure contains members to hold the driver details
*
*		The driver details includes the driver version.
*
*/
typedef struct _SDPPCI755_DRIVER_DETAILS
{
    U32BIT m_u32Version;	/*!< Driver version */
}PACK_ATTRIBUTE SDPPCI755_DRIVER_DETAILS, *PSDPPCI755_DRIVER_DETAILS;

/**
*	\struct 	: _SDPPCI755_ARBITRARYWAVEFORM
*	\brief  	:This structure is used store  Arbitrary waveform details
*
*/
typedef struct _SDPPCI755_ARBITRARYWAVEFORM
{
	FSINGLE m_fStartAmplitude;	/*!< where the corresponding segment, arbitrary waveform segment, begins*/
    FSINGLE m_fStopAmplitude;	/*!< where the corresponding segment, arbitrary waveform segment, ends*/
    FSINGLE m_fTime;			/*!< specifies the time, in seconds, to complete one cycle of arbitrary waveform segment for the specified amplitude*/
    FSINGLE m_fFrequency;		/*!< specifies the time in terms of frequency, in Hz, to complete one cycle of sine waveform segment for the specified amplitude*/
	U32BIT m_u32WaveformType;	/*!< specifies the waveform to be generated(Arbitrary Waveform / Sine Waveform)*/
    U32BIT m_u32StopAngle;		/*!< specifies the angle, in degree, to stop the sine waveform segment */
    U32BIT m_u32RMS;		/*!< specifies RMS value */
}PACK_ATTRIBUTE SDPPCI755_ARBITRARYWAVEFORM, *PSDPPCI755_ARBITRARYWAVEFORM;

#define ANA_DATABUFF_SIZE       175
/**
*	\struct 	: _SDPPCI755_ANALYZEDDATABUFFER
*	\brief  	:This structure is used store  Analyzed data
*
*/
typedef struct _SDPPCI755_ANALYZEDDATABUFFER
{
    FSINGLE m_fFrequency;	/*!< specifies the frequency in Hz for sweep*/
    FSINGLE m_fGain;		/*!< Calculated gain value*/
    FSINGLE m_fPhase;		/*!< Calculated phase value*/
    FSINGLE m_fRMSVolt1;	/*!< specifies the RMS1 voltage value in volt*/
    FSINGLE m_fRMSVolt2;	/*!< specifies the RMS2 voltage value in volt*/
}PACK_ATTRIBUTE SDPPCI755_ANALYZEDDATABUFFER, *PSDPPCI755_ANALYZEDDATABUFFER;

/**
*	\struct 	: _SDPPCI755_RAWDATABUFFER
*	\brief  	:This structure is used store  Analyzed data
*
*/
typedef struct _SDPPCI755_RAWDATABUFFER
{
    FSINGLE	m_fChannel1Data;	/*!< ADC Channel 1 data*/
    FSINGLE	m_fChannel2Data;	/*!< ADC Channel 2 data*/
    FSINGLE	m_fTime;			/*!< Calculated time value*/
}PACK_ATTRIBUTE SDPPCI755_RAWDATABUFFER, *PSDPPCI755_RAWDATABUFFER;

/**
*	\struct 	: _SDPPCI755_CALIBDETAILS
*	\brief  	:This structure is used get the calibration refference voltage
*
*/
typedef struct _SDPPCI755_CALIBDETAILS
{
    U32BIT      m_u32Index;		/*!< Predefined reference voltage selection*/
    FSINGLE	m_fReferenceVoltage; /*!< The voltage corresponding to the selected reference*/
}PACK_ATTRIBUTE SDPPCI755_CALIBDETAILS, *PSDPPCI755_CALIBDETAILS;


/**
*	\struct 	: _SDPPCI755_STATUS_REG
*	\brief  	:Thread info to store the status information
*
*/
typedef struct _SDPPCI755_STATUS_REG
{
    U8BIT m_u8CmdRdy;				/*!< It specifies command ready*/
    U8BIT m_u8SelfTestPassed;		/*!< It specifies selftest pass or fail*/
    U8BIT m_u8ModuleRdy;			/*!< It specifies module ready status*/
    U8BIT m_u8NoErr;				/*!< It specifies Module ready status*/
    U8BIT m_u8CmdExcd;				/*!< It specifies Module ready status*/
    U8BIT m_u8ErrInProcess;			/*!< It specifies Module ready status*/
    U8BIT m_u8AnalyzedDataRdy;		/*!< It specifies analyzed data ready */
    U8BIT m_u8RawDataRdy;			/*!< It specifies RAW data ready */
    U8BIT m_u8CalibrationFinished;	/*!< It specifies calibration finished or not*/
    U8BIT m_u8Dummy;
}PACK_ATTRIBUTE SDPPCI755_STATUS_REG, *PSDPPCI755_STATUS_REG;
PRAGMA_PACK_POP()

/****************************function  prototypes ******************************/
/*!
* \addtogroup Common_Functions List of common driver functions
* \brief This section details the general API implementations.
* @{
*/

/**
*\brief		 This function is used to find the total number of DP-PCI-755 device(s) present in the system
*
*\param[out] out_pu16TotalDevices	It specifies the output pointer to hold the number of DP-PCI-755 device(s) found
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output total devices pointer is null
*
*\par Pre-requisite Functions and it's sequence:
		This function does not have any pre-requisite function and can be called at any time if needed.
*/
S32BIT STDCALL DPPCI755_GetTotalDeviceFound(PU16BIT out_pu16TotalDevices);

/**
*\brief 	 This function is used to get pci details such as bus number, slot number, function number and channel number for the DP-PCI-755 device(s)
*
*\param[out]  out_pSAllDevLocDetails	It specifies the pointer to device location information of all detected boards. See ::_SDPPCI755_DEVICE_LOCATION for structure member description. This pointer should be capable of holding device locations specified in in_u16MaxDevices parameter.
*\param[in]   in_u16MaxDevices	It specifies the maximum number of device locations that can be stored in the buffer.
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output device location details structure pointer is null
*
*\par Pre-requisite Functions and it's sequence:
*		-# ::DPPCI755_GetTotalDeviceFound
*
*/
S32BIT STDCALL DPPCI755_GetAllDeviceLocations(PSDPPCI755_DEVICE_LOCATION out_pSAllDevLocDetails, U16BIT in_u16MaxDevices);

/**
*\brief 	  This function is used to open the DP-PCI-755 device and obtain the handle for that specified device. Further operations on the device can be performed using this handle. All the other operations related to the particular device can be performed only after this function is called successfully. A device once opened cannot be opened again before closing it (if it is not initialized as shared device). If the the device is initialized as shared after open by using ::DPPCI755_SetDeviceShare function, multiple open can be performed.
*
*\param[in]		in_pSDeviceOpenInfo		This structure pointer specifies the location details of the board number, which is to be opened. See ::_SDPPCI755_DEVICE_LOCATION for structure member description. The location details can be get from ::DPPCI755_GetAllDeviceLocations() function.
*\param[out]	out_phDeviceHandle		It specifies the pointer to hold output device handle
*
*\retval		::DPPCI755_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_POINTER is returned if the device locataion structure pointer is null
*\retval		::DPPCI755_ERR_DEVICE_BUSY is returned if the the device is already opened
*
*\par Pre-requisite Functions and it's sequence:
*		-# ::DPPCI755_GetTotalDeviceFound
*		-# ::DPPCI755_GetAllDeviceLocations
*
*/
S32BIT STDCALL DPPCI755_Open(PSDPPCI755_DEVICE_LOCATION in_pSDeviceOpenInfo, DP_DRV_HANDLE out_phDeviceHandle);

/**
*\brief 	  This function is used to close the device using the handle obtained during ::DPPCI755_Open() function call and to deallocate the memory which was allocated for handle. On calling the ::DPPCI755_Close API the device internal registers will be reset. If the device is initialized as shared device, the number of close should be matched with the number of open is called for the device.
*\note The device is to be closed at the time of terminating the application.
*
*\param[in]	 in_hHandle		It specifies the device handle which obtained from device open function
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_DEVICE_NOT_OPEN is returned if the device is not opened
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_GetTotalDeviceFound
*		-# ::DPPCI755_GetAllDeviceLocations
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_Close(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	  This function is used to reset only the internal FPGA registers. This will not affect the device memory. On reset, the device returns to the default state.
*
*\param[in]	 in_hHandle		It specifies the device handle which obtained from device open function
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_GetTotalDeviceFound
*		-# ::DPPCI755_GetAllDeviceLocations
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_Reset(DP_DRV_HANDLE in_hHandle);
 
/**
*\brief		This function is used to get opened device location details(PCI device information such as bus number, slot number, function number and channel number).
*
*\param[in]	 in_hHandle				It specifies the device handle which obtained from device open function
*\param[out] out_pSDeviceLocation	It specifies the pointer to hold the device location details. See ::_SDPPCI755_DEVICE_LOCATION for structure member description.
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output device location pointer is null
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_GetTotalDeviceFound
*		-# ::DPPCI755_GetAllDeviceLocations
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_GetDeviceLocation(DP_DRV_HANDLE in_hHandle, PSDPPCI755_DEVICE_LOCATION out_pSDeviceLocation);

/**
*\brief 	  This function is used to obtain the error message corresponding to the error code specified. Usually this function is called when any other driver function returns with an error, i.e., returns with a value other than 0 (success). The non-zero value is mentioned as error code.
*
*\param[in]  in_s32ErrCode	It specifies the error code returned by the functions
*\param[out] out_ps8ErrMsg	It specifies the pointer to hold the error message(size:in_u16BufSize)
*\param[in]  in_u16BufSize	It specifies the size (in bytes) of the buffer which includes string termination character ('\0').
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output error message pointer is null
*
*\par Pre-requisite Functions and it's Sequence:
* This function does not have any pre-requisite function and can be called at any time if needed. Usually this function will be called whenever other driver function returns with error.
*
*/
S32BIT STDCALL DPPCI755_GetErrorMessage(S32BIT in_s32ErrCode, PS8BIT out_ps8ErrMsg, U16BIT in_u16BufSize);

/**
*\brief 	 This function is used to get the driver details(Driver Version)
*
*\param[out] out_pSDriverDetails	It specifies the structure pointer to read the driver details. See ::_SDPPCI755_DRIVER_DETAILS for structure member description.(driver version)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output driver details pointer is null
*
*\par Pre-requisite Functions and it's Sequence:
* This function does not have any pre-requisite function and can be called at any time if needed.
*
*/
S32BIT STDCALL DPPCI755_GetDriverDetails(PSDPPCI755_DRIVER_DETAILS out_pSDriverDetails);

/**
*\brief 	 This function is used to get the firmware version
*
*\param[out] out_pu32FirmVersion	It specifies the output pointer read the Firmware version
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output firmware version pointer is null
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_GetTotalDeviceFound
*		-# ::DPPCI755_GetAllDeviceLocations
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_GetFirmwareVersion(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32FirmVersion);

/**
*\brief		This function is used to write double word data into the specified FPGA register offset
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	in_u8BarNo			It specifies the bar number to access FPGA register(max:5)
*\param[in]	in_u32Offset		It specifies the offset value of selected device
*\param[in] in_u32WrDWordData	It specifies the the double word data to be written in specified register offset
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPPCI755_ERR_INVALID_BARNO is returned if the FPGA bar number is out of limit(0 to 5)
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_GetTotalDeviceFound
*		-# ::DPPCI755_GetAllDeviceLocations
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_WriteDWord(DP_DRV_HANDLE in_hHandle, U8BIT in_u8BarNo, U32BIT in_u32Offset, U32BIT in_u32WrDWordData);

/**
*\brief		This function is used to read double word data from the specified FPGA register offset
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]	 in_u8BarNo				It specifies the bar number to access FPGA register(max:5)
*\param[in]	 in_u32Offset			It specifies the offset value of selected device
*\param[out] out_pu32RdDWordData	It specifies the pointer to read double word data from specified register offset
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPPCI755_ERR_INVALID_BARNO is returned if the FPGA bar number is out of limit(0 to 5)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read double word data output pointer is null
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_GetTotalDeviceFound
*		-# ::DPPCI755_GetAllDeviceLocations
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_ReadDWord(DP_DRV_HANDLE in_hHandle, U8BIT in_u8BarNo, U32BIT in_u32Offset, PU32BIT out_pu32RdDWordData);

/**
*\brief 	This function is used to write a double word to the given location
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in] in_u8BarNo	It specifies the Bar number(max:5)
*\param[in] in_u32Offset	It specifies the offset value
*\param[in] in_u32Bytes		It specifies the no of bytes
*\param[in] in_pu32Data		It specifies the data to be written(size:in_u32Bytes)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the write memory block data pointer is null
*\retval	::DPPCI755_ERR_INVALID_BARNO is returned if the FPGA bar number is out of limit(0 to 5)
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_GetTotalDeviceFound
*		-# ::DPPCI755_GetAllDeviceLocations
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_WriteMemBlock(DP_DRV_HANDLE in_hHandle, U8BIT in_u8BarNo, U32BIT in_u32Offset, U32BIT in_u32Bytes, PU32BIT in_pu32Data);

/**
*\brief This function is used to read a double word from the given location
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in] in_u8BarNo	It specifies the Bar number(max:5)
*\param[in] in_u32Offset	It specifies the offset value of selected channel
*\param[in] in_u32Bytes		It specifies the no of bytes
*\param[out] out_pu32Data	It specifies the pointer to get read value(size:in_u32Bytes)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPPCI755_ERR_INVALID_BARNO is returned if the FPGA bar number is out of limit(0 to 5)
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_GetTotalDeviceFound
*		-# ::DPPCI755_GetAllDeviceLocations
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_ReadMemBlock(DP_DRV_HANDLE in_hHandle, U8BIT in_u8BarNo, U32BIT in_u32Offset, U32BIT in_u32Bytes, PU32BIT out_pu32Data);

/**
*\brief		This function is used to enable or disable(1 - Enable, 0 - Disable) the device share 
option(opening same device more than one time)
*
*\param[in]	in_hHandle		It specifies the device handle which obtained from device open function
*\param[in]	in_u8EnDis		It specifies the enable / disable value(max:1)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPPCI755_ERR_INVALID_ENDIS is returned if the enable / disable device share option is out of limit(0 to 1)
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_GetTotalDeviceFound
*		-# ::DPPCI755_GetAllDeviceLocations
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_SetDeviceShare(DP_DRV_HANDLE in_hHandle, U8BIT in_u8EnDis);
/*!
* @}
*/

/******************************* Board Specific ************************************/
/*!
*	\addtogroup Board_Functions List of device specific driver functions
* \brief This section details the device specific API implementations.
* @{
*/

/**
*\brief		This function will set the system in two different modes like Master mode or Slave mode.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_u8MSMode		It specifies the mode of operation(min:1 to max:2)(Where, 1 - Master Mode  and 2 - Slave Mode)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_MSMODE is returned if the mode selection is out of limit(1 to 2)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_SetModeRegister(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MSMode);

/**
*\brief		This function is used to set the amplitude and the bias voltage of the waveform. The unit for the voltage can be selected as either linear voltage or RMS voltage. This function is not applicable for arbitrary waveform.
*
*\note		The final amplitude value should be the summation of amplitude and bias multiplied by gain. The gain can take values of 1, 10, 100 and 1000 which can be set using the function DPPCI755_SetGain(). Hence the values amplitude, bias and gain should be given in such a way that the final amplitude value should not exceed the limit from -10 and +10.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_fAmplitude	It specifies the amplitude of voltage to generate a waveform by DAC. - Limit for Linear type -10.5 to 10.5 - Limit for RMS type -7.071067 and 7.071067.
*\param[in]	in_fBias		It specifies the bias voltage used to generate a waveform by DAC(min:-10.5 to max:10.5)
*\param[in]	in_u8AmpUnit	It specifies the type of amplitude and bias voltage(max:1)(Where, 0 - Linear and 1 - RMS) 
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_AMPLITUDE is returned if the amplitude value is out of limit(-10.5 to 10.5) in case of linear amplitude type and limit(-7.071067 to 7.071067) in case of RMS amplitude type
*\return	::DPPCI755_ERR_INVALID_BIAS is returned if the bias voltage is out of limit(-10.5 to 10.5)
*\return	::DPPCI755_ERR_INVALID_AMPLITUDE_BIAS_VOLT is returned if the sum of both the amplitude and bias voltage is out of limit(-10.5 to 10.5)
*\return	::DPPCI755_ERR_INVALID_AMPUNIT is returned if the amplitude unit is out of limit(0 to 1)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetFrequency
*		-# ::DPPCI755_SetTime
*		-# ::DPPCI755_SetStartAngle
*		-# ::DPPCI755_SetStopAngle
*		-# ::DPPCI755_SetDelay
*
*/
S32BIT STDCALL DPPCI755_SetAmplitudeBias(DP_DRV_HANDLE in_hHandle, FSINGLE in_fAmplitude, FSINGLE in_fBias, U8BIT in_u8AmpUnit);

/**
*\brief		This function is used to set the gain value of the waveform. The amplitude of waveform is based on this gain that is the summation of both amplitude and bias will be multiplied by selected gain. The final value should be between -10 and 10.
*
*\note		This function is not applicable for Arbitrary Waveform.
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	in_u8ADCChannelNo	It specifies the ADC channel number(min:1 to max:2)
*\param[in]	in_u8Gain			It specifies the gain value(max:3)(Where, 0 - Gain 1, 1 - Gain 10, 2 - Gain 100 and 3 - Gain 1000)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_ADCCHANNELNO is returned if the ADC channel number is out of limit(1 to 2)
*\return	::DPPCI755_ERR_INVALID_GAIN is returned if the gain value is out of limit(0 to 3)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetFrequency
*		-# ::DPPCI755_SetTime
*		-# ::DPPCI755_SetStartAngle
*		-# ::DPPCI755_SetStopAngle
*		-# ::DPPCI755_SetDelay
*		-# ::DPPCI755_SetAmplitudeBias
*
*/
S32BIT STDCALL DPPCI755_SetGain(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ADCChannelNo, U8BIT in_u8Gain);

/**
*\brief		This function is used to set the frequency for waveform by specifying start frequency, end frequency, step frequency, and unit of step frequency.
*
*\note		This function is applicable for sine Waveform.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_fStartFreq	It specifies the start frequency in Hz to generate waveform(min:0.001 to max:2000)
*\param[in]	in_fEndFreq		It specifies the end frequency in Hz to generate waveform(min:0.001 to max:2000)
*\param[in]	in_fStepSize    It specifies the step frequency(End frequency - start frequency) should be less than from zero
*\param[in]	in_u8FreqUnit	It specifies the step size type(max:1)(Where, 0 - Linear Step Size and 1 - Logarithmic Step Size)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_STARTFREQ is returned if the start frequency is out of limit(0.001 Hz to max:2000 Hz)
*\return	::DPPCI755_ERR_INVALID_ENDFREQ is returned if the end frequency is out of limit(0.001 Hz to max:2000 Hz)
*\return	DPPCI755_ERR_INVALID_STEPSIZE	
*\return	::DPPCI755_ERR_INVALID_FREQUENCY_UNIT is returned if the frequency unit is out of limit(0 to 1)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetWaveform
*
*/
S32BIT STDCALL DPPCI755_SetFrequency(DP_DRV_HANDLE in_hHandle, FSINGLE in_fStartFreq, FSINGLE in_fEndFreq, FSINGLE in_fStepSize, U8BIT in_u8FreqUnit);

/**
*\brief		This function is used to set the time period of ON pulse duration for waveform.
*
*\note		This function is applicable for square waveform or ramp waveform.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_fTime    	It specifies the time period in seconds for ON pulse of the pulse waveform(min:0.0005 to max:1000)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_TIME is returned if the ON pulse time period is out of limit(0.0005 Sec to 1000 Sec)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_SetNoOfCycles
*
*/
S32BIT STDCALL DPPCI755_SetTime(DP_DRV_HANDLE in_hHandle, FSINGLE in_fTime);

/**
*\brief		This function is used to set the sweep cycle for waveform. For instance, if the number of cycles is set to three, each frequency will have three cycles. If the number of cycle is zero, it will be considered as continuous waveform sweep.
*
*\note		This function is not applicable for arbitrary waveform.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_u16NoOfCycle	It specifies the number of cycles in the same frequency of the waveform. If it is zero then the waveform will be configured as continuous waveform(max:1000)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_NOOFCYCLE is returned if the number of cycles value is out of limit(0 to 1000)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetFrequency
*		-# ::DPPCI755_SetTime
*
*/
S32BIT STDCALL DPPCI755_SetNoOfCycles(DP_DRV_HANDLE in_hHandle, U16BIT in_u16NoOfCycle);

/**
*\brief		This function is used to increase the delay period between the two frequencies in terms of cycles or seconds. If the delay is in terms of cycle(s), there is an addition delay cycle(s) between two consecutive frequencies. If the delay is in terms of second(s), each cycle is multiplied with delay value
*
*\note		This function is applicable for square, sine, or ramp waveform.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_fDelay		It specifies the how many cycles the acquisitions are present in wait state after issuing the start command. If the delay is in terms of number of cycles then the delay ranges between 0 and 20 cycles and if the delay is in terms of seconds, then the valid range is between 0 sec and 1000 sec.(max:1000)
*\param[in]	in_u8DelayType	It specifies the delay in terms of cycles or seconds(max:1)(Where, 0 - Cycles and 1 - Seconds) 
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_DELAY is returned if the delay time is out of limit(0 to 1000)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetFrequency
*		-# ::DPPCI755_SetTime
*		-# ::DPPCI755_SetStartAngle
*		-# ::DPPCI755_SetStopAngle
*
*/
S32BIT STDCALL DPPCI755_SetDelay(DP_DRV_HANDLE in_hHandle, FSINGLE in_fDelay, U8BIT in_u8DelayType);

/**
*\brief		This function is used to set the waveform type to generate the waveform from DAC.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_u8Waveform	It specifies the types of waveform to be generated(min:1 to max:5)(Where, 1 - Sine Wave, 2 - Ramp Wave, 3 - Square Wave, 4 - Not Used and 5 - Arbitrary Wave)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_WAVEFORM is returned if the waveform type selection is out limit(1 to 5)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetRelayOnOff
*
*/
S32BIT STDCALL DPPCI755_SetWaveform(DP_DRV_HANDLE in_hHandle, U8BIT in_u8Waveform);

/**
*\brief		This function is used to set the start angle of the waveform. The waveform generation starts with the specified start angle for the first cycle. If the start angle is set to 30 degree, the waveform will start with 30 degree.
*
*\note		This function is applicable for square waveform or sine waveform.
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	in_u16StartAngle	It specifies the start angle in degree(max:360)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_STARTANGLE is returned if the start angle value is out of limit(0 degree to 360 degree)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetFrequency
*		-# ::DPPCI755_SetTime
*
*/
S32BIT STDCALL DPPCI755_SetStartAngle(DP_DRV_HANDLE in_hHandle, U16BIT in_u16StartAngle);

/**
*\brief		This function is used to set the stop angle of the waveform. The waveform generation ends with the stop angle specified. If the stop angle is set to 90 degree, the waveform will end with 90 degree.
*
*\note		This function is applicable for square waveform or sine waveform.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_u16StopAngle	It specifies the stop angle in degree(max:360)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_STOPANGLE is returned if the stop angle value is out of limit(0 degree to 360 degree)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetFrequency
*		-# ::DPPCI755_SetTime
*		-# ::DPPCI755_SetStartAngle
*
*/
S32BIT STDCALL DPPCI755_SetStopAngle(DP_DRV_HANDLE in_hHandle, U16BIT in_u16StopAngle);

/**
*\brief		This function is used to set the waveform parameters for the arbitrary waveform. The arbitrary waveform can also be used for the profile generation. The arbitrary waveform parameters are defined in arbitrary waveform structure. The structure should be used to set the waveform parameters. The arbitrary waveform supports two types of segments - Arbitrary Waveform Segment and Sine Waveform Segment.
*
*\note		This function must be invoked in the event of arbitrary waveform is selected.
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	in_u8NoOfSegments	It specifies the total segment count of the arbitrary waveform(min:1 to max:64)
*\param[in]	in_pSArbitraryWave	It specifies the information for arbitary wave(size:in_u8NoOfSegments)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_NO_SEGMENTS is retuned if number of segments is out of limit(1 to 64)
*\return	::DPPCI755_ERR_INVALID_AMPLITUDE is returned if start amplitude value is out of limit(-10.5 to 10.5)
*\return	::DPPCI755_ERR_INVALID_BIAS_VOLTis returned if stop amplitude value is out of limit(-10.5 to 10.5)
*\return	::DPPCI755_ERR_INVALID_START_FREQ	is returned if frequency is out of limit(0.001 to 2000Hz)
*\return	::DPPCI755_ERR_INVALID_TIME is returned if time value is out of limit(0.0005 to 1000)
*\return	::DPPCI755_ERR_INVALID_STOP_ANGLE is returned if the stop angle out of limit(0 to 360)Degree
*\return	::DPPCI755_ERR_INVALID_START_ANGLE is returned if the start angle out of limit(0 to 360)Degree
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetWaveform
*
*/
S32BIT STDCALL DPPCI755_SetArbitraryWaveform(DP_DRV_HANDLE in_hHandle, U8BIT in_u8NoOfSegments, PSDPPCI755_ARBITRARYWAVEFORM in_pSArbitraryWave);

/**
*\brief		This function is used to set the ADC reference voltage with respect to the ADC gain selection. The ADC input reference level is sent to the driver with the ADC measured voltage.
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	in_u8ADCChannelNo	It specifies ADC channel number(min:1 to max:2)
*\param[in]	in_pSCalibDetails	It specifies the calibration information
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_ADCCHANNELNO is returned if the ADC channel number is out of limit(1 to 2)
*\return	::DPPCI755_ERR_INVALID_REFVOLT_SEL	is returned if the reference voltage selection is out of limit(0 to 5)
*\return	::DPPCI755_ERR_INVALID_REFVOLT		is returned if the reference voltage is out of limit(-10.0 to 10.0)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetWaveform
*
*/
S32BIT STDCALL DPPCI755_SetRefVoltage(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ADCChannelNo, PSDPPCI755_CALIBDETAILS in_pSCalibDetails);

/**
*\brief		This function is used to issue a command to the firmware to do the calibration for the specified ADC channel in two different modes. If calibration mode is internal, the reference voltage will be predefined voltage. If calibration mode is external then, the user should give the reference voltage corresponding to the predefined reference voltage.
*
*\param[in]	in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]	in_u8ADCChannelNo		It specifies the ADC channel number(min:1 to max:2)
*\param[in]	in_u8CalibrationMode	It specifies the Calibration mode(max:1)(Where, 0 - Internal and 1 - External)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_ADCCHANNELNO is returned if the ADC channel number is out of limit(1 to 2)
*\return	::DPPCI755_ERR_INVALID_CALIB_MODE is returned if the calibration mode is out of limit(0 to 1)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetRefVoltage
*		-# ::DPPCI755_SetGain
*
*/
S32BIT STDCALL DPPCI755_DoADCCalibration(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ADCChannelNo, U8BIT in_u8CalibrationMode);

/**
*\brief		The store calibration function is to store the ADC calibration values to the EEPROM. In this call the calibration data in the global memory of the firmware for ADC gets stored to the EEPROM. So before the calibration is stored to the EEPROM the calibration constants in the global memory of the firmware can be read using the function DPPCI755_GetADCCalibration() call
*
*\note		Calling this function would load whatever data in the global memory of the firmware to the EEPROM. So utmost care has to be taken that the Store command is given only after a calibration of the EEPROM is done and the Reset should not be given before the Store Calibration command which will reset the entire data in the firmware global memory to default calibration values of slope as 1 and constant as 0.
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_IN_CALIBRATION is returned if calibration is in progress.
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_DoADCCalibration
*
*/
S32BIT STDCALL DPPCI755_StoreCalibration(DP_DRV_HANDLE in_hHandle);

/**
*\brief		This function is used to set the input voltage value to the DAC. This call is mainly used in the DAC calibration for setting the DAC input voltage for the OFFSET and the RAM DAC. For the RAM DAC this function is to be used along with the arbitrary waveform configuration for the RAM DAC output voltage
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	in_u8RefLvl		It specifies the level of measured voltage with respect to gain value(min:1 to max:3).
*\param[in]	in_fInputVoltage	It specifies the input voltage(min:-10 to max:10)
*\param[in]	in_u8DACType		It specifies the DAC selection type(max:1)(Where 0 - Offset DAC, 1 - RAM DAC)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_REF_LEVEL is returned if reference level selection is out of limit(1 to 3)
*\return	::DPPCI755_ERR_INVALID_DAC_INPUT_VOLT	is returned if DAC input voltage is out of limit(-10 to 10)
*\return	::DPPCI755_ERR_INVALID_DAC_TYPE is returned if DAC selection type is out of limit(0 to 1)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetWaveform
*
*/
S32BIT STDCALL DPPCI755_SetDACInputVoltage(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RefLvl, FSINGLE in_fInputVoltage, U8BIT in_u8DACType);

/**
*\brief		This function is used to set the measured DAC voltage in the driver for DAC calibration to  corresponding applied input voltage. The voltage level parameter in the driver call is used as the low level reference and the high reference. For the low reference value the voltage measured for zero volt input for both the DAC. For RAM DAC the high reference selection is passed as 2 and voltage is measured as 9 volt. For the OFFSET DAC the high reference selection is passed as 3 and voltage measured is 9 volt.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_u8RefLvl		It specifies the ref. level(min:1 to max:3)
*\param[in]	in_fMeasVoltage	It specifies the measured voltage(min:-10 to max:10)
*\param[in]	in_u8DACType	It specifies the DAC type(max:1)(Where 0 - Offset DAC, 1 - RAM DAC)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_REF_LEVEL is returned if reference level selection is out of limit(1 to 3)
*\return	::DPPCI755_ERR_INVALID_MEASVOLTAGE is returned if DAC measured voltage is out of limit(-10 to 10)
*\return	::DPPCI755_ERR_INVALID_DAC_TYPE is returned if DAC selection type is out of limit(0 to 1)
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetDACInputVoltage
*
*/
S32BIT STDCALL DPPCI755_SetDACMeasuredVoltage(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RefLvl, FSINGLE in_fMeasVoltage, U8BIT in_u8DACType);

/**
*\brief		This function is used to start the DAC calibration for the RAM DAC and the OFFSET DAC and load the calibrated data to the EEPROM. Before performing the calibration, apply input and measured voltages for both levels.
*
*\param[in] in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_u8DACType	It specifies the DAC type(max:1)(Where 0 - Offset DAC, 1 - RAM DAC)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetDACInputVoltage
*		-# ::DPPCI755_SetDACMeasuredVoltage
*
*/
S32BIT STDCALL DPPCI755_DoDACCalibration(DP_DRV_HANDLE in_hHandle, U8BIT in_u8DACType);

/**
*\brief		This function is used to issue a command to the DSP to start / stop waveform generation and acquisition.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_u8Status	    It specifies enable or disable the acquisition(max:1)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_STATUS is returned if the acquisition enable/disable value is out of limit(0 to 1)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetRelayOnOff
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetGain
*		-# ::DPPCI755_SetNoOfCycles
*		-# ::DPPCI755_SetDelay
*		-# ::DPPCI755_SetTime
*		-# ::DPPCI755_SetStartAngle
*		-# ::DPPCI755_SetStopAngle
*		-# ::DPPCI755_SetAmplitudeBias
*	
*
*/
S32BIT STDCALL DPPCI755_StartStopAcquisition(DP_DRV_HANDLE in_hHandle, U8BIT in_u8Status);

/**
*\brief		This function is used to read the analyzed data(i.e. frequency, gain and the phase difference) from the DPRAM analyzed data memory.
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_pu32DataCount	    It specifies to hold read data count
*\param[out] out_pSAnaDataBuffer    It specifies the analyzed data buffer
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DP_DRV_ERR_INVALID_POINTER is returned if the output pointer is null
*\return	::DPPCI755_ERR_INVALID_OPTIONS is returned if the option value is out of limit(max:1)
*\return	::DPPCI755_ERR_BUFFER_NOT_FULL is returned if buffer is not full
*\return	::DPPCI755_ERR_SWEEP_FINISHED	is returned if sweep is not finished
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetRelayOnOff
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetGain
*		-# ::DPPCI755_SetNoOfCycles
*		-# ::DPPCI755_SetDelay
*		-# ::DPPCI755_SetTime
*		-# ::DPPCI755_SetStartAngle
*		-# ::DPPCI755_SetStopAngle
*		-# ::DPPCI755_SetAmplitudeBias
*		-# ::DPPCI755_StartStopAcquisition
*
*/
S32BIT STDCALL DPPCI755_ReadSineWaveData(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32DataCount, PSDPPCI755_ANALYZEDDATABUFFER out_pSAnaDataBuffer);

/**
*\brief		This function is used read the raw data in bulk(i.e. channel 1 data and channel 2 data) from the DPRAM raw data memory.
*
*\param[in]  in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_pSRawDataBuffer	It specifies the output structure pointer to hold the Raw data buffer
*\param[out] out_pu32DataCount		It specifies the output pointer to hold the read data count
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DP_DRV_ERR_INVALID_POINTER is returned if the output data count pointer is null
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetRelayOnOff
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetGain
*		-# ::DPPCI755_SetNoOfCycles
*		-# ::DPPCI755_SetDelay
*		-# ::DPPCI755_SetTime
*		-# ::DPPCI755_SetStartAngle
*		-# ::DPPCI755_SetStopAngle
*		-# ::DPPCI755_SetAmplitudeBias
*		-# ::DPPCI755_StartStopAcquisition
*
*/
S32BIT STDCALL DPPCI755_ReadRawData(DP_DRV_HANDLE in_hHandle, PSDPPCI755_RAWDATABUFFER out_pSRawDataBuffer, PU32BIT out_pu32DataCount);

/**
*\brief		This function is used to read the current analyzed data for Sine Waveform(i.e. Frequency, Gain and Phase Difference) from the DPRAM
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_psAnalyzedData It specifies the data buffer
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DP_DRV_ERR_INVALID_POINTER is returned if the analyzed data pointer is null
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetRelayOnOff
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetGain
*		-# ::DPPCI755_SetNoOfCycles
*		-# ::DPPCI755_SetDelay
*		-# ::DPPCI755_SetTime
*		-# ::DPPCI755_SetStartAngle
*		-# ::DPPCI755_SetStopAngle
*		-# ::DPPCI755_SetAmplitudeBias
*		-# ::DPPCI755_StartStopAcquisition
*
*/
S32BIT STDCALL DPPCI755_ReadCurrentData(DP_DRV_HANDLE in_hHandle, PSDPPCI755_ANALYZEDDATABUFFER out_psAnalyzedData);

/**
*\brief		The function is used to read the ADC value from the DPRAM after the acquisition is finished. This function can be called to read the last ADC value.
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*\param[out] out_pfADCValue	It specifies the ADC data
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DP_DRV_ERR_INVALID_POINTER is returned if the ADC value pointer is null
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*		-# ::DPPCI755_SetRelayOnOff
*		-# ::DPPCI755_SetWaveform
*		-# ::DPPCI755_SetGain
*		-# ::DPPCI755_SetNoOfCycles
*		-# ::DPPCI755_SetDelay
*		-# ::DPPCI755_SetTime
*		-# ::DPPCI755_SetStartAngle
*		-# ::DPPCI755_SetStopAngle
*		-# ::DPPCI755_SetAmplitudeBias
*		-# ::DPPCI755_StartStopAcquisition
*
*/
S32BIT STDCALL DPPCI755_ReadADCValue(DP_DRV_HANDLE in_hHandle, PFSINGLE out_pfADCValue);

/**
*\brief		This function is used to obtain the status information from the DPRAM status register. The status is needed to check periodically to issue next command. If command not ready / module not ready is set, next command should not be issued.
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pSStatusReg	It specifies the status to issue the next command.
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DP_DRV_ERR_INVALID_POINTER is returned if the status structure pointer is null
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_GetStatusRegister(DP_DRV_HANDLE in_hHandle, PSDPPCI755_STATUS_REG out_pSStatusReg);

/**
*\brief		This function is used to read the status of selftest, i.e selftest is pass / fail.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_SelfTest(DP_DRV_HANDLE in_hHandle);

/**
*\brief		This function is used to switch ON/OFF the relay . The relay should be switched ON before starting the acquisition.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_u8RelayOnOff	It specifies the relay On/Off status(max:1)(Where, 0 - Relay OFF and 1 - Relay ON)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_RELAYONOFF is returned if the relay status is out of limit(0 to 1)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_SetRelayOnOff(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RelayOnOff);

/**
*\brief		This function is used to reduce the bias voltage level from the current voltage level. The voltage specified will be reduced from the current voltage level.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_fBiasVolt	It specifies the bias voltage value that has to be reduced from the current bias voltage value(min:-10.5 to max:10.5)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_BIASVOLT is returned if the bias voltage value is out of limit(-10.5 to 10.5)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_ResetBias(DP_DRV_HANDLE in_hHandle, FSINGLE in_fBiasVolt);

/**
*\brief		This function is used to enable the bias reset option. The bias reset option should be enabled to reduce the bias voltage level.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_u8Status		It specifies the enable / disable bias(max:1)
*
*\retval	::DPPCI755_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPCI755_ERR_INVALID_STATUS is returned if the enable or disable status is out of limit(0 to 1)
*\return	::DPPCI755_ERR_MODULE_BUSY is returned if the module is busy
*
*\par Pre-requisite Functions and it's Sequence:
*		-# ::DPPCI755_Open
*
*/
S32BIT STDCALL DPPCI755_EnableBiasReset(DP_DRV_HANDLE in_hHandle, U8BIT in_u8Status);
/*!
* @}
*/
#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif

#endif
