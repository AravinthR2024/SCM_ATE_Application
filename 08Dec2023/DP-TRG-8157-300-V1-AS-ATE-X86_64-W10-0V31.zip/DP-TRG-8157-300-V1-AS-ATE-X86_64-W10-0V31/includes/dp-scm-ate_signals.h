/**
* \file dp-scm-ate_signals.h
* \brief This file contains the signal ID details for SCM ATE System
*
* \author Giriprakash K
* \date  18 Nov, 2022
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef _DP_SCM_ATE_SIGNALS_H_
#define _DP_SCM_ATE_SIGNALS_H_

/* Maximum boards */

	#define SCM_ATE_MAX_PCI755_BRDS		1
	#define SCM_ATE_MAX_XMC5775_BRDS	1

    #define SCM_ATE_MAX_PCI755_CHN      2

    #define SID_GET_CHANNEL(usSignalId) 	(usSignalId & 0x00FF)       	/* get the Channel number from the signal ID (bit 0 to 7) */
	#define SID_GET_BOARD_NUM(usSignalId) 	((usSignalId >> 8) & 0x000F) 	/* get the board number from the signal ID (bit 8 to 11)*/
    #define SID_GET_BOARD_ID(usSignalId) 	((usSignalId >> 12) & 0x000F) 	/* get the board ID from the signal ID (bit 12 to 15)*/
	
	/* To define unique signal ID based on Channel number, board number & board ID */
	/* In signal ID the 8th to 11th bits are used as board number for corresponding channel */
	#define SID_BOARD_1			0x0100 	/* 1st board */
	#define SID_BOARD_2			0x0200 	/* 2nd board */
	#define SID_BOARD_3			0x0300	/* 3rd board */
	#define SID_BOARD_4			0x0400	/* 4th board */
	#define SID_BOARD_5			0x0500	/* 5th board */
	#define SID_BOARD_6			0x0600 	/* 6th board */
	#define SID_BOARD_7			0x0700  /* 7th board */
	#define SID_BOARD_8			0x0800  /* 8th board */
	#define SID_BOARD_9			0x0900  /* 9th board */
    #define SID_BOARD_10        0x0A00  /* 10th board */

	/* In signal ID the bit 12 to 15 are used as board ID */
    #define BRD_PCI755_FRA_RES		0x1000  /* DP-PCI-755 - FRA Response from SCM */
    #define BRD_PCI755_FRA_DEM		0x2000  /* DP-PCI-755 - FRA Demand to SCM */
    #define BRD_XMC5775_RS422       0x3000  /* DP-XMC-5775 - RS422 */
	
    #define BRD_TYPE_PCI755_FRA		0x1     /* DP-PCI-755 - FRA */
    #define BRD_TYPE_XMC5775_RS422  0x2	/* DP-XMC-5775 - RS422 */

/* ############################################################################################################## */

	/*********  Signal ID  **************************  Channel Mapping  **************  Description  *************/
	
/* DP-PCI-755 - Frequency Response Analyser */			                             	
    #define	FRA_AI_MON_CH1_RESPONSE     ( BRD_PCI755_FRA_RES + SID_BOARD_1 + 1 )	/* SCM Response Monitoring Channel-1 */
    #define	FRA_AI_MON_CH2_RESPONSE     ( BRD_PCI755_FRA_RES + SID_BOARD_1 + 2 )	/* SCM Response Monitoring Channel-2 */
    #define	FRA_AO_CURR_DEMAND			( BRD_PCI755_FRA_DEM + SID_BOARD_1 + 1 )	/* Current Demand to SCM System */
/* ############################################################################################################## */

#endif //_DP_SCM_ATE_SIGNALS_H_
