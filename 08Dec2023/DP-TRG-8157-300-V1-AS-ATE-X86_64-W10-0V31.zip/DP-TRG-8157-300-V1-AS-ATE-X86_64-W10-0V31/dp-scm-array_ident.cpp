#include "dp-scm-array_ident.h"
#include "ui_dp-scm-array_ident.h"
#include "dp-scm-mainwindow.h"

extern S_GLOBAL g_SGlobal;

CArrayIdentVerification::CArrayIdentVerification(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CArrayIdentVerification)
{
    ui->setupUi(this);

    memset(&m_UCommand[0], 0, sizeof(U_DEM_PORT_TX));
    memset(&m_UResponse[0], 0, sizeof(U_DEM_PORT_RX));
    memset(&m_UCommand[1], 0, sizeof(U_DEM_PORT_TX));
    memset(&m_UResponse[1], 0, sizeof(U_DEM_PORT_RX));

    m_pthArrayIdent_RGA = new CArrayIdentThread(this, ARRIDENT_MODE_AZ_IDENT);

    ui->leRGAResp_AzPos->clear();
    ui->leRGAResp_BITFault->clear();
    ui->leRGAResp_DiagData->clear();
    ui->leRGAResp_DiagID->clear();
    ui->leRGAResp_FarEndCS->clear();
    ui->leRGAResp_IndSensorPos->clear();

    ui->lbStart1->setText(ui->pbStart1->toolTip());
    ui->lbStart2->setText(ui->pbStart2->toolTip());
    ui->lbSend3->setText(ui->pbSend3->toolTip());
    ui->lbSend4->setText(ui->pbSend4->toolTip());

    ui->cmbRGACmd_Mode->setCurrentIndex(DP_SCM_POS_MODE);
    ui->cmbRGACmd_ArrayIdent->setCurrentIndex(DP_SCM_ARRAY_ID_OSPREY_20);
    ui->sbRGACmd_DiagID->setValue(ID_15);

    connect (m_pthArrayIdent_RGA, SIGNAL(sig_updateRGAResponse(U_DEM_PORT_RX)), this, SLOT(slot_updateRGAResponse(U_DEM_PORT_RX)));
    connect (m_pthArrayIdent_RGA, SIGNAL(sig_updateRTGAResponse(U_DEM_PORT_TX)), this, SLOT(slot_updateRTGAResponse(U_DEM_PORT_TX)), Qt::BlockingQueuedConnection);
    connect (m_pthArrayIdent_RGA, SIGNAL(sig_updateButtonName(QString)), this, SLOT(slot_updateButtonName(QString)));
}

CArrayIdentVerification::~CArrayIdentVerification()
{
    delete ui;
}

void CArrayIdentVerification::slot_updateRGAResponse(U_DEM_PORT_RX in_UResponse)
{
    short sAzResponse = DPSCM_INIT_0;
    float fAzPositionResponse = 0.0f;

    sAzResponse = in_UResponse.m_S_RGAResp.m_ucByte3_AzPosition_1_0 & 0x03;
    sAzResponse |= ((in_UResponse.m_S_RGAResp.m_ucByte2_AzPosition_8_2 & 0x7F) << 2);
    sAzResponse |= ((in_UResponse.m_S_RGAResp.m_ucByte1_AzPosition_15_9 & 0x7F) << 9);

    fAzPositionResponse = (sAzResponse * BIT_RESOLUTION_AZ_POS) / BIT_RESOLUTION_16BIT;

    ui->leRGAResp_AzPos->setText(QString::number(fAzPositionResponse));
    ui->leRGAResp_BITFault->setText(QString::number(in_UResponse.m_S_RGAResp.m_ucByte3_BIT_Fault));
    ui->leRGAResp_IndSensorPos->setText(QString::number(in_UResponse.m_S_RGAResp.m_ucByte3_AzIndSenPosition));
    ui->leRGAResp_DiagData->setText(QString::number((in_UResponse.m_S_RGAResp.m_ucByte4_BIT_DataVal & 0x7F), 16).toUpper());
    ui->leRGAResp_DiagID->setText(QString::number(in_UResponse.m_S_RGAResp.m_ucByte5_DiagnosticsID));
    ui->leRGAResp_FarEndCS->setText(QString::number(in_UResponse.m_S_RGAResp.m_ucByte6_FarEndCSErr));

    if ((in_UResponse.m_S_RGAResp.m_ucByte5_DiagnosticsID == ID_15) && ((in_UResponse.m_S_RGAResp.m_ucByte4_BIT_DataVal & 0x02) != DPSCM_INIT_0))
    {
        m_pthArrayIdent_RGA->Stop();
        ui->gbRGA_Command->setEnabled(true);
        ui->pbStart1->setText("Start (&1)");
    }
}

void CArrayIdentVerification::slot_updateRTGAResponse(U_DEM_PORT_TX in_UResponse)
{
        unsigned char ucStoreParam = in_UResponse.m_S_RGACmd.m_ucByte1_StrParameters;
        short sAzData = (in_UResponse.m_S_RGACmd.m_ucByte2_AzCmd_12_7 & 0x7F) << 7;
        unsigned char ucMode = in_UResponse.m_S_RGACmd.m_ucByte2_AzModeSel;
        unsigned char ucCW = in_UResponse.m_S_RGACmd.m_ucByte3_CW_UpEndStop;
        unsigned char ucCCW = in_UResponse.m_S_RGACmd.m_ucByte3_CCW_LowEndStop;
        unsigned char ucArrayIdent = in_UResponse.m_S_RGACmd.m_ucByte3_ArrayIdent;
        float fAzCommand = 0.0f;

        sAzData |= in_UResponse.m_S_RGACmd.m_ucByte4_AzCmd_6_0;// & 0x7F;

        if (ucCCW == 1 || ucCW == 1)
        {
            fAzCommand = (sAzData * BIT_RESOLUTION_AZ_POS) / BIT_RESOLUTION_13BIT;
        }
        else
        {
            if (ucMode == DP_SCM_RATE_MODE)
            {
                fAzCommand = (sAzData * BIT_RESOLUTION_RATE) / BIT_RESOLUTION_13BIT;
            }
            else
            {
                fAzCommand = (sAzData * BIT_RESOLUTION_AZ_POS) / BIT_RESOLUTION_13BIT;
            }
        }

        unsigned char ucDiagID = in_UResponse.m_S_RGACmd.m_ucByte5_DiagnosticsID;

        unsigned char ucCRC6CS = in_UResponse.m_S_RGACmd.m_ucByte6_Crc6_CS;

        ui->cbRGACmd_CCW->setChecked((ucCCW == 1) ? true : false);
        ui->cbRGACmd_CW->setChecked((ucCW == 1) ? true : false);
        ui->cbRGACmd_StoreParam->setChecked((ucStoreParam == 1) ? true : false);
        ui->cmbRGACmd_Mode->setCurrentIndex(ucMode);
        ui->sbRGACmd_AzCommand->setValue(fAzCommand);
        ui->cmbRGACmd_ArrayIdent->setCurrentIndex(ucArrayIdent);
        ui->sbRGACmd_DiagID->setValue(ucDiagID);

        unsigned char ucChecksum = DPSCM_INIT_0;
        dp_scm_crc6_checksum((unsigned char *)&in_UResponse.m_S_RGACmd, (sizeof(S_RGA_COMMAND) - 1), &ucChecksum);
        if (ucChecksum != ucCRC6CS)
        {
            QString qstr = QString();
            qstr.sprintf("Checksum Error [Exp: 0x%X :: Act: 0x%X]", ucChecksum, ucCRC6CS);
            sig_updateActionLog(qstr, LOG_ERROR);
        }
}

void CArrayIdentVerification::slot_updateRTGAResponse_Display(U_DEM_PORT_RX in_UResponse)
{
    unsigned char m_ucByte0_AzCmd_15_9      = DPSCM_INIT_0;
    unsigned char m_ucByte1_AzCmd_8_2       = DPSCM_INIT_0;
    unsigned char m_ucByte1_ElCmd_8_7       = DPSCM_INIT_0;
    unsigned char m_ucByte2_BITFault        = DPSCM_INIT_0;
    unsigned char m_ucByte2_AzCmd_0_1       = DPSCM_INIT_0;
    unsigned char m_ucByte3_ElCmd_6_0       = DPSCM_INIT_0;
    unsigned char m_ucByte4_BitDataVal      = DPSCM_INIT_0;
    unsigned char m_ucByte5_DiagnosticsID   = DPSCM_INIT_0;
    unsigned char m_ucByte6_Crc7_CS         = DPSCM_INIT_0;

    m_ucByte0_AzCmd_15_9      = in_UResponse.m_S_RTGAResp.m_ucByte0_AzCmd_15_9;
    m_ucByte1_AzCmd_8_2       = in_UResponse.m_S_RTGAResp.m_ucByte1_AzCmd_8_2;
    m_ucByte1_ElCmd_8_7       = in_UResponse.m_S_RTGAResp.m_ucByte1_ElCmd_8_7;
    m_ucByte2_BITFault        = in_UResponse.m_S_RTGAResp.m_ucByte2_BITFault;
    m_ucByte2_AzCmd_0_1       = in_UResponse.m_S_RTGAResp.m_ucByte2_AzCmd_0_1;
    m_ucByte3_ElCmd_6_0       = in_UResponse.m_S_RTGAResp.m_ucByte3_ElCmd_6_0;
    m_ucByte4_BitDataVal      = in_UResponse.m_S_RTGAResp.m_ucByte4_BitDataVal;
    m_ucByte5_DiagnosticsID   = in_UResponse.m_S_RTGAResp.m_ucByte5_DiagnosticsID;
    m_ucByte6_Crc7_CS         = in_UResponse.m_S_RTGAResp.m_ucByte6_Crc7_CS;

    short sAzCommand = DPSCM_INIT_0;
    short sElCommand = DPSCM_INIT_0;
    float fAzCommand = 0.0f;
    float fElCommand = 0.0f;

    sAzCommand = m_ucByte2_AzCmd_0_1 & 0x03;
    sAzCommand |= ((m_ucByte1_AzCmd_8_2 & 0x7F) << 2);
    sAzCommand |= ((m_ucByte0_AzCmd_15_9 & 0x7F) << 9);

    fAzCommand = (sAzCommand * BIT_RESOLUTION_AZ_POS) / BIT_RESOLUTION_13BIT;

    sElCommand = m_ucByte3_ElCmd_6_0 & 0x7F;
    sElCommand |= ((m_ucByte1_ElCmd_8_7 & 0x03) << 7);

    fElCommand = (sElCommand * BIT_RESOLUTION_EL_POS) / BIT_RESOLUTION_9BIT;

    ui->leRTGAResp_AzData->setText(QString::number(fAzCommand));
    ui->leRTGAResp_ElPos->setText(QString::number(fElCommand));
    ui->leRTGAResp_BITFault->setText(QString::number(m_ucByte2_BITFault));
    ui->leRTGAResp_DiagData->setText(QString::number(m_ucByte4_BitDataVal & 0x7F, 16).toUpper());
    ui->leRTGAResp_DiagID->setText(QString::number(m_ucByte5_DiagnosticsID));
    ui->leRTGAResp_CS->setText(QString::number(m_ucByte6_Crc7_CS, 16).toUpper());
}

void CArrayIdentVerification::slot_updateButtonName(QString in_qstrName)
{
    ui->pbStart2->setText(in_qstrName);
}

void CArrayIdentVerification::on_pbStart1_clicked()
{
    double dPos = DPSCM_INIT_0;
    short sAzCommand = DPSCM_INIT_0;
    unsigned char ucChecksum = DPSCM_INIT_0;

    CHECK_TC_RUNNING;

    if (ui->pbStart1->text().contains("Start (&1)"))
    {
        CHECK_PORT_OPEN(COMMAND_PORT_IDX)

        dPos = ui->sbRGACmd_AzCommand->value();
        if (ui->cbRGACmd_CCW->isChecked() || ui->cbRGACmd_CW->isChecked())
        {
            sAzCommand = (dPos * BIT_RESOLUTION_13BIT) / BIT_RESOLUTION_AZ_POS;
        }
        else
        {
            if (ui->cmbRGACmd_Mode->currentIndex() == DP_SCM_RATE_MODE)
            {
                sAzCommand = (dPos * BIT_RESOLUTION_13BIT) / BIT_RESOLUTION_RATE;
            }
            else
            {
                sAzCommand = (dPos * BIT_RESOLUTION_13BIT) / BIT_RESOLUTION_AZ_POS;
            }
        }

        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte0_MsgLength = sizeof(S_RGA_COMMAND) & 0x7F;
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte0_Bit7 = 1;

        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte1_Spare = 0;
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte1_StrParameters = ui->cbRGACmd_StoreParam->isChecked() ? 1 : 0;
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte1_Bit7 = 0;

        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte2_AzCmd_12_7 = (sAzCommand >> 7) & 0x3F;
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte2_AzModeSel = ui->cmbRGACmd_Mode->currentIndex();
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte2_Bit7 = 0;

        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte3_Spare = 0;
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte3_CW_UpEndStop = ui->cbRGACmd_CW->isChecked() ? 1 : 0;
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte3_CCW_LowEndStop = ui->cbRGACmd_CCW->isChecked() ? 1 : 0;
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte3_ArrayIdent = ui->cmbRGACmd_ArrayIdent->currentIndex();
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte3_Bit7 = 0;

        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte4_AzCmd_6_0 = sAzCommand & 0x7F;
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte4_Bit7 = 0;

        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte5_DiagnosticsID = ui->sbRGACmd_DiagID->value();
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte5_Bit7 = 0;

        dp_scm_crc6_checksum((unsigned char *)&m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd, (sizeof(S_RGA_COMMAND) - 1), &ucChecksum);
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte6_Crc6_CS = ucChecksum & 0x3F;
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte6_FarEndCSErr = 0;
        m_UCommand[ARRIDENT_MODE_AZ_IDENT].m_S_RGACmd.m_ucByte6_Bit7 = 0;

        ui->gbRGA_Command->setEnabled(false);
        ui->gbRGA_Response->setEnabled(true);
        m_pthArrayIdent_RGA->setSystem(ARRIDENT_MODE_AZ_IDENT);
        m_pthArrayIdent_RGA->setTxCommand(m_UCommand[ARRIDENT_MODE_AZ_IDENT]);
        m_pthArrayIdent_RGA->Start();
        ui->pbStart1->setText("Stop (&1)");
    }
    else
    {
        m_pthArrayIdent_RGA->Stop();
        ui->pbStart1->setText("Start (&1)");
        ui->gbRGA_Command->setEnabled(true);
        ui->gbRGA_Response->setEnabled(true);
    }
}

CArrayIdentThread::CArrayIdentThread(QObject *parent, unsigned char in_ucSystem) : QThread(parent)
{
    m_bIsRunning = false;
    m_ucSystem = in_ucSystem;

    memset (&m_UCommand, 0, sizeof(U_DEM_PORT_TX));
    memset (&m_UResponse, 0, sizeof(U_DEM_PORT_RX));
}

void CArrayIdentThread::setSystem(unsigned char in_ucSystem)
{
    if (in_ucSystem > ARRIDENT_MODE_EL_IDENT || in_ucSystem < ARRIDENT_MODE_AZ_IDENT)
    {
        return;
    }

    m_ucSystem = in_ucSystem;
}

void CArrayIdentThread::setTxCommand(U_DEM_PORT_TX in_UCommand)
{
    memset (&m_UCommand, 0, sizeof(U_DEM_PORT_TX));
    memcpy(&m_UCommand, &in_UCommand, sizeof(U_DEM_PORT_TX));
}

void CArrayIdentThread::Start()
{
    if (m_bIsRunning)
    {
        return;
    } else { }

    m_bIsRunning = true;
    this->start();
}

void CArrayIdentThread::Stop()
{
    if (!m_bIsRunning)
    {
        return;
    }
    else { }

    m_bIsRunning = false;
    this->terminate();
}

void CArrayIdentThread::run()
{
    unsigned char ucLastArrayID = DPSCM_INIT_0;
    int iRetVal = DPSCM_INIT_0;
    unsigned int uiBytesRead = DPSCM_INIT_0;
    static unsigned char ucArrayIDCnt = DPSCM_INIT_0;
    static unsigned char ucInvalidArrayIDCnt = DPSCM_INIT_0;
    QString qstrErrMsg = QString();
    QString qstrTemp = QString();

    while (m_bIsRunning)
    {
        if (m_ucSystem == ARRIDENT_MODE_AZ_IDENT)
        {
            memset (&m_UResponse, 0, sizeof(U_DEM_PORT_RX));

            iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_WriteData((char *) m_UCommand.m_arrucData, sizeof(S_RGA_COMMAND));
            if (iRetVal != DPSCM_SUCCESS)
            {
                g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
                qstrTemp.sprintf("Command Send Failed : %s [Err: %d]", qstrErrMsg.toStdString().c_str(), iRetVal);
                emit sig_updateActionLog(qstrTemp, LOG_WARNING);
                return;
            }

            iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_RGA_RESPONSE), (char *) &m_UResponse.m_S_RGAResp, &uiBytesRead, 200);
            if (iRetVal != DPSCM_SUCCESS && uiBytesRead != sizeof(S_RGA_RESPONSE))
            {
                emit sig_updateActionLog("Response Receive Failed : Bytes received = " + QString::number(uiBytesRead), LOG_ERROR);
            }
            else
            {
                emit sig_updateRGAResponse(m_UResponse);
                emit sig_updateActionLog("Response Receive Success", LOG_SUCCESS);
            }
        }
        else if (m_ucSystem == ARRIDENT_MODE_EL_IDENT)
        {
            iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_RGA_COMMAND), (char *) &m_UCommand.m_S_RGACmd, &uiBytesRead, 200);
            if (iRetVal != DPSCM_INIT_0)
            {
                emit sig_updateActionLog("Command Receive Failed", LOG_ERROR);
                continue;
            }
            else
            {
                emit sig_updateActionLog("Command Received successful", LOG_SUCCESS);
                emit sig_updateRTGAResponse(m_UCommand);
            }

            memset(&m_UResponse, 0, sizeof(U_DEM_PORT_RX));

            m_UResponse.m_S_RGAResp.m_ucByte0_MsgLength = sizeof(S_RGA_RESPONSE) & 0x7F;
            m_UResponse.m_S_RGAResp.m_ucByte0_Bit7 = 1;

            if((m_UCommand.m_S_RGACmd.m_ucByte3_ArrayIdent      == DP_SCM_ARRAY_ID_5000_E)    ||\
                    (m_UCommand.m_S_RGACmd.m_ucByte3_ArrayIdent == DP_SCM_ARRAY_ID_OSPREY_20) ||\
                    (m_UCommand.m_S_RGACmd.m_ucByte3_ArrayIdent == DP_SCM_ARRAY_ID_OSPREY_30) ||\
                    (m_UCommand.m_S_RGACmd.m_ucByte3_ArrayIdent == DP_SCM_ARRAY_ID_OSPREY_40))
            {
                if(ucLastArrayID == m_UCommand.m_S_RGACmd.m_ucByte3_ArrayIdent)
                {
                    ucArrayIDCnt++;
                }
                else
                {
                    ucArrayIDCnt = 1;
                }

                ucInvalidArrayIDCnt = 0;
                ucLastArrayID = m_UCommand.m_S_RGACmd.m_ucByte3_ArrayIdent;
            }
            else
            {
                ucInvalidArrayIDCnt++;
            }

            m_UResponse.m_S_RGAResp.m_ucByte5_DiagnosticsID = ID_15;

            if(ucArrayIDCnt == 10)
            {
                //Diagnostics Reg Update
                m_UResponse.m_S_RGAResp.m_ucByte4_BIT_DataVal = 2;
                m_bIsRunning = false;
                emit sig_updateButtonName("Start (&2)");
                ucArrayIDCnt = DPSCM_INIT_0;
                ucInvalidArrayIDCnt = DPSCM_INIT_0;
            }

            unsigned char ucChecksum = DPSCM_INIT_0;
            dp_scm_crc6_checksum((unsigned char *)&m_UResponse.m_S_RGAResp, (sizeof(S_RGA_RESPONSE) - 1), &ucChecksum);
            m_UResponse.m_S_RGAResp.m_ucByte6_Crc6_CS = ucChecksum & 0x3F;

            emit sig_updateRGAResponse(m_UResponse);

            iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *) m_UResponse.m_arrucData, sizeof(S_RGA_RESPONSE));
            if (iRetVal == DPSCM_SUCCESS)
            {
                emit sig_updateActionLog("Response Sent Successful", LOG_SUCCESS);
            }
            else
            {
                emit sig_updateActionLog("Response Send Failed", LOG_ERROR);
            }
        }
        else
        {
            // Do nothing
        }
    }
}

void CArrayIdentVerification::on_cmbRGACmd_Mode_currentIndexChanged(int index)
{
	QString qstrTemp = QString();
    if (index == DP_SCM_POS_MODE)
    {
        ui->sbRGACmd_AzCommand->setSuffix(" deg");
        ui->sbRGACmd_AzCommand->setRange(DP_SCM_POS_MIN, DP_SCM_POS_MAX);
	   qstrTemp.sprintf ("[Minimum : %.3f\n Maximum : %.3f]", DP_SCM_POS_MIN, DP_SCM_POS_MAX);
	   ui->sbRGACmd_AzCommand->setToolTip (qstrTemp);
    }
    else
    {
        ui->sbRGACmd_AzCommand->setSuffix(" deg/s");
        ui->sbRGACmd_AzCommand->setRange(DP_SCM_RATE_MIN, DP_SCM_RATE_MAX);
	   qstrTemp.sprintf ("[Minimum : %.3f\n Maximum : %.3f]", DP_SCM_RATE_MIN, DP_SCM_RATE_MAX);
	   ui->sbRGACmd_AzCommand->setToolTip (qstrTemp);
    }
}

void CArrayIdentVerification::on_pbStart2_clicked()
{
    CHECK_TC_RUNNING;

    if (ui->pbStart2->text().contains("Start (&2)"))
    {
        CHECK_PORT_OPEN(COMMAND_PORT_IDX);

        m_pthArrayIdent_RGA->setSystem(ARRIDENT_MODE_EL_IDENT);
        ui->gbRGA_Response->setEnabled(true);
        ui->gbRGA_Command->setEnabled(false);
        m_pthArrayIdent_RGA->Start();
        ui->pbStart2->setText("Stop (&2)");
    }
    else
    {
        m_pthArrayIdent_RGA->Stop();
        ui->pbStart2->setText("Start (&2)");
        ui->gbRGA_Response->setEnabled(true);
        ui->gbRGA_Command->setEnabled(true);
    }
}

void CArrayIdentVerification::on_pbSend3_clicked()
{
    U_DEM_PORT_TX	U_cmd  = { 0 };
    double dPos = DPSCM_INIT_0;
    double dRate = DPSCM_INIT_0;
    short sAzCommand = DPSCM_INIT_0;
    short sElCommand = DPSCM_INIT_0;
    unsigned char ucChecksum = DPSCM_INIT_0;

    memset (&U_cmd, 0, sizeof(U_DEM_PORT_TX));
    m_bIsThread = false;

    CHECK_TC_RUNNING;

    CHECK_PORT_OPEN(COMMAND_PORT_IDX)

    if (g_SGlobal.m_ucConfiguredMode != SERVO_MODE)
    {
        if (ui->rbRGA->isChecked())
        {
            DISPLAY_MESSAGE_BOX(this, "Mode Configuration", "Cannot send RGA Command in Diagnostics Mode.\nPlease switch to Servo Mode.");
            return;
        }
        else if (ui->rbRTGA->isChecked())
        {
            DISPLAY_MESSAGE_BOX(this, "Mode Configuration", "Cannot send RTGA Command in Diagnostics Mode.\nPlease switch to Servo Mode.");
            return;
        }
        else
        {
            return; // Do nothing
        }
    }

    if (ui->rbRGA->isChecked())
    {
        dPos = ui->sbRGACmd_AzCommand->value();
        if (ui->cbRGACmd_CCW->isChecked() || ui->cbRGACmd_CW->isChecked())
        {
            sAzCommand = (dPos * BIT_RESOLUTION_13BIT) / BIT_RESOLUTION_AZ_POS;
        }
        else
        {
            if (ui->cmbRGACmd_Mode->currentIndex() == DP_SCM_RATE_MODE)
            {
                sAzCommand = (dPos * BIT_RESOLUTION_13BIT) / BIT_RESOLUTION_RATE;
            }
            else
            {
                sAzCommand = (dPos * BIT_RESOLUTION_13BIT) / BIT_RESOLUTION_AZ_POS;
            }
        }

        U_cmd.m_S_RGACmd.m_ucByte0_MsgLength = sizeof(S_RGA_COMMAND) & 0x7F;
        U_cmd.m_S_RGACmd.m_ucByte0_Bit7 = 1;

        U_cmd.m_S_RGACmd.m_ucByte1_Spare = 0;
        U_cmd.m_S_RGACmd.m_ucByte1_StrParameters = ui->cbRGACmd_StoreParam->isChecked() ? 1 : 0;
        U_cmd.m_S_RGACmd.m_ucByte1_Bit7 = 0;

        U_cmd.m_S_RGACmd.m_ucByte2_AzCmd_12_7 = (sAzCommand >> 7) & 0x3F;
        U_cmd.m_S_RGACmd.m_ucByte2_AzModeSel = ui->cmbRGACmd_Mode->currentIndex();
        U_cmd.m_S_RGACmd.m_ucByte2_Bit7 = 0;

        U_cmd.m_S_RGACmd.m_ucByte3_Spare = 0;
        U_cmd.m_S_RGACmd.m_ucByte3_CW_UpEndStop = ui->cbRGACmd_CW->isChecked() ? 1 : 0;
        U_cmd.m_S_RGACmd.m_ucByte3_CCW_LowEndStop = ui->cbRGACmd_CCW->isChecked() ? 1 : 0;
        U_cmd.m_S_RGACmd.m_ucByte3_ArrayIdent = ui->cmbRGACmd_ArrayIdent->currentIndex();
        U_cmd.m_S_RGACmd.m_ucByte3_Bit7 = 0;

        U_cmd.m_S_RGACmd.m_ucByte4_AzCmd_6_0 = sAzCommand & 0x7F;
        U_cmd.m_S_RGACmd.m_ucByte4_Bit7 = 0;

        U_cmd.m_S_RGACmd.m_ucByte5_DiagnosticsID = ui->sbRGACmd_DiagID->value();
        U_cmd.m_S_RGACmd.m_ucByte5_Bit7 = 0;

        dp_scm_crc6_checksum((unsigned char *)&U_cmd.m_S_RGACmd, (sizeof(S_RGA_COMMAND) - 1), &ucChecksum);
        U_cmd.m_S_RGACmd.m_ucByte6_Crc6_CS = ucChecksum & 0x3F;
        U_cmd.m_S_RGACmd.m_ucByte6_FarEndCSErr = 0;
        U_cmd.m_S_RGACmd.m_ucByte6_Bit7 = 0;

        RGA_WR_RD(U_cmd);
    }
    else if (ui->rbRTGA->isChecked())
    {
        dPos = ui->dsbRTGACmd_ElCommand->value();
        dRate = ui->sbRTGACmd_AzCommand->value();

        sElCommand = (dPos * BIT_RESOLUTION_9BIT) / BIT_RESOLUTION_EL_POS;
        if (ui->cbRTGACmd_CCW->isChecked() || ui->cbRTGACmd_CW->isChecked())
        {
            sAzCommand = (dRate * BIT_RESOLUTION_13BIT) / BIT_RESOLUTION_AZ_POS;
        }
        else if (!ui->cbRTGACmd_CCW->isChecked() && !ui->cbRTGACmd_CW->isChecked() && !ui->cbRTGACmd_StoreParam->isChecked())
        {
            sAzCommand = (dRate * BIT_RESOLUTION_13BIT) / BIT_RESOLUTION_RATE;
        }

        U_cmd.m_S_RTGACmd.m_ucByte0_AzCmd_12_7 = (sAzCommand >> 7) & 0x3F;
        U_cmd.m_S_RTGACmd.m_ucByte0_StrParameters = (ui->cbRTGACmd_StoreParam->isChecked()) ? 1 : 0;
        U_cmd.m_S_RTGACmd.m_ucByte0_Bit7 = 1;

        U_cmd.m_S_RTGACmd.m_ucByte1_AzCmd_6_0 = sAzCommand & 0x7F;
        U_cmd.m_S_RTGACmd.m_ucByte1_Bit7 = 0;

        U_cmd.m_S_RTGACmd.m_ucByte1_ElCmd_8_7 = (sElCommand >> 7) & 0x03;
        U_cmd.m_S_RTGACmd.m_ucByte2_CW_UpEndStop = (ui->cbRTGACmd_CW->isChecked()) ? 1 : 0;
        U_cmd.m_S_RTGACmd.m_ucByte2_CCW_LowEndStop = (ui->cbRTGACmd_CCW->isChecked()) ? 1 : 0;
        U_cmd.m_S_RTGACmd.m_ucByte2_ConfOffset = (ui->cbRTGACmd_ConfigOffset->isChecked()) ? 1 : 0;
        U_cmd.m_S_RTGACmd.m_ucByte2_Bit_5_6 = 0;
        U_cmd.m_S_RTGACmd.m_ucByte2_Bit7 = 0;

        U_cmd.m_S_RTGACmd.m_ucByte3_ElCmd_6_0 = sElCommand & 0x7F;
        U_cmd.m_S_RTGACmd.m_ucByte3_Bit7 = 0;

        U_cmd.m_S_RTGACmd.m_ucByte4_DiagnosticsID = ui->sbRTGACmd_DiagID->value() & 0x7F;
        U_cmd.m_S_RTGACmd.m_ucByte4_Bit7 = 0;

        dp_scm_7bit_xor_checksum((unsigned char *)&U_cmd.m_S_RTGACmd, (sizeof(S_RTGA_COMMAND) - 1), &ucChecksum);
        U_cmd.m_S_RTGACmd.m_ucByte5_Crc7_CS = ucChecksum & 0x7F;
        U_cmd.m_S_RTGACmd.m_ucByte5_Bit7 = 0;

        RTGA_WR_RD(U_cmd);
    }
    else
    {
        // Do nothing
    }
}

void CArrayIdentVerification::setRGAResponse(S_RGA_RESPONSE in_SRGAResponse)
{
    short sAzResponse = DPSCM_INIT_0;
    float fAzPositionResponse = 0.0f;

    sAzResponse = (in_SRGAResponse.m_ucByte1_AzPosition_15_9 & 0x7F) << 9;
    sAzResponse = sAzResponse | ((in_SRGAResponse.m_ucByte2_AzPosition_8_2 & 0x7F) << 2);
    sAzResponse = sAzResponse | (in_SRGAResponse.m_ucByte3_AzPosition_1_0 & 0x03);

    fAzPositionResponse = (sAzResponse * BIT_RESOLUTION_AZ_POS) / BIT_RESOLUTION_16BIT;

    if (m_bIsThread)
    {
        if ((in_SRGAResponse.m_ucByte4_BIT_DataVal & 0x02) != DPSCM_INIT_0)
        {
            m_qTimerRGA.stop();
        }
        else { }
    }
    else {}

    ui->leRGAResp_AzPos->setText(QString::number(fAzPositionResponse));
    ui->leRGAResp_BITFault->setText(QString::number(in_SRGAResponse.m_ucByte3_BIT_Fault));
    ui->leRGAResp_IndSensorPos->setText(QString::number(in_SRGAResponse.m_ucByte3_AzIndSenPosition));
    ui->leRGAResp_DiagData->setText(QString::number((in_SRGAResponse.m_ucByte4_BIT_DataVal & 0x7F), 16).toUpper());
    ui->leRGAResp_DiagID->setText(QString::number(in_SRGAResponse.m_ucByte5_DiagnosticsID));
    ui->leRGAResp_FarEndCS->setText(QString::number(in_SRGAResponse.m_ucByte6_FarEndCSErr));
}

void CArrayIdentVerification::setRTGAResponse(S_RTGA_RESPONSE in_SRTGAResponse)
{
    short sAzResponse = DPSCM_INIT_0;
    short sElResponse = DPSCM_INIT_0;
    float fAzRateResponse = 0.0f;
    float fElPositionResponse = 0.0f;

    sAzResponse = (in_SRTGAResponse.m_ucByte0_AzCmd_15_9 & 0x7F) << 9;
    sAzResponse = sAzResponse | ((in_SRTGAResponse.m_ucByte1_AzCmd_8_2 & 0x7F) << 2);
    sAzResponse = sAzResponse | (in_SRTGAResponse.m_ucByte2_AzCmd_0_1 & 0x03);

    fAzRateResponse = (sAzResponse * BIT_RESOLUTION_AZ_POS) / BIT_RESOLUTION_16BIT;

    sElResponse = ((in_SRTGAResponse.m_ucByte1_ElCmd_8_7 & 0x03) << 7);
    sElResponse = sAzResponse | (in_SRTGAResponse.m_ucByte3_ElCmd_6_0 & 0x7F);

    fElPositionResponse = (sElResponse * BIT_RESOLUTION_EL_POS) / BIT_RESOLUTION_9BIT;

    if (m_bIsThread)
    {
        if ((in_SRTGAResponse.m_ucByte4_BitDataVal & 0x02) != DPSCM_INIT_0)
        {
            m_qTimerRTGA.stop();
        }
        else{}
    }
    else {}

    ui->leRTGAResp_AzData->setText(QString::number(fAzRateResponse));
    ui->leRTGAResp_ElPos->setText(QString::number(fElPositionResponse));
    ui->leRTGAResp_BITFault->setText(QString::number(in_SRTGAResponse.m_ucByte2_BITFault));
    ui->leRTGAResp_DiagData->setText(QString::number(in_SRTGAResponse.m_ucByte4_BitDataVal & 0x7F, 16).toUpper());
    ui->leRTGAResp_DiagID->setText(QString::number(in_SRTGAResponse.m_ucByte5_DiagnosticsID));
    ui->leRTGAResp_CS->setText(QString::number(in_SRTGAResponse.m_ucByte6_Crc7_CS & 0x7F, 16).toUpper());
}

void CArrayIdentVerification::RGA_WR_RD(U_DEM_PORT_TX in_UCommand)
{
    int iRetVal = DPSCM_INIT_0;
    U_DEM_PORT_RX U_resp = { 0 };
    unsigned int uiBytesRead = DPSCM_INIT_0;

    memset (&U_resp, 0, sizeof(U_DEM_PORT_RX));

    iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_WriteData((char *) in_UCommand.m_arrucData, sizeof(S_RGA_COMMAND));
    if (iRetVal == DPSCM_SUCCESS)
    {
        emit sig_updateActionLog("Command Sent Successful", LOG_SUCCESS);
    }
    else
    {
        emit sig_updateActionLog("Command Send Failed", LOG_ERROR);
        return;
    }

    iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_RGA_RESPONSE), (char *) &U_resp.m_S_RGAResp, &uiBytesRead, 200);
    if (iRetVal != DPSCM_SUCCESS)
    {
        emit sig_updateActionLog("Response Receive Failed : Bytes Read = " + QString::number(uiBytesRead), LOG_ERROR);
        return;
    }
    else
    {
        emit sig_updateActionLog("Response Receive Success", LOG_SUCCESS);
    }

    setRGAResponse(U_resp.m_S_RGAResp);
}

void CArrayIdentVerification::RTGA_WR_RD(U_DEM_PORT_TX in_UCommand)
{
    int iRetVal = DPSCM_INIT_0;
    U_DEM_PORT_RX U_resp = { 0 };
    unsigned int uiBytesRead = DPSCM_INIT_0;
    QString qstrTemp = QString();

    memset (&U_resp, 0, sizeof(U_DEM_PORT_RX));

    iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_WriteData((char *) in_UCommand.m_arrucData, sizeof(S_RTGA_COMMAND));
    if (iRetVal == DPSCM_SUCCESS)
    {
//        emit sig_updateActionLog("Command Sent Successful", LOG_SUCCESS);
    }
    else
    {
//        emit sig_updateActionLog("Command Send Failed", LOG_ERROR);
        return;
    }

    iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_RTGA_RESPONSE), (char *) &U_resp.m_S_RTGAResp, &uiBytesRead, 10);
    if (iRetVal != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrTemp);
        emit sig_updateActionLog("Response Receive Failed : " + qstrTemp + " - " + QString::number(uiBytesRead), LOG_ERROR);
        return;
    }
    else
    {
        emit sig_updateActionLog("Response Receive Success", LOG_SUCCESS);
    }

    setRTGAResponse(U_resp.m_S_RTGAResp);
}

void CArrayIdentVerification::RTGA_AZ_Simulation()
{
    U_DEM_PORT_TX UTxCommand;
    U_DEM_PORT_RX URxResponse;
    unsigned char ucChecksum = 0;
    unsigned int uiBytesRead = 0;
    int iRetVal = 0;
    QString qstrErrMsg = QString();
    QString qstrTemp = QString();

    memset (&UTxCommand, 0, sizeof(U_DEM_PORT_TX));
    memset (&URxResponse, 0, sizeof(U_DEM_PORT_TX));

    UTxCommand.m_S_DiagCmd.m_ucByte0_Bit6_0 = 0;
    UTxCommand.m_S_DiagCmd.m_ucByte0_Bit7 = 1;

    UTxCommand.m_S_DiagCmd.m_ucByte1_CmdID = CMDID_DIAGMON_READ & 0x1F;
    UTxCommand.m_S_DiagCmd.m_ucByte1_TestInit = 0;
    UTxCommand.m_S_DiagCmd.m_ucByte1_ElorAz = 1;

    UTxCommand.m_S_DiagCmd.m_ucByte1_Bit7 = 0;

    UTxCommand.m_S_DiagCmd.m_ucByte2_Bit6_0 = ui->sbRTGACmd_DiagID->value() & 0x7F;

    dp_scm_7bit_xor_checksum((unsigned char *)&UTxCommand.m_S_DiagCmd, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);

    UTxCommand.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;
    iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *)UTxCommand.m_arrucData, sizeof(S_DIAG_CMDRESP));
    if (iRetVal != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
        qstrTemp.sprintf("Error Send Command : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
        emit sig_updateActionLog(qstrTemp, LOG_ERROR);
        return;
    }
    sig_updateActionLog("Diagnostics Data Sent in Diagnostics Port", LOG_PARTIAL_SUCCESS);
#if 0
    iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_DIAG_CMDRESP), (char *) &URxResponse.m_S_DiagResp, &uiBytesRead, 200);
    if (iRetVal != DPSCM_INIT_0)
    {
        g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
        qstrTemp.sprintf("Error Receiving Response");
        emit sig_updateActionLog(qstrTemp, LOG_ERROR);
        return;
    }
    sig_updateActionLog("Diagnostics Data Received in Demand Port", LOG_PARTIAL_SUCCESS);

    URxResponse.m_S_DiagResp.m_ucByte3_Bit6_0 = ui->sbRTGACmd_AzCommand->value();
    dp_scm_7bit_xor_checksum((unsigned char *)&URxResponse.m_S_DiagResp, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);

    iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_WriteData((char *)URxResponse.m_arrucData, sizeof(S_DIAG_CMDRESP));
    if (iRetVal != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
        qstrTemp.sprintf("Error Send Command : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
        emit sig_updateActionLog(qstrTemp, LOG_ERROR);
        return;
    }
    sig_updateActionLog("Diagnostics Data Sent in Demand Port", LOG_PARTIAL_SUCCESS);
#endif
    iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_DIAG_CMDRESP), (char *) &URxResponse.m_S_DiagResp, &uiBytesRead, 200);
    if (iRetVal != DPSCM_INIT_0)
    {
        g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
        qstrTemp.sprintf("Error Receiving Response");
        emit sig_updateActionLog(qstrTemp, LOG_ERROR);
        return;
    }
    sig_updateActionLog("Diagnostics Data Received in Diagnostics Port", LOG_PARTIAL_SUCCESS);

    ui->leRTGAResp_AzData->clear();
    ui->leRTGAResp_ElPos->clear();
    ui->leRTGAResp_BITFault->clear();
    ui->leRTGAResp_DiagData->clear();
    ui->leRTGAResp_DiagID->clear();
    ui->leRTGAResp_CS->clear();

    ui->leRTGAResp_DiagData->setText(QString::number(URxResponse.m_S_DiagResp.m_ucByte3_Bit6_0));
    ui->leRTGAResp_DiagID->setText(QString::number(URxResponse.m_S_DiagResp.m_ucByte2_Bit6_0));
}

void CArrayIdentVerification::on_pbSend4_clicked()
{
    int iRetVal = DPSCM_INIT_0;
    unsigned int uiBytesRead = DPSCM_INIT_0;
    double dPos = DPSCM_INIT_0;
    double dRate = DPSCM_INIT_0;
    short sAzCommand = 0;
    short sElCommand = 0;
    unsigned char ucChecksum = 0;
    U_DEM_PORT_TX	U_cmd  = { 0 };
//    U_DEM_PORT_RX U_resp = { 0 };

    memset (&U_cmd, 0, sizeof(U_DEM_PORT_TX));

    CHECK_TC_RUNNING;

    CHECK_PORT_OPEN(COMMAND_PORT_IDX);
    CHECK_PORT_OPEN(DIAGNOSTIC_PORT_IDX);

    if (g_SGlobal.m_ucSystem == SYSTEM_RGA_RTGA_AZ)
    {
        RTGA_AZ_Simulation();
        return;
    }

    dPos = ui->dsbRTGACmd_ElCommand->value();
    dRate = ui->sbRTGACmd_AzCommand->value();

    sElCommand = (dPos * BIT_RESOLUTION_9BIT) / BIT_RESOLUTION_EL_POS;
    sAzCommand = (dRate * BIT_RESOLUTION_13BIT) / BIT_RESOLUTION_AZ_POS;

    U_cmd.m_S_RTGACmd.m_ucByte0_AzCmd_12_7 = (sAzCommand >> 7) & 0x3F;
    U_cmd.m_S_RTGACmd.m_ucByte0_StrParameters = (ui->cbRTGACmd_StoreParam->isChecked()) ? 1 : 0;
    U_cmd.m_S_RTGACmd.m_ucByte0_Bit7 = 1;

    U_cmd.m_S_RTGACmd.m_ucByte1_AzCmd_6_0 = sAzCommand & 0x7F;
    U_cmd.m_S_RTGACmd.m_ucByte1_Bit7 = 0;

    U_cmd.m_S_RTGACmd.m_ucByte1_ElCmd_8_7 = (sElCommand >> 7) & 0x03;
    U_cmd.m_S_RTGACmd.m_ucByte2_CW_UpEndStop = (ui->cbRTGACmd_CW->isChecked()) ? 1 : 0;
    U_cmd.m_S_RTGACmd.m_ucByte2_CCW_LowEndStop = (ui->cbRTGACmd_CCW->isChecked()) ? 1 : 0;
    U_cmd.m_S_RTGACmd.m_ucByte2_ConfOffset = (ui->cbRTGACmd_ConfigOffset->isChecked()) ? 1 : 0;
    U_cmd.m_S_RTGACmd.m_ucByte2_Bit_5_6 = 0;
    U_cmd.m_S_RTGACmd.m_ucByte2_Bit7 = 0;

    U_cmd.m_S_RTGACmd.m_ucByte3_ElCmd_6_0 = sElCommand & 0x7F;
    U_cmd.m_S_RTGACmd.m_ucByte3_Bit7 = 0;

    U_cmd.m_S_RTGACmd.m_ucByte4_DiagnosticsID = ui->sbRTGACmd_DiagID->value() & 0x7F;
    U_cmd.m_S_RTGACmd.m_ucByte4_Bit7 = 0;

    iRetVal = dp_scm_7bit_xor_checksum((unsigned char *)&U_cmd.m_S_RTGACmd, (sizeof(S_RTGA_COMMAND) - 1), &ucChecksum);
    U_cmd.m_S_RTGACmd.m_ucByte5_Crc7_CS = ucChecksum & 0x7F;
    U_cmd.m_S_RTGACmd.m_ucByte5_Bit7 = 0;

    iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_WriteData((char *) U_cmd.m_arrucData, sizeof(S_RTGA_COMMAND));
    if (iRetVal != DPSCM_SUCCESS)
    {
        emit sig_updateActionLog("Error sending RTGA Command", LOG_ERROR);
//        continue;
        return;
    }
    else {}
#if 0
    iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData(sizeof(S_RGA_COMMAND), (char *) &m_UCommand[0].m_S_RGACmd, &uiBytesRead, 200);
    if (iRetVal == DPSCM_SUCCESS)
    {
        slot_updateRTGAResponse(m_UCommand[0]);
        emit sig_updateActionLog("RGA Command Receive Success", LOG_SUCCESS);
    }
    else
    {
        emit sig_updateActionLog("RGA Command Receive Failed : Bytes received = " + QString::number(uiBytesRead), LOG_ERROR);
        return;
    }

    memset(&m_UResponse[0], 0, sizeof(U_DEM_PORT_RX));

    sAzRate = ((m_UCommand[0].m_S_RGACmd.m_ucByte2_AzCmd_12_7 & 0x7F) << 7) | ((m_UCommand[0].m_S_RGACmd.m_ucByte4_AzCmd_6_0 & 0x7F));

    m_UResponse[0].m_S_RGAResp.m_ucByte0_MsgLength = sizeof(S_RGA_RESPONSE) & 0x7F;
    m_UResponse[0].m_S_RGAResp.m_ucByte0_Bit7 = 1;

    sAzData = (sAzRate * BIT_RESOLUTION_16BIT) / BIT_RESOLUTION_AZ_POS;
    m_UResponse[0].m_S_RGAResp.m_ucByte1_AzPosition_15_9 = (sAzData >> 9) & 0x7F;
    m_UResponse[0].m_S_RGAResp.m_ucByte2_AzPosition_8_2 = (sAzData >> 2) & 0x7F;
    m_UResponse[0].m_S_RGAResp.m_ucByte3_AzPosition_1_0 = sAzData & 0x03;

    m_UResponse[0].m_S_RGAResp.m_ucByte5_DiagnosticsID = ui->sbRTGACmd_DiagID->value();

    dp_scm_crc6_checksum((unsigned char *)&m_UResponse[0].m_S_RGAResp, (sizeof(S_RGA_RESPONSE) - 1), &ucChecksum);
    m_UResponse[0].m_S_RGAResp.m_ucByte6_Crc6_CS = ucChecksum & 0x3F;

    iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *) m_UResponse[0].m_arrucData, sizeof(S_RGA_RESPONSE));
    if (iRetVal != DPSCM_SUCCESS)
    {
        emit sig_updateActionLog("Error sending RGA Response", LOG_ERROR);
        return;
    }
    else
    {
        slot_updateRGAResponse(m_UResponse[0]);
        ui->leRGAResp_AzPos->setText(QString::number(fAzPositionResponse));
    }
#endif
    iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_ReadData(sizeof(S_RTGA_RESPONSE), (char *) &m_UResponse[0].m_S_RTGAResp, &uiBytesRead, 200);
    if (iRetVal == DPSCM_SUCCESS)
    {
        slot_updateRTGAResponse_Display(m_UResponse[0]);
        emit sig_updateActionLog("RTGA Response Receive Success", LOG_SUCCESS);
    }
    else
    {
        emit sig_updateActionLog("RTGA Response Receive Failed : Bytes received = " + QString::number(uiBytesRead), LOG_ERROR);
        return;
    }
}

void CArrayIdentVerification::on_rbRGA_toggled(bool checked)
{
    if (checked)
    {
        ui->pbSend3->setToolTip("RGA Demand Command");
    }
    else
    {
        ui->pbSend3->setToolTip("RTGA Demand Command");
    }

    ui->lbSend3->setText(ui->pbSend3->toolTip());
}
