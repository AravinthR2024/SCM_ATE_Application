#ifndef QT_DRAGNDROPWIDGET_H
#define QT_DRAGNDROPWIDGET_H

#include <QWidget>
#include <QDragEnterEvent>
#include <QDragLeaveEvent>
#include <QDropEvent>
#include <QMimeData>
#include <QUrl>
#include <QEvent>
#include <QDebug>

namespace Ui {
	class CDragnDropWidget;
}

class CDragnDropWidget : public QWidget
{
		Q_OBJECT

	public:
		explicit CDragnDropWidget(QWidget *parent = 0, QStringList in_qstrliAcceptedFileFormats = QStringList());
		~CDragnDropWidget();

		QStringList m_qstrliAcceptedFileFormats;

		void dragEnterEvent (QDragEnterEvent *in_pevtDragEnter);
		void dropEvent (QDropEvent *in_pevtDrop);

		void setAcceptedFileFormat (QStringList in_qstrliAcceptedFileName);
		void addAcceptedFileFormat (QString in_qstrAcceptedFileName);
		void addAcceptedFileFormat (QStringList in_qstrliAcceptedFileNames);

	signals:
		void sig_fileEntered (QString in_qstrFilePath);
		void sig_fileDropped (QString in_qstrFilePath);

	private:
		Ui::CDragnDropWidget *ui;
};

#endif // QT_DRAGNDROPWIDGET_H
