#ifndef UART_WRAPPER_H
#define UART_WRAPPER_H

#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QThread>
#include <QDebug>

/*Error Code*/
#define DPSCM_SUCCESS                                   0
#define DP_FAILURE                                  -1
#define DP_ERR_NO                                   -1000
#define DP_COM_PORT_NOT_OPENED                      DP_ERR_NO + 1
#define DP_CMD_NOT_TRANSMITED                       DP_ERR_NO + 2
#define DP_INVALID_BAUDRATE                         DP_ERR_NO + 3
#define DP_INVALID_DATABITS                         DP_ERR_NO + 4
#define DP_INVALID_PARITY                           DP_ERR_NO + 5
#define DP_INVALID_FLOW_CONTROL                     DP_ERR_NO + 6


class DP_UART_Wrapper
{
public:

    DP_UART_Wrapper();

    QSerialPort     m_objqserialportUART;

public slots:
    short ComPortList(QStringList &out_qslPortName);

    void ComPortName(QString in_qsComNo);

    short Baudrate(unsigned long in_ulBaudRate);

    short DataBit(unsigned char in_ucDataBits);

    short ParityBit(unsigned char in_ucParity);

    short FlowControl(unsigned char in_ucFlowControl);

    short StopBit(unsigned char in_ucStopBit);

    short PortStatus();

    short PortOpen();

    short PortClose();

    int DataWrite(char *in_pcBuffData, long long in_lliDataLen);

    int DataRead(unsigned char *out_pucRxBuffer);

    int DataRead(unsigned int in_uiTotalBytesToRead, unsigned char *out_pcRxBuffer, unsigned int *out_puiBytesRead,unsigned int in_uiMilliSecTOut);

    short ClearInput();

    short ClearOutput();

    int ClearAll();
};

#endif
