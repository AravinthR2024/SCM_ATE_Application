#ifndef CLOGGINGTHREAD_H
#define CLOGGINGTHREAD_H

#include <QThread>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QTime>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "dprs232_wrapper.h"
#include "includes/dp_qt_msgqueue.h"

class CLoggingThread : public QThread
{
        Q_OBJECT
    public:
        CLoggingThread(QObject *parent = 0);

        QFile m_qfDemPortLog;
        QFile m_qfDiagPortLog;
        QFile m_qfDebugDataLog;
        QFile m_qfHDLCDataLog;

        QTime m_qtDebugTime;
        QTime m_qtDiagTime;
        QTime m_qtDemTime;
        QTime m_qtHDLCTime;
        bool m_bIsRunning;

        void createNewLogFile(unsigned char in_ucLogType);
        void Start();
        void Stop();
        void run();

signals:
        void sig_updateDiagParams(S_RESP_DEBUG_DATA);
        void sig_updateActionLog(QString, int);
};

#endif // CLOGGINGTHREAD_H
