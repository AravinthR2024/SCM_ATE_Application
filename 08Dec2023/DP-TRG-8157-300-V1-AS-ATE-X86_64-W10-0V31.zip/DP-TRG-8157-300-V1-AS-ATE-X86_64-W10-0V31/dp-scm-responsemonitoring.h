/**
* \file dp-scm-responsemonitoring.h
* \brief This is the header file for dp-scm-responsemonitoring.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef RESPONSEMONITORING_H
#define RESPONSEMONITORING_H

#include <QWidget>
#include <QFileDialog>
#include <QDebug>

#include "qvector.h"
#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "qcustomplot.h"
#include "dp-scm-fra_acq.h"

namespace Ui {
	class CResponseMonitoring;
}

class CResponseMonitoring : public QWidget
{
    Q_OBJECT

	public:
		explicit CResponseMonitoring(QWidget *parent = 0);
		~CResponseMonitoring();

		QString m_qstrTCLogFileName;
		S32BIT m_iSelectedTestCase;
		bool m_bIsGraphPlotted;
        bool m_bEnableTracing_Gain;
        bool m_bEnableTracing_Phase;
        double *m_pdCmdArr;
        unsigned long m_ulXLimit_L;
        unsigned long m_ulXLimit_U;
        unsigned long m_ulLimit;

        int m_ui_X_Min;
        int m_ui_X_Max;
        int m_ui_Y_Min;
        int m_ui_Y_Max;
        int m_ui_Y2_Min;
        int m_ui_Y2_Max;
        QFile fpLog;

		S_MOTOR_WAVE_INPUTS m_stMotorWaveInputs[NO_OF_ACTUATORS];

		CDataReadThread *m_pThFRAAcq;
        QDateTime m_dateTime;

		QCPItemLine *m_pTracerLine;
		QCPItemTracer *m_pTracer;
		QCPItemText *m_pTracerLabel;

		QCPItemTracer *m_pTracer2;
		QCPItemText *m_pTracerLabel2;

		QCPItemTracer *m_pTracer3;
		QCPItemText *m_pTracerLabel3;
		bool m_bPlot3Tracers;
        unsigned int m_uiCurrIndx;

        QMenu *m_menuContextMenu;
        QAction *m_actClear;
        QAction *m_actReset;
        QAction *m_actDeleteLabels;
        QAction *m_actShowLegend;
        QAction *m_actTrace_Gain;
        QAction *m_actTrace_Phase;

        QVector<FDOUBLE> m_dvectCol1;
        QVector<FDOUBLE> m_dvectCol2;
        QVector<FDOUBLE> m_dvectCol3;
        QVector<FDOUBLE> m_dvectCol4;

        QVector<SDPPCI755_DATA_BUFFER>m_stTempBuffer/*(10)*/;
		QVector<SDPPCI755_DATA_BUFFER>m_stBoard1Buffer;
		unsigned int m_u32DispIdx;
		unsigned int	 m_u32nMapMode, m_u32nStartIdx, m_u32nEndIdx, m_u32nCount, m_u32nIdx, m_u32nZoomLvl;
		unsigned int m_u32nFileSize, m_u32nNoOfData, m_u32nSelectedGraph, m_u32MaxPages;
		SDPPCI755_CONFIG m_OnGraphSCfgData;

		void initGraph();
		void initTracer();
        void updateTestcaseDetails(int in_iSelectedTestcase);
		void setGraphAppearance();
		float DP_GetMinimumValAnaData(QVector<SDPPCI755_DATA_BUFFER> in_pSBuffer, U32BIT, U8BIT in_u8Option, U8BIT in_u8Coordinates);
        float DP_GetMaximuValAnaData(QVector<SDPPCI755_DATA_BUFFER> in_pSBuffer, U32BIT, U8BIT in_u8Option, U8BIT in_u8Coordinates);

        void removeTracingFromGraph();
	private:
		Ui::CResponseMonitoring *ui;

	signals:
		void sig_updateActionLog(QString, int);
		void sig_changePage(int);

        void sig_startFRAAcquisition(bool);
		void sig_setEnDisMenuBar(bool);
        void sig_startResponseMonitoring();
        void sig_show_hide_DiagParams (bool);

	public slots:
		void slot_graphSavepoint(QMouseEvent *in_pMevent);

        void slot_graphTracePoint(QMouseEvent *in_pMevent);

        void saveGraph(QString in_qstrFilename);

        void slot_changeButtonName(QString in_qstrName);

        void slot_configureGraph(int in_iSelectedTestcase, char in_cGraphType, int in_iXMin, int in_iXMax, int in_iYMin, int in_iYMax, int in_iY2Min, int in_iY2Max);

		void slot_onlineGraphAddValue(void * param);

        void slot_updateServoGraph(float in_fCmd, float in_fResp, double in_dTime);

		void DrawGraph();

        void slot_updateDiagParam(S_RESP_DEBUG_DATA in_SDebugData);

        void slot_clearGraph();

        void slot_enableGraphInteraction(bool in_bEnable);

        void slot_show_hide_DiagParams(bool in_bShow);

        void slot_changeTestcaseName(QString in_qstrTCName);

        void slot_contextMenuRequested(QMouseEvent* in_qMouseEvt);
        void slot_contextMenu_Reset_triggered();
        void slot_contextMenu_Clear_triggered();
        void slot_contextMenu_Delete_Labels();
        void slot_contextMenu_ShowHide_Legend_triggered(bool in_bIsChecked);
        void slot_contextMenu_Trace_Gain_triggered(bool in_bIsChecked);
        void slot_contextMenu_Trace_Phase_triggered(bool in_bIsChecked);

private slots:
        void on_pbStart_clicked();

        void on_dockDiagParams_visibilityChanged(bool visible);
};

#endif // RESPONSEMONITORING_H
