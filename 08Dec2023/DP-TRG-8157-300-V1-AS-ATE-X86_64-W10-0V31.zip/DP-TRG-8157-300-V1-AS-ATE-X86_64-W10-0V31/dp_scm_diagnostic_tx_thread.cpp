#include "dp_scm_diagnostic_tx_thread.h"

dp_scm_diagnostic_tx_thread::dp_scm_diagnostic_tx_thread(QObject *parent) : QObject(parent)
{

}

