/**
* \file dp-scm-mainwindow.h
* \brief This is the header file for dp-scm-mainwindow.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFile>
#include <QFileInfo>
#include <QFileDialog>
#include <QDebug>
#include <QEvent>
#include <QDateTime>
#include <QCloseEvent>
#include <QStringListModel>

#include <QLabel>
#include <QMovie>

#include "includes/dp-scm-macros.h"
#include "includes/dp_qt_msgqueue.h"

#include "User_Management/authentication.h"
#include "User_Management/cadminauthentication.h"
#include "User_Management/cchangepassword.h"
#include "User_Management/cusermanagement.h"
#include "User_Management/usr_management.h"

#include "dp-scm-about.h"
#include "dp-scm-modinitstatus.h"
#include "dp-scm-rs422configuration.h"
#include "dp-scm-pbitstatus.h"
#include "dp-scm-cbitstatus.h"
#include "dp-scm-scmoperation.h"
#include "dp-scm-ateselftest.h"
#include "dp-scm-bootloader.h"
#include "dp-scm-control_loop_config.h"
#include "dp-scm-systemdetails.h"
#include "dp-scm-responsemonitoring.h"
#include "dp-scm-resp_rx_thread.h"
#include "dp-scm-diagnostic_rx_thread.h"
#include "dp-scm-processing_thread.h"
#include "dp-scm-loggingthread.h"
#include "dp-scm-fpga_rw.h"
#include "dp-scm-array_ident.h"
#include "dp-scm-diagdatamonitoring.h"
#include "dp_loadingscreen.h"
#include "dp-scm-seasprayoperation.h"

namespace Ui {
class MainWindow;
}

class CDelay : public QThread
{
    public:
        CDelay() {}
        static void usleep(unsigned int usecs){QThread::usleep(usecs);}
        static void msleep(unsigned int msecs){QThread::msleep(msecs);}
        static void sleep(unsigned int secs){QThread::sleep(secs);}
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    CDelay m_objDelay;

    CAbout *m_pobjAbout;
    CModInitStatus *m_pobjModInit;
    CRS422Configuration *m_pobjRS422Config;
    CPBITStatus *m_pobjPBITStatus;
    CCBITStatus *m_pobjCBITStatus;
    CSCMOperation *m_pobjSCMControl;
    CATESelftest *m_pobjATESelftest;
    CBootLoader *m_pobjBootLoading;
    CControlLoopConfig *m_pobjCtrlLoopConfig;
    CSystemDetails *m_pobjSystemDetails;
    CResponseMonitoring *m_pobjResponseMon;
    CUserManagement *m_pobjUserMgmt;
    Authentication *m_pobjAuth;
    CResponseRx *m_pThRespRx;
    CDiagnosticRx *m_pThDiagRx;
    CDataProcessing *m_pThDataProcessing;
    CLoggingThread *m_pThLogging;
    CDiagDataMonitoring *m_pobjDiagMonitoring;
    CFPGA_RW *m_pobjFPGA_RW;
    CArrayIdentVerification *m_pobjArrayIdent;
    CLoadingScreen *m_pobjLoadingScreen;
    CSeasprayOperation *m_pobjSeasprayOperation;

    bool m_bDataProcessRunning;
    bool m_bIsLoggedIn;
    bool m_bIsAcqStarted;

    QString m_qstrLoggedinUserName;
    int m_iLoggedinUserPrevil;

    /* Action Log */
    QString m_qstrActionLogFileName;
    QFile m_qfileActionLog;
    QString m_qstrActionLogBeforeClear;	/* Used to store the action log data before cleared for Undo action */
    //    QList<int> m_iliTraverse;
    int m_iCurrPage;

    /* Reports */
    QString m_qstrBITReportFname;
    QFile m_qfileBITStatusReport;

    void connectSigSlots();
    void initAppScreen();
    void applyStyleSheet();
    void closeEvent(QCloseEvent *in_pEvt);
    void showAppScreen();
    bool createNewActionLogFile();
    bool createNewReportFile(E_REPORT_FILE_SELECT in_eFileSelection);
    void writeBITReportHeader();
    S32BIT StopAcquisition();
#if 0
    short DP_SCM_FramePacket_And_Buffer(unsigned short in_usCommandID, unsigned short in_usDataLength, unsigned char *in_pucData, S_DATA_PACKET *out_pSDataPacket, unsigned char *out_pucDataBuffer);
    short DP_SPL_6996_ReadData_Packet(unsigned char in_ucData, S_DATA_PACKET *out_pSDataPacket, unsigned char *out_pucDataRxStatus, unsigned char *out_pucState, unsigned short *out_pusCheckSum, unsigned short *out_pusDataReadCnt);
    void Delay(unsigned long in_ulTime_usec);
    short DP_SCM_Receive_DataPacket1(unsigned short in_usCommandID, S_DATA_PACKET *out_pSRxDataPacket, unsigned short in_usTimeOut);
#endif
private:
    Ui::MainWindow *ui;

public slots:
    void slot_updateActionLog(QString in_qstrMsg, int in_iLogType);
    void slot_changePageTitle(QString in_qstrTitle, bool in_bIsSubTitle = false);
    void slot_changePage(int in_iPageNo);
    void slot_DisplayMessage(QString in_qstrMsg);
    void slot_updateCBITSts(unsigned char in_ucDiagID, unsigned char in_ucBITStatus);
    void slot_updateBITStatus(unsigned char in_ucDiagId, unsigned char in_ucBITStatus);
    void startRespRxThread(bool in_bStart);
    void startDataProcThread(bool in_bStart);
    void startLoggingThread(bool in_bStart);
    void slot_startSCMCmdResp(bool in_bStart, unsigned char in_ucMode);
    void slot_startDiagCMDThread(bool in_bStart);
    void slot_FRAAcqStart(bool in_bIsRunning);
    void slot_FRAAcqStop();
    void slot_CurrentDataDisplay(unsigned short in_u16BoardNo, unsigned int in_uiSource/* , float * in_pfCurrentFrequency*/);
    void slot_Test_Current_Data_Generator(U16BIT in_u16BoardNo, PSDPPCI755_ANALYZEDDATABUFFER in_pSAnaDataBuffer, SDPPCI755_CONFIG in_ScfgData);
    void slot_contextMenuRequested(QPoint in_qptPoint);
    void slot_contextMenuActionLogClear();
    void slot_contextMenuCopy();
    void slot_contextMenuSelectAll();
    void slot_contextMenuUndoClear();
    void slot_append_BIT_HTMLReport(QString in_qstrHTML);
    void MainWinOngraphDraw(unsigned int in_uiBrdNo);
    void slot_startFRAAcq();
    void slot_showLoadingScreen (bool in_bShow);
    short slot_UARTWrite(char *in_pcBuffData, long long in_lliDataLen);
    void slot_show_hide_DiagParams (bool in_bShow);
    void slot_start_Stop_HDLCRx(bool in_bStart);
    void slot_AppPath_Link_Clicked(QString in_qstrLink);

#if 0
    short slot_DP_SCM_Receive_DataPacket(unsigned short in_usCommandID, S_DATA_PACKET *out_pSRxDataPacket, unsigned long in_ulTimeOut);
    short slot_DP_SCM_TxData_RxResponse(unsigned short in_usCommandID, unsigned short in_usDataLength, unsigned char *in_pucData, S_DATA_PACKET *out_pSRxDataPacket, unsigned long in_ulTimeOut);
    short slot_DP_SCM_TxData_RxResponse1(unsigned short in_usCommandID, unsigned short in_usDataLength, unsigned char *in_pucData, S_DATA_PACKET *out_pSRxDataPacket, unsigned long in_ulTimeOut);
#endif
    void slot_startSCMDiagResp(bool in_bStart);
signals:
    //        void sig_updatePBITStatus(unsigned char);
    void sig_updateCBITStatus(unsigned char, unsigned char);
    void OnGraph_Draw();
    void sig_onlineGraphAddValue(void*);
    void sig_saveGraph(QString);
    void sig_show_hide_DiagParams (bool);
    sig_UART_WriteRead_Cmd(unsigned short in_usCommandID, char *in_pucInputDataBuffer, unsigned int uiInputDataLen,
                           char *out_pucOutputDataBuffer, unsigned int uiOutputDataLen, unsigned int uiTimeout_ms);

private slots:
    void on_action_Initialization_Status_triggered();
    void on_action_CBIT_Status_triggered();
    void on_action_Motor_Control_triggered();
    void on_action_About_ATE_triggered();
    void on_action_RS422_Configuration_triggered();
    void on_action_Communication_Status_triggered();
    void on_action_PBIT_Status_triggered();
    void on_action_Software_Programming_triggered();
    void on_action_Control_Loop_Constant_Configuration_triggered();
    void on_action_System_Details_triggered();
    void on_action_Response_Monitoring_triggered();
    void on_action_Change_Password_triggered();
    void on_action_User_Management_triggered();
    void on_label_13_linkActivated(const QString &link);
    void on_label_16_linkActivated(const QString &link);
    void on_label_19_linkActivated(const QString &link);
    void on_label_18_linkActivated(const QString &link);
    void on_label_40_linkActivated(const QString &link);
    void on_action_Logout_triggered();
    void on_action_Quit_triggered();
    void on_action_Diagnostics_Data_Monitoring_2_triggered();
    void on_action_FPGA_Read_Write_triggered();
    void on_tbActionLog_anchorClicked(const QUrl &in_qurlFile);

    void print_uart_processing_errors(short in_sRetVal);
    void on_action_Command_and_Response_triggered();
    void on_action_Antenna_Array_Identifiers_triggered();
    void on_actionSave_Graph_triggered();

    void on_pbEnDis_DiagMode_toggled(bool checked);

    void on_actionShow_Diagnostics_Parametes_triggered(bool checked);

    void on_actionOpen_Log_Folder_triggered();

    void on_action_Seaspray_Operation_triggered();

signals:
    void tempsig(U_DEM_PORT_RX);
};

#endif // MAINWINDOW_H
