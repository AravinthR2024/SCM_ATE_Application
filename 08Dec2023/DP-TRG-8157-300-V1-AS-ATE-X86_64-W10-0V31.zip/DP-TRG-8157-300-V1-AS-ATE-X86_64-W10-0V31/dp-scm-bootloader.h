/**
* \file dp-scm-bootloader.h
* \brief This is the header file for dp-scm-flashprogramming.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef FLASHPROGRAMMING_H
#define FLASHPROGRAMMING_H

//#include "winnt.h"
//#include "profileapi.h"
#include <QWidget>
#include <QFileDialog>
#include <QThread>
#include <QTimer>
#include <QDebug>
#include <QEvent>
#include <QMouseEvent>
#include <QFocusEvent>
#include <QFontMetrics>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "dprs232_wrapper.h"
#include "includes/dp-scm-crc32checksum.h"

#define PRGMMODE_EN      0
#define PRGMMODE_DIS     1

#define MODE_WRITE          0
#define MODE_CKSM_READ		1
#define MODE_VERIFY         2
#define MODE_ERASE          3

#define SET_PROGRAM_MODE(mode) {\
    ui->pbFlash_Erase->setEnabled(mode);\
    ui->pbFlash_Write->setEnabled(mode);\
    ui->pbFlash_ReadChecksum->setEnabled(mode);\
}

namespace Ui {
class CBootLoader;
}

class CBootLoaderThread : public QThread
{
    Q_OBJECT

public:
    CBootLoaderThread(QObject *parent);
    bool m_bIsRunning;
    unsigned char m_ucMode;
    QString m_qstrPrgmFile;
    int m_iProgBar;
    unsigned long m_ulBootloadFileSize;
    unsigned long m_ulReadbackChecksum;

    bool bFlag = true;
    unsigned char  ucTestCount = 0;
    unsigned char  ucExecuteCount = 0;
    QString         m_qsFLASHLoad_FilePath;
    S_FLASH_CSTEST          S_FlashCksmTst;
    S_FLASH_CSTEST          m_S_FlashCksmTst;
    S_FPGA_FLASH_LOAD       S_FPGA_FlashLoad;
    //extern  class UART_Config *ObjUART;
    QTime m_qtimeTime;
    unsigned char gucPortStatus;
    int m_iRetval;

    void setMode(unsigned char in_ucMode);
    void Start(unsigned char in_ucMode = DPSCM_FAILURE);
    void Stop();
    void setProgramFile(QString in_qstrPrgmFile);
    void run();

    void DPSCM_FLASH_CHKSM_READ();

    void DPSCM_FLASH_ERASE();

    void DPSCM_FLASH_LOAD();

    void DPSCM_FLASH_VERIFY();

    void DPSCM_FLASH_VERIFY_LOAD(unsigned short in_usCMDId);

    void DPSCM_FLASH_LOAD_DATA(unsigned short in_usCMDId);

    short DP_SCM_FramePacket_And_Buffer(unsigned short in_usCommandID, unsigned short in_usDataLength, unsigned char *in_pucData, S_DATA_PACKET *out_pSDataPacket, unsigned char *out_pucDataBuffer);
    short DP_SCM_TxData_RxResponse(unsigned short in_usCommandID, unsigned short in_usDataLength, unsigned char *in_pucData, S_DATA_PACKET *out_pSRxDataPacket, unsigned long in_ulTimeOut);
    short DP_SCM_TxData_RxResponse1(unsigned short in_usCommandID, unsigned short in_usDataLength, unsigned char *in_pucData, S_DATA_PACKET *out_pSRxDataPacket, unsigned long in_ulTimeOut);
    short DP_SCM_Receive_DataPacket1(unsigned short in_usCommandID, S_DATA_PACKET *out_pSRxDataPacket, unsigned short in_usTimeOut);
    short DP_SPL_6996_ReadData_Packet(unsigned char in_ucData, S_DATA_PACKET *out_pSDataPacket, unsigned char *out_pucDataRxStatus, unsigned char *out_pucState, unsigned short *out_pusCheckSum, unsigned short *out_pusDataReadCnt);
    short DP_SCM_Receive_DataPacket(unsigned short in_usCommandID, S_DATA_PACKET *out_pSRxDataPacket, unsigned long in_ulTimeOut);
    void Delay(unsigned long in_ulTime_usec);
signals:
    sig_updateProgressBar(int in_iMaxVal, int in_iCurrValue, QString in_qstrLabel = QString());

    sig_UART_WriteRead_Cmd(unsigned short in_usCommandID, char *in_pucInputDataBuffer, unsigned int uiInputDataLen,
                           char *out_pucOutputDataBuffer, unsigned int uiOutputDataLen, unsigned int uiTimeout_ms);


    sig_updateActionLog(QString, int);

    sig_threadFinished();
    void sig_updateChecksum();

#if 0
//    short sig_UARTWrite(char *in_pcBuffData, long long in_lliDataLen);
    short sig_DP_SCM_TxData_RxResponse(unsigned short in_usCommandID, unsigned short in_usDataLength,
                                       unsigned char *in_pucData, S_DATA_PACKET *out_pSRxDataPacket,
                                       unsigned long in_ulTimeOut);
    short sig_DP_SCM_TxData_RxResponse1(unsigned short in_usCommandID, unsigned short in_usDataLength,
                                              unsigned char *in_pucData, S_DATA_PACKET *out_pSRxDataPacket,
                                              unsigned long in_ulTimeOut);
    short sig_DP_SCM_Receive_DataPacket(unsigned short in_usCommandID, S_DATA_PACKET *out_pSRxDataPacket, unsigned long in_ulTimeOut);
#endif
    sig_showErrorMessage(short);
};

class CBootLoader : public QWidget
{
    Q_OBJECT

public:
    explicit CBootLoader(QWidget *parent = 0);
    ~CBootLoader();

    CBootLoaderThread *m_pThProgramLoading;
    QTimer m_timerHideProgBar;
    QString m_qstrPrgmFile;
    unsigned long m_ulPrgmFileSize;

    int SerialWrite(unsigned short in_us_Command_Id, char *in_ucData, unsigned short in_usDataSize);

    int SerialRead(char *out_pucDataBuffer, unsigned int in_uiOutputDataLen, unsigned int in_uiTimeout);

    short calculateChecksumRS232(char *in_pucMessage, unsigned long in_ulBytes);

private:
    Ui::CBootLoader *ui;

signals:
    void sig_updateActionLog(QString, int);
    void sig_changePage(int);
    void sig_showLoadingScreen(bool);

public slots:
    void slot_updateFlash_ProgBar(int in_iMaxVal, int in_iProgSts, QString in_qstrLabel);
    int slot_UARTSendAndReceive(unsigned short in_usCommandID, char *in_pucInputDataBuffer, unsigned int in_uiInputDataLen, \
                                char *out_pucOutputDataBuffer, unsigned int in_uiOutputDataLen, unsigned int in_uiTimeout_ms);
    void slot_hideProgBar();
    void slot_updateActionLog(QString in_qstrMsg, int in_iType);
    void slot_updateChecksum();
    void slot_threadFinished();
    void slot_EnDisSync(bool in_bEnable = true, bool in_bFromConfig = true);
    void slot_setProgramFile(QString in_qstrPrgmFile);


private slots:
    void on_pbFlash_Browse_clicked();
    void Flash_Verify_Function();
    void on_pbFlash_Erase_clicked();
    void on_pbFlash_Write_clicked();
    void on_rbSection_DSP_clicked();
    void on_rbSection_FPGA_clicked();
    void on_cmbFlash_FilePath_currentIndexChanged(int index);
    void on_pbFlash_ReadChecksum_clicked();
    void on_rbSection_DSP_toggled(bool checked);
    void on_rbSection_FPGA_toggled(bool checked);
    void on_pbProgramEnablePin_clicked(bool in_bEnable);
    void on_pbProgramEnablePin_toggled(bool in_bEnable);
};

#endif // FLASHPROGRAMMING_H
