/**
* \file dp-scm-ateselftest.cpp
* \brief This file contains the code for Self test panel
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-ateselftest.h"
#include "ui_dp-scm-ateselftest.h"

extern S_GLOBAL g_SGlobal;

/*******************************************************************************
 * Name					: CATESelftest
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief This function is the constructor of CATESelftest class
 *
 * @param[in]	parent	Holds the reference to the parent object (QWidget*)
 * @param[in]	in_pobjRS232	Holds the reference to the object of RS232 Wrapper (CDPRS232Wrapper*)
 * @return	NA
 ******************************************************************************/
CATESelftest::CATESelftest(QWidget *parent) :
	QWidget(parent),
	ui(new Ui::CATESelftest)
{
	ui->setupUi(this);

	m_bIsSelfTestDone = false;
	m_bIsSelftestPass = false;

//	m_pobjRS232 = in_pobjRS232;

    ui->rbPort_CmdPort->setText("&RS422 Real Time Port");
    ui->rbPort_DiagPort->setText("RS422 Diagnostics &Port");
	ui->rbATESelfTest->setChecked(true);
    ui->stackSelfTest->setCurrentIndex(SELFTEST_PAGE_ATE);

    /** For Hiding ATE Self Test and HDLC Self Test Selection */
    ui->frameSelfTestSelection->setHidden(false); //changed for HDLC testing
}

/*******************************************************************************
 * Name					: ~CATESelftest
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief This function is the destructor of CATESelftest class
 *
 * @param		NIL
 * @return	NA
 ******************************************************************************/
CATESelftest::~CATESelftest()
{
	delete ui;
}

/*******************************************************************************
 * Name					: executeSelftest
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To execute selftest
 ***************************************************************************//**
 * @brief This function executes the self test for ATE and return pass or fail
 *
 * @param[in]	in_ucTestMode	Holds the ATE Selftest mode	(unsigned char)
 *				0 - Selftest based on the Input text given by user (Pattern)
 *				1 - Selftest based on the text auto generated (Counter)
 * @return	DPSCM_SUCCESS	if ATE Selftest is passed
 *			DPSCM_FAILURE	if ATE Selftest is failed
 ******************************************************************************/
short CATESelftest::executeSelftest(unsigned char in_ucPortNo, unsigned char in_ucTestMode)
{
    char pcData[SELFTEST_SIZE] = { 0 };
    char pcReadData[SELFTEST_SIZE] = { 0 };
	char *szTempArr = 0;
	unsigned int uiReadSize = DPSCM_INIT_0;
    int iRetval = DPSCM_INIT_0;
    int iTemp = DPSCM_INIT_0;
    QString qstrErrMsg = QString();
    QString qstrTemp = QString();

	unsigned short usLoop = DPSCM_INIT_0;
    unsigned short usInputLength = DPSCM_INIT_0;

	if (in_ucTestMode == TESTMODE_AUTO)
	{
		char cChar = 'A';
		unsigned char ucDataCnt = 26;
		for (usLoop = DPSCM_INIT_0; usLoop < SELFTEST_SIZE; usLoop++)
		{
			pcData[usLoop] = (cChar + (usLoop % ucDataCnt));
		}
	}
	else
	{
		usInputLength = ui->leSelftest_TxtInp->text().length();
		if (usInputLength == DPSCM_INIT_0)
        {
            free(szTempArr);
			return (DPSCM_FAILURE - 1);
		}

		szTempArr = (char *) calloc(usInputLength, sizeof(char));
		if (!szTempArr)
        {
			free(szTempArr);
			return DPSCM_FAILURE;
		}
		sprintf(szTempArr, ui->leSelftest_TxtInp->text().toStdString().c_str());
        for (usLoop = DPSCM_INIT_0; usLoop < SELFTEST_SIZE; usLoop++)
		{
            iTemp = usLoop % usInputLength;
            pcData[usLoop] = szTempArr[iTemp];
		}
    }

    iRetval = g_SGlobal.m_objRS232[in_ucPortNo].DPRS232Wrap_WriteData(pcData, SELFTEST_SIZE);
    if (iRetval != DPSCM_SUCCESS)
    {
		free(szTempArr);
        g_SGlobal.m_objRS232[in_ucPortNo].DPRS232Wrap_GetLastError(&iRetval, qstrErrMsg);
        qstrTemp.sprintf("Data Write Failed : %s [Err: %d]", qstrErrMsg.toStdString().c_str(), iRetval);
        emit sig_updateActionLog(qstrTemp, LOG_WARNING);
		return DPSCM_FAILURE;
	}

    iRetval = g_SGlobal.m_objRS232[in_ucPortNo].DPRS232Wrap_ReadData(SELFTEST_SIZE, pcReadData, &uiReadSize, 3000 /* Infinite TImeout */);
    if (iRetval != DPSCM_SUCCESS)
    {
        free(szTempArr);
        g_SGlobal.m_objRS232[in_ucPortNo].DPRS232Wrap_GetLastError(&iRetval, qstrErrMsg);
        qstrTemp.sprintf("Data Read Failed : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetval);
        emit sig_updateActionLog(qstrTemp, LOG_WARNING);
        return DPSCM_FAILURE;
    }

#if 0   // Temp change to 0 after testing
    qDebug() << "DISPLAYING WRITTEN DATA : ";
    for (int i = 0; i < SELFTEST_SIZE; i++)
    {
        qDebug("%d : %c", i, pcData[i]);
    }
    qDebug() << "DISPLAYING READ DATA : ";
    for (int i = 0; i < uiReadSize; i++)
    {
        qDebug("%d : %c", i, pcReadData[i]);
    }

    qDebug() << "WRITE SIZE : " << SELFTEST_SIZE;
    qDebug() << "READ SIZE : " << uiReadSize;
#endif

	if (uiReadSize != SELFTEST_SIZE)
    {
		free(szTempArr);
        emit sig_updateActionLog("Write and Read data size doesn't match", LOG_WARNING);
		return DPSCM_FAILURE;
    }

	for (usLoop = DPSCM_INIT_0; usLoop < SELFTEST_SIZE; usLoop++)
	{
        if (pcData[usLoop] != pcReadData[usLoop])
        {
			free(szTempArr);
            emit sig_updateActionLog("Write and Read Data doesn't match", LOG_WARNING);
			return DPSCM_FAILURE;
		}
	}

	free(szTempArr);
	return DPSCM_SUCCESS;
}

/*******************************************************************************
 * Name					: on_pbSelfTest_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To start executing self test
 ***************************************************************************//**
 * @brief This function is used to initiate ATE Selftest execution and display result
 *		This function is called when Test button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CATESelftest::on_pbSelfTest_clicked()
{
	unsigned char ucTestmode = DPSCM_SUCCESS;
    unsigned char ucTestPortNo = DPSCM_INIT_0;
    short sRetval = DPSCM_INIT_0;
	QString qstrPortMsg = QString("");

    CHECK_TC_RUNNING;

    if (ui->rbPort_CmdPort->isChecked())
	{
        ucTestPortNo = COMMAND_PORT_IDX;
        qstrPortMsg.sprintf("Real Time Port");
        CHECK_PORT_OPEN(COMMAND_PORT_IDX);
	}
    else if (ui->rbPort_DiagPort->isChecked())
	{
        ucTestPortNo = DIAGNOSTIC_PORT_IDX;
		qstrPortMsg.sprintf("Diagnostics Port");
        CHECK_PORT_OPEN(DIAGNOSTIC_PORT_IDX);
	}
	else
	{
		DISPLAY_MESSAGE_BOX(this, "ATE Selftest", "Please select a port");
		return;
    }

    if ((!ui->rbTestMode_Input->isChecked()) && (!ui->rbTestMode_Auto->isChecked()))
	{
		DISPLAY_MESSAGE_BOX(this, "ATE Selftest", "Please select a test mode");
		return;
	}

    ucTestmode = ui->rbTestMode_Auto->isChecked();
	if (ucTestmode == TESTMODE_INPUT)
	{
		if (ui->leSelftest_TxtInp->text().isEmpty())
		{
			DISPLAY_MESSAGE_BOX(this, "ATE Selftest", "Please enter text for self test");
			return;
		}
    }

    sRetval = executeSelftest(ucTestPortNo, ucTestmode);
    if (sRetval != DPSCM_SUCCESS)
    {
        sig_updateActionLog("ATE Self Test Failed", LOG_ERROR);
        DISPLAY_MESSAGE_BOX(this, "ATE Self Test", "Self Test Failed");
        return;
    }
}

/*******************************************************************************
 * Name					: on_rbTestMode_Input_toggled
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To specify which selftest mode is selected
 ***************************************************************************//**
 * @brief This function is used to Enable/Disable Selftest line edit input
 *		This function is called when Pattern Test radiobutton toggled in ATE Selftest
 *
 * @param[in]	in_bIsChecked	Holds the select/unselect state of radiobutton (bool)
 * @return	NIL
 ******************************************************************************/
void CATESelftest::on_rbTestMode_Input_toggled(bool in_bIsChecked)
{
	ui->frameSelfTestTxtInput->setEnabled(in_bIsChecked);
}

/*******************************************************************************
 * Name					: on_rbATESelfTest_toggled
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To specify which self test is selected
 ***************************************************************************//**
 * @brief This function is used to change between ATE and HDLC Selftest widgets
 *		This function is called when ATE Selftest radiobutton is toggled
 *
 * @param[in]	in_bChecked	Holds if ATE Selftest radiobutton is checked (bool)
 * @return	NIL
 ******************************************************************************/
void CATESelftest::on_rbATESelfTest_toggled(bool in_bChecked)
{
	Q_UNUSED(in_bChecked);

	if (ui->rbATESelfTest->isChecked())
	{
		ui->stackSelfTest->setCurrentIndex(SELFTEST_PAGE_ATE);
	}
	else
	{
		ui->stackSelfTest->setCurrentIndex(SELFTEST_PAGE_HDLC);
	}
}

/*******************************************************************************
 * Name					: on_pbXMC_Send_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To send data in HDLC
 ***************************************************************************//**
 * @brief	This function is used to send the data in HDLC
 *		This function is called when Send button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CATESelftest::on_pbXMC_Send_clicked()
{
	int iRetval = DPSCM_INIT_0;
    bool ok = 0;
    unsigned int uiInput = DPSCM_INIT_0;
    unsigned char ucRepeatCount = DPSCM_INIT_0;
	QFile qfpXMCTestFile;
	QString qstrTxData = QString();
	QString qstrTemp = QString();
	char szErrMsg[100];

    SDPXMC5775_12_HDLC_FRAME_CONFIG SFrameConfig;

    memset (&SFrameConfig, 0, sizeof(SDPXMC5775_12_HDLC_FRAME_CONFIG));

    CHECK_TC_RUNNING;

    SFrameConfig.m_u8Command = SEASPRAY_CMD_ERR_RESET_PEDESTAL_ON;
    SFrameConfig.m_u8IdelFlag = SEASPRAY_IDLE_FLAG;
    SFrameConfig.m_u8SlaveAddress = SEASPRAY_ADDR_TX;
    uiInput = ui->leXMC_TxData->text().toUInt(&ok, 16);
    SFrameConfig.m_u16Velocity = (uiInput & 0xFFFF);
    SFrameConfig.m_u16Spare1 = (uiInput & 0xFFFF);
    SFrameConfig.m_u8Spare2 = (uiInput >> 16) & 0xFF;

    ucRepeatCount = ui->leXMC_RepeatCount->text().toUShort(&ok);

    if (ui->leXMC_TxData->text ().isEmpty ())
    {
        DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", "Please enter Tx Data");
        return;
    }

    qstrTxData = ui->leXMC_TxData->text ();

    iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_SetMasterAddress (XMC_BRD_IDX, SEASPRAY_ALL_DEVICE_MASTER);
    if (iRetval != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
        qstrTemp.sprintf ("XMC Master Address Configuration Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
        emit sig_updateActionLog (qstrTemp, LOG_ERROR);
        DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
        return;
    }

    iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_SetResponseTimeout(XMC_BRD_IDX, 50);
    if (iRetval != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
        qstrTemp.sprintf ("XMC Set Response Timeout Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
        emit sig_updateActionLog (qstrTemp, LOG_ERROR);
        DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
        return;
    }

    iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_SetFIFOThreshold(XMC_BRD_IDX, SCM_RESP_CNT);
    if (iRetval != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
        qstrTemp.sprintf ("XMC Set FIFO Threshold Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
        emit sig_updateActionLog (qstrTemp, LOG_ERROR);
        DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
        return;
    }

    iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_SetInterrupt(XMC_BRD_IDX, SCM_FIFO_FULL_INT|SCM_FIFO_EMPTY_INT|SCM_FIFO_THRESHOLD_INT|SCM_RESP_TIMEOUT_INT, true);
    if (iRetval != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
        qstrTemp.sprintf ("XMC Set Interrupt Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
        emit sig_updateActionLog (qstrTemp, LOG_ERROR);
        DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
        return;
    }

    iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_ConfigureHDLCFrame (XMC_BRD_IDX, &SFrameConfig);
	if (iRetval != DPSCM_SUCCESS)
	{
		g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
        qstrTemp.sprintf ("XMC Frame Packet Configuration Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
		emit sig_updateActionLog (qstrTemp, LOG_ERROR);
		DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
		return;
    }

    iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_StartTransmission (XMC_BRD_IDX, ucRepeatCount);
    if (iRetval != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
        qstrTemp.sprintf ("XMC Transmission Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
        emit sig_updateActionLog (qstrTemp, LOG_ERROR);
        DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
        return;
    }

	emit sig_updateActionLog ("HDLC Self Test Data sent successfully", LOG_SUCCESS);
    // DISPLAY_MESSAGE_BOX(this, "XMC Self Test", "HDLC Self Test Data sent successfully");

#if 0
    on_pbXMC_Recv_clicked();

	iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_StopTransmission (XMC_BRD_IDX);
	if (iRetval != DPSCM_SUCCESS)
	{
		g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
        qstrTemp.sprintf ("XMC Transmission Stop Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
		emit sig_updateActionLog (qstrTemp, LOG_ERROR);
		DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
		return;
	}
#endif
}

/*******************************************************************************
 * Name					: on_pbXMC_Recv_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To receive data in HDLC
 ***************************************************************************//**
 * @brief	This function is used to receive data from HDLC and display
 *		This function is called when Receive button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CATESelftest::on_pbXMC_Recv_clicked()
{
    unsigned short usLoop = DPSCM_INIT_0;
    unsigned int uiResponseData[SCM_RESP_CNT] = { DPSCM_INIT_0 };
	unsigned int uiActualReadCnt = DPSCM_INIT_0;
    unsigned int uiFifoCnt = DPSCM_INIT_0;
    unsigned int uiTimeout = DPSCM_INIT_0;
	int iRetval = DPSCM_INIT_0;
    char szErrMsg[100] = { 0 };
	QString qstrRxData = QString();
	QString qstrTemp = QString();
    QFile qfFile;

    CHECK_TC_RUNNING;

    uiTimeout = 50;

#if 1
    iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetFIFOCount (XMC_BRD_IDX, &uiFifoCnt);
    if (iRetval != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
        qstrTemp.sprintf ("XMC Reception Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
        emit sig_updateActionLog (qstrTemp, LOG_ERROR);
        DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
        return;
    }

    ui->leXMC_RxData->setText(QString::number(uiFifoCnt));

    if (uiFifoCnt <= DPSCM_INIT_0)
    {
        emit sig_updateActionLog("Rx FIFO Count is " + QString::number(uiFifoCnt), LOG_ERROR);
        return;
    }
#endif

    iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_ReadData (XMC_BRD_IDX, &uiTimeout, SCM_RESP_CNT, uiResponseData, &uiActualReadCnt);
    if (iRetval != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
        qstrTemp.sprintf ("XMC Reception Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
        emit sig_updateActionLog (qstrTemp, LOG_ERROR);
        DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
        return;
    }
#if 1
    qfFile.setFileName("./hdlc_data.txt");
    qfFile.open(QIODevice::WriteOnly);
    for (usLoop = DPSCM_INIT_0; usLoop < uiActualReadCnt; usLoop++)
    {
        qstrRxData = QString::number (uiResponseData[usLoop], 16).toUpper ();
        qstrRxData.append("\n");
        qfFile.write(CONV_QSTR_TO_SZ(qstrRxData));
    }
    qfFile.close();
#else
    qstrRxData = QString::number (uiResponseData[usLoop], 16).toUpper ();
#endif

    qstrTemp.sprintf ("XMC Reception Successful");
    emit sig_updateActionLog (qstrTemp, LOG_SUCCESS);
#if 0
    iRetval = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_StartStopReception (XMC_BRD_IDX, false);
    if (iRetval != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError (&iRetval, szErrMsg);
        qstrTemp.sprintf ("XMC Reception Stop Failed : %s [ErrCode: %d]", szErrMsg, iRetval);
        emit sig_updateActionLog (qstrTemp, LOG_ERROR);
        DISPLAY_MESSAGE_BOX(this, "HDLC Self Test", qstrTemp);
        return;
    }
#endif
}
