/**
* \file dp-scm-mainwindow.cpp
* \brief This file contains the code for Mainwindow
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-mainwindow.h"
#include "ui_dp-scm-mainwindow.h"

S_GLOBAL g_SGlobal;
extern SDPPCI755_ANALYZEDDATABUFFER g_SCurrentDataBuffer;

/*******************************************************************************
 * Name					: MainWindow
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of MainWindow class
 *
 * @param[in]	parent	Holds the reference of the parent
 *
 * @return	NA
 ******************************************************************************/
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    setWindowTitle(WINDOW_TITLE);
    ui->lbPageTitle->setText("SCM ATE Application");

    qRegisterMetaType<U_DEM_PORT_RX>("U_DEM_PORT_RX");
    qRegisterMetaType<U_DEM_PORT_TX>("U_DEM_PORT_TX");
    qRegisterMetaType<S_RGA_RESPONSE>("S_RGA_RESPONSE");
    qRegisterMetaType<S_RTGA_RESPONSE>("S_RTGA_RESPONSE");

    m_iCurrPage = PAGE_INVALID;
    g_SGlobal.m_ucSystem = DPSCM_FAILURE;

    g_SGlobal.m_pobjCommandMsgQ = new CDPMsgQueue(1000, sizeof(U_DEM_PORT_TX));
    g_SGlobal.m_pobjResponseMsgQ = new CDPMsgQueue(1000, sizeof(U_DEM_PORT_RX));
    g_SGlobal.m_pobjDiagRespMsgQ = new CDPMsgQueue(1000, sizeof(S_DIAG_CMDRESP));
    g_SGlobal.m_objDiagCmdMsgQ = new CDPMsgQueue(1000, sizeof(S_DIAG_CMDRESP));
    g_SGlobal.m_objDebugDataMsgQ = new CDPMsgQueue(1000, sizeof(S_DIAG_DATA_RESP));
    g_SGlobal.m_objHDLCDataMsgQ = new CDPMsgQueue(10000, sizeof(S_DIAG_DATA_RESP));
    g_SGlobal.m_qDemPortLogMsgQ = new CDPMsgQueue(1000, sizeof(U_CMDRESP_DATA));
    g_SGlobal.m_qDiagPortLogMsgQ = new CDPMsgQueue(1000, sizeof(U_CMDRESP_DATA));
    g_SGlobal.m_qDebugDataLogMsgQ = new CDPMsgQueue(1000, sizeof(U_CMDRESP_DATA));
    g_SGlobal.m_qHDLCDataLogMsgQ = new CDPMsgQueue(10000, sizeof(S_DIAG_DATA_RESP));

    m_pobjAbout = new CAbout(this); /* About Dialog */
    m_pobjModInit = new CModInitStatus(this);
    m_pobjRS422Config = new CRS422Configuration(this);
    m_pobjPBITStatus = new CPBITStatus(this);
    m_pobjCBITStatus = new CCBITStatus(this);
    m_pobjSCMControl = new CSCMOperation(this);
    m_pobjATESelftest = new CATESelftest(this);
    m_pobjBootLoading = new CBootLoader(this);
    m_pobjCtrlLoopConfig = new CControlLoopConfig(this);
    m_pobjSystemDetails = new CSystemDetails(this);
    m_pobjResponseMon = new CResponseMonitoring(this);
    m_pobjUserMgmt = new CUserManagement(this);
    m_pobjAuth = new Authentication(this);
    m_pobjDiagMonitoring = new CDiagDataMonitoring(this);
    m_pobjFPGA_RW = new CFPGA_RW(this);
    m_pobjSeasprayOperation = new CSeasprayOperation(this);

    m_pThRespRx = new CResponseRx(this, 50000);
    m_pThDiagRx = new CDiagnosticRx(this, 50000);
    m_pThDataProcessing = new CDataProcessing(this, 50000);
    m_pThLogging = new CLoggingThread(this);

    m_pobjSCMControl->m_pThAnaDataRead = new CANADataReadThread(this);
    m_pobjSCMControl->m_pThDataRead = new CDataReadThread(this);
    m_pobjSCMControl->m_pThReadRawDataFIFO = new CReadRawDataFIFO(this);

    m_pobjArrayIdent = new CArrayIdentVerification(this);

    m_pobjLoadingScreen = new CLoadingScreen(this);

    ui->tbActionLog->setContextMenuPolicy (Qt::CustomContextMenu);
    m_qstrActionLogBeforeClear.clear ();

    g_SGlobal.m_ucConfiguredMode = SERVO_MODE;

    /* Connect slots and signals */
    connectSigSlots ();

    ui->action_Command_and_Response->setVisible(false);

    ui->splitter->setSizes(QList<int>() << window()->height() - ACTION_LOG_SIZE << ACTION_LOG_SIZE); /* For setting initial size for actionlog */

    initAppScreen();

    m_pobjModInit->initModules();
    m_pobjModInit->updateModulesTable();
}

/*******************************************************************************
 * Name					: ~MainWindow
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief	This function is the destructor of MainWindow class
 *
 * @param		NIL
 * @return	NA
 ******************************************************************************/
MainWindow::~MainWindow()
{
    slot_startSCMCmdResp(false, SERVO_MODE);

    if (m_qfileActionLog.isOpen ())
    {
        m_qfileActionLog.close();
    }

    if (m_qfileBITStatusReport.isOpen ())
    {
        m_qfileBITStatusReport.close ();
    }

    if (m_pobjSCMControl->m_pThAnaDataRead->isRunning ())
    {
        m_pobjSCMControl->m_pThAnaDataRead->terminate ();
    }

    if (m_pThDataProcessing->isRunning ())
    {
        m_pThDataProcessing->terminate ();
    }

    if (m_pobjSCMControl->m_pThDataRead->isRunning ())
    {
        m_pobjSCMControl->m_pThDataRead->terminate ();
    }

    if (m_pThDiagRx->isRunning ())
    {
        m_pThDiagRx->terminate ();
    }

    if (m_pobjSCMControl->m_pThReadRawDataFIFO->isRunning ())
    {
        m_pobjSCMControl->m_pThReadRawDataFIFO->terminate ();
    }

    if (m_pThRespRx->isRunning ())
    {
        m_pThRespRx->terminate ();
    }

    if (m_pThLogging->isRunning())
    {
        m_pThLogging->terminate();
    }

    delete ui;
}

void MainWindow::connectSigSlots()
{
    /** Enable/Disable Menubar */
    connect(this, SIGNAL(sig_UART_WriteRead_Cmd(unsigned short,char*,uint,char*,uint,uint)), \
            m_pobjBootLoading, SLOT(slot_UARTSendAndReceive(unsigned short,char*,uint,char*,uint,uint)));
    connect(m_pobjModInit, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjModInit, SIGNAL(sig_changePage(int)), this, SLOT(slot_changePage(int)));
    connect(m_pobjRS422Config, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjRS422Config, SIGNAL(sig_changePage(int)), this, SLOT(slot_changePage(int)));
    connect(m_pobjRS422Config, SIGNAL(sig_EnDisSync(bool,bool)), m_pobjBootLoading, SLOT(slot_EnDisSync(bool,bool)));
    connect(m_pobjPBITStatus, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjPBITStatus, SIGNAL(sig_changePage(int)), this, SLOT(slot_changePage(int)));
    connect(m_pobjCBITStatus, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjCBITStatus, SIGNAL(sig_changePage(int)), this, SLOT(slot_changePage(int)));
    connect(m_pobjSCMControl, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjSCMControl, SIGNAL(sig_changePage(int)), this, SLOT(slot_changePage(int)));
    connect(m_pobjATESelftest, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjATESelftest, SIGNAL(sig_changePage(int)), this, SLOT(slot_changePage(int)));
    connect(m_pobjBootLoading, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjBootLoading, SIGNAL(sig_changePage(int)), this, SLOT(slot_changePage(int)));
    connect(m_pobjCtrlLoopConfig, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjCtrlLoopConfig, SIGNAL(sig_changePage(int)), this, SLOT(slot_changePage(int)));
    connect(m_pobjSystemDetails, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjSystemDetails, SIGNAL(sig_changePage(int)), this, SLOT(slot_changePage(int)));
    connect(m_pobjResponseMon, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjResponseMon, SIGNAL(sig_changePage(int)), this, SLOT(slot_changePage(int)));

    connect (m_pThDiagRx, SIGNAL(sig_updateBITStatus(unsigned char,unsigned char)), this, SLOT(slot_updateBITStatus(unsigned char,unsigned char)));
    connect (m_pThDiagRx, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));

    connect(m_pobjATESelftest, SIGNAL(sig_changePageTitle(QString)), this, SLOT(slot_changePageTitle(QString)));
    connect (m_pobjRS422Config, SIGNAL(sig_changePageTitle(QString,bool)), this, SLOT(slot_changePageTitle(QString,bool)));

    connect(m_pobjSCMControl, SIGNAL(sig_changePageTitle(QString,bool)), this, SLOT(slot_changePageTitle(QString,bool)));
    connect(m_pobjCBITStatus, SIGNAL(sig_updateCBITBar(PSSCM_CBIT01STS)), this, SLOT(slot_updateCBITBar(PSSCM_CBIT01STS)));
    connect(m_pThDataProcessing, SIGNAL(sig_updateBITStatus(unsigned char,unsigned char)), this, SLOT(slot_updateBITStatus(unsigned char,unsigned char)));
    connect(m_pobjSCMControl, SIGNAL(sig_startDiagCMDTx(bool)), this, SLOT(slot_startDiagCMDThread(bool)));
    connect(m_pobjRS422Config, SIGNAL(sig_startDiagCMDTx(bool)), this, SLOT(slot_startDiagCMDThread(bool)));
    connect (m_pobjArrayIdent, SIGNAL(sig_startDiagCMDTx(bool)), this, SLOT(slot_startDiagCMDThread(bool)));
    connect(m_pobjResponseMon, SIGNAL(sig_startFRAAcquisition(bool)), this, SLOT(slot_FRAAcqStart(bool)));
    connect(m_pobjResponseMon, SIGNAL(sig_startResponseMonitoring()), m_pobjSCMControl, SLOT(on_pbStart_clicked()));

    connect(m_pobjSCMControl, SIGNAL(sig_startOnlineGraphAcquisition()), this, SLOT(slot_startFRAAcq()));
    connect(m_pobjSCMControl->m_pThAnaDataRead, SIGNAL(sig_DisplayMessage(QString)), this, SLOT(slot_DisplayMessage(QString)));
    connect(m_pobjSCMControl->m_pThAnaDataRead, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjSCMControl->m_pThAnaDataRead, SIGNAL(Test_Current_Data_Generator(U16BIT,PSDPPCI755_ANALYZEDDATABUFFER,SDPPCI755_CONFIG)), this, SLOT(slot_Test_Current_Data_Generator(U16BIT,PSDPPCI755_ANALYZEDDATABUFFER,SDPPCI755_CONFIG)));
    connect(m_pobjSCMControl->m_pThAnaDataRead, SIGNAL(Current_Data_Display(unsigned short, unsigned int)), this,SLOT(slot_CurrentDataDisplay(unsigned short, unsigned int)), Qt::BlockingQueuedConnection);
    connect(m_pobjSCMControl->m_pThAnaDataRead, SIGNAL(Acq_Start(bool)), this, SLOT(slot_FRAAcqStart(bool)));
    connect(m_pobjSCMControl->m_pThAnaDataRead, SIGNAL(Stop_Acq()), this, SLOT(slot_FRAAcqStop()));
    connect(m_pobjSCMControl->m_pThAnaDataRead, SIGNAL(MainWin_Ongraph_Draw(unsigned int)), this, SLOT(MainWinOngraphDraw(unsigned int)));
    connect(m_pobjSCMControl->m_pThDataRead, SIGNAL(sig_DisplayMessage(QString)), this, SLOT(slot_DisplayMessage(QString)));
    connect(m_pobjSCMControl->m_pThDataRead, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjSCMControl->m_pThDataRead, SIGNAL(Current_Data_Display(unsigned short, unsigned int)), this,SLOT(slot_CurrentDataDisplay(unsigned short, unsigned int)));
    connect(m_pobjSCMControl->m_pThDataRead, SIGNAL(Test_Current_Data_Generator(U16BIT,PSDPPCI755_ANALYZEDDATABUFFER,SDPPCI755_CONFIG)), this, SLOT(slot_Test_Current_Data_Generator(U16BIT,PSDPPCI755_ANALYZEDDATABUFFER,SDPPCI755_CONFIG)));
    connect(m_pobjSCMControl->m_pThDataRead, SIGNAL(Acq_Start(bool)), this, SLOT(slot_FRAAcqStart(bool)));
    connect(m_pobjSCMControl->m_pThDataRead, SIGNAL(Stop_Acq()), this, SLOT(slot_FRAAcqStop()));
    connect(m_pobjSCMControl->m_pThDataRead, SIGNAL(MainWin_Ongraph_Draw(unsigned int)), this, SLOT(MainWinOngraphDraw(unsigned int)));
    connect(m_pobjSCMControl->m_pThReadRawDataFIFO, SIGNAL(sig_DisplayMessage(QString)), this, SLOT(slot_DisplayMessage(QString)));
    connect(m_pobjSCMControl->m_pThReadRawDataFIFO, SIGNAL(sig_updateActionLog(QString, int)), this, SLOT(slot_updateActionLog(QString, int)));
    connect(m_pobjSCMControl->m_pThReadRawDataFIFO, SIGNAL(Stop_Acq()), this, SLOT(slot_FRAAcqStop()));
    connect(this,SIGNAL(OnGraph_Draw()), m_pobjResponseMon,SLOT(DrawGraph()));
    connect (m_pobjSCMControl, SIGNAL(sig_clearGraph()), m_pobjResponseMon, SLOT(slot_clearGraph()));
    connect(m_pobjBootLoading->m_pThProgramLoading, SIGNAL(sig_showErrorMessage(short)), this, SLOT(print_uart_processing_errors(short)));

    connect (m_pThRespRx, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));

    connect (m_pobjSCMControl->m_pThDataRead, SIGNAL(sig_changeButtonName(QString)), m_pobjSCMControl, SLOT(slot_changeButtonName(QString)));

    connect(m_pobjFPGA_RW, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));

    connect(this, SIGNAL(sig_updateCBITStatus(unsigned char,unsigned char)), m_pobjCBITStatus, SLOT(slot_updateCBITStatus(unsigned char,unsigned char)));

    connect(ui->tbActionLog, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(slot_contextMenuRequested(QPoint)));

    connect (m_pobjArrayIdent, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));
    connect (m_pobjArrayIdent->m_pthArrayIdent_RGA, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));

    connect (m_pobjDiagMonitoring, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));
    connect (m_pobjDiagMonitoring->m_pthDataMon, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));
    connect (m_pobjDiagMonitoring->m_pthDataMon, SIGNAL(sig_threadCompleted()), m_pobjDiagMonitoring, SLOT(slot_threadCompleted()));

    connect (this, SIGNAL(sig_onlineGraphAddValue(void *)), m_pobjResponseMon, SLOT(slot_onlineGraphAddValue(void*)));

    connect (m_pobjDiagMonitoring->m_pthDataMon, SIGNAL(sig_setValue(int,QString)), m_pobjDiagMonitoring, SLOT(slot_setValue(int,QString)));

    connect (this, SIGNAL(sig_saveGraph(QString)), m_pobjResponseMon, SLOT(saveGraph(QString)));
    connect (m_pobjRS422Config, SIGNAL(sig_EnDisAzimuth(bool)), m_pobjCBITStatus, SLOT(slot_EnDisAzimuth(bool)));
    connect (m_pobjRS422Config, SIGNAL(sig_fetchSystemDetails()), m_pobjSystemDetails, SLOT(slot_fetchSystemDetails()));

    connect (m_pobjCtrlLoopConfig, SIGNAL(sig_showLoadingScreen(bool)), this, SLOT(slot_showLoadingScreen(bool)));
    connect (m_pobjDiagMonitoring, SIGNAL(sig_showLoadingScreen(bool)), this, SLOT(slot_showLoadingScreen(bool)));
    connect (m_pobjBootLoading, SIGNAL(sig_showLoadingScreen(bool)), this, SLOT(slot_showLoadingScreen(bool)));
    connect (m_pobjCtrlLoopConfig->m_pthControlLoopConfig, SIGNAL(sig_threadCompleted()), m_pobjCtrlLoopConfig, SLOT(slot_threadCompleted()));
    connect (m_pobjCtrlLoopConfig->m_pthControlLoopConfig, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));

    /** Servo Mode Test */
    connect (m_pobjSCMControl, SIGNAL(sig_configureServoModeGraph(S_SERVO_MODE_TEST)),\
             m_pobjResponseMon, SLOT(slot_configureServoModeGraph(S_SERVO_MODE_TEST)));
    connect (m_pobjSCMControl, SIGNAL(sig_drawGraph(float,float,double)),\
             m_pobjResponseMon, SLOT(slot_updateServoGraph(float,float,double)));
    connect (m_pThDataProcessing, SIGNAL(sig_drawGraph(float,float,double)),\
             m_pobjResponseMon, SLOT(slot_updateServoGraph(float,float,double)));

    connect (m_pobjCBITStatus->m_pthCBITThread, SIGNAL(sig_updateCBITStatus(unsigned char,unsigned char)), m_pobjCBITStatus, SLOT(slot_updateCBITStatus(unsigned char,unsigned char)));
    connect (m_pobjCBITStatus, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));
    connect (m_pobjCBITStatus->m_pthCBITThread, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));
    connect (m_pobjSCMControl, SIGNAL(sig_enableGraphInteraction(bool)), m_pobjResponseMon, SLOT(slot_enableGraphInteraction(bool)));
    connect (m_pobjSCMControl, SIGNAL(sig_startLog()), m_pobjResponseMon, SLOT(slot_openFile()));
    connect (m_pobjSCMControl, SIGNAL(sig_stopLog()), m_pobjResponseMon, SLOT(slot_closeFile()));
    connect (m_pobjSCMControl, SIGNAL(sig_updateTestcaseDetails(int,char,int,int,int,int,int,int)),\
             m_pobjResponseMon, SLOT(slot_configureGraph(int,char,int,int,int,int,int,int)));
    connect (m_pobjSCMControl, SIGNAL(sig_changeButtonName(QString)), m_pobjResponseMon, SLOT(slot_changeButtonName(QString)));
    connect (this, SIGNAL(sig_show_hide_DiagParams(bool)), m_pobjResponseMon, SLOT(slot_show_hide_DiagParams(bool)));
    connect (m_pobjResponseMon, SIGNAL(sig_show_hide_DiagParams(bool)), this, SLOT(slot_show_hide_DiagParams(bool)));
    connect (m_pobjSCMControl, SIGNAL(sig_startTest(bool,unsigned char)), this, SLOT(slot_startSCMCmdResp(bool,unsigned char)));
    connect (m_pThLogging, SIGNAL(sig_updateDiagParams(S_RESP_DEBUG_DATA)), m_pobjResponseMon, SLOT(slot_updateDiagParam(S_RESP_DEBUG_DATA)));
    connect (m_pThLogging, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));

    connect (m_pobjSCMControl->m_pThAnaDataRead, SIGNAL(sig_acqStarted()), m_pobjSCMControl, SLOT(slot_acqStart()), Qt::BlockingQueuedConnection);
    connect (m_pobjSeasprayOperation->m_pthHDLCRxThread, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));
    connect (m_pobjSeasprayOperation, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));
    connect (m_pobjSeasprayOperation, SIGNAL(sig_start_stop_hdlc(bool)), this, SLOT(slot_start_Stop_HDLCRx(bool)));

    connect (m_pobjSCMControl, SIGNAL(sig_changeTestcaseName(QString)), m_pobjResponseMon, SLOT(slot_changeTestcaseName(QString)));

    /** HTML Reports */
    connect (m_pobjModInit, SIGNAL(sig_append_BIT_HTMLReport(QString)), this, SLOT(slot_append_BIT_HTMLReport(QString)));
    connect (m_pobjRS422Config, SIGNAL(sig_append_BIT_HTMLReport(QString)), this, SLOT(slot_append_BIT_HTMLReport(QString)));
}

/*******************************************************************************
 * Name					: initPage
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To initialize all pages
 ***************************************************************************//**
 * @brief	This function is used to initialize all the pages and menus
 *		This function is called only in the constructor of @ref MainWindow class
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::initAppScreen()
{
    applyStyleSheet();

    ui->stackMain->insertWidget(PAGE_INIT, m_pobjModInit);
    ui->stackMain->insertWidget(PAGE_CONFIG_RS422, m_pobjRS422Config);
    ui->stackMain->insertWidget(PAGE_PBIT, m_pobjPBITStatus);
    ui->stackMain->insertWidget(PAGE_SELF_TEST, m_pobjATESelftest);
    ui->stackMain->insertWidget(PAGE_FLASH_PROGRAMMING, m_pobjBootLoading);
    ui->stackMain->insertWidget(PAGE_CONFIG_CTRL_LOOP_CONST, m_pobjCtrlLoopConfig);
    ui->stackMain->insertWidget(PAGE_MOTOR_CONTROL, m_pobjSCMControl);
    ui->stackMain->insertWidget(PAGE_CBIT, m_pobjCBITStatus);
    ui->stackMain->insertWidget(PAGE_RESPONSE_MONITORING, m_pobjResponseMon);
    ui->stackMain->insertWidget(PAGE_SYSTEM_DETAILS, m_pobjSystemDetails);
    ui->stackMain->insertWidget(PAGE_DIAG_MONITORING, m_pobjDiagMonitoring);
    ui->stackMain->insertWidget(PAGE_FPGA_RW, m_pobjFPGA_RW);
    ui->stackMain->insertWidget(PAGE_ARRAY_IDENT, m_pobjArrayIdent);
    ui->stackMain->insertWidget(PAGE_SEASPRAY_OPERATION, m_pobjSeasprayOperation);

    slot_changePage(PAGE_INIT);

    m_pobjSCMControl->initialize();
}

/*******************************************************************************
 * Name					: applyStyle
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set stylesheet for the application
 ***************************************************************************//**
 * @brief	This function is used to apply the style for the application
 *
 * @param		NIL
 * @return	NA
 ******************************************************************************/
void MainWindow::applyStyleSheet()
{
    /* Apply stylesheet for all widgets */
    SET_STYLESHEET(this);
    ui->SAMain->setPalette(PALETTE_RGB);
    ui->SAMain->setStyleSheet(QString("background-color: rgb(%1, %2, %3);").arg(PALETTE_R).arg(PALETTE_G).arg(PALETTE_B));
    SET_STYLESHEET(ui->stackMain);
    SET_STYLESHEET(m_pobjAbout);
    SET_STYLESHEET(m_pobjModInit);
    SET_STYLESHEET(m_pobjRS422Config);
    SET_STYLESHEET(m_pobjPBITStatus);
    SET_STYLESHEET(m_pobjCBITStatus);
    SET_STYLESHEET(m_pobjSCMControl);
    SET_STYLESHEET(m_pobjATESelftest);
    SET_STYLESHEET(m_pobjCtrlLoopConfig);
    SET_STYLESHEET(m_pobjSystemDetails);
    SET_STYLESHEET(m_pobjResponseMon);
    SET_STYLESHEET(m_pobjBootLoading);
    SET_STYLESHEET(m_pobjFPGA_RW);
    SET_STYLESHEET(m_pobjDiagMonitoring);
    SET_STYLESHEET(m_pobjArrayIdent);
    SET_STYLESHEET(m_pobjSeasprayOperation);
}

/*******************************************************************************
 * Name					: closeEvent
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To handle the close event
 ***************************************************************************//**
 * @brief	This function is used to show confirm message box for closing the application
 *		This function is called when the user tries to close the application
 *
 * @param[in]	in_pEvt	Holds the pointer to the close event
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::closeEvent(QCloseEvent *in_pEvt)
{
    QMessageBox msgbox;
    S32BIT s32RetVal = DPSCM_INIT_0;
    char szErrMsg[100] = { DPSCM_INIT_0 };
    QString qstrTemp = QString("");

    msgbox.setWindowTitle("SCM ATE Application");
    if (m_bIsLoggedIn)
    {
        msgbox.setText("Do you really want to close the application?");
    }
    else
    {
        msgbox.setText("Do you really want to log out?");
    }
    msgbox.addButton(QMessageBox::Yes);
    msgbox.addButton(QMessageBox::No);
    msgbox.setDefaultButton(QMessageBox::Yes);
    msgbox.setStyleSheet(MSG_STYLE);

    if (msgbox.exec() == QMessageBox::Yes)
    {
        s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_Close(PCI_BRD_IDX);
        if((s32RetVal != DPPCI755_SUCCESS))
        {
            g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);
            DISPLAY_MESSAGE_BOX(this, "Error Closing Application", szErrMsg);
            in_pEvt->ignore();
            return;
        }

        s32RetVal = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_Close(XMC_BRD_IDX);
        if (s32RetVal != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError(&s32RetVal, szErrMsg);
            qstrTemp.sprintf("Error writing data : %s [ErrCode: %d]", szErrMsg, s32RetVal);

            DISPLAY_MESSAGE_BOX(this, "Error Closing Application", qstrTemp);
            return;
        }

        in_pEvt->accept();
    }
    else
    {
        m_bIsLoggedIn = true;
        in_pEvt->ignore();
    }
}

/*******************************************************************************
 * Name					: showUserManagement
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show/hide user management option
 ***************************************************************************//**
 * @brief	This function is used to show/hide user management menu based on the
 *			logged in user (Visible only for Super Users)
 *
 * @param		NIL
 * @return	NA
 ******************************************************************************/
void MainWindow::showAppScreen()
{
    QString qstrTemp;
    qstrTemp.sprintf("&Logout (%s)", m_qstrLoggedinUserName.toLatin1().data());
    ui->action_Logout->setText(qstrTemp);
    m_bIsLoggedIn = true;

    if (m_iLoggedinUserPrevil == SUPER_USER)
    {
        ui->action_User_Management->setVisible(true);
    }
    else
    {
        ui->action_User_Management->setVisible(false);
    }

    m_pobjUserMgmt->m_qstrLoggedinUser = m_qstrLoggedinUserName;
    m_pobjUserMgmt->m_iLoggedinUserPrevil = m_iLoggedinUserPrevil;

    this->showMaximized();
}

/*******************************************************************************
 * Name					: StopAcquisition
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To stop the acquisition
 ***************************************************************************//**
 * @brief	This function is used to stop the data acquisition from FRA
 *
 * @param		NIL
 *
 * @return	DPSCM_SUCCESS	if acquisition stopped successfully
 *			DPSCM_FAILURE	if any error occurred
 ******************************************************************************/
S32BIT MainWindow::StopAcquisition()
{
    S32BIT s32RetVal = DPSCM_SUCCESS;
    char szErrMsg[200];
    QString qstrMsg = QString("");

    g_SGlobal.g_SthInfo[PCI_BRD_IDX].m_u32semStopEvent = true;
    g_SGlobal.g_SRawDataThreadInfo[PCI_BRD_IDX].m_u32semStopEvent = true;
    s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_StartStopAcquisition();
    if (s32RetVal != DPSCM_SUCCESS)
    {
        g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);
        qstrMsg.sprintf("Error acquisition stop : %s [ErrCode: %d]", szErrMsg, s32RetVal);
        DISPLAY_MESSAGE_BOX(this, "Stop Acquisition", qstrMsg);
        return DPSCM_FAILURE;
    }

    m_objDelay.msleep(10);
    g_SGlobal.g_u16CurrentDataReadFlg = 0;
    g_SGlobal.g_u16RandomDataReadFlg = 0;
    g_SGlobal.g_u16AnalysedDataReadFlg = 0;
    g_SGlobal.g_u16RawDataReadFlg[PCI_BRD_IDX] = 0;

    m_bIsAcqStarted = false;

    return DPSCM_SUCCESS;
}

/*******************************************************************************
 * Name					: slot_updateActionLog
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To update action log
 ***************************************************************************//**
 * @brief	This function is used to display message in action log
 *		This function is called  when sig_updateActionLog signal is emitted
 *			from any of the classes or threads
 *
 * @param[in]	in_qstrMsg	Holds the message to display in action log
 * @param[in]	in_iLogType	Specifies the type of message (Success/Failure/Info)
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::slot_updateActionLog(QString in_qstrMsg, int in_iLogType)
{
    QString qstrColor = QString("black");
    QTextEdit *pteTemp = new QTextEdit();
    QString qstrTime = QString();
    QString qstrDisplayHTML = QString();

    switch (in_iLogType)
    {
    case LOG_SUCCESS: qstrColor = "green"; break;
    case LOG_WARNING: qstrColor = "#FF9122"; break;
    case LOG_ERROR: qstrColor = "red"; break;
    case LOG_PARTIAL_SUCCESS: qstrColor = "#667AFF"; break;
    case LOG_INFO: qstrColor = "black"; break;
    default: qstrColor = "black"; break;
    }

    pteTemp->setVisible (false);
    qstrTime = QDateTime::currentDateTime().toString("MM/dd/yyyy HH:mm:ss.zzz");\
    qstrDisplayHTML = QString("[%1]  <span style=\"color: %3; font-weight: bold;\">%2</span>").\
            arg(qstrTime).arg(in_qstrMsg).arg(qstrColor);
    pteTemp->setHtml (qstrDisplayHTML);
    ui->tbActionLog->append(qstrDisplayHTML);

    if (m_qfileActionLog.isOpen ())
    {
        if (CONV_BYTES_TO_MB(m_qfileActionLog.size ()) >= LOGFILE_MAX_SIZE)
        {
            if (!createNewActionLogFile ())
            {
                return;
            }
        }
    }
    else
    {
        if (!createNewActionLogFile ())
        {
            return;
        }
    }

    m_qfileActionLog.write (CONV_QSTR_TO_SZ(pteTemp->toPlainText().append ("\n")));

#if 0
    if (in_qstrMsg.compare("FRA Testcase Completed", Qt::CaseInsensitive) == DPSCM_SUCCESS)
    {
        s32RetVal = g_SGlobal.g_objPCI755.DPPCI755Wrap_Reset(PCI_BRD_IDX);
        if (s32RetVal != DPPCI755_SUCCESS)
        {
            g_SGlobal.g_objPCI755.DPPCI755Wrap_GetLastErrorMessage(&s32RetVal, szErrMsg);
            qstrTemp.sprintf("Error Resetting Bias : %s [ErrCode: %d]", szErrMsg, s32RetVal);
            slot_updateActionLog (qstrTemp, LOG_ERROR);
            DISPLAY_MESSAGE_BOX(this, "SCM Configuration", qstrTemp);
            return;
        }
        else
        {
            slot_updateActionLog("FRA Board Reset Successfully", LOG_INFO);
        }
    }
#endif
}

bool MainWindow::createNewActionLogFile()
{
    QString qstrPath = LOG_ACTIVITY_PATH;
    QDir qLogDir;
    qLogDir.setPath (qstrPath);
    if (!qLogDir.exists ())
    {
        qLogDir.mkpath (".");
    }

    if (m_qfileActionLog.isOpen ())
    {
        m_qfileActionLog.close ();
    }

    LOGFNAME_SETFNAME(m_qstrActionLogFileName, LOGFNAME_ACTIVITY, qstrPath);
    m_qfileActionLog.setFileName (m_qstrActionLogFileName);
    if (!m_qfileActionLog.open (QIODevice::Append))
    {
        qDebug() << "Error creating activity log file" << m_qfileActionLog.errorString ();
        return false;
    }

    return true;
}

bool MainWindow::createNewReportFile(E_REPORT_FILE_SELECT in_eFileSelection)
{
    Q_UNUSED(in_eFileSelection);
    QString qstrFoldername = QString();
    //	QString qstrFilename = QString();
    QString qstrPath = QString();
    QDir qLogDir;

    qstrPath = REPORT_BIT_PATH + qstrFoldername + QDateTime::currentDateTime ().toString ("_yyyy-MM-dd/");
    qLogDir.setPath (qstrPath);
    if (!qLogDir.exists ())
    {
        qLogDir.mkpath (".");
    }

    if (m_qfileBITStatusReport.isOpen ())
    {
        m_qfileBITStatusReport.close ();
    }

    LOGFNAME_SETFNAME(m_qstrBITReportFname, REPORT_BIT_FNAME, qstrPath);
    m_qfileBITStatusReport.setFileName (m_qstrBITReportFname);
    if (!m_qfileBITStatusReport.open (QIODevice::Append))
    {
        qDebug() << "Error creating BIT Status Report file" << m_qfileBITStatusReport.errorString ();
        return false;
    }

    writeBITReportHeader ();

    return true;
}

void MainWindow::writeBITReportHeader()
{
    QString qstrTemp = QString();
    QString qstrReport = QString();

    /* Writing BIT Report Header */
    qstrTemp.sprintf (REPORT_HEADER, "SCM BIT Report");
    qstrReport.append (qstrTemp);
    qstrTemp.sprintf (REPORT_SYS_SW_DETAILS, CONV_QSTR_TO_SZ(qApp->applicationDirPath ()), CONV_QSTR_TO_SZ(qApp->applicationDirPath ()), \
                      "Seaspray",1, 0, 1, 0, 1, 0, \
                      CONV_QSTR_TO_SZ(QDateTime::currentDateTime ().toString ("MMM dd, yyyy")), \
                      (unsigned int)g_SGlobal.g_ulAppChecksum, \
                      CONV_QSTR_TO_SZ(QDateTime::currentDateTime ().toString ("HH:mm:ss")),\
                      CONV_QSTR_TO_SZ(QDateTime::fromString (__DATE__, "MMM dd yyyy").toString ("MMM dd, yyyy")), \
                      CONV_QSTR_TO_SZ(QDateTime::fromString (__TIME__, "HH:mm:ss").toString ("HH:mm:ss")), \
                      CONV_QSTR_TO_SZ(m_qstrLoggedinUserName));
    qstrReport.append (qstrTemp);

    m_qfileBITStatusReport.write (CONV_QSTR_TO_SZ(qstrReport));
    /*******************/
}
/*******************************************************************************
 * Name					: slot_changePageTitle
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To change the page title
 ***************************************************************************//**
 * @brief	This function is used to change the page title based on the current page
 *		This function is called when current page is changed
 *			(when slot_changePage function is executed)
 *
 * @param[in]	in_qstrTitle	Holds the page title to display
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::slot_changePageTitle(QString in_qstrTitle, bool in_bIsSubTitle)
{
    if (in_bIsSubTitle)
    {
        ui->lbSelectedSystem->setVisible (true);
        ui->lbSelectedSystem->setText (in_qstrTitle);
    }
    else
    {
        ui->lbSelectedSystem->setVisible (true);
        ui->lbPageTitle->setText(in_qstrTitle);
    }
}

/*******************************************************************************
 * Name					: slot_changePage
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To change current page
 ***************************************************************************//**
 * @brief	This function is used to change the current page to display
 *		This function is called when any of the menu action is triggered
 *
 * @param[in]	in_iPageNo	Specifies the page number to display
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::slot_changePage(int in_iPageNo)
{
    if (m_iCurrPage == in_iPageNo)
    {
        return;
    }

    m_iCurrPage = in_iPageNo;

    ui->stackMain->setCurrentIndex(in_iPageNo);

    switch(in_iPageNo)
    {
    case PAGE_INIT:
    {
        slot_changePageTitle("Servo Control Module ATE Application", false);
    } break;
    case PAGE_CONFIG_RS422:
    {
        slot_changePageTitle("RS422 Configuration");
        m_pobjRS422Config->displayComStatus();
    } break;
    case PAGE_PBIT:
    {
        slot_changePageTitle("PBIT");
    } break;
    case PAGE_MOTOR_CONTROL:
    {
        slot_changePageTitle("Servo Control Operation");
    } break;
    case PAGE_CBIT:
    {
        slot_changePageTitle("CBIT");
    } break;
    case PAGE_SELF_TEST:
    {
        slot_changePageTitle("ATE Self Test");
    } break;
    case PAGE_FLASH_PROGRAMMING:
    {
        slot_changePageTitle("DSP/FPGA Code Loading");
    } break;
    case PAGE_CONFIG_CTRL_LOOP_CONST:
    {
        slot_changePageTitle("Control Loop Constant Configuration");
    } break;
    case PAGE_SYSTEM_DETAILS:
    {
        slot_changePageTitle("SCM System Version Details");
    } break;
    case PAGE_RESPONSE_MONITORING:
    {
        slot_changePageTitle("Servo Response Monitoring");
    } break;
    case PAGE_DIAG_MONITORING:
    {
        slot_changePageTitle("Diagnostics Data Monitoring");
    } break;
    case PAGE_FPGA_RW:
    {
        slot_changePageTitle("Memory Read/Write");
    } break;
    case PAGE_COMMAND_RESPONSE_DEBUG:
    {
        slot_changePageTitle("RGA/RTGA Command and Response");
    } break;
    case PAGE_ARRAY_IDENT:
    {
        slot_changePageTitle("Demand Port Simulation and Antenna Array Identification");
    } break;
    case PAGE_ARRAY_IDENT_DIAG:
    {
        slot_changePageTitle("Antenna Diag Identifiers");
    } break;
    case PAGE_SEASPRAY_OPERATION:
    {
        slot_changePageTitle("Seaspray Operation");
    } break;

    case PAGE_INVALID:
    default:
        break;
    }
}

/*******************************************************************************
 * Name					: slot_DisplayMessage
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To display message box
 ***************************************************************************//**
 * @brief	This function is used to display message box
 *		This function is called when sig_displayMessage signal is emitted
 *			from any of the threads
 *
 * @param[in]	in_qstrMsg	Holds the message to display
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::slot_DisplayMessage(QString in_qstrMsg)
{
    DISPLAY_MESSAGE_BOX(this, "FRA", in_qstrMsg);
}

/*******************************************************************************
 * Name					: slot_updateCBITSts
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To update CBIT Status
 ***************************************************************************//**
 * @brief	This function is used to update CBIT status and CBIT bar with current status
 *		This function is called when slot_updateBITStatus is executed
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::slot_updateCBITSts(unsigned char in_ucDiagID, unsigned char in_ucBITStatus)
{
    emit sig_updateCBITStatus(in_ucDiagID, in_ucBITStatus);
}

/*******************************************************************************
 * Name					: slot_updateBITStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To update BIT status
 ***************************************************************************//**
 * @brief	This function is used to update PBIT and CBIT status
 *		This function is called when sig_updateBITStatus signal is emitted
 *			from Data processing thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::slot_updateBITStatus(unsigned char in_ucDiagId, unsigned char in_ucBITStatus)
{
    if (in_ucDiagId == ID_02 || in_ucDiagId == ID_11)
    {
        //        emit sig_updatePBITStatus(in_ucBITStatus);
    }
    else
    {
        slot_updateCBITSts(in_ucDiagId, in_ucBITStatus);
    }
}

/*******************************************************************************
 * Name					: slot_receiveResponse
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To start/stop response reception
 ***************************************************************************//**
 * @brief	This function is used to start/stop response reception thread
 *
 * @param[in]	in_bStart	Specifies if to start or stop the response reception
 *				true - Start response reception
 *				false - Stop response reception
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::startRespRxThread(bool in_bStart)
{
    if (in_bStart)
    {
        m_pThRespRx->Start();
    }
    else
    {
        m_pThRespRx->Stop();
    }
}

/*******************************************************************************
 * Name					: slot_processData
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To start/stop data processing
 ***************************************************************************//**
 * @brief	This function is used to start/stop data processing thread
 *
 * @param[in]	in_bStart	Specifies if to start/stop data processing
 *				true - Start data processing
 *				false - Stop data processing
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::startDataProcThread(bool in_bStart)
{
    if (in_bStart)
    {
        m_pThDataProcessing->Start();
    }
    else
    {
        m_pThDataProcessing->Stop();
    }
}

void MainWindow::startLoggingThread(bool in_bStart)
{
    if (in_bStart)
    {
        m_pThLogging->Start();
    }
    else
    {
        m_pThLogging->Stop();
    }
}

void MainWindow::slot_startDiagCMDThread(bool in_bStart)
{
    if(in_bStart)
    {
        m_pThDiagRx->setMode(DIAGRX_DEBUG_DATA);
        m_pThDiagRx->Start();
    }
    else
    {
        m_pThDiagRx->Stop();
    }
}

/*******************************************************************************
 * Name					: slot_startTransmission
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To start/stop all transactions
 ***************************************************************************//**
 * @brief	This function is used to start/stop the transmission, reception and
 *			data processing
 *		This function is called sig_startTransmission signal is emitted
 *			from RS422 configuration class
 *
 * @param
 *
 * @return
 ******************************************************************************/
void MainWindow::slot_startSCMCmdResp(bool in_bStart, unsigned char in_ucMode)
{
    if (in_bStart)
    {
        startDataProcThread(true);
        startLoggingThread(true);
        if (in_ucMode == SERVO_MODE)
        {
            startRespRxThread(true);
            m_pThDataProcessing->m_bIsDebugDataRunning = false;
            m_pThDataProcessing->m_bIsDemandPortRunning = true;
            m_pThDataProcessing->m_bIsDiagPortRunning = false;
        }
        else
        {
            slot_startDiagCMDThread(true);
            m_pThDataProcessing->m_bIsDebugDataRunning = true;
            m_pThDataProcessing->m_bIsDemandPortRunning = false;
            m_pThDataProcessing->m_bIsDiagPortRunning = false;
        }
    }
    else
    {
        startDataProcThread(false);
        startLoggingThread(false);
        startRespRxThread(false);
        slot_startDiagCMDThread(false);
    }

}

void MainWindow::slot_startSCMDiagResp(bool in_bStart)
{
    startDataProcThread(in_bStart);
    slot_startDiagCMDThread(in_bStart);
    startLoggingThread(in_bStart);
}

/*******************************************************************************
 * Name					: slot_FRAAcqStart
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To start FRA acquisition
 ***************************************************************************//**
 * @brief	This function is used to start FRA acquisition
 *		This function is called when sig_startFRAAcquisition signal is emitted
 *			from Response monitoring class
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::slot_FRAAcqStart(bool in_bIsRunning)
{
    m_bIsAcqStarted = in_bIsRunning;
}

/*******************************************************************************
 * Name					: slot_FRAAcqStop
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To stop FRA Acquisition
 ***************************************************************************//**
 * @brief	This function is used to stop the FRA Acquisition
 *		This function is called when Stop_Acq signal is emitted
 *			from any of the threads
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::slot_FRAAcqStop()
{
    StopAcquisition();
}

void MainWindow::slot_CurrentDataDisplay(unsigned short in_u16BoardNo, unsigned int in_uiSource)
{
    Q_UNUSED(in_u16BoardNo);
    Q_UNUSED(in_uiSource);
    U8BIT u8GainType = FRA_GAIN_TYPE_DB;
    PSDPPCI755_ANALYZEDDATABUFFER pSDataBuffer = NULL;
    QString qstrTemp = "";
    pSDataBuffer = &g_SCurrentDataBuffer;

    if(pSDataBuffer->m_fFrequency != DPSCM_INIT_0)
    {
        memcpy(&g_SCurrentDataBuffer, pSDataBuffer, sizeof(SDPPCI755_ANALYZEDDATABUFFER));

        if(u8GainType == FRA_GAIN_TYPE_DB)
        {
            if(__isnan(g_SCurrentDataBuffer.m_fGain))
            {
                g_SCurrentDataBuffer.m_fGain = 0.0f;
            }
            else
            {
                g_SCurrentDataBuffer.m_fGain = (float)(20 * log10(g_SCurrentDataBuffer.m_fGain));
            }
        }
        else if(u8GainType == FRA_GAIN_TYPE_DBV)
        {
            g_SCurrentDataBuffer.m_fGain = (float)(20 * log10(g_SCurrentDataBuffer.m_fRMSVolt2));
            if((__isnan(g_SCurrentDataBuffer.m_fGain)) || (g_SCurrentDataBuffer.m_fRMSVolt2 == 0))
            {
                g_SCurrentDataBuffer.m_fGain = 0.0f;
            }
        }
        else if(u8GainType == FRA_GAIN_TYPE_DBmV)
        {
            g_SCurrentDataBuffer.m_fGain = (float)(20 * log10(g_SCurrentDataBuffer.m_fRMSVolt2 * 1000));
            if((__isnan(g_SCurrentDataBuffer.m_fGain)) || (g_SCurrentDataBuffer.m_fRMSVolt2 == 0))
            {
                g_SCurrentDataBuffer.m_fGain = 0.0f;
            }
        }

        qstrTemp.clear();

        if((pSDataBuffer->m_fFrequency != 0) && (pSDataBuffer->m_fPhase != 0) && (pSDataBuffer->m_fGain != 0))
        {
            g_SGlobal.m_sCurrentDataBuffer.m_fFreqData = pSDataBuffer->m_fFrequency;
            g_SGlobal.m_sCurrentDataBuffer.m_fPhaseData = pSDataBuffer->m_fPhase;
            g_SGlobal.m_sCurrentDataBuffer.m_fGainData = pSDataBuffer->m_fGain;
            emit sig_onlineGraphAddValue((void *)&g_SGlobal.m_sCurrentDataBuffer);
        }
    }
}

/*******************************************************************************
 * Name					: slot_Test_Current_Data_Generator
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To generate test current data
 ***************************************************************************//**
 * @brief	This function is used to generate test current data
 *		This function is called when Test_Current_Data_Generator signal is
 *			emitted from any of the threads
 *
 * @param[in]	in_u16BoardNo	Specifies the board number
 * @param[in]	in_pSAnaDataBuffer	Specifies the buffer with analyzed data
 * @param[in]	in_ScfgData	Holds the Configuration data
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::slot_Test_Current_Data_Generator(U16BIT in_u16BoardNo, PSDPPCI755_ANALYZEDDATABUFFER in_pSAnaDataBuffer, SDPPCI755_CONFIG in_ScfgData)
{
    Q_UNUSED(in_u16BoardNo);

    static	float fIndx1 = in_ScfgData.m_fStartFreq;

    in_pSAnaDataBuffer->m_fGain		= 1 - (float)(rand() % 100) / (float)1000;
    in_pSAnaDataBuffer->m_fPhase		= (float)(sin(fIndx1) / 100);
    m_objDelay.msleep(int(10 / (in_ScfgData.m_fStepSize * in_pSAnaDataBuffer->m_fFrequency)));

    if(in_pSAnaDataBuffer->m_fFrequency < in_ScfgData.m_fEndFreq)
    {
        in_pSAnaDataBuffer->m_fFrequency	= in_pSAnaDataBuffer->m_fFrequency + in_ScfgData.m_fStepSize;
    }

    fIndx1 = (float) fmod((fIndx1 + 1), 360);
}

void MainWindow::slot_contextMenuRequested(QPoint in_qptPoint)
{
    QPoint qptActionLog = ui->tbActionLog->pos ();
    QPoint qptGroupbox = ui->gbActionLog->pos ();
    QPoint qptResult = QPoint();

    QMenu *menuContextMenu = new QMenu("Context Menu", ui->tbActionLog);

    QAction *actClear = new QAction("C&lear Action Log", menuContextMenu);
    QAction *actCopy = new QAction("&Copy", menuContextMenu);
    QAction *actSelectAll = new QAction("Select &All", menuContextMenu);
    QAction *actUndo = new QAction("&Undo Clear", menuContextMenu);
    connect(actClear, SIGNAL(triggered(bool)), this, SLOT(slot_contextMenuActionLogClear()));
    connect(actCopy, SIGNAL(triggered(bool)), this, SLOT(slot_contextMenuCopy()));
    connect(actSelectAll, SIGNAL(triggered(bool)), this, SLOT(slot_contextMenuSelectAll()));
    connect(actUndo, SIGNAL(triggered(bool)), this, SLOT(slot_contextMenuUndoClear()));

    menuContextMenu->addAction(actClear);
    menuContextMenu->addAction(actUndo);
    menuContextMenu->addAction(actCopy);
    menuContextMenu->addAction(actSelectAll);

    if (ui->tbActionLog->toPlainText().isEmpty())
    {
        actClear->setEnabled(false);
    }
    else
    {
        actClear->setEnabled(true);
    }

    if (ui->tbActionLog->textCursor ().selectionStart () == ui->tbActionLog->textCursor ().selectionEnd ())
    {
        actCopy->setEnabled (false);
    }
    else
    {
        actCopy->setEnabled (true);
    }

    if (ui->tbActionLog->toPlainText ().isEmpty ())
    {
        actUndo->setEnabled (true);
    }
    else
    {
        actUndo->setEnabled (false);
    }

    qptResult = (QPoint((qptActionLog.x () + in_qptPoint.x () + qptGroupbox.x ()), \
                        (qptActionLog.y () + in_qptPoint.y () + qptGroupbox.y ())));

    menuContextMenu->exec (mapToGlobal (qptResult));
}

void MainWindow::slot_contextMenuActionLogClear()
{
    m_qstrActionLogBeforeClear = ui->tbActionLog->toHtml ();
    ui->tbActionLog->clear ();
}

void MainWindow::slot_contextMenuCopy()
{
    ui->tbActionLog->copy ();
}

void MainWindow::slot_contextMenuSelectAll()
{
    ui->tbActionLog->selectAll ();
}

void MainWindow::slot_contextMenuUndoClear()
{
    ui->tbActionLog->setHtml (m_qstrActionLogBeforeClear);
}

void MainWindow::slot_append_BIT_HTMLReport(QString in_qstrHTML)
{
    if (!m_qfileBITStatusReport.isOpen ())
    {
        createNewReportFile (E_REPORT_BIT_FILE);
    }

    m_qfileBITStatusReport.write (in_qstrHTML.toStdString ().c_str ());
}

void MainWindow::MainWinOngraphDraw(unsigned int in_uiBrdNo)
{
    if((g_SGlobal.g_SData.m_bIsDataReady[in_uiBrdNo] == true))
    {
        memcpy(&m_pobjResponseMon->m_OnGraphSCfgData, &m_pobjSCMControl->m_SFRAConfig, sizeof(SDPPCI755_CONFIG));
        emit OnGraph_Draw();
    }
}

void MainWindow::slot_startFRAAcq()
{
    m_bIsAcqStarted = true;
}

void MainWindow::slot_showLoadingScreen(bool in_bShow)
{
    if (in_bShow)
    {
        qApp->processEvents();
        m_pobjLoadingScreen->Start();
    }
    else
    {
        m_pobjLoadingScreen->Stop();
    }
}

short MainWindow::slot_UARTWrite(char *in_pcBuffData, long long in_lliDataLen)
{
    short sRetVal = 0;

    sRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData (in_pcBuffData, in_lliDataLen);
    return sRetVal;
}

void MainWindow::slot_show_hide_DiagParams(bool in_bShow)
{
    if (ui->actionShow_Diagnostics_Parametes->isChecked() != in_bShow)
    {
        ui->actionShow_Diagnostics_Parametes->setChecked(in_bShow);
    }
    else
    {
        // Do nothing
    }
}

void MainWindow::slot_start_Stop_HDLCRx(bool in_bStart)
{
    if (in_bStart)
    {
        m_pobjSeasprayOperation->m_pthHDLCRxThread->Start();

        m_pThDataProcessing->m_bIsDemandPortRunning = false;
        m_pThDataProcessing->m_bIsDiagPortRunning = false;
        m_pThDataProcessing->m_bIsDebugDataRunning = false;
        m_pThDataProcessing->m_bIsHDLCRunning = true;
        m_pThDataProcessing->Start();

        m_pThLogging->Start();
    }
    else
    {
        m_pobjSeasprayOperation->m_pthHDLCRxThread->Stop();
        m_pThDataProcessing->Stop();
        m_pThLogging->Start();
    }
}

void MainWindow::slot_AppPath_Link_Clicked(QString in_qstrLink)
{
    Q_UNUSED(in_qstrLink);

    QDesktopServices::openUrl(QUrl(qApp->applicationDirPath()));
}

/*******************************************************************************
 * Name					: on_action_Initialization_Status_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show module initialization page
 ***************************************************************************//**
 * @brief	This function is used to change display to Module Initialization page
 *		This function is called when Initialization Status menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_Initialization_Status_triggered()
{
    slot_changePage(PAGE_INIT);
}

/*******************************************************************************
 * Name					: on_action_CBIT_Status_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show CBIT status page
 ***************************************************************************//**
 * @brief	This function is used to change display to CBIT Status page
 *		This function is called when CBIT Status menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_CBIT_Status_triggered()
{
    slot_changePage(PAGE_CBIT);
}

/*******************************************************************************
 * Name					: on_action_Motor_Control_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show SCM Control page
 ***************************************************************************//**
 * @brief	This function is used to change display Servo Control Operation page
 *		This function is called when Motor Control menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_Motor_Control_triggered()
{
    slot_changePage(PAGE_MOTOR_CONTROL);
}

/*******************************************************************************
 * Name					: on_action_About_ATE_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show About dialog box
 ***************************************************************************//**
 * @brief	This function is used to display About dialog
 *		This function is called when About ATE menu is clicked
 *
 * @param
 *
 * @return
 ******************************************************************************/
void MainWindow::on_action_About_ATE_triggered()
{
    m_pobjAbout->exec();
}

/*******************************************************************************
 * Name					: on_action_RS422_Configuration_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show Communication Configuration page
 ***************************************************************************//**
 * @brief	This function is used to change display to Communication Configuration page
 *		This function is called when RS422 Configuratoin menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_RS422_Configuration_triggered()
{
    slot_changePage(PAGE_CONFIG_RS422);
}

/*******************************************************************************
 * Name					: on_action_Communication_Status_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show Self test page
 ***************************************************************************//**
 * @brief	This function is used to change display to Self Test page
 *		This function is called when Self Test menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_Communication_Status_triggered()
{
    slot_changePage(PAGE_SELF_TEST);
}

/*******************************************************************************
 * Name					: on_action_PBIT_Status_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show PBIT Status page
 ***************************************************************************//**
 * @brief	This function is used to change display to PBIT Status page
 *		This function is called when PBIT Status menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_PBIT_Status_triggered()
{
    slot_changePage(PAGE_PBIT);
}

/*******************************************************************************
 * Name					: on_action_Software_Programming_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show Software Programming page
 ***************************************************************************//**
 * @brief	This function is used to change display to Software Programming page
 *		This function is called when Software Programming menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_Software_Programming_triggered()
{
    slot_changePage(PAGE_FLASH_PROGRAMMING);
}

/*******************************************************************************
 * Name					: on_action_Control_Loop_Constant_Configuration_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show Constant Configuration page
 ***************************************************************************//**
 * @brief	This function is used to change display to Control Loop Constant
 *			Configuration page
 *		This function is called when Control Loop Constant Configuration
 *			menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_Control_Loop_Constant_Configuration_triggered()
{
    slot_changePage(PAGE_CONFIG_CTRL_LOOP_CONST);
}

/*******************************************************************************
 * Name					: on_action_System_Details_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show System details page
 ***************************************************************************//**
 * @brief	This function is used to change display to SCM System Version Details page
 *		This function is called when System Details menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_System_Details_triggered()
{
    slot_changePage(PAGE_SYSTEM_DETAILS);
}

/*******************************************************************************
 * Name					: on_action_Response_Monitoring_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show Response Monitoring page
 ***************************************************************************//**
 * @brief	This function is used to change display to Response Monitoring page
 *		This function is called when Response Monitoring menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_Response_Monitoring_triggered()
{
    slot_changePage(PAGE_RESPONSE_MONITORING);
}

/*******************************************************************************
 * Name					: on_action_Change_Password_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show Change Password page
 ***************************************************************************//**
 * @brief	This function is used to change display to Change Password dialog
 *		This function is called when Change Password menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_Change_Password_triggered()
{
    m_pobjUserMgmt->execChangePassword();
}

/*******************************************************************************
 * Name					: on_action_User_Management_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show User Management page
 ***************************************************************************//**
 * @brief	This function is used to change display to User Management dialog
 *		This function is called when User Management menu is clicked
 *		This menu is only visible for Super Users
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_User_Management_triggered()
{
    m_pobjUserMgmt->execUserMgmt();
}

/*******************************************************************************
 * Name					: on_label_13_linkActivated
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To display CBIT Status page
 ***************************************************************************//**
 * @brief	This function is used to display CBIT Status page
 *
 * @param[in]	link	This parameter is unused
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_label_13_linkActivated(const QString &link)
{
    Q_UNUSED(link)

    slot_changePage(PAGE_CBIT);
}

/*******************************************************************************
 * Name					: on_label_16_linkActivated
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To display CBIT Status page
 ***************************************************************************//**
 * @brief	This function is used to display CBIT Status page
 *
 * @param[in]	link	This parameter is unused
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_label_16_linkActivated(const QString &link)
{
    on_label_13_linkActivated(link);
}

/*******************************************************************************
 * Name					: on_label_19_linkActivated
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To display CBIT Status page
 ***************************************************************************//**
 * @brief	This function is used to display CBIT Status page
 *
 * @param[in]	link	This parameter is unused
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_label_19_linkActivated(const QString &link)
{
    on_label_13_linkActivated(link);
}

/*******************************************************************************
 * Name					: on_label_18_linkActivated
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To display CBIT Status page
 ***************************************************************************//**
 * @brief	This function is used to display CBIT Status page
 *
 * @param[in]	link	This parameter is unused
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_label_18_linkActivated(const QString &link)
{
    on_label_13_linkActivated(link);
}

/*******************************************************************************
 * Name					: on_label_40_linkActivated
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To display CBIT Status page
 ***************************************************************************//**
 * @brief	This function is used to display CBIT Status page
 *
 * @param[in]	link	This parameter is unused
 *
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_label_40_linkActivated(const QString &link)
{
    on_label_13_linkActivated(link);
}

/*******************************************************************************
 * Name					: on_action_Logout_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To logout current user
 ***************************************************************************//**
 * @brief	This function is used to logout from the application
 *		This function is called when Logout menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_Logout_triggered()
{
    m_bIsLoggedIn = false;
    this->close();
}

/*******************************************************************************
 * Name					: on_action_Quit_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To close the application
 ***************************************************************************//**
 * @brief	This function is used to close the application
 *		This function is called when Quit menu is clicked
 *
 * @param
 *
 * @return
 ******************************************************************************/
void MainWindow::on_action_Quit_triggered()
{
    m_bIsLoggedIn = true;
    this->close();
}

/*******************************************************************************
 * Name					: on_action_Diagnostics_Data_Monitoring_2_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show Diagnostics Monitoring page
 ***************************************************************************//**
 * @brief	This function is used to change display to Diagnostics Monitoring page
 *			for debug
 *		This function is called when Diagnostics Data Monitoring menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_Diagnostics_Data_Monitoring_2_triggered()
{
    slot_changePage(PAGE_DIAG_MONITORING);
}

/*******************************************************************************
 * Name					: on_action_FPGA_Read_Write_triggered
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To show FPGA Read Write page
 ***************************************************************************//**
 * @brief	This function is used to change display to FPGA Read/Write page
 *		This function is called when FPGA Read/Write menu is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void MainWindow::on_action_FPGA_Read_Write_triggered()
{
    slot_changePage(PAGE_FPGA_RW);
}

void MainWindow::on_tbActionLog_anchorClicked(const QUrl &in_qurlFile)
{
    QDesktopServices::openUrl (in_qurlFile);
}

void MainWindow::print_uart_processing_errors(short in_sRetVal)
{
    QString qstrTemp = QString();
    if(in_sRetVal == DP_NULL_PTR_ERROR)
    {
        slot_updateActionLog("Null pointer error", LOG_ERROR);
    }
    else if(in_sRetVal == DP_CHECKSUM_ERROR)
    {
        slot_updateActionLog("Invalid checksum", LOG_ERROR);
    }
    else if(in_sRetVal == DP_INVALID_RX_STATE_ERROR)
    {
        slot_updateActionLog("Invalid data reception state", LOG_ERROR);
    }
    else if(in_sRetVal == DP_CMD_ID_MISMATCH_ERROR)
    {
        slot_updateActionLog("Transmitted and received command id not matching", LOG_ERROR);
    }
    else if(in_sRetVal == DP_TIMEOUT_ERROR)
    {
        slot_updateActionLog("Data reception timeout", LOG_ERROR);
    }
    else if(in_sRetVal == DP_INVALID_CMD_ID)
    {
        slot_updateActionLog("Invalid command id", LOG_ERROR);
    }
    else if(in_sRetVal == DP_COM_PORT_NOT_OPENED)
    {
        slot_updateActionLog("COM Port not connected", LOG_ERROR);
    }
    else
    {
        qstrTemp.sprintf("Unknown Error [ErrCode: %d]", in_sRetVal);
        slot_updateActionLog(qstrTemp, LOG_ERROR);
    }
}

void MainWindow::on_action_Command_and_Response_triggered()
{
    slot_changePage(PAGE_COMMAND_RESPONSE_DEBUG);
}

void MainWindow::on_action_Antenna_Array_Identifiers_triggered()
{
    slot_changePage(PAGE_ARRAY_IDENT);
}

void MainWindow::on_actionSave_Graph_triggered()
{
    QString qstrFilename = QFileDialog::getSaveFileName(this, "Save Graph", "./", "JPG Image (*.jpg) ;; PNG Image (*.png) ;; PDF File (*.pdf)");
    if (qstrFilename.isEmpty())
    {
        return;
    }

    sig_saveGraph(qstrFilename);
}

void MainWindow::on_pbEnDis_DiagMode_toggled(bool checked)
{
    unsigned char ucChecksum = DPSCM_INIT_0;
    unsigned int uiBytesRead = DPSCM_INIT_0;
    unsigned char ucConfiguredMode = DPSCM_INIT_0;
    int iRetVal = DPSCM_INIT_0;
    QString qstrErrMsg = QString();
    QString qstrTemp = QString();
    U_DEM_PORT_TX UTxCommand = { 0 };
    U_DEM_PORT_RX URxResponse = { 0 };

    memset(&UTxCommand, 0, sizeof(U_DEM_PORT_TX));
    memset(&URxResponse, 0, sizeof(U_DEM_PORT_RX));

    CHECK_TC_RUNNING;

    ucConfiguredMode = checked ? DIAGNOSTICS_MODE : SERVO_MODE;

    UTxCommand.m_S_DiagCmd.m_ucByte0_Bit7 = 0x01;
    UTxCommand.m_S_DiagCmd.m_ucByte1_CmdID = CMDID_OPERATION_MODE & 0x1F;
    UTxCommand.m_S_DiagCmd.m_ucByte2_Bit6_0 = ucConfiguredMode;
    dp_scm_7bit_xor_checksum((unsigned char *)&UTxCommand.m_S_DiagCmd, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);
    UTxCommand.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;

    iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *)UTxCommand.m_arrucData, sizeof(S_DIAG_CMDRESP));
    if (iRetVal != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
        ui->pbEnDis_DiagMode->setState(!checked);
        qstrTemp.sprintf("Error Send Command : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
        slot_updateActionLog(qstrTemp, LOG_ERROR);
        return;
    }


    iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_DIAG_CMDRESP), (char *) &URxResponse.m_S_DiagResp, &uiBytesRead, 2);
    if (iRetVal != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
        ui->pbEnDis_DiagMode->setState(!checked);
        qstrTemp.sprintf("Error Receiving Response : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
        slot_updateActionLog(qstrTemp, LOG_ERROR);
        return;
    }

    if (URxResponse.m_S_DiagResp.m_ucByte0_Bit7 == 1)
    {
        g_SGlobal.m_ucConfiguredMode = ucConfiguredMode;
        qstrTemp.sprintf("Operation Mode Changed to %s Mode.", (ucConfiguredMode == DIAGNOSTICS_MODE) ? "Diagnostics" : "Servo");
        slot_updateActionLog(qstrTemp, LOG_SUCCESS);
    }
    else
    {
        ui->pbEnDis_DiagMode->setState(!checked);
        qstrTemp.sprintf("Error Configuring Operation Mode : Invalid Response");
        slot_updateActionLog(qstrTemp, LOG_ERROR);
        return;
    }
}

void MainWindow::on_actionShow_Diagnostics_Parametes_triggered(bool checked)
{
    emit sig_show_hide_DiagParams(checked);
}

void MainWindow::on_actionOpen_Log_Folder_triggered()
{
//    slot_updateActionLog(LOG_FOLDER_PATH, LOG_PARTIAL_SUCCESS);
    QDesktopServices::openUrl(QUrl(LOG_FOLDER_PATH));
}

void MainWindow::on_action_Seaspray_Operation_triggered()
{
    slot_changePage(PAGE_SEASPRAY_OPERATION);
}
