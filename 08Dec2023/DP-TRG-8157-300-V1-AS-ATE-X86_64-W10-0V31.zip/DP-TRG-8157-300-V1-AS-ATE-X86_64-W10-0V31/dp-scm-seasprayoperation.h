#ifndef DPSCMSEASPRAYOPERATION_H
#define DPSCMSEASPRAYOPERATION_H

#include <QWidget>
#include <QThread>

#include "dp-scm-hdlcrxthread.h"

namespace Ui {
class CSeasprayOperation;
}

class CSeasprayOperation : public QWidget
{
    Q_OBJECT

public:
    explicit CSeasprayOperation(QWidget *parent = 0);
    ~CSeasprayOperation();

    U_DEM_PORT_TX m_UCommand;
    U_DEM_PORT_RX m_UResponse;
    CHDLCRxThread *m_pthHDLCRxThread;

    void fetchHDLCFrame();

private slots:
    void on_pbSend_clicked();

    void on_cbContinuousTx_clicked(bool checked);

signals:
    void sig_updateActionLog(QString, int);
    void sig_start_stop_hdlc(bool);

private:
    Ui::CSeasprayOperation *ui;
};

#endif // DPSCMSEASPRAYOPERATION_H
