/**
* \file dp-scm-about.h
* \brief This is the header file for dp-scm-about.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef ABOUT_H
#define ABOUT_H

#include <QDialog>
#include <QDateTime>

#include "includes/dp-scm-macros.h"

namespace Ui {
	class CAbout;
}

class CAbout : public QDialog
{
		Q_OBJECT

	public:
		explicit CAbout(QWidget *parent = 0);
		~CAbout();

	private slots:
		void on_pbOk_clicked();

        void on_lbLink_Address_linkActivated(const QString &link);

private:
		Ui::CAbout *ui;
};

#endif // ABOUT_H
