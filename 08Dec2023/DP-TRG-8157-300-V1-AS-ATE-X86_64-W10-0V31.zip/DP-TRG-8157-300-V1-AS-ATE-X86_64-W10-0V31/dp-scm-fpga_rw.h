/**
* \file dp-scm-fpga_rw.h
* \brief This is the header file for dp-scm-fpga_rw.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef DPSCMFPGA_RW_H
#define DPSCMFPGA_RW_H

#include <QWidget>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"

#define RESET_DISPLAY ui->sbAddress->setValue(0);\
ui->leData->clear();

namespace Ui {
	class CFPGA_RW;
}

class CFPGA_RW : public QWidget
{
		Q_OBJECT

	public:
		explicit CFPGA_RW(QWidget *parent = 0);
		~CFPGA_RW();

	private slots:
		void on_pbFPGA_RW_clicked();

		void on_rbWrite_toggled(bool checked);

		void on_rbRead_toggled(bool checked);

        void on_leData_returnPressed();

signals:
    void sig_updateActionLog(QString, int);

private:
		Ui::CFPGA_RW *ui;
};

#endif // DPSCMFPGA_RW_H
