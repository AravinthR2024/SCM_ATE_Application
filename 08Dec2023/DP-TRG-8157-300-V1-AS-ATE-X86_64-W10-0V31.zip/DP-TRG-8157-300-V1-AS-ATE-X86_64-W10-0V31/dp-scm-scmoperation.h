/**
* \file dp-scm-scmoperation.h
* \brief This is the header file for dp-scm-scmoperation.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef SCMOPERATION_H
#define SCMOPERATION_H

#include <QWidget>
#include <QDebug>
#include <QTimer>
#include <QStringListModel>
#include <QTreeWidgetItem>
#include <QDoubleSpinBox>
#include <QSpinBox>
#include <QCheckBox>
#include <QLabel>
#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "dppci755_wrapper.h"
#include "dp-scm-fra_acq.h"
#include "checksum.h"
#include "math.h"

#define WAVEGEN_PAGE_COUNT		5
#define WAVEGEN_PAGE_SERVO		0
#define WAVEGEN_PAGE_MOTOR_AMP	1
#define WAVEGEN_PAGE_TFA_LOOP		2
#define WAVEGEN_PAGE_TFA_PLANT	3
#define WAVEGEN_PAGE_CLOSED_LOOP	4

namespace Ui {
	class CSCMOperation;
}

class CSCMOperation : public QWidget
{
		Q_OBJECT

	public:
		explicit CSCMOperation(QWidget *parent = 0);
		~CSCMOperation();

		int m_iSelectedTestcase;
		int m_iSelectedWaveform;
		unsigned char m_ucSelectedPage;
		int m_iSelectedMode;
		int m_iarrGainValues[4];
		bool m_bCloseLoopEnable;
		QString m_qstrLogfile;
        QString m_qstrTCName;
		QString m_qstrDataFileName;
		QStringList m_qstrliTestCaseName;
        S_SERVO_MODE_TEST m_SServoTest;
        QTimer *m_qtServo;
        QTimer *m_qtDiagnostic;
        unsigned int m_uiCurrIdx;
        unsigned char m_ucScansCompleted;
        bool m_bIsConfigured;
        unsigned char m_ucTestStart_CMD_ID;

        QMutex m_mutex;

        /** For Configuring Graph */
        int m_iXMin = DPSCM_INIT_0;
        int m_iXMax = DPSCM_INIT_0;
        int m_iYMin = DPSCM_INIT_0;
        int m_iYMax = DPSCM_INIT_0;
        int m_iY2Min = DPSCM_INIT_0;
        int m_iY2Max = DPSCM_INIT_0;
        char m_cSelectedGraph = GRAPHTYPE_INVALID;

		CANADataReadThread *m_pThAnaDataRead;
		CDataReadThread *m_pThDataRead;
		CReadRawDataFIFO *m_pThReadRawDataFIFO;
        QVector<double> m_arrdServoData;

		QTreeWidgetItem *m_item1;
		QTreeWidgetItem *m_item2;
		QTreeWidgetItem *m_item21;
		QTreeWidgetItem *m_item22;
		QTreeWidgetItem *m_item23;
        QTreeWidgetItem *m_item24;
        QTreeWidgetItem *m_item3;

		QDoubleSpinBox *m_pdsbStartFreq[WAVEGEN_PAGE_COUNT];
		QDoubleSpinBox *m_pdsbStopFreq[WAVEGEN_PAGE_COUNT];
		QDoubleSpinBox *m_pdsbStepFreq[WAVEGEN_PAGE_COUNT];
		QCheckBox *m_pcbStepFreqIsLog[WAVEGEN_PAGE_COUNT];
		QSpinBox *m_psbIntegTime[WAVEGEN_PAGE_COUNT];
		QSpinBox *m_psbStartAngle[WAVEGEN_PAGE_COUNT];
		QSpinBox *m_psbStopAngle[WAVEGEN_PAGE_COUNT];
		QLabel *m_plbStartFreq[WAVEGEN_PAGE_COUNT];
		QLabel *m_plbStopFreq[WAVEGEN_PAGE_COUNT];
		QLabel *m_plbStepFreq[WAVEGEN_PAGE_COUNT];
		QLabel *m_plbIntegTime[WAVEGEN_PAGE_COUNT];
		QLabel *m_plbStartAngle[WAVEGEN_PAGE_COUNT];
		QLabel *m_plbStopAngle[WAVEGEN_PAGE_COUNT];

		SDPPCI755_CONFIG m_SFRAConfig;

		void initialize();
        short configureTestcaseInput();
        short configureFRAInput();
		unsigned int startFRAAcquisitionThread();

public slots:
        void slot_getServoModeCommand();
        void slot_getDiagnosticsModeCommand();
        void slot_changeButtonName(QString in_qstr);
        void slot_stopAcq();
        void slot_acqStart();

private slots:
		void on_pbConfigure_clicked();

        void on_pbStart_clicked();

        void on_treewDiag_TestCases_currentItemChanged(QTreeWidgetItem *current, QTreeWidgetItem *previous);

		int slot_startMonitoring();

        void on_rbTest_LargeAngleSlew_toggled(bool checked);

        void on_rbTest_BidirScan_toggled(bool checked);

        void on_rbTest_AltScan_toggled(bool checked);

        void on_rbTest_ContRateMode_toggled(bool checked);

        void on_cbFRA_StepFreqInLog_toggled(bool checked);

        void on_pbTC_Collapse_clicked();

signals:
    void sig_updateActionLog(QString, int);
    void sig_changePage(int);
    void sig_startOnlineGraphAcquisition();
    void sig_startDiagCMDTx(bool);
    void sig_startTest(bool, unsigned char);
    void sig_startMonitoring();
    void sig_updateTestcaseDetails(int, char, int, int, int, int, int, int);
    void sig_changePageTitle(QString, bool);
    void sig_changeButtonName(QString);
    void sig_clearGraph();
    void sig_setServoModeTestData(S_SERVO_MODE_TEST);
    void sig_startServoModeTest(S_SERVO_MODE_TEST);
    void sig_configureServoModeGraph(S_SERVO_MODE_TEST);
    void sig_stopServoModeTest();
    void sig_enableGraphInteraction(bool);
    void sig_startLog();
    void sig_stopLog();
    void sig_drawGraph(float, float, double);
    void sig_changeTestcaseName(QString);

private:
		Ui::CSCMOperation *ui;
};

#endif // SCMOPERATION_H
