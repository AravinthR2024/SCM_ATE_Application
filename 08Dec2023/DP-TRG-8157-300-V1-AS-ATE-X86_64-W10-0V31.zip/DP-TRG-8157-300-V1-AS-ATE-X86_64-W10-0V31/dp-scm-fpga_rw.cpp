/**
* \file dp-scm-fpga_rw.cpp
* \brief This file contains the code for FPGA Read/Write panel
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-fpga_rw.h"
#include "ui_dp-scm-fpga_rw.h"

extern S_GLOBAL g_SGlobal;

/*******************************************************************************
 * Name					: CFPGA_RW
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor for CFPGA_RW class
 *
 * @param[in]	parent	Holds the reference to the parent
 * @return	NA
 ******************************************************************************/
CFPGA_RW::CFPGA_RW(QWidget *parent) :
	QWidget(parent),
	ui(new Ui::CFPGA_RW)
{
	ui->setupUi(this);

	QFont font;
	font = ui->sbAddress->font();
	font.setCapitalization(QFont::AllUppercase);
	ui->sbAddress->setFont(font);
    ui->leData->setFont(font);

	ui->sbAddress->setMaximum (INT_MAX);
}

/*******************************************************************************
 * Name					: ~CFPGA_RW
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief	This function is the destructor of CFPGA_RW class
 *
 * @param	NIL
 * @return	NA
 ******************************************************************************/
CFPGA_RW::~CFPGA_RW()
{
	delete ui;
}

/*******************************************************************************
 * Name					: on_pbFPGA_RW_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To read/write FPGA register
 ***************************************************************************//**
 * @brief	This function is used  to read/write from/to FPGA register
 *		This funciton is called when Write or Read button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CFPGA_RW::on_pbFPGA_RW_clicked()
{
    U32BIT u32Address = DPSCM_INIT_0;   //hdlc testing so changed 32 bit
    U32BIT u32Data = DPSCM_INIT_0;
	QString qstrTemp = QString("");
    S32BIT s32RetVal = DPSCM_SUCCESS;
    bool ok = false;
    char szErrMsg[100] = { 0 };

    if (ui->rbWrite->isChecked())
    {
        u32Address = ui->sbAddress->value();
        u32Data = ui->leData->text().toUInt(&ok, 16);

        s32RetVal = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_WriteRegister(XMC_BRD_IDX, u32Address, u32Data);
        if (s32RetVal != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError(&s32RetVal, szErrMsg);
            qstrTemp.sprintf("Error writing data : %s [ErrCode: %d]", szErrMsg, s32RetVal);
            sig_updateActionLog(qstrTemp, LOG_ERROR);
            return;
        }
        qstrTemp.sprintf("Data successfully written to 0x%X", u32Address);
        sig_updateActionLog(qstrTemp, LOG_SUCCESS);
        DISPLAY_MESSAGE_BOX(this, "FPGA Write", "Data Write Successful");
    }
    else
    {
        u32Address = ui->sbAddress->value();

        s32RetVal = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_ReadRegister(XMC_BRD_IDX, u32Address, &u32Data);
        if (s32RetVal != DPSCM_SUCCESS)
        {
            g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError(&s32RetVal, szErrMsg);
            qstrTemp.sprintf("Error reading data : %s [ErrCode: %d]", szErrMsg, s32RetVal);
            sig_updateActionLog(qstrTemp, LOG_ERROR);
            return;
        }
        ui->leData->setText(QString::number(u32Data, 16));
        qstrTemp.sprintf ("Data read successfully from 0x%X", u32Address);
        sig_updateActionLog(qstrTemp, LOG_SUCCESS);
    }
}

/*******************************************************************************
 * Name					: on_rbWrite_toggled
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set read/write selection
 ***************************************************************************//**
 * @brief	This function is used to set controls for FPGA Write
 *		This function is called when Write radiobutton selection is toggled
 *
 * @param[in]	checked	Specifies if Write radionbutton is selected
 *
 * @return	NIL
 ******************************************************************************/
void CFPGA_RW::on_rbWrite_toggled(bool checked)
{
    ui->leData->setReadOnly(!checked);
    ui->leData->clear();

	if (checked)
	{
		ui->pbFPGA_RW->setText("&Write");
		ui->pbFPGA_RW->setToolTip ("Write Data to the Address");
	}
	else
	{
		ui->pbFPGA_RW->setText("&Read");
		ui->pbFPGA_RW->setToolTip ("Read Data from the Address");
	}
}

/*******************************************************************************
 * Name					: on_rbRead_toggled
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set read/write selection
 ***************************************************************************//**
 * @brief	This function is used to set controls for FPGA Read
 *		This function is called when Read radiobutton selection is toggled
 *
 * @param[in]	checked	Specifies if Read radiobutton is selected
 *
 * @return	NIL
 ******************************************************************************/
void CFPGA_RW::on_rbRead_toggled(bool checked)
{
	on_rbWrite_toggled(!checked);
}

void CFPGA_RW::on_leData_returnPressed()
{
    on_pbFPGA_RW_clicked();
}
