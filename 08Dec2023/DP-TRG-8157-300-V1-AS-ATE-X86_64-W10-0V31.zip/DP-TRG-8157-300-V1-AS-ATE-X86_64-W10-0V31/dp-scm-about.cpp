/**
* \file dp-scm-about.cpp
* \brief This file contains the code for About panel
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/
#include "dp-scm-about.h"
#include "ui_dp-scm-about.h"
#include "dp-scm-mainwindow.h"

extern S_GLOBAL g_SGlobal;

/*******************************************************************************
 * Name					: CAbout
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief This function is the constructor of CAbout class
 *
 * @param[in]	parent	Holds the parents of the object	(QWidget*)
 * @return	NA
 ******************************************************************************/
CAbout::CAbout(QWidget *parent) :
	QDialog(parent),
	ui(new Ui::CAbout)
{
	ui->setupUi(this);

    QDateTime date = QDateTime();
    QDateTime time = QDateTime();
    QString datetimeStr = QString();

	setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);

    ui->lbChecksum->setText("0x" + QString::number(g_SGlobal.g_ulAppChecksum, 16).toUpper());
    ui->lbAppVersion->setText(SCM_ATE_APP_VER);

#if 1
    date = QDateTime::fromString (__DATE__, "MMM dd yyyy");
    time = QDateTime::fromString (__TIME__, "HH:mm:ss");
    datetimeStr.sprintf("%s %s", date.toString ("MMM dd, yyyy").toStdString ().c_str (), time.toString ("HH:mm:ss").toStdString ().c_str ());
    ui->lbBuildTime->setText (datetimeStr);
#endif

    /** Tool Tip Display */
    ui->lbChecksum->setToolTip(ui->lbChecksum->text());
    ui->lbAppVersion->setToolTip(ui->lbAppVersion->text());
    ui->lbLink_Address->setToolTip("Contact Information");
    ui->lbBuildTime->setToolTip(ui->lbBuildTime->text());
    ui->lbDisp_Logo->setToolTip("DataPatterns Logo");

    ui->lbDisp_Checksum->setToolTip(ui->lbDisp_Checksum->text());
    ui->lbDis_AppVersion->setToolTip(ui->lbDis_AppVersion->text());
    ui->lbDisp_BuildTime->setToolTip(ui->lbDisp_BuildTime->text());
    /** *********************/
}

/*******************************************************************************
 * Name					: ~CAbout
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief This function is the destructor of CAbout class
 *
 * @param		NIL
 * @return	NA
 ******************************************************************************/
CAbout::~CAbout()
{
	delete ui;
}

/*******************************************************************************
 * Name					: on_pbOk_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Close the about panel
 ***************************************************************************//**
 * @brief This function will close the about panel
 *		This function is called when Ok button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CAbout::on_pbOk_clicked()
{
	this->close();
}

void CAbout::on_lbLink_Address_linkActivated(const QString &link)
{
    QDesktopServices::openUrl (QUrl(link));
}
