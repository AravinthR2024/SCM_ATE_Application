/**
* \file dp-scm-bootlaoder.cpp
* \brief This file contains the code for Software Programming panel and
*		Programming loading thread
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-bootloader.h"
#include "ui_dp-scm-bootloader.h"
#include "dp-scm-mainwindow.h"

extern S_GLOBAL g_SGlobal;

/* PROGRAM FILE LOADING THREAD */
/*******************************************************************************
 * Name					: CBootLoaderThread
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constuctor of CBootLoaderThread
 *
 * @param[in]	parent	Holds the reference to the parent	(QObject*)
 * @return	NA
 ******************************************************************************/
CBootLoaderThread::CBootLoaderThread(QObject *parent) : QThread(parent)
{
    m_bIsRunning = false;
    m_ucMode = 0;

    m_ulBootloadFileSize = DPSCM_INIT_0;
    m_iProgBar = DPSCM_INIT_0;
    m_qstrPrgmFile = QString("");
}

/*******************************************************************************
 * Name					: setMode
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set the mode of programming
 ***************************************************************************//**
 * @brief	This function is used to set mode of programming (Write/Read/Verify)
 *
 * @param[in]	in_ucMode	Specifies the operation mode	(unsigned char)
 *			0 - Flash Write Mode - Write data into the flash
 *			1 - Flash Read Mode - Read data from the flash
 *			2 - Flash Verify mode - Verify the data stored in the flash
 *			3 - Flash Erase size mode - To get size to erase
 *
 * @return	NIL
 ******************************************************************************/
void CBootLoaderThread::setMode(unsigned char in_ucMode)
{
    m_ucMode = in_ucMode;
}

/*******************************************************************************
 * Name					: Start
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To start the thread
 ***************************************************************************//**
 * @brief	This function is used to start the Program Loading thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CBootLoaderThread::Start(unsigned char in_ucMode)
{
    if (in_ucMode != (unsigned char) DPSCM_FAILURE)
    {
        m_ucMode = in_ucMode;
    }

    m_bIsRunning = true;
    this->start();
}

/*******************************************************************************
 * Name					: Stop
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To stop the thread
 ***************************************************************************//**
 * @brief	This function is used to terminate the Program Loading thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CBootLoaderThread::Stop()
{
    m_bIsRunning = false;
    this->terminate();
}

/*******************************************************************************
 * Name					: setProgramFile
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set the program file location
 ***************************************************************************//**
 * @brief	This function is used to set the program file name
 *
 * @param[in]	in_qstrPrgmFile	Specifies the program file name (QString)
 * @return	NIL
 ******************************************************************************/
void CBootLoaderThread::setProgramFile(QString in_qstrPrgmFile)
{
    if (in_qstrPrgmFile.isEmpty())
    {
        return;
    }

    m_qsFLASHLoad_FilePath = in_qstrPrgmFile;
}

/*******************************************************************************
 * Name					: run
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To execute the thread
 ***************************************************************************//**
 * @brief	This function contains the repeating execution of the thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CBootLoaderThread::run()
{
    while(m_bIsRunning)
    {
        switch(m_ucMode)
        {
        case MODE_CKSM_READ:
            DPSCM_FLASH_CHKSM_READ();
            break;

        case MODE_ERASE:
            DPSCM_FLASH_ERASE();
            break;

        case MODE_WRITE:
            DPSCM_FLASH_LOAD();
            break;

        case MODE_VERIFY:
            DPSCM_FLASH_VERIFY();
            break;
        }
        ucExecuteCount++;
        m_bIsRunning = false;
    }

    emit sig_threadFinished();
}

void CBootLoaderThread::DPSCM_FLASH_CHKSM_READ()
{
    unsigned long   ulTimeout = 1000;
    unsigned short  usTxDataLength = 0;
    S_DATA_PACKET   SRx_Packet;
    unsigned char   ucData = 0;

    memset(&SRx_Packet, 0, sizeof(S_DATA_PACKET));

    usTxDataLength = 0;

    emit sig_updateActionLog("Reading Flash Checksum", LOG_INFO);
    m_iRetval =  DP_SCM_TxData_RxResponse(DP_SCM_FLASH_CKSM_READ_CMD,
                                        usTxDataLength, &ucData, &SRx_Packet, ulTimeout);


    if(m_iRetval == DPSCM_SUCCESS)
    {
        if (SRx_Packet.m_sStatus == DPSCM_SUCCESS)
        {
            memcpy(&S_FlashCksmTst,&SRx_Packet.m_UData.m_S_FlashCksmTst, sizeof(S_FLASH_CSTEST));
            emit sig_updateActionLog("Checksum Read successful", LOG_SUCCESS);
            emit sig_updateChecksum();
        }
        else
        {
            emit sig_updateActionLog("Checksum Read failure", LOG_ERROR);
        }
    }
    else
    {
        sig_showErrorMessage(m_iRetval);
    }
}

short CBootLoaderThread::DP_SCM_FramePacket_And_Buffer(unsigned short in_usCommandID, \
                                                       unsigned short in_usDataLength, \
                                                       unsigned char *in_pucData, \
                                                       S_DATA_PACKET *out_pSDataPacket, \
                                                       unsigned char *out_pucDataBuffer)
{
    short sRetVal = DPSCM_SUCCESS;
    unsigned short usCheckSum = 0;
    unsigned short usLooper   = 0;

    if((NULL == in_pucData) || (NULL == out_pSDataPacket) || (NULL == out_pucDataBuffer))
    {
        sRetVal = DP_NULL_PTR_ERROR;
    }
    else
    {
        out_pSDataPacket->m_ucHeader[0]  = HEADER1;
        out_pSDataPacket->m_ucHeader[1]  = HEADER2;
        out_pSDataPacket->m_usCommandID	 = in_usCommandID;
        out_pSDataPacket->m_sStatus      = 0;
        out_pSDataPacket->m_usDataLength = in_usDataLength;
        memcpy(out_pSDataPacket->m_UData.m_ucData, in_pucData, in_usDataLength);

        memcpy(out_pucDataBuffer, out_pSDataPacket, (FIXED_FRAME_LENGTH + in_usDataLength));

        for(usLooper = 2; usLooper < (FIXED_FRAME_LENGTH + in_usDataLength); usLooper++)
        {
            usCheckSum ^= out_pucDataBuffer[usLooper];
        }

        out_pSDataPacket->m_usChecksum = usCheckSum;
        memcpy(&out_pucDataBuffer[FIXED_FRAME_LENGTH + in_usDataLength], &out_pSDataPacket->m_usChecksum, FOOTER_SIZE);
    }

    return sRetVal;
}

short CBootLoaderThread::DP_SCM_TxData_RxResponse(unsigned short in_usCommandID, unsigned short in_usDataLength,
                                                  unsigned char *in_pucData, S_DATA_PACKET *out_pSRxDataPacket,
                                                  unsigned long in_ulTimeOut)
{
    QString qstrErr = QString();
    unsigned char	ucTxDataBuffer[DATA_BUFFER_SIZE] = {0};
    S_DATA_PACKET	S_TxDataPacket;

    memset(&S_TxDataPacket, 0, sizeof(S_DATA_PACKET));

    if(g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].getPortStatus() == DPSCM_SUCCESS)
    {
        if((NULL == in_pucData) || (NULL == out_pSRxDataPacket))
        {
            m_iRetval = DP_NULL_PTR_ERROR;
        }
        else
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ClearAll();

            m_iRetval = DP_SCM_FramePacket_And_Buffer(in_usCommandID, in_usDataLength, in_pucData, &S_TxDataPacket, ucTxDataBuffer);

            if(DPSCM_SUCCESS == m_iRetval)
            {
                m_iRetval = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char*)&ucTxDataBuffer[0], (FIXED_FRAME_LENGTH + FOOTER_SIZE + in_usDataLength));
                if (m_iRetval != DPSCM_SUCCESS)
                {
                    qDebug() << "Error : " << g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(NULL, qstrErr);
                }
            }

            if(DPSCM_SUCCESS == m_iRetval)
            {
                m_iRetval = DP_SCM_Receive_DataPacket(in_usCommandID, out_pSRxDataPacket, in_ulTimeOut);
            }
        }
    }
    else
    {
        m_iRetval = DP_COM_PORT_NOT_OPENED;
    }

    return m_iRetval;
}

short CBootLoaderThread::DP_SCM_TxData_RxResponse1(unsigned short in_usCommandID, unsigned short in_usDataLength,
                                                        unsigned char *in_pucData, S_DATA_PACKET *out_pSRxDataPacket,
                                                        unsigned long in_ulTimeOut)
{
    short			sRetVal				= DPSCM_SUCCESS;
    unsigned char	ucTxDataBuffer[DATA_BUFFER_SIZE] = {0};
    S_DATA_PACKET	S_TxDataPacket;

    memset(&S_TxDataPacket, 0, sizeof(S_DATA_PACKET));

    if(g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].getPortStatus() == DPSCM_SUCCESS)
    {
        if((NULL == in_pucData) || (NULL == out_pSRxDataPacket))
        {
            sRetVal = DP_NULL_PTR_ERROR;
        }
        else
        {
            sRetVal = DP_SCM_FramePacket_And_Buffer(in_usCommandID, in_usDataLength, in_pucData, &S_TxDataPacket, ucTxDataBuffer);

            if(DPSCM_SUCCESS == sRetVal)
            {
                sRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char*)&ucTxDataBuffer[0], (FIXED_FRAME_LENGTH + FOOTER_SIZE + in_usDataLength));
            }

            if(DPSCM_SUCCESS == sRetVal)
            {
                sRetVal = DP_SCM_Receive_DataPacket1(in_usCommandID, out_pSRxDataPacket, in_ulTimeOut);
            }
        }
    }
    else
    {
        sRetVal = DP_COM_PORT_NOT_OPENED;
    }

    return sRetVal;
}
short CBootLoaderThread::DP_SCM_Receive_DataPacket1(unsigned short in_usCommandID, S_DATA_PACKET *out_pSRxDataPacket, unsigned short in_usTimeOut)
{
    Q_UNUSED(in_usCommandID);
    Q_UNUSED(in_usTimeOut);

    short sRetVal = DPSCM_SUCCESS;
    unsigned char ucarrData[4096] = {0};


    if(NULL == out_pSRxDataPacket)
    {
        sRetVal = DP_NULL_PTR_ERROR;
    }
    else
    {
        g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].WaitForData(ucarrData, DATA_BUFFER_SIZE);
        memcpy(out_pSRxDataPacket,ucarrData,DATA_BUFFER_SIZE);
    }

    return sRetVal;
}

short CBootLoaderThread::DP_SPL_6996_ReadData_Packet(unsigned char   in_ucData, \
                                                     S_DATA_PACKET  *out_pSDataPacket, \
                                                     unsigned char  *out_pucDataRxStatus, \
                                                     unsigned char  *out_pucState, \
                                                     unsigned short *out_pusCheckSum, \
                                                     unsigned short *out_pusDataReadCnt)
{
    short sRetVal = DPSCM_SUCCESS;

    if((NULL == out_pSDataPacket) || (NULL == out_pucDataRxStatus) || (NULL == out_pucState) || (NULL == out_pusCheckSum) || (NULL == out_pusDataReadCnt))
    {
        sRetVal = DP_NULL_PTR_ERROR;
    }
    else
    {
        switch(*out_pucState)
        {
        case HEADER_1_STATE:

            if(in_ucData == HEADER1)
            {
                out_pSDataPacket->m_ucHeader[0] = HEADER1;
                *out_pucState = HEADER_2_STATE;
            }
            else
            {
                *out_pucState = HEADER_1_STATE;
            }
            *out_pusCheckSum = 0;

            break;

        case HEADER_2_STATE:

            if(in_ucData == HEADER2)
            {
                out_pSDataPacket->m_ucHeader[1] = HEADER2;
                *out_pucState = CMD_ID_1_STATE;
            }
            else
            {
                *out_pucState = HEADER_1_STATE;
            }
            *out_pusCheckSum = 0;

            break;

        case CMD_ID_1_STATE:

            out_pSDataPacket->m_usCommandID = ((in_ucData << 0) & CLEAR_MSB);
            *out_pucState = CMD_ID_2_STATE;
            *out_pusCheckSum ^= in_ucData;

            break;

        case CMD_ID_2_STATE:

            out_pSDataPacket->m_usCommandID |= ((in_ucData << 8) & CLEAR_LSB);
            *out_pucState = STATUS_1_STATE;
            *out_pusCheckSum ^= in_ucData;

            break;

        case STATUS_1_STATE:

            out_pSDataPacket->m_sStatus = ((in_ucData << 0) & CLEAR_MSB);
            *out_pucState = STATUS_2_STATE ;
            *out_pusCheckSum ^= in_ucData;

            break;

        case STATUS_2_STATE:

            out_pSDataPacket->m_sStatus |= ((in_ucData << 8) & CLEAR_LSB);
            *out_pucState = DATA_LEN_1_STATE;
            *out_pusCheckSum ^= in_ucData;

            break;

        case DATA_LEN_1_STATE:

            out_pSDataPacket->m_usDataLength = ((in_ucData << 0) & CLEAR_MSB);
            *out_pucState = DATA_LEN_2_STATE;
            *out_pusCheckSum ^= in_ucData;

            break;

        case DATA_LEN_2_STATE:

            out_pSDataPacket->m_usDataLength |= ((in_ucData << 8) & CLEAR_LSB);
            *out_pusCheckSum ^= in_ucData;

            if(out_pSDataPacket->m_usDataLength > 0)
            {
                *out_pucState = DATA_STATE;
                *out_pusDataReadCnt = 0;
            }
            else
            {
                *out_pucState = CHECKSUM_1_STATE;
                *out_pusDataReadCnt = 0;
            }

            break;

        case DATA_STATE:

            out_pSDataPacket->m_UData.m_ucData[*out_pusDataReadCnt] = in_ucData;
            *out_pusDataReadCnt += 1;
            *out_pusCheckSum ^= in_ucData;

            if(*out_pusDataReadCnt == out_pSDataPacket->m_usDataLength)
            {
                *out_pucState    = CHECKSUM_1_STATE;
                *out_pusDataReadCnt = 0;
            }

            break;

        case CHECKSUM_1_STATE:

            out_pSDataPacket->m_usChecksum = ((in_ucData << 0) & CLEAR_MSB);
            *out_pucState = CHECKSUM_2_STATE;
            break;

        case CHECKSUM_2_STATE:

            out_pSDataPacket->m_usChecksum |= ((in_ucData << 8) & CLEAR_LSB);

            if(*out_pusCheckSum == out_pSDataPacket->m_usChecksum)
            {
                *out_pucDataRxStatus = DP_SET;
            }
            else
            {
                sRetVal = DP_CHECKSUM_ERROR;
            }
            *out_pucState = HEADER_1_STATE;
            *out_pusCheckSum = 0;
            break;

        default:
            *out_pucState = HEADER_1_STATE;
            *out_pusCheckSum = 0;
            *out_pucDataRxStatus = DP_RESET;
            sRetVal = DP_INVALID_RX_STATE_ERROR;
            break;
        }
    }

    return sRetVal;
}

short CBootLoaderThread::DP_SCM_Receive_DataPacket(unsigned short in_usCommandID, S_DATA_PACKET *out_pSRxDataPacket, unsigned long in_ulTimeOut)
{
    short sRetVal = DPSCM_SUCCESS;
    unsigned char	ucDataRxStatus		= 0;
    unsigned char	ucState				= 0;
    unsigned short	usCheckSum			= 0;
    unsigned short	usDataReadCnt		= 0;
    char	ucData				= 0;

    if(NULL == out_pSRxDataPacket)
    {
        sRetVal = DP_NULL_PTR_ERROR;
    }
    else
    {
        while(in_ulTimeOut)
        {
            if(g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].getPortStatus() == DPSCM_FAILURE)
            {
                sRetVal = DP_COM_PORT_CLOSED;
                break;
            }
            else
            {
                sRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData((char *)&ucData);
                if(DPSCM_SUCCESS == sRetVal)
                {
                    sRetVal = DP_SPL_6996_ReadData_Packet(ucData, out_pSRxDataPacket, &ucDataRxStatus, &ucState, &usCheckSum, &usDataReadCnt);
                    if((sRetVal != DPSCM_SUCCESS) || (ucDataRxStatus == DP_SET))
                    {
                        break;
                    }
                }
                else
                {
                    Delay(1000);
                    in_ulTimeOut--;
                }
            }
        }

        if((DPSCM_SUCCESS == sRetVal) && (DP_SET == ucDataRxStatus))
        {
            if(in_usCommandID != out_pSRxDataPacket->m_usCommandID)
            {
                sRetVal = DP_CMD_ID_MISMATCH_ERROR;
            }
        }
        else if(in_ulTimeOut == DP_RESET)
        {
            sRetVal = DP_TIMEOUT_ERROR;
        }
        else
        {

        }
    }

    return sRetVal;
}

void CBootLoaderThread::Delay(unsigned long in_ulTime_usec)
{
    LARGE_INTEGER freq;
    LARGE_INTEGER iStartCount;
    LARGE_INTEGER iEndCount;
    unsigned long in_ulMeasureTime_usec = 0;

    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&iStartCount);

    while(in_ulMeasureTime_usec < in_ulTime_usec)
    {
        QueryPerformanceCounter(&iEndCount);
        in_ulMeasureTime_usec = ((double)(iEndCount.QuadPart-iStartCount.QuadPart) / freq.QuadPart) * 1000000;
    }

    return;
}

void CBootLoaderThread::DPSCM_FLASH_ERASE()
{
    unsigned long   ulTimeout = (10000 * 60); //10Mins
    unsigned short  usTxDataLength = 0;
    unsigned int uiMilliSec = DPSCM_INIT_0;
    unsigned int uiSeconds = DPSCM_INIT_0;
    QString qstrTemp = QString();
    S_DATA_PACKET   SRx_Packet;

    memset(&SRx_Packet, 0, sizeof(S_DATA_PACKET));

    usTxDataLength = sizeof(unsigned short);

    m_iRetval = DP_SCM_TxData_RxResponse(DP_SCM_FLASH_ERASE_CMD, usTxDataLength, (unsigned char *)&S_FPGA_FlashLoad.m_usModuleSel, &SRx_Packet, ulTimeout);

    if(m_iRetval != DPSCM_SUCCESS)
    {
        qstrTemp.sprintf("Erase Failed [Err : %d]", m_iRetval);
        emit sig_updateActionLog(qstrTemp, LOG_ERROR);
    }
    else
    {
        uiMilliSec = m_qtimeTime.elapsed();
        uiSeconds = uiMilliSec / 1000;
        uiMilliSec = uiMilliSec - (uiSeconds * 1000);
        qstrTemp.sprintf("Erase Successful (Operation Completed in %02ds %02dms)", uiSeconds, uiMilliSec);
        emit sig_updateActionLog(qstrTemp, LOG_SUCCESS);
    }
}

void CBootLoaderThread::DPSCM_FLASH_LOAD()
{
    unsigned char   ucData = 0;
    unsigned short  usTxDataLength = 0;
    unsigned int uiMilliSec = DPSCM_INIT_0;
    unsigned int uiSeconds = DPSCM_INIT_0;
    unsigned long   ulTimeout = 1000;
    QString qstrTemp = QString();
    S_DATA_PACKET   SRx_Packet;

    memset(&SRx_Packet, 0, sizeof(S_DATA_PACKET));

    usTxDataLength = 0;

    m_qtimeTime.restart();

    /*Start Command to set the checksum as 0*/
    m_iRetval =  DP_SCM_TxData_RxResponse(DP_SCM_FLASH_START_CMD,\
                                        usTxDataLength, &ucData, &SRx_Packet, ulTimeout);
    if(m_iRetval == DPSCM_SUCCESS)
    {
        if(SRx_Packet.m_sStatus == DPSCM_SUCCESS)
        {
            emit sig_updateActionLog("Write Started",LOG_INFO);
        }
        else
        {
            emit sig_updateActionLog("Write Initiation Failed",LOG_ERROR);
        }
    }
    else
    {
        sig_showErrorMessage(m_iRetval);
    }

    if(m_iRetval == DPSCM_SUCCESS)
    {

        DPSCM_FLASH_LOAD_DATA(DP_SCM_FLASH_LOAD_CMD);
    }

    /*Stop Command*/
    usTxDataLength = 0;
    m_iRetval =  DP_SCM_TxData_RxResponse(DP_SCM_FLASH_STOP_CMD,\
                                        usTxDataLength, &ucData, &SRx_Packet, ulTimeout);
    if(m_iRetval == DPSCM_SUCCESS)
    {
        uiMilliSec = m_qtimeTime.elapsed();
        uiSeconds = uiMilliSec / 1000;
        uiMilliSec = uiMilliSec - (uiSeconds * 1000);
        qstrTemp.sprintf("Write Successful (Operation Completed in %02ds %02dms)", uiSeconds, uiMilliSec);
        emit sig_updateActionLog(qstrTemp, LOG_SUCCESS);
    }
    else
    {
        emit sig_updateActionLog("Write Failed",LOG_ERROR);
    }
}

void CBootLoaderThread::DPSCM_FLASH_VERIFY()
{
    DPSCM_FLASH_VERIFY_LOAD(DP_SCM_FLASH_VERIFY_CMD);
}

void CBootLoaderThread::DPSCM_FLASH_VERIFY_LOAD(unsigned short in_usCMDId)
{
    unsigned long   ulTimeout = 2000;
    unsigned short  usTxDataLength = 0;
    S_DATA_PACKET   SRx_Packet;
    unsigned char ucFlashData = 0;
    unsigned long ulFileSize = 0;
    unsigned short usPages = 0;
    unsigned short usNo_of_Packets = 0;
    unsigned short usLoop = 0;
    unsigned long ulLooper1 = 0;
    unsigned short usWriteLoop = 0;

    FILE *fFilePtr = NULL;
    FILE *fpWrFile = NULL;

    fFilePtr = fopen(m_qsFLASHLoad_FilePath.toUtf8().data(),"rb");

    if((fFilePtr != NULL))
    {
        if(S_FPGA_FlashLoad.m_usModuleSel == DP_SCM_DSP_CODE)
        {
            fpWrFile = fopen("DSP_ReadBack.bin","wb");
            if(fpWrFile == NULL)
            {
                emit sig_updateActionLog("FPGA code loader verify error",LOG_ERROR);
                m_bIsRunning = false;
                return;
            }
            while(!feof(fFilePtr))
            {
                fscanf(fFilePtr,"%x\n", (unsigned int *)&ucFlashData);
                ulFileSize++;
            }

            usPages = ulFileSize % DP_SCM_FPGA_PACKET_SIZE;

            if(usPages == 0)
            {
                usNo_of_Packets = (ulFileSize / DP_SCM_FPGA_PACKET_SIZE);
            }
            else
            {
                usNo_of_Packets = (ulFileSize / DP_SCM_FPGA_PACKET_SIZE) + 1;
            }

            fseek(fFilePtr,0,SEEK_SET);

            for(usLoop = 0; usLoop < usNo_of_Packets; usLoop++)
            {
                memset(S_FPGA_FlashLoad.m_ucarrData, 0, sizeof(S_FPGA_FlashLoad.m_ucarrData));

                if(usLoop == (usNo_of_Packets - 1) && (usPages !=0))
                {
                    for(ulLooper1 = 0; ulLooper1 < usPages; ulLooper1++)
                    {
                        fscanf(fFilePtr,"%x\n",(unsigned int *)&S_FPGA_FlashLoad.m_ucarrData[ulLooper1]);
                    }
                    S_FPGA_FlashLoad.m_usDataSize = usPages;
                }
                else
                {
                    for(ulLooper1 = 0; ulLooper1 < DP_SCM_FPGA_PACKET_SIZE; ulLooper1++)
                    {
                        fscanf(fFilePtr,"%x\n", (unsigned int *)&S_FPGA_FlashLoad.m_ucarrData[ulLooper1]);
                    }
                    S_FPGA_FlashLoad.m_usDataSize = DP_SCM_FPGA_PACKET_SIZE;
                }

                S_FPGA_FlashLoad.m_usTxPKtCount = usLoop;

                emit sig_updateProgressBar(100,((float)(usLoop +1) / usNo_of_Packets) * 100,"");

                usTxDataLength = sizeof(S_FPGA_FLASH_LOAD);

                memset(&SRx_Packet,0,sizeof (S_DATA_PACKET));

                m_iRetval =  DP_SCM_TxData_RxResponse1(in_usCMDId, \
                                                          usTxDataLength, (unsigned char *)&S_FPGA_FlashLoad, &SRx_Packet, ulTimeout);

                if(m_iRetval == DPSCM_SUCCESS)
                {
                    for(usWriteLoop = 0; usWriteLoop < S_FPGA_FlashLoad.m_usDataSize;usWriteLoop++)
                    {
                        fprintf(fpWrFile,"0x%02X\n",SRx_Packet.m_UData.m_S_FPGAFlashLoad.m_ucarrData[usWriteLoop]);
                    }

                    if(SRx_Packet.m_sStatus != DPSCM_SUCCESS)
                    {
                        emit sig_updateActionLog("FPGA code loader verify failure",LOG_SUCCESS);
                        m_bIsRunning = false;
                        break;
                    }
                }
                else
                {
                    //                    emit sig_updateActionLog("FPGA code loader verify failed",LOG_ERROR);
                    sig_showErrorMessage(m_iRetval);
                    m_bIsRunning = false;
                    break;
                }
            }
        }
        else if(S_FPGA_FlashLoad.m_usModuleSel == DP_SCM_FPGA_CODE)
        {
            fpWrFile = fopen("FPGA_ReadBack.bin","wb");
            if(fpWrFile == NULL)
            {
                emit sig_updateActionLog("FPGA code loader verify failed",LOG_ERROR);
                return;
            }

            fseek(fFilePtr,0,SEEK_END);

            ulFileSize = ftell(fFilePtr);

            fseek(fFilePtr,0,SEEK_SET);

            usPages = ulFileSize % DP_SCM_FPGA_PACKET_SIZE;

            if(usPages == 0)
            {
                usNo_of_Packets = (ulFileSize / DP_SCM_FPGA_PACKET_SIZE);
            }
            else
            {
                usNo_of_Packets = (ulFileSize / DP_SCM_FPGA_PACKET_SIZE) + 1;
            }

            for(usLoop = 0; usLoop < usNo_of_Packets; usLoop++)
            {
                memset(S_FPGA_FlashLoad.m_ucarrData, 0, sizeof(S_FPGA_FlashLoad.m_ucarrData));

                if(usLoop == (usNo_of_Packets - 1) && (usPages !=0))
                {
                    fread(S_FPGA_FlashLoad.m_ucarrData, usPages, 1, fFilePtr);
                    S_FPGA_FlashLoad.m_usDataSize = usPages;
                }
                else
                {
                    fread(S_FPGA_FlashLoad.m_ucarrData, DP_SCM_FPGA_PACKET_SIZE, 1, fFilePtr);
                    S_FPGA_FlashLoad.m_usDataSize = DP_SCM_FPGA_PACKET_SIZE;
                }
                S_FPGA_FlashLoad.m_usTxPKtCount = usLoop;

                emit sig_updateProgressBar(100,((float)(usLoop +1) / usNo_of_Packets) * 100, "");

                usTxDataLength = sizeof(S_FPGA_FLASH_LOAD);

                memset(&SRx_Packet,0,sizeof (S_DATA_PACKET));

                m_iRetval =  DP_SCM_TxData_RxResponse1(in_usCMDId, \
                                                          usTxDataLength, (unsigned char *)&S_FPGA_FlashLoad, &SRx_Packet, ulTimeout);
                if(m_iRetval == DPSCM_SUCCESS)
                {
                    fwrite(SRx_Packet.m_UData.m_S_FPGAFlashLoad.m_ucarrData, 256, 1, fpWrFile);

                    if(SRx_Packet.m_sStatus != DPSCM_SUCCESS)
                    {
                        emit sig_updateActionLog("FPGA code verify failed",LOG_ERROR);
                        m_bIsRunning = false;
                        break;
                    }
                }
                else
                {
                    //                    emit sig_updateActionLog("FPGA code verify success",LOG_SUCCESS);
                    sig_showErrorMessage(m_iRetval);
                    m_bIsRunning = false;
                    break;
                }
            }
        }
        else
        {
            // DO nothing..
        }
        if(m_iRetval == DPSCM_SUCCESS)
        {
            emit sig_updateActionLog("FPGA code verify success",LOG_SUCCESS);
        }
    }
    else
    {
        emit sig_updateActionLog("FPGA code verify failed",LOG_ERROR);
    }

    m_bIsRunning = false;
    fclose(fFilePtr);
    fclose(fpWrFile);
}

void CBootLoaderThread::DPSCM_FLASH_LOAD_DATA(unsigned short in_usCMDId)
{
    unsigned long   ulTimeout = 2000;
    unsigned short  usTxDataLength = 0;
    S_DATA_PACKET   SRx_Packet;
    unsigned char ucFlashData = 0;
    unsigned long ulFileSize = 0;
    unsigned short usPages = 0;
    unsigned short usNo_of_Packets = 0;
    unsigned short usLoop = 0;
    unsigned long ulLooper1 = 0;

    FILE *fFilePtr = NULL;

    fFilePtr = fopen(m_qsFLASHLoad_FilePath.toUtf8().data(),"rb");

    if(fFilePtr != NULL)
    {
        if(S_FPGA_FlashLoad.m_usModuleSel == DP_SCM_DSP_CODE)
        {
            while(!feof(fFilePtr))
            {
                fscanf(fFilePtr,"%x\n", (unsigned int *)&ucFlashData);
                ulFileSize++;
            }

            usPages = ulFileSize % DP_SCM_FPGA_PACKET_SIZE;

            if(usPages == 0)
            {
                usNo_of_Packets = (ulFileSize / DP_SCM_FPGA_PACKET_SIZE);
            }
            else
            {
                usNo_of_Packets = (ulFileSize / DP_SCM_FPGA_PACKET_SIZE) + 1;
            }

            fseek(fFilePtr,0,SEEK_SET);

            for(usLoop = 0; usLoop < usNo_of_Packets; usLoop++)
            {
                memset(S_FPGA_FlashLoad.m_ucarrData, 0, sizeof(S_FPGA_FlashLoad.m_ucarrData));

                if(usLoop == (usNo_of_Packets - 1) && (usPages !=0))
                {
                    for(ulLooper1 = 0; ulLooper1 < usPages; ulLooper1++)
                    {
                        fscanf(fFilePtr,"%x\n", (unsigned int *)&S_FPGA_FlashLoad.m_ucarrData[ulLooper1]);
                    }
                    S_FPGA_FlashLoad.m_usDataSize = usPages;
                }
                else
                {
                    for(ulLooper1 = 0; ulLooper1 < DP_SCM_FPGA_PACKET_SIZE; ulLooper1++)
                    {
                        fscanf(fFilePtr,"%x\n", (unsigned int *)&S_FPGA_FlashLoad.m_ucarrData[ulLooper1]);
                    }
                    S_FPGA_FlashLoad.m_usDataSize = DP_SCM_FPGA_PACKET_SIZE;
                }

                S_FPGA_FlashLoad.m_usTxPKtCount = usLoop;

                emit sig_updateProgressBar(100, ((float)(usLoop +1) / usNo_of_Packets) * 100, "");

                usTxDataLength = sizeof(S_FPGA_FLASH_LOAD);

                m_iRetval =  DP_SCM_TxData_RxResponse(in_usCMDId,
                                                    usTxDataLength, (unsigned char *)&S_FPGA_FlashLoad, &SRx_Packet, ulTimeout);
                if(m_iRetval == DPSCM_SUCCESS)
                {
                    if(SRx_Packet.m_sStatus != DPSCM_SUCCESS)
                    {
                        emit sig_updateActionLog( "FPGA code loader Failed",LOG_ERROR);
                        m_bIsRunning = false;
                        break;
                    }
                }
                else
                {
                    sig_showErrorMessage(m_iRetval);
                    m_bIsRunning = false;
                    break;
                }
            }
            if(m_iRetval == DPSCM_SUCCESS)
            {
                if(SRx_Packet.m_sStatus != DPSCM_SUCCESS)
                {
                    emit sig_updateActionLog( "FPGA code loader Failed",LOG_ERROR);
                }
            }
            else
            {
                sig_showErrorMessage(m_iRetval);
            }
        }
        else if(S_FPGA_FlashLoad.m_usModuleSel == DP_SCM_FPGA_CODE)
        {

            fseek(fFilePtr,0,SEEK_END);

            ulFileSize = ftell(fFilePtr);

            fseek(fFilePtr,0,SEEK_SET);

            usPages = ulFileSize % DP_SCM_FPGA_PACKET_SIZE;

            if(usPages == 0)
            {
                usNo_of_Packets = (ulFileSize / DP_SCM_FPGA_PACKET_SIZE);
            }
            else
            {
                usNo_of_Packets = (ulFileSize / DP_SCM_FPGA_PACKET_SIZE) + 1;
            }

            for(usLoop = 0; usLoop < usNo_of_Packets; usLoop++)
            {
                memset(S_FPGA_FlashLoad.m_ucarrData, 0, sizeof(S_FPGA_FlashLoad.m_ucarrData));

                if(usLoop == (usNo_of_Packets - 1) && (usPages !=0))
                {
                    fread(S_FPGA_FlashLoad.m_ucarrData, usPages, 1, fFilePtr);
                    S_FPGA_FlashLoad.m_usDataSize = usPages;
                }
                else
                {
                    fread(S_FPGA_FlashLoad.m_ucarrData, DP_SCM_FPGA_PACKET_SIZE, 1, fFilePtr);

                    S_FPGA_FlashLoad.m_usDataSize = DP_SCM_FPGA_PACKET_SIZE;
                }

                S_FPGA_FlashLoad.m_usTxPKtCount = usLoop;

                emit sig_updateProgressBar(100,((float)(usLoop +1) / usNo_of_Packets) * 100, "");

                usTxDataLength = sizeof(S_FPGA_FLASH_LOAD);

                m_iRetval =  DP_SCM_TxData_RxResponse(in_usCMDId,
                                                    usTxDataLength, (unsigned char *)&S_FPGA_FlashLoad, &SRx_Packet, ulTimeout);

                if(m_iRetval == DPSCM_SUCCESS)
                {
                    if(SRx_Packet.m_sStatus != DPSCM_SUCCESS)
                    {
                        emit sig_updateActionLog( "FPGA code loader Failed", LOG_ERROR);
                        m_bIsRunning = false;
                        break;
                    }
                }
                else
                {

                    sig_showErrorMessage(m_iRetval);
                    m_bIsRunning = false;
                    break;
                }
            }
        }
        else
        {
            // DO nothing..
        }
        if(m_iRetval == DPSCM_SUCCESS)
        {
            if(SRx_Packet.m_sStatus == DPSCM_SUCCESS)
            {
                emit sig_updateActionLog( "FPGA code loader success",LOG_SUCCESS);
            }
            else
            {
                emit sig_updateActionLog( "FPGA code loader Failed",LOG_ERROR);
            }
        }
        else
        {
            sig_showErrorMessage(m_iRetval);
        }

        m_bIsRunning = true;

    }
    else
    {
        sig_showErrorMessage(DPSCM_FAILURE);
    }

    fclose(fFilePtr);

}

/* PROGRAM FILE APPLICATION CLASS */
/*******************************************************************************
 * Name					: CBootLoader
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CBootLoader class
 *
 * @param[in]	parent	Holds the reference to the parent
 * @return	NA
 ******************************************************************************/
CBootLoader::CBootLoader(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CBootLoader)
{
    ui->setupUi(this);

    ui->frameProgress->setVisible(false);

    m_pThProgramLoading = new CBootLoaderThread(this);

    m_qstrPrgmFile = QString("");
    m_ulPrgmFileSize = DPSCM_INIT_0;

    ui->cmbFlash_FilePath->setEditable (false);

    ui->pbFlash_Erase->setEnabled (true);
    ui->pbFlash_Write->setEnabled (true);

    QFont qfFont = ui->leDSP_ExpChecksum->font();
    qfFont.setCapitalization(QFont::AllUppercase);
    ui->leDSP_ExpChecksum->setFont(qfFont);

    qfFont = ui->leDSP_CalcChecksum->font();
    qfFont.setCapitalization(QFont::AllUppercase);
    ui->leDSP_CalcChecksum->setFont(qfFont);

    qfFont = ui->leFPGA_ExpChecksum->font();
    qfFont.setCapitalization(QFont::AllUppercase);
    ui->leFPGA_ExpChecksum->setFont(qfFont);

    qfFont = ui->leFPGA_CalcChecksum->font();
    qfFont.setCapitalization(QFont::AllUppercase);
    ui->leFPGA_CalcChecksum->setFont(qfFont);

    ui->widgetPrgmFileSelection->setAcceptedFileFormat (QStringList() << "ldr" << "bin");

    ui->rbSection_DSP->setChecked(true);
    on_rbSection_DSP_clicked();

    QPixmap qpDefaultState(LED_GRAY);

    ui->lbLED_DSPChecksum_Status->setPixmap(qpDefaultState.scaled(32, 32, Qt::KeepAspectRatio));
    ui->lbLED_FPGAChecksum_Status->setPixmap(qpDefaultState.scaled(32, 32, Qt::KeepAspectRatio));

    SET_PROGRAM_MODE(false);

    connect(m_pThProgramLoading, SIGNAL(sig_threadFinished()), this, SLOT(slot_threadFinished()));
    connect(m_pThProgramLoading, SIGNAL(sig_UART_WriteRead_Cmd(unsigned short,char*,uint,char*,uint,uint)), this, SLOT(slot_UARTSendAndReceive(unsigned short,char*,uint,char*,uint,uint)), (Qt::ConnectionType) (Qt::BlockingQueuedConnection | Qt::UniqueConnection));
    connect(m_pThProgramLoading, SIGNAL(sig_updateProgressBar(int,int, QString)), this, SLOT(slot_updateFlash_ProgBar(int,int,QString)));
    connect(m_pThProgramLoading, SIGNAL(sig_updateActionLog(QString,int)), this, SLOT(slot_updateActionLog(QString,int)));
    connect(m_pThProgramLoading, SIGNAL(sig_updateChecksum()), this, SLOT(slot_updateChecksum()));
    connect(&m_timerHideProgBar, SIGNAL(timeout()), this, SLOT(slot_hideProgBar()));
    connect(ui->widgetPrgmFileSelection, SIGNAL(sig_fileDropped(QString)), this, SLOT(slot_setProgramFile(QString)));
}

/*******************************************************************************
 * Name					: ~CBootLoader
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief	This function is the destructor of CBootLoader
 *
 * @param		NIL
 * @return	NA
 ******************************************************************************/
CBootLoader::~CBootLoader()
{
    if (m_pThProgramLoading->isRunning())
    {
        m_pThProgramLoading->Stop ();
    }

    delete ui;
}

/*******************************************************************************
 * Name					: calculateChecksumRS232
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To calculate checksum
 ***************************************************************************//**
 * @brief	This function is used to calculate checksum
 *
 * @param[in]	in_pucMessage	Holds the message for which to calculate checksum
 * @param[in]	in_ulBytes	Specifies the size of the message
 *
 * @return	Return the checksum of the message
 ******************************************************************************/
short CBootLoader::calculateChecksumRS232( char *in_pucMessage, unsigned long in_ulBytes)
{
    unsigned long ulByte = 0;

    short usChksm =0;

    for (ulByte = 0; ulByte < in_ulBytes; ulByte = ulByte + 1)
    {
        usChksm ^= (unsigned char) in_pucMessage[ulByte];
    }

    return usChksm;
}

/*******************************************************************************
 * Name					: SerialWrite
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To send data through serial port
 ***************************************************************************//**
 * @brief	This function is used to write the data in the serial port
 *
 * @param[in]	in_us_Command_Id	Holds the command id
 * @param[in]	in_ucData			Holds the data to send in the serial port
 * @param[in]	in_usDataSize		Specifies the size of data to send
 *
 * @return	DPSCM_SUCCESS	if data send successful
 *			DPSCM_FAILURE	if any error occurred
 ******************************************************************************/
int CBootLoader::SerialWrite(unsigned short in_us_Command_Id, char *in_ucData, unsigned short in_usDataSize)
{int iRetVal = 0;
    unsigned int uiTxDataSize = 0;
    unsigned char ucTxArray[RS232_MAX_TX_PKT_LEN] ={0};
    QString qstrErrMsg = QString();
    QString qstrTemp = QString();
    S_UART_DATA_PKT S_UART_Tx_Packet = {
        {DPSCM_INIT_0, DPSCM_INIT_0},
        DPSCM_INIT_0,
        DPSCM_FAILURE,
        DPSCM_INIT_0,
        { DPSCM_INIT_0 },
        DPSCM_INIT_0
    };

    memset(&S_UART_Tx_Packet, 0, sizeof(S_UART_DATA_PKT));

    /** Packing the fixed header values*/
    S_UART_Tx_Packet.m_ucHeader[0] = RS232_TX_HEADER_1;
    S_UART_Tx_Packet.m_ucHeader[1] = RS232_TX_HEADER_2;

    /** Packing packet status as 0 */
    S_UART_Tx_Packet.m_sStatus = DPSCM_SUCCESS;

    /** Packing the command ID*/
    S_UART_Tx_Packet.m_usCmdID = in_us_Command_Id;

    /** Packing the Data Size*/
    S_UART_Tx_Packet.m_usDataLength = in_usDataSize;

    /** If data size is not zero, fill the data*/
    if(in_usDataSize > 0)
    {
        /** Packing the Tx Data*/
        memcpy(&S_UART_Tx_Packet.m_ucarrDataBuffer[0],in_ucData,in_usDataSize);
    }

#if 0
    /** Calculating the UART XOR checksum and packing the checksum*/
    S_UART_Tx_Packet.m_uschecksum = calculateChecksumRS232(&S_UART_Tx_Packet.m_ucarrDataBuffer[0],\
            S_UART_Tx_Packet.m_usDataLength);
#endif

    /** Assigning the strcuture members into array*/
    memcpy(&ucTxArray[uiTxDataSize],&S_UART_Tx_Packet.m_ucHeader,sizeof(S_UART_Tx_Packet.m_ucHeader));
    uiTxDataSize+=sizeof(S_UART_Tx_Packet.m_ucHeader);

    memcpy(&ucTxArray[uiTxDataSize],&S_UART_Tx_Packet.m_usCmdID,sizeof(S_UART_Tx_Packet.m_usCmdID));
    uiTxDataSize+=sizeof(S_UART_Tx_Packet.m_usCmdID);

    S_UART_Tx_Packet.m_sStatus = HTONS(S_UART_Tx_Packet.m_sStatus);
    memcpy(&ucTxArray[uiTxDataSize], &S_UART_Tx_Packet.m_sStatus, sizeof(S_UART_Tx_Packet.m_sStatus));
    uiTxDataSize += sizeof(S_UART_Tx_Packet.m_sStatus);

    memcpy(&ucTxArray[uiTxDataSize],&S_UART_Tx_Packet.m_usDataLength,sizeof(S_UART_Tx_Packet.m_usDataLength));
    uiTxDataSize+=sizeof(S_UART_Tx_Packet.m_usDataLength);

    memcpy(&ucTxArray[uiTxDataSize],&S_UART_Tx_Packet.m_ucarrDataBuffer[0],in_usDataSize);
    uiTxDataSize += in_usDataSize;

    S_UART_Tx_Packet.m_uschecksum = calculateChecksumRS232 ((char *) &ucTxArray[0], uiTxDataSize);

    memcpy(&ucTxArray[uiTxDataSize],&S_UART_Tx_Packet.m_uschecksum,sizeof(S_UART_Tx_Packet.m_uschecksum));
    uiTxDataSize+=sizeof(S_UART_Tx_Packet.m_uschecksum);

    /** Clear the UART buffer before starting a transmission*/
    g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_ClearAll ();

    /** Write the array into UART*/
#ifdef _PORT_CONNECTED_
    iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *) &ucTxArray[0], uiTxDataSize);
    if (iRetVal != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
        qstrTemp.sprintf("Serial Write Error : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
        emit sig_updateActionLog(qstrTemp, LOG_WARNING);
    }
#endif

    return iRetVal;
}

/*******************************************************************************
 * Name					: SerialRead
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To read data through serial port
 ***************************************************************************//**
 * @brief	This function is used to read the data from serial port
 *
 * @param[out]	out_pucDataBuffer	Specifies the memory address to store read data
 * @param[in]	in_uiOutputDataLen	Specifies the maximum data size to read
 * @param[in]	in_uiTimeout		Specifies the data read wait timeout
 *
 * @return	DPSCM_SUCCESS	if data read successful
 *			DPSCM_FAILURE	if any error occurred
 ******************************************************************************/
int CBootLoader::SerialRead(char *out_pucDataBuffer, unsigned int in_uiOutputDataLen, unsigned int in_uiTimeout)
{
    unsigned char ucHeaderReady = 0;
    unsigned short usChecksum = 0;
    QString qstrErrMsg = QString();
    QString qstrTemp = QString();
    S_UART_DATA_PKT S_UART_Rx_Packet = {
        { DPSCM_INIT_0, DPSCM_INIT_0 },
        DPSCM_INIT_0,
        DPSCM_FAILURE,
        DPSCM_INIT_0,
        { DPSCM_INIT_0 },
        DPSCM_INIT_0

    };
    int iRetVal = 0;
    unsigned int uiReadSize = 0;

    memset(&S_UART_Rx_Packet,0,sizeof(S_UART_DATA_PKT));

    /** Reading the Rx packet header*/
#ifdef _PORT_CONNECTED_
    iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData(sizeof(S_UART_Rx_Packet.m_ucHeader), (char *) S_UART_Rx_Packet.m_ucHeader, &uiReadSize, in_uiTimeout);
#endif

    if(iRetVal)
    {
        g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
        qstrTemp.sprintf("Header Read Error : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
        emit sig_updateActionLog(qstrTemp, LOG_WARNING);
        return DPSCM_FAILURE;
    }

    if ((S_UART_Rx_Packet.m_ucHeader[0] == RS232_TX_HEADER_1) && \
            (S_UART_Rx_Packet.m_ucHeader[1] == RS232_TX_HEADER_2))
    {
        ucHeaderReady = 1;
    }

    /** If header is ready, go for parsing the remaining packet*/
    if(ucHeaderReady == 1)
    {
        /// Read Command ID
#ifdef _PORT_CONNECTED_
        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData(sizeof(S_UART_Rx_Packet.m_usCmdID), (char *)&S_UART_Rx_Packet.m_usCmdID, &uiReadSize, in_uiTimeout);
#endif
        if(iRetVal)
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Command ID Read Error : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_WARNING);
            return iRetVal;
        }

#ifdef _PORT_CONNECTED_
        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData (sizeof(S_UART_Rx_Packet.m_sStatus), (char *)&S_UART_Rx_Packet.m_sStatus, &uiReadSize, in_uiTimeout);
#endif
        if (iRetVal)
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError (&iRetVal, qstrErrMsg);
            qstrTemp.sprintf ("Status Read Error : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog (qstrTemp, LOG_WARNING);
            return iRetVal;
        }

        if (S_UART_Rx_Packet.m_sStatus != DPSCM_SUCCESS)
        {
            return S_UART_Rx_Packet.m_sStatus;
        }

        /// Read Data length
#ifdef _PORT_CONNECTED_
        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData(sizeof(S_UART_Rx_Packet.m_usDataLength), (char *)&S_UART_Rx_Packet.m_usDataLength, &uiReadSize, in_uiTimeout);
#endif

        if(iRetVal)
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Data Read Error : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_WARNING);
            return iRetVal;
        }

        if (S_UART_Rx_Packet.m_usDataLength != in_uiOutputDataLen)
        {
            qstrTemp.sprintf ("Data Length Error : Invalid data length is read (Exp: %d - Act: %d)", in_uiOutputDataLen, S_UART_Rx_Packet.m_usDataLength);
            emit sig_updateActionLog (qstrTemp, LOG_WARNING);
            return DPSCM_FAILURE;
        }

        if(S_UART_Rx_Packet.m_usDataLength !=0)
        {
            /// Read data in the Rx packet
#ifdef _PORT_CONNECTED_
            iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData(S_UART_Rx_Packet.m_usDataLength, (char *) out_pucDataBuffer, &uiReadSize, in_uiTimeout);
#endif

            if(iRetVal)
            {
                g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
                qstrTemp.sprintf("Serial Read Error : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
                emit sig_updateActionLog(qstrTemp, LOG_WARNING);
                return iRetVal;
            }
        }


        /// Checking the output parameter length with the received data size
        if(S_UART_Rx_Packet.m_usDataLength != in_uiOutputDataLen)
        {
            qstrTemp.sprintf("Received packet data size (%d) not matched with expected data size (%d)",\
                             S_UART_Rx_Packet.m_usDataLength, in_uiOutputDataLen);
            emit sig_updateActionLog(qstrTemp, LOG_WARNING);
            return DPSCM_FAILURE;
        }

        ///Read Checksum
#ifdef _PORT_CONNECTED_
        iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData(sizeof(S_UART_Rx_Packet.m_uschecksum), (char *)&S_UART_Rx_Packet.m_uschecksum, &uiReadSize, in_uiTimeout);
#endif

        if(iRetVal)
        {
            g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&iRetVal, qstrErrMsg);
            qstrTemp.sprintf("Serial Read Error : %s [Err: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), iRetVal);
            emit sig_updateActionLog(qstrTemp, LOG_WARNING);
            return iRetVal;
        }
#ifdef _PORT_CONNECTED_
        /// Calculating checksum for the incoming packet data
        usChecksum = calculateChecksumRS232((char *)&S_UART_Rx_Packet, sizeof(S_UART_Rx_Packet) - 2);

        /// Checksum error
        if(usChecksum != S_UART_Rx_Packet.m_uschecksum)
        {
            qstrTemp.sprintf("Received Rx packet checksum (0x%X) doesn't match with Transmitted checksum (0x%X)",\
                             usChecksum, S_UART_Rx_Packet.m_uschecksum);
            emit sig_updateActionLog(qstrTemp, LOG_WARNING);
            return iRetVal;
        }
#endif
    }
    else
    {
        qstrTemp.sprintf("Cannot parse the Received Rx Packet : Invalid Header");
        emit sig_updateActionLog(qstrTemp, LOG_WARNING);
        return DPSCM_FAILURE;
    }

    /** return success in case of no error*/
    return DPSCM_SUCCESS;
}

/*******************************************************************************
 * Name					: slot_updateFlash_ProgBar
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To update progress bar
 ***************************************************************************//**
 * @brief	This function is used to update the value of progress bar
 *		This function is called when sig_updateProgressBar signal
 *			emitted by program loading thread
 *
 * @param[in]	in_iMaxVal	Specifies the maximum value of the progress bar
 * @param[in]	in_iProgSts	Specifies the current value of progress bar
 *
 * @return	NIL
 ******************************************************************************/
void CBootLoader::slot_updateFlash_ProgBar(int in_iMaxVal, int in_iProgSts, QString in_qstrLabel)
{
    ui->frameProgress->setVisible(true);
    ui->progressFlashProgram->setMaximum(in_iMaxVal);
    ui->progressFlashProgram->setValue(in_iProgSts);
}

/*******************************************************************************
 * Name					: slot_UARTSendAndReceive
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To send and read data in UART
 ***************************************************************************//**
 * @brief	This function is used to send and validate send status in UART
 *		This function is called when sig_UART_WriteRead_Cmd signal is emitted
 *			from program loading thread
 *
 * @param[in]	in_usCommandID			Holds the command ID
 * @param[in]	in_pucInputDataBuffer	Holds the data to send
 * @param[in]	in_uiInputDataLen		Specifies the size of the data to send
 * @param[out]	out_pucOutputDataBuffer	Holds the memory address to store read data
 * @param[in]	in_uiOutputDataLen		Specifies the size of data to read
 * @param[in]	in_uiTimeout_ms		Specifies the timeout for read
 *
 * @return	DPSCM_SUCCESS	if data is send and response is read
 *			DPSCM_FAILURE	if any error occurred
 ******************************************************************************/
int CBootLoader::slot_UARTSendAndReceive(unsigned short in_usCommandID, char *in_pucInputDataBuffer, unsigned int in_uiInputDataLen, \
                                         char *out_pucOutputDataBuffer, unsigned int in_uiOutputDataLen, unsigned int in_uiTimeout_ms)
{
    int iRetVal = DPSCM_INIT_0;

    /** Transmit the RS232 packet to firmware*/
    iRetVal = SerialWrite(in_usCommandID,in_pucInputDataBuffer,in_uiInputDataLen);
    if(iRetVal)
    {
        if(iRetVal == DPRS232ERR_COM_PORT_NOT_OPEN)
        {
            DISPLAY_MESSAGE_BOX(this,"Error","COM Port Not opened");
        }
        else
        {
            DISPLAY_MESSAGE_BOX(this, "Error", "Error while writing data in UART");
        }
        return iRetVal;
    }


    /** Receive the response for the transmitted packet */
    iRetVal = SerialRead(out_pucOutputDataBuffer,in_uiOutputDataLen,in_uiTimeout_ms);
    if (iRetVal)
    {
        DISPLAY_MESSAGE_BOX(this,"Error", "Error while reading data from UART");
    }

    return iRetVal;
}

/*******************************************************************************
 * Name					: slot_hideProgBar
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To hide the progress bar
 ***************************************************************************//**
 * @brief	This function is used to hide the progress bar
 *		This function is called when timeout signal is emitted from m_timerHideProgBar
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CBootLoader::slot_hideProgBar()
{
    m_timerHideProgBar.stop();
}

/*******************************************************************************
 * Name					: slot_updateActionLog
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To update action log
 ***************************************************************************//**
 * @brief	This function is used to update action log and hide progress bar
 *		This function is called when sig_updateActionLog signal is emitted
 *			from program loading thread
 *
 * @param[in]	in_qstrMsg	Holds the message to display
 * @param[in]	in_iType		Specifies the type of message
 *
 * @return	NIL
 ******************************************************************************/
void CBootLoader::slot_updateActionLog(QString in_qstrMsg, int in_iType)
{
    if (in_iType == LOG_SUCCESS || in_iType == LOG_INFO)
    {
        m_timerHideProgBar.start(2000);
    }
    else
    {
        ui->frameProgress->setHidden(true);
    }

    emit sig_updateActionLog(in_qstrMsg, in_iType);
}

/*******************************************************************************
 * Name					: slot_updateChecksum
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To display the checksum value
 ***************************************************************************//**
 * @brief	This function is used to update Checksum value of flash data
 *		This function is called when sig_updateChecksum signal is emitted
 *			from program loading thread
 *
 * @param[in]	in_qstrChksum	Holds the value of checksum to display
 *
 * @return	NIL
 ******************************************************************************/
void CBootLoader::slot_updateChecksum()
{
    QPixmap qpPassState(LED_GREEN);
    QPixmap qpFailState(LED_RED);

    ui->leDSP_ExpChecksum->setText(QString::number(m_pThProgramLoading->S_FlashCksmTst.m_usDSPRdCksum, 16).toUpper());
    ui->leDSP_CalcChecksum->setText(QString::number(m_pThProgramLoading->S_FlashCksmTst.m_usDSPCompCksum, 16).toUpper());
    ui->leFPGA_ExpChecksum->setText(QString::number(m_pThProgramLoading->S_FlashCksmTst.m_usFPGARdCksum, 16).toUpper());
    ui->leFPGA_CalcChecksum->setText(QString::number(m_pThProgramLoading->S_FlashCksmTst.m_usFPGACompCksum, 16).toUpper());

    /** Set Tooltips for Checksums */
    ui->leDSP_ExpChecksum->setToolTip(ui->leDSP_ExpChecksum->text());
    ui->leDSP_CalcChecksum->setToolTip(ui->leDSP_CalcChecksum->text());
    ui->leFPGA_CalcChecksum->setToolTip(ui->leFPGA_CalcChecksum->text());
    ui->leFPGA_ExpChecksum->setToolTip(ui->leFPGA_ExpChecksum->text());
    /** ****************************/

    if(m_pThProgramLoading->S_FlashCksmTst.m_usDSPRdCksum == m_pThProgramLoading->S_FlashCksmTst.m_usDSPCompCksum)
    {
        ui->lbLED_DSPChecksum_Status->setPixmap(qpPassState.scaled(32, 32, Qt::KeepAspectRatio));
        ui->lbLED_DSPChecksum_Status->setToolTip("Pass");
    }
    else
    {
        ui->lbLED_DSPChecksum_Status->setPixmap(qpFailState.scaled(32, 32, Qt::KeepAspectRatio));
        ui->lbLED_DSPChecksum_Status->setToolTip("Fail");
    }

    if(m_pThProgramLoading->S_FlashCksmTst.m_usFPGARdCksum == m_pThProgramLoading->S_FlashCksmTst.m_usFPGACompCksum)
    {
        ui->lbLED_FPGAChecksum_Status->setPixmap(qpPassState.scaled(32, 32, Qt::KeepAspectRatio));
        ui->lbLED_FPGAChecksum_Status->setToolTip("Pass");
    }
    else
    {
        ui->lbLED_FPGAChecksum_Status->setPixmap(qpFailState.scaled(32, 32, Qt::KeepAspectRatio));
        ui->lbLED_FPGAChecksum_Status->setToolTip("Fail");
    }
}

void CBootLoader::slot_threadFinished()
{
    switch (m_pThProgramLoading->m_ucMode)
    {
    case MODE_WRITE:
    {
        ui->pbFlash_Erase->setEnabled (true);
    } break;
    case MODE_CKSM_READ:
    {

    } break;
    case MODE_ERASE:
    {
        if (m_pThProgramLoading->m_iRetval != DPSCM_SUCCESS)
        {
            ui->pbFlash_Erase->setEnabled(true);
        }
        else
        {
            ui->pbFlash_Erase->setEnabled(false);
        }
    } break;
    case MODE_VERIFY:
    {

    } break;

    default: break;
    }

    ui->frameProgress->setVisible(false);
    emit sig_showLoadingScreen(false);
}

void CBootLoader::slot_EnDisSync(bool in_bEnable, bool in_bFromConfig)
{
    Q_UNUSED(in_bEnable);

    if (!in_bFromConfig)
    {
        ui->pbFlash_Erase->setDisabled (false);
        ui->pbFlash_Write->setDisabled (false);
    }
    else
    {
        ui->pbFlash_Erase->setDisabled (false);
        ui->pbFlash_Write->setDisabled (false);
    }
}

/*******************************************************************************
 * Name					: on_pbFlash_Browse_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To browse the program file
 ***************************************************************************//**
 * @brief	This function is used to choose Program file to write into flash
 *		This function is called when Browse button is clicked
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CBootLoader::on_pbFlash_Browse_clicked()
{
    QString qstrPrgmFile = QString();
    if(ui->rbSection_DSP->isChecked())
    {
        qstrPrgmFile = QFileDialog::getOpenFileName(this,"Select LDR File", "C:\\users\\%USERPROFILE%\\Documents","LDR File (*.ldr)");
    }
    else if(ui->rbSection_FPGA->isChecked())
    {
        qstrPrgmFile = QFileDialog::getOpenFileName(this,"Select BIN File", "C:\\users\\%USERPROFILE%\\Documents","FPGA File (*.bin *.mcs)");
    }

    slot_setProgramFile(qstrPrgmFile);
}


void CBootLoader::slot_setProgramFile (QString in_qstrPrgmFile)
{
    QString qstrElided = QString();

    if(in_qstrPrgmFile.isEmpty())
    {
        DISPLAY_MESSAGE_BOX(this,"Program file", "Select appropriate path");
        return;
    }

    if (in_qstrPrgmFile.endsWith("ldr"))
    {
        ui->rbSection_DSP->setChecked(true);
    }
    else if (in_qstrPrgmFile.endsWith("bin") || in_qstrPrgmFile.endsWith("mcs"))
    {
        ui->rbSection_FPGA->setChecked(true);
    }
    else
    {
        DISPLAY_MESSAGE_BOX(this, "Program File", "Please select appropriate DSP or FPGA file");
        return;
    }

    m_pThProgramLoading->setProgramFile(in_qstrPrgmFile);

    for (int i = 0; i < ui->cmbFlash_FilePath->count (); i++)
    {
        if (ui->cmbFlash_FilePath->itemData (i).toString () == in_qstrPrgmFile)
        {
            ui->cmbFlash_FilePath->setCurrentIndex (i);
            return;
        }
    }

    QFontMetrics fmetric(ui->cmbFlash_FilePath->font ());
    qstrElided = fmetric.elidedText (in_qstrPrgmFile, Qt::ElideLeft, ui->cmbFlash_FilePath->width () - ui->cmbFlash_FilePath->font ().pointSize ());
    ui->cmbFlash_FilePath->insertItem (0, qstrElided, in_qstrPrgmFile);
    ui->cmbFlash_FilePath->setCurrentIndex (0);
}

void CBootLoader::Flash_Verify_Function()
{
    /** If nothing is selected print Error message*/
    if(m_pThProgramLoading->m_qsFLASHLoad_FilePath.isEmpty())
    {
        QMessageBox::information(this,"Flash Programming","Select appropriate path",QMessageBox::Ok);
    }
    /** Print the selected path in corresponding line edit*/
    else
    {
        m_pThProgramLoading->setMode(MODE_VERIFY);
        m_pThProgramLoading->m_bIsRunning = true;
        m_pThProgramLoading->Start();
    }
}

void CBootLoader::on_pbFlash_Erase_clicked()
{
    CHECK_TC_RUNNING;

    CHECK_PORT_OPEN(DIAGNOSTIC_PORT_IDX);

    if(ui->rbSection_DSP->isChecked())
    {
        QMessageBox::StandardButton OkCancel = QMessageBox::question\
                (this, "Flash erase", tr("This operation will erase DSP code from the flash,\nIt will take approximately 10 minutes.\nClick Yes to erase the code"), QMessageBox::No | QMessageBox::Yes, QMessageBox::Yes);
        if (OkCancel != QMessageBox::Yes)
        {
            return;
        }
        else
        {
            emit sig_updateActionLog("DSP Erase started", LOG_INFO);
            emit sig_showLoadingScreen(true);
        }
    }
    else
    {
        QMessageBox::StandardButton OkCancel = QMessageBox::question\
                (this, "Flash erase", tr("This operation will erase FPGA code from the flash.\n"
                                         "It will take approximately 10 minutes.\n"
                                         "Click Yes to erase the code"), QMessageBox::No | QMessageBox::Yes, QMessageBox::Yes);
        if (OkCancel != QMessageBox::Yes)
        {
            return;
        }
        else
        {
            emit sig_updateActionLog("FPGA Erase started", LOG_INFO);
            emit sig_showLoadingScreen(true);
        }
    }

    m_pThProgramLoading->setMode(MODE_ERASE);
    m_pThProgramLoading->m_bIsRunning = true;
    m_pThProgramLoading->m_qtimeTime.restart();
    m_pThProgramLoading->Start();
}

void CBootLoader::on_pbFlash_Write_clicked()
{
    CHECK_TC_RUNNING;

    CHECK_PORT_OPEN(DIAGNOSTIC_PORT_IDX);

    /** If nothing is selected print Error message*/
    if(m_pThProgramLoading->m_qsFLASHLoad_FilePath.isEmpty())
    {
        DISPLAY_MESSAGE_BOX(this,"Flash Programming","Select appropriate path");
    }
    /** Print the selected path in corresponding line edit*/
    else
    {
        m_pThProgramLoading->setMode(MODE_WRITE);
        m_pThProgramLoading->m_bIsRunning = true;
        m_pThProgramLoading->Start();
    }
}

void CBootLoader::on_rbSection_DSP_clicked()
{
    on_rbSection_DSP_toggled(true);
}

void CBootLoader::on_rbSection_FPGA_clicked()
{
    on_rbSection_FPGA_toggled(true);
}

void CBootLoader::on_cmbFlash_FilePath_currentIndexChanged(int index)
{
    if (index == DPSCM_FAILURE)
    {
        return;
    }

    if (ui->cmbFlash_FilePath->currentData().toString().endsWith(".ldr"))
    {
        ui->rbSection_DSP->setChecked(true);
    }
    else
    {
        ui->rbSection_FPGA->setChecked(true);
    }

    slot_setProgramFile (ui->cmbFlash_FilePath->currentData ().toString ());
}

void CBootLoader::on_pbFlash_ReadChecksum_clicked()
{
    CHECK_TC_RUNNING;

    CHECK_PORT_OPEN(DIAGNOSTIC_PORT_IDX);

    emit sig_showLoadingScreen(true);
    if (g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ClearAll())
    m_pThProgramLoading->setMode(MODE_CKSM_READ);
    m_pThProgramLoading->m_bIsRunning = true;
    m_pThProgramLoading->Start();
}

void CBootLoader::on_rbSection_DSP_toggled(bool checked)
{
    if (checked)
    {
        ui->lbDisp_SelectFile->setText("Select File (.ldr)");

        memset(&m_pThProgramLoading->S_FPGA_FlashLoad, 0, sizeof(S_FPGA_FLASH_LOAD));
        m_pThProgramLoading->S_FPGA_FlashLoad.m_usModuleSel = DP_SCM_DSP_CODE;

        ui->pbFlash_Erase->setToolTip("Erase DSP Section of Flash");
        ui->pbFlash_Write->setToolTip("Load DSP Flash Data");
    }
}

void CBootLoader::on_rbSection_FPGA_toggled(bool checked)
{
    if (checked)
    {
        ui->lbDisp_SelectFile->setText("Select File (.bin or .mcs)");

        memset(&m_pThProgramLoading->S_FPGA_FlashLoad, 0, sizeof(S_FPGA_FLASH_LOAD));
        m_pThProgramLoading->S_FPGA_FlashLoad.m_usModuleSel = DP_SCM_FPGA_CODE;

        ui->pbFlash_Erase->setToolTip("Erase FPGA Section of Flash");
        ui->pbFlash_Write->setToolTip("Load FPGA Flash Data");
    }
}

void CBootLoader::on_pbProgramEnablePin_clicked(bool in_bEnable)
{
    int iRetVal = DPSCM_INIT_0;
    unsigned char ucEnable = DPSCM_INIT_0;
    char szErrMsg[100] = { 0 };
    QString qstrTemp = QString("");

    if (in_bEnable)
    {
        ucEnable = PRGMMODE_EN;
    }
    else
    {
        ucEnable = PRGMMODE_DIS;
    }

    /**
      MODE CONFIGURATION AND PROGRAM ENABLE REGISTER - BASE4 + 0x00, BASE4 = 0x00000400
      */
    iRetVal = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_ProgramEnable(XMC_BRD_IDX, ucEnable);
    if (iRetVal != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError(&iRetVal, szErrMsg);
        qstrTemp.sprintf("Error Configuring Program Enable Pin : %s [ErrCode: %d] ", szErrMsg, iRetVal);
        sig_updateActionLog(qstrTemp, LOG_ERROR);
    }

    if (iRetVal == DPSCM_SUCCESS)
    {
        if (ucEnable == PRGMMODE_EN)
        {
            ui->pbProgramEnablePin->setText("Disable");
        }
        else
        {
            ui->pbProgramEnablePin->setText("Enable");
        }
    }
    else
    {
        ui->pbProgramEnablePin->setChecked(ucEnable);
    }

    SET_PROGRAM_MODE(in_bEnable);
}

void CBootLoader::on_pbProgramEnablePin_toggled(bool in_bEnable)
{
    int iRetVal = DPSCM_INIT_0;
    unsigned char ucEnable = DPSCM_INIT_0;
    char szErrMsg[100] = { 0 };
    QString qstrTemp = QString("");

    if (in_bEnable)
    {
        ucEnable = PRGMMODE_EN;
    }
    else
    {
        ucEnable = PRGMMODE_DIS;
    }

    /**
      MODE CONFIGURATION AND PROGRAM ENABLE REGISTER - BASE4 + 0x00, BASE4 = 0x00000400
      */
    iRetVal = g_SGlobal.m_objXMC5775.DPXMC5775Wrap_ProgramEnable(XMC_BRD_IDX, ucEnable);
    if (iRetVal != DPSCM_SUCCESS)
    {
        g_SGlobal.m_objXMC5775.DPXMC5775Wrap_GetLastError(&iRetVal, szErrMsg);
        qstrTemp.sprintf("Error Configuring Program Enable Pin : %s [ErrCode: %d] ", szErrMsg, iRetVal);
        ui->pbProgramEnablePin->setState(!in_bEnable);
        emit sig_updateActionLog(qstrTemp, LOG_ERROR);
    }

    if (iRetVal == DPSCM_SUCCESS)
    {
        if (ucEnable == PRGMMODE_EN)
        {
            ui->pbProgramEnablePin->setText("Disable");
        }
        else
        {
            ui->pbProgramEnablePin->setText("Enable");
        }

        SET_PROGRAM_MODE(in_bEnable);
    }
    else
    {
        ui->pbProgramEnablePin->setChecked(ucEnable);
    }

}
