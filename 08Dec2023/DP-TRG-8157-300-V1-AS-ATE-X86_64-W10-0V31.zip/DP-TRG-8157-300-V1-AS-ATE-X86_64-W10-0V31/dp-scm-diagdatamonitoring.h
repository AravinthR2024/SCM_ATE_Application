#ifndef DPSCMDIAGDATAMONITORING_H
#define DPSCMDIAGDATAMONITORING_H

#include <QWidget>

#include <QTableWidgetItem>
#include <QThread>
#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "checksum.h"

typedef struct _S_TABLE_INDEX
{
        int m_iRow;
        int m_iCol;
} S_TABLE_INDEX, *PS_TABLE_INDEX;

namespace Ui {
class CDiagDataMonitoring;
}

class CDiagDataMonThread : public QThread
{
    Q_OBJECT

public:
    CDiagDataMonThread(QObject *parent = 0);

    bool m_bIsRunning;
    unsigned char m_arrucValues[TOTAL_DIAG_LIST];
    QTableWidgetItem *m_pobjarrNameItem[TOTAL_DIAG_LIST];
    QTableWidgetItem *m_pobjarrValueItem[TOTAL_DIAG_LIST];

    void Start();
    void Stop();
    void run() override;

signals:
    void sig_threadCompleted();
    void sig_setValue(int, QString);
    void sig_updateActionLog(QString, int);
};

class CDiagDataMonitoring : public QWidget
{
    Q_OBJECT

public:
    explicit CDiagDataMonitoring(QWidget *parent = 0);
    ~CDiagDataMonitoring();

    unsigned char m_arrucValues[TOTAL_DIAG_LIST];

    CDiagDataMonThread *m_pthDataMon;

private :
    S_TABLE_INDEX m_arrSNameIndex[TOTAL_DIAG_LIST];
    S_TABLE_INDEX m_arrSValueIndex[TOTAL_DIAG_LIST];

    QTableWidgetItem *m_pobjarrNameItem[TOTAL_DIAG_LIST];
    QTableWidgetItem *m_pobjarrValueItem[TOTAL_DIAG_LIST];

    void loadIndices();

signals:
    void sig_updateActionLog(QString, int);

    void sig_showLoadingScreen (bool);

private slots:
    void on_pbDiagData_Read_clicked();

    void on_tblwidDiagData_itemClicked(QTableWidgetItem *item);

    void on_cbSelectAll_clicked();

    void on_pbDiagDataClear_clicked();

public slots:
    void slot_setValue (int in_iIndex, QString in_qstrValue);

    void slot_threadCompleted();

private:
    Ui::CDiagDataMonitoring *ui;
};

#endif // DPSCMDIAGDATAMONITORING_H
