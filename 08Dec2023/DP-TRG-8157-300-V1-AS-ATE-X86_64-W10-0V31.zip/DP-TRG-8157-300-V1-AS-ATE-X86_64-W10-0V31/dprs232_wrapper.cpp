/**
* \file dprs232_wrapper.cpp
* \brief This file contains the wrapper functions for RS232
*
* \author aravinth.rajalingam
* \date 21 November, 2022
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/
#include "dprs232_wrapper.h"

CDPRS232Wrapper::CDPRS232Wrapper()
{
    getAvailComports(m_qsAllComport);
    m_ucPortStatus = DPRS232_FAILURE;
    m_iErrCode = DPRS232_INIT_0;
    m_qstrErrMsg = QString();

    SET_RS232_LAST_ERROR(DPRS232_SUCCESS, QString());
}

short CDPRS232Wrapper::DPRS232Wrap_Open(SDPRS232_PORT_INFO in_SPortInfo)
{
	short sRetVal = DPRS232_SUCCESS;

	if (m_qsAllComport.length() <= DPRS232_INIT_0)
    {
        SET_RS232_LAST_ERROR(DPRS232ERR_COM_PORT_NOT_AVAILABLE, "No Comports available");
		return DPRS232_FAILURE;
	}

	sRetVal = DPRS232Wrap_Configure(in_SPortInfo);
    VALIDATE_RETVAL;

	sRetVal = openUARTPort();
    VALIDATE_RETVAL;

	if (m_objqserialportUART.isOpen ())
	{
        m_ucPortStatus = DPRS232_SUCCESS;
	}
    else
    {
        m_ucPortStatus = DPRS232_FAILURE;
    }

	return sRetVal;
}

short CDPRS232Wrapper::DPRS232Wrap_Configure(SDPRS232_PORT_INFO in_SPortInfo)
{
	short sRetVal = DPRS232_SUCCESS;

    setComportName(in_SPortInfo.m_qstrPortName);

    sRetVal = setBaudrate(in_SPortInfo.m_ulBaudRate);
	VALIDATE_RETVAL;

	sRetVal = setDataBit(in_SPortInfo.m_ucDataBits);
	VALIDATE_RETVAL;

	sRetVal = setParityBit(in_SPortInfo.m_ucParity);
	VALIDATE_RETVAL;

	sRetVal = setStopBit(in_SPortInfo.m_ucStopBits);
	VALIDATE_RETVAL;

	sRetVal = setFlowControl(in_SPortInfo.m_ucFlowcontrol);
	VALIDATE_RETVAL;

	return sRetVal;
}

short CDPRS232Wrapper::DPRS232Wrap_Close()
{
    if (getPortStatus() == DPRS232_SUCCESS)
	{
        m_objqserialportUART.close();
		return DPRS232_SUCCESS;
	}
	else
	{
        SET_RS232_LAST_ERROR(DPRS232ERR_COM_PORT_NOT_OPEN, m_objqserialportUART.portName() + " is Not Open");
		return DPRS232_FAILURE;
	}
}

short CDPRS232Wrapper::getAvailComports(QStringList &out_qslPortName)
{
	short sRetVal = DPRS232_SUCCESS;
    QList<QSerialPortInfo> qPorts = QSerialPortInfo::availablePorts();

	if(!qPorts.count())
	{
        SET_RS232_LAST_ERROR(DPRS232ERR_COM_PORT_NOT_AVAILABLE, "No Comports available");
		sRetVal = DPRS232_FAILURE;
	}

	for(int iIndex = DPRS232_INIT_0; iIndex < qPorts.count(); iIndex++)
	{
		QSerialPortInfo qTemp = qPorts.at(iIndex);
		out_qslPortName << qTemp.portName();
	}

	return sRetVal;
}

void CDPRS232Wrapper::setComportName(QString in_qsComName)
{
	if(m_objqserialportUART.isOpen())
	{
		m_objqserialportUART.close();
	}

    m_objqserialportUART.setPortName(in_qsComName);
}

short CDPRS232Wrapper::setBaudrate(unsigned long in_ulBaudRate)
{
	short sRetVal = DPRS232_SUCCESS;
    bool bSuccess = true;

	switch(in_ulBaudRate)
	{
		case QSerialPort::Baud1200:
		case QSerialPort::Baud2400:
		case QSerialPort::Baud4800:
		case QSerialPort::Baud9600:
		case QSerialPort::Baud19200:
		case QSerialPort::Baud38400:
		case QSerialPort::Baud57600:
		case QSerialPort::Baud115200:
		case Baud921600:
		{
            bSuccess = m_objqserialportUART.setBaudRate(in_ulBaudRate);    // Set Baudrate for any valid value
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_BAUDRATE;
			  SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_BAUDRATE, "Error Setting Baudrate");
		  }
			break;
		}
		default:
		{
            bSuccess = m_objqserialportUART.setBaudRate(QSerialPort::UnknownBaud);
            sRetVal = DPRS232ERR_INVALID_BAUDRATE;
            SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_BAUDRATE, "Invalid value for Baudrate");
		}
	}

	return sRetVal;
}

short CDPRS232Wrapper::setDataBit(unsigned char in_ucDataBits)
{
	short sRetVal = DPRS232_SUCCESS;
    bool bSuccess = true;

	switch(in_ucDataBits)
	{
		case QSerialPort::Data5:
		{
		  bSuccess = m_objqserialportUART.setDataBits(QSerialPort::Data5);
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_DATABITS;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_DATABITS, "Error setting Data Bits Value");
		  }
			break;
		}
		case QSerialPort::Data6 :
		{
		  bSuccess = m_objqserialportUART.setDataBits(QSerialPort::Data6);
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_DATABITS;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_DATABITS, "Error setting Data Bits Value");
		  }
			break;
		}
		case QSerialPort::Data7 :
		{
		  bSuccess = m_objqserialportUART.setDataBits(QSerialPort::Data7);
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_DATABITS;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_DATABITS, "Error setting Data Bits Value");
		  }
			break;
		}
		case QSerialPort::Data8 :
		{
		  bSuccess = m_objqserialportUART.setDataBits(QSerialPort::Data8);
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_DATABITS;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_DATABITS, "Error setting Data Bits Value");
		  }
			break;
		}
		default:
		{
            bSuccess = m_objqserialportUART.setDataBits(QSerialPort::UnknownDataBits);
			sRetVal = DPRS232ERR_INVALID_DATABITS;
            SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_DATABITS, "Invalid value for Data its given : " + QString::number(in_ucDataBits));
		}
	}

	return sRetVal;
}

short CDPRS232Wrapper::setParityBit(unsigned char in_ucParity)
{
	short sRetVal = DPRS232_SUCCESS;
    bool bSuccess = true;

	switch(in_ucParity)
	{
		case QSerialPort::NoParity:
		{
            bSuccess = m_objqserialportUART.setParity(QSerialPort::NoParity);
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_PARITY;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_PARITY, "Error setting Parity");
		  }
			break;
		}
		case QSerialPort::EvenParity :
		{
            bSuccess = m_objqserialportUART.setParity(QSerialPort::EvenParity);
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_PARITY;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_PARITY, "Error setting Parity");
		  }
			break;
		}
		case QSerialPort::OddParity :
		{
            bSuccess = m_objqserialportUART.setParity(QSerialPort::OddParity);
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_PARITY;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_PARITY, "Error setting Parity");
		  }
			break;
		}
		case QSerialPort::SpaceParity :
		{
            bSuccess = m_objqserialportUART.setParity(QSerialPort::SpaceParity);
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_PARITY;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_PARITY, "Error setting Parity");
		  }
			break;
		}
		case QSerialPort::MarkParity :
		{
            bSuccess = m_objqserialportUART.setParity(QSerialPort::MarkParity);
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_PARITY;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_PARITY, "Error setting Parity");
		  }
			break;
		}
		default:
		{
            bSuccess = m_objqserialportUART.setParity(QSerialPort::UnknownParity);
			sRetVal = DPRS232ERR_INVALID_PARITY;
            SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_PARITY, "Invalid value for Parity given : " + QString::number(in_ucParity));
		}
	}

	return sRetVal;
}

short CDPRS232Wrapper::setFlowControl(unsigned char in_ucFlowControl)
{
	short sRetVal = DPRS232_SUCCESS;
    bool bSuccess = true;

	switch (in_ucFlowControl)
	{
		case QSerialPort::NoFlowControl:
		{
            bSuccess = m_objqserialportUART.setFlowControl(QSerialPort::NoFlowControl);
		  if (!bSuccess)
		  {
			  sRetVal =  DPRS232ERR_INVALID_FLOW_CONTROL;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_FLOW_CONTROL, "Error setting Flow Control");
		  }
			break;
		}
		case QSerialPort::HardwareControl :
		{
            bSuccess = m_objqserialportUART.setFlowControl(QSerialPort::HardwareControl);
		  if (!bSuccess)
		  {
			  sRetVal =  DPRS232ERR_INVALID_FLOW_CONTROL;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_FLOW_CONTROL, "Error setting Flow Control");
		  }
			break;
		}
		case QSerialPort::SoftwareControl :
		{
            bSuccess = m_objqserialportUART.setFlowControl(QSerialPort::SoftwareControl);
		  if (!bSuccess)
		  {
			  sRetVal =  DPRS232ERR_INVALID_FLOW_CONTROL;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_FLOW_CONTROL, "Error setting Flow Control");
		  }
			break;
		}

		default:
		{
            bSuccess = m_objqserialportUART.setFlowControl(QSerialPort::UnknownFlowControl);
			sRetVal =  DPRS232ERR_INVALID_FLOW_CONTROL;
            SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_FLOW_CONTROL, "Invalid value for Flow Control given : " + QString::number(in_ucFlowControl));
		}
	}

	return sRetVal;
}

short CDPRS232Wrapper::setStopBit(unsigned char in_ucStopBit)
{
	short sRetVal = DPRS232_SUCCESS;
    bool bSuccess = true;

	switch (in_ucStopBit)
	{
		case QSerialPort::OneStop:
		{
            bSuccess = m_objqserialportUART.setStopBits(QSerialPort::OneStop);
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_STOP_BIT;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_STOP_BIT, "Invalid Stop Bit value given : " + QString::number(in_ucStopBit));
		  }
			break;
		}
		case QSerialPort::TwoStop:
		{
            bSuccess = m_objqserialportUART.setStopBits(QSerialPort::TwoStop);
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_STOP_BIT;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_STOP_BIT, "Invalid Stop Bit value given : " + QString::number(in_ucStopBit));
		  }
			break;
		}
		case QSerialPort::OneAndHalfStop:
		{
            bSuccess = m_objqserialportUART.setStopBits(QSerialPort::OneAndHalfStop);
		  if (!bSuccess)
		  {
			  sRetVal = DPRS232ERR_INVALID_STOP_BIT;
		    SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_STOP_BIT, "Invalid Stop Bit value given : " + QString::number(in_ucStopBit));
		  }
			break;
		}
		default:
		{
            bSuccess = m_objqserialportUART.setStopBits(QSerialPort::UnknownStopBits);
			sRetVal = DPRS232ERR_INVALID_STOP_BIT;
            SET_RS232_LAST_ERROR(DPRS232ERR_INVALID_STOP_BIT, "Invalid Stop Bit value given : " + QString::number(in_ucStopBit));
		}
	}

	return sRetVal;
}

short CDPRS232Wrapper::getPortStatus()
{
	short sRetVal = DPRS232_SUCCESS;

    if(m_objqserialportUART.isOpen())
    {
        sRetVal = DPRS232_SUCCESS;
	}
    else
    {
        sRetVal = DPRS232_FAILURE;
    }

	return sRetVal;
}

short CDPRS232Wrapper::openUARTPort()
{
    short sRetVal = DPRS232_SUCCESS;

    if(!m_objqserialportUART.open(QIODevice::ReadWrite))
    {
        sRetVal = DPRS232ERR_COM_PORT_NOT_OPEN;
        SET_RS232_LAST_ERROR(m_objqserialportUART.error(), m_objqserialportUART.errorString());
	}

	return sRetVal;
}

void CDPRS232Wrapper::closeUARTPort()
{
    m_objqserialportUART.close();
}

short CDPRS232Wrapper::DPRS232Wrap_WriteData(char *in_pcBuffData, long long in_lliDataLen)
{
	short sRetVal = DPRS232_SUCCESS;
    long long int lliDataWritten = DPRS232_INIT_0;

	if (m_objqserialportUART.isOpen())
	{
        DPRS232Wrap_ClearAll();

        lliDataWritten = m_objqserialportUART.write(in_pcBuffData, in_lliDataLen);

        m_objqserialportUART.flush();

        QThread::msleep(1);

//        if (!m_objqserialportUART.waitForBytesWritten(WRITE_WAIT_DELAY))
//        {
//            sRetVal = DPRS232ERR_DATA_WR_FAILED;
//            return sRetVal;
//        }
//        m_objqserialportUART.waitForBytesWritten(WRITE_WAIT_DELAY);

        if(lliDataWritten != in_lliDataLen)
		{
			sRetVal = DPRS232ERR_DATA_WR_FAILED;
            if (lliDataWritten == DPRS232_INIT_0)
            {
                SET_RS232_LAST_ERROR(m_objqserialportUART.error(), "Cannot write data into the " + QSTR_PORT_NAME);
            }
            else
            {
                SET_RS232_LAST_ERROR(m_objqserialportUART.error(), "Data cannot be written into " + QSTR_PORT_NAME +\
                                     " correctly");
            }
		}
	}
	else
	{
        sRetVal = DPRS232ERR_COM_PORT_NOT_OPEN;
        SET_RS232_LAST_ERROR(DPRS232ERR_COM_PORT_NOT_OPEN, QSTR_PORT_NAME + " is Not Open");
	}

	return sRetVal;
}

int CDPRS232Wrapper::WaitForData(unsigned char* ucData, unsigned short usExpectedSize)
{
    unsigned short usLoop = 0;
    unsigned short usIndex = 0;
    unsigned short usSizeToRead = 0;

    m_objqserialportUART.clearError();

    while(usExpectedSize > usIndex)
    {
        m_objqserialportUART.waitForReadyRead(1);
        usSizeToRead = m_objqserialportUART.bytesAvailable();

        for(usLoop = 0; usLoop < usSizeToRead; usLoop++)
        {
            m_objqserialportUART.read((char*)&ucData[usIndex], 1);
            usIndex++;
        }
    }

    return 0;
}

short CDPRS232Wrapper::DPRS232Wrap_ReadData(char *out_pcRxBuffer)
{
#if 0
	short sRetVal = DPRS232_SUCCESS;
    unsigned int uiTimer = 100;
    long long int lliTotalBytes = DPRS232_INIT_0;
    unsigned int uiAvailBytes = DPRS232_INIT_0;

	m_objqserialportUART.clearError();

	if (m_objqserialportUART.isOpen())
	{
        do {
            m_objqserialportUART.waitForReadyRead(READ_READY_DELAY);
            uiAvailBytes = m_objqserialportUART.bytesAvailable();
            if (uiAvailBytes >= 1)
            {
                break;
            }
            QThread::usleep(100);
        } while(uiTimer--);

        if (uiAvailBytes < 1)
        {
            return DPRS232_FAILURE;
        }

		while(uiTimer--)
		{

            lliTotalBytes = m_objqserialportUART.read(out_pcRxBuffer, 1);

            if(lliTotalBytes <= DPRS232_INIT_0)
			{
				*out_pcRxBuffer = DPRS232_INIT_0;
				sRetVal = DPRS232ERR_DATA_RD_FAILED;
                if (lliTotalBytes == DPRS232_INIT_0)
                {
                    SET_RS232_LAST_ERROR(m_objqserialportUART.error(), "NoData to Read from " + QSTR_PORT_NAME);
                }
                else
                {
                    SET_RS232_LAST_ERROR(m_objqserialportUART.error(), "Error reading data from " + QSTR_PORT_NAME + " : " + QSTR_PORT_ERROR);
                }
			}
			else
			{
				sRetVal = DPRS232_SUCCESS;
				break;
			}
		}
	}
	else
	{
        sRetVal = DPRS232ERR_COM_PORT_NOT_OPEN;
	}

	return sRetVal;
#else
    int iRetVal = 0;
    unsigned int uiTimer = 1;
    long long int lliTotalBytes = 0;
    unsigned short usSizeToRead = 0;

    m_objqserialportUART.clearError();

    if (!m_objqserialportUART.isOpen())
    {
        QThread::msleep(100);
    }

    while(uiTimer--)
    {
        m_objqserialportUART.waitForReadyRead(1);

        usSizeToRead = m_objqserialportUART.bytesAvailable();
        if(usSizeToRead > 0)
        {
            lliTotalBytes = m_objqserialportUART.read((char*)out_pcRxBuffer, 1);
        }
        else
        {
            iRetVal = -1;
        }

        if(lliTotalBytes < 1)
        {
            *out_pcRxBuffer = 0;
            iRetVal = -1;
        }
        else
        {
            iRetVal = 0;
            break;
        }
    }

    return iRetVal;
#endif
}

short CDPRS232Wrapper::DPRS232Wrap_ReadData(unsigned int in_uiTotalBytesToRead, char *out_pcRxBuffer, unsigned int *out_puiBytesRead, unsigned int in_uiMilliSecTOut)
{
	short sRetVal = DPRS232_SUCCESS;
    long long int lliTotalBytes = DPRS232_INIT_0;

	if (m_objqserialportUART.isOpen())
    {
        m_objqserialportUART.waitForReadyRead(in_uiMilliSecTOut);
        lliTotalBytes = m_objqserialportUART.read(out_pcRxBuffer, in_uiTotalBytesToRead);

        if(lliTotalBytes <= DPRS232_INIT_0)
		{
            *out_pcRxBuffer = DPRS232_INIT_0;
			*out_puiBytesRead = DPRS232_INIT_0;
            sRetVal = DPRS232ERR_DATA_RD_FAILED;
            if (lliTotalBytes == DPRS232_INIT_0)
            {
                SET_RS232_LAST_ERROR(m_objqserialportUART.error(), "No Data to Read from " + QSTR_PORT_NAME);
            }
            else
            {
                SET_RS232_LAST_ERROR(m_objqserialportUART.error(), "Error reading data from " + QSTR_PORT_NAME + " : " + QSTR_PORT_ERROR);
            }
		}
        else
		{
            *out_puiBytesRead = (unsigned int) lliTotalBytes;
			sRetVal = DPRS232_SUCCESS;
		}
	}
	else
	{
        sRetVal = DPRS232ERR_COM_PORT_NOT_OPEN;
	}

    return sRetVal;
}

short CDPRS232Wrapper::DPRS232Wrap_ReadAll(char *out_pcRxBuffer)
{
    short sRetVal = DPRS232_SUCCESS;
    unsigned int uiTimer = READ_DATA_COUNTDOWN;
    QString qstrTemp = QString();

    m_objqserialportUART.clearError();

    if (m_objqserialportUART.isOpen())
    {
        while(uiTimer--)
        {
            m_objqserialportUART.waitForReadyRead(READ_READY_DELAY);

            qstrTemp = QString::fromLatin1(m_objqserialportUART.readAll());

            if(qstrTemp.isEmpty())
            {
                *out_pcRxBuffer = DPRS232_INIT_0;
                sRetVal = DPRS232ERR_DATA_RD_FAILED;
                SET_RS232_LAST_ERROR(m_objqserialportUART.error(), "No data available to read from " + QSTR_PORT_NAME);
            }
            else
            {
                sprintf(out_pcRxBuffer, qstrTemp.toStdString().c_str());
                sRetVal = DPRS232_SUCCESS;
                break;
            }
        }
    }
    else
    {
        sRetVal = DPRS232ERR_COM_PORT_NOT_OPEN;
    }

    return sRetVal;
}

short CDPRS232Wrapper::DPRS232Wrap_GetLastError(int *out_iErrCode, QString &out_qstrErrMsg)
{
    if (out_iErrCode != NULL)
    {
        *out_iErrCode = m_iErrCode;
//        return DPRS232_FAILURE;
    }

//    if (out_qstrErrMsg != NULL)
//    {
    out_qstrErrMsg = m_qstrErrMsg;
//    }

	return DPRS232_SUCCESS;
}


short CDPRS232Wrapper::DPRS232Wrap_ClearUARTInputs()
{
	short sRetVal = DPRS232_SUCCESS;
	bool bResult = false;

	bResult = m_objqserialportUART.clear(QSerialPort::Input);

	if(bResult == false)
	{
		sRetVal = DPRS232ERR_IP_BUFF_CLEAR_FAILED;
	}

	return sRetVal;
}
short CDPRS232Wrapper::DPRS232Wrap_ClearUARTOutputs()
{
	short sRetVal = DPRS232_SUCCESS;
	bool bResult = 0;

	bResult = m_objqserialportUART.clear(QSerialPort::Output);

	if(bResult == false)
	{
		sRetVal = DPRS232ERR_OP_BUFF_CLEAR_FAILED;
	}

	return sRetVal;
}
short CDPRS232Wrapper::DPRS232Wrap_ClearAll()
{
	int iRetVal = DPRS232_SUCCESS;
	bool bResult = 0;

	bResult = m_objqserialportUART.clear(QSerialPort::AllDirections);

	if(bResult == false)
	{
		iRetVal = DPRS232ERR_IP_OP_BUFF_CLEAR_FAILED;
	}

	return iRetVal;
}
