/**
* \file dp-scm-processing_thread.cpp
* \brief This file contains the code for data processing thread
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-processing_thread.h"

extern S_GLOBAL g_SGlobal;
//extern CDPPCI755Wrapper g_objPCI755;

/*******************************************************************************
 * Name					: CDataProcessing
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CDataProcessing class
 *
 * @param[in]	parent	Holds the reference to the parent
 * @param[in]	in_iTimeout	Holds the timeout value for receive wait in millisec
 *				if timeout > 0, wait for specified milliseconds
 *				if timeout = 0, wait infinitely
 *
 * @return	NA
 ******************************************************************************/
CDataProcessing::CDataProcessing(QWidget *parent, int in_iTimeout) : QThread(parent)
{
    m_bDataProcessRunning = false;
    m_bIsDebugDataRunning = false;
    m_bIsDemandPortRunning = false;
    m_iTimeout = in_iTimeout;

    qRegisterMetaType<U_CMDRESP_DATA>("U_CMDRESP_DATA");

    memset(&m_UCmdRespData_Dem, 0, sizeof(U_CMDRESP_DATA));
    memset(&m_UCmdRespData_Diag, 0, sizeof(U_CMDRESP_DATA));
    memset(&m_UTxData, 0, sizeof(U_DEM_PORT_TX));
    memset(&m_URxData, 0, sizeof(U_DEM_PORT_RX));
}

void CDataProcessing::extractDemPortData()
{
    short sTemp = DPSCM_INIT_0;
    double dTemp = 0.0;
    double dTemp2 = 0.0;
    memset (&m_UCmdRespData_Dem, 0, sizeof(U_CMDRESP_DATA));

    /// Command
    m_UCmdRespData_Dem.m_UCmdData.m_SCmd_RGA.m_ucStoreParam = m_UTxData.m_S_RGACmd.m_ucByte1_StrParameters;
    m_UCmdRespData_Dem.m_UCmdData.m_SCmd_RGA.m_ucAzMode = m_UTxData.m_S_RGACmd.m_ucByte2_AzModeSel;
    m_UCmdRespData_Dem.m_UCmdData.m_SCmd_RGA.m_ucArrayIdent = m_UTxData.m_S_RGACmd.m_ucByte3_ArrayIdent;
    m_UCmdRespData_Dem.m_UCmdData.m_SCmd_RGA.m_ucCCW_LowerEndStop = m_UTxData.m_S_RGACmd.m_ucByte3_CCW_LowEndStop;
    m_UCmdRespData_Dem.m_UCmdData.m_SCmd_RGA.m_ucCW_UpperEndStop = m_UTxData.m_S_RGACmd.m_ucByte3_CW_UpEndStop;
    m_UCmdRespData_Dem.m_UCmdData.m_SCmd_RGA.m_ucDiagnosticsID = m_UTxData.m_S_RGACmd.m_ucByte5_DiagnosticsID;
    m_UCmdRespData_Dem.m_UCmdData.m_SCmd_RGA.m_ucFarEndCSError = m_UTxData.m_S_RGACmd.m_ucByte6_FarEndCSErr;
    sTemp = (m_UTxData.m_S_RGACmd.m_ucByte2_AzCmd_12_7 & 0x3F) << 7;
    sTemp |= ((m_UTxData.m_S_RGACmd.m_ucByte4_AzCmd_6_0 & 0x7F) << 0);
    if ((sTemp >> 12) == 1)
    {
        sTemp = sTemp | 0xF000;
    }
    if (m_UCmdRespData_Dem.m_UCmdData.m_SCmd_RGA.m_ucAzMode == DP_SCM_RATE_MODE)   // Rate Mode
    {
        dTemp = (sTemp * BIT_RESOLUTION_RATE) / BIT_RESOLUTION_13BIT;
    }
    else    // Position Mode
    {
        dTemp = (sTemp * BIT_RESOLUTION_AZ_POS) / BIT_RESOLUTION_13BIT;
    }

    m_UCmdRespData_Dem.m_UCmdData.m_SCmd_RGA.m_dAzRatePos = dTemp;

    /// Response
    m_UCmdRespData_Dem.m_URespData.m_SResp_RGA.m_ucAzIndependentSensorPos = m_URxData.m_S_RGAResp.m_ucByte3_AzIndSenPosition;
    m_UCmdRespData_Dem.m_URespData.m_SResp_RGA.m_ucBITFault = m_URxData.m_S_RGAResp.m_ucByte3_BIT_Fault;
    m_UCmdRespData_Dem.m_URespData.m_SResp_RGA.m_ucDiagData = m_URxData.m_S_RGAResp.m_ucByte4_BIT_DataVal;
    m_UCmdRespData_Dem.m_URespData.m_SResp_RGA.m_ucDiagId = m_URxData.m_S_RGAResp.m_ucByte5_DiagnosticsID;

    sTemp = (m_URxData.m_S_RGAResp.m_ucByte1_AzPosition_15_9 & 0x7F) << 9;
    sTemp |= ((m_URxData.m_S_RGAResp.m_ucByte2_AzPosition_8_2 & 0x7F) << 2);
    sTemp |= ((m_URxData.m_S_RGAResp.m_ucByte3_AzPosition_1_0 & 0x03) << 0);
    dTemp2 = (sTemp * BIT_RESOLUTION_AZ_POS) / BIT_RESOLUTION_16BIT;
    m_UCmdRespData_Dem.m_URespData.m_SResp_RGA.m_dAzPosition = dTemp2;

    emit sig_drawGraph(dTemp, dTemp2, 0);
}

void CDataProcessing::extractDiagPortData()
{
    short sTemp = DPSCM_INIT_0;
    unsigned int uiTemp = DPSCM_INIT_0;
    m_UCmdRespData_Diag = { 0 };

    // Command
    m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_ucTestInit = m_UTxData.m_S_DiagCmd.m_ucByte1_TestInit;
    m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_ucCommandId = m_UTxData.m_S_DiagCmd.m_ucByte1_CmdID;
    if (m_UTxData.m_S_DiagCmd.m_ucByte1_CmdID == CMDID_DIAGMON_READ)
    {
        m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_ucDiagID = m_UTxData.m_S_DiagCmd.m_ucByte2_Bit6_0;
    }
    else
    {
        m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_ucDiagID = DPSCM_INIT_0;
    }

    if ((m_UTxData.m_S_DiagCmd.m_ucByte1_CmdID == CMDID_CLCCONFIG_READ) || (m_UTxData.m_S_DiagCmd.m_ucByte1_CmdID == CMDID_CLCCONFIG_UPDATE))
    {
        m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_ucConstantId = m_UTxData.m_S_DiagCmd.m_ucByte2_Bit6_0 & 0x7F;
    }
    else
    {
        m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_ucConstantId = DPSCM_INIT_0;
    }

    if (m_UTxData.m_S_DiagCmd.m_ucByte1_CmdID == CMDID_CLCCONFIG_UPDATE)
    {
        uiTemp = (m_UTxData.m_S_DiagCmd.m_ucByte3_Bit6_0 & 0x7F) << 21;
        uiTemp |= ((m_UTxData.m_S_DiagCmd.m_ucByte4_Bit6_0 & 0x7F) << 14);
        uiTemp |= ((m_UTxData.m_S_DiagCmd.m_ucByte5_Bit6_0 & 0x7F) << 7);
        uiTemp |= ((m_UTxData.m_S_DiagCmd.m_ucByte6_Bit6_0 & 0x7F));

        switch (m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_ucConstantId)
        {
        case CLC_INVERSION_WORD:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_CONFIG_ST;
        } break;
        case CLC_ENABLE_ENDSTOP:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_EN_ENDSTOP;
        } break;
        case CLC_ENABLE_NOISE_FILTER:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_EN_NLP;
        } break;
        case CLC_ENABLE_RATE_FEED_FRWRD:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_EN_RFF;
        } break;
        case CLC_ENABLE_LAG_CONTROLLER:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_EN_LAG;
        } break;
        case CLC_MINIMUM_ENDSTOP:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_THETA_MIN_PREC;
        } break;
        case CLC_MAXIMUM_ENDSTOP:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_THETA_MAX_PREC;
        } break;
        case CLC_RATE_LIMIT:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_LIM_R_PREC;
        } break;
        case CLC_ACC_LIMIT:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_LIM_A_PREC;
        } break;
        case CLC_CUR_LIMIT:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_LIM_I_PREC;
        } break;
        case CLC_RATE_DEAD_ZONE:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_RATE_DZ_PREC;
        } break;
        case CLC_NOISEFILTER_CUTOFF_RATEMODE:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_OMG_NLP_PREC;
        } break;
        case CLC_DAMPING_FACTOR:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_ZETA_NLP_PREC;
        } break;
        case CLC_PREFILTER_DISCOUNT:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_ALPHA_PREC;
        } break;
        case CLC_PREFILTER_LINEARZONE:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_DELTA_PREC;
        } break;
        case CLC_RATE_FEEDFRWRD_BW:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_OMG_RFF_PREC;
        } break;
        case CLC_TOTAL_GEAR_RATIO:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_N_PREC;
        } break;
        case CLC_PROP_GAIN_LOADED:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_KPL_PREC;
        } break;
        case CLC_DERV_GAIN_LOADED:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_KDL_PREC;
        } break;
        case CLC_PROP_GAIN_UNLOADED:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_KPM_PREC;
        } break;
        case CLC_DERV_GAIN_UNLOADED:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_KDM_PREC;
        } break;
        case CLC_NORM_GAIN_LOADED:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_WL_PREC;
        } break;
        case CLC_NORM_GAIN_UNLOADED:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_WM_PREC;
        } break;
        case CLC_LAGFILTER_LAG_BREAKPOINT:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_OMG_1_PREC;
        } break;
        case CLC_LAGFILTER_LEAD_BREAKPOINT:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_OMG_2_PREC;
        } break;
        case CLC_LOWPASS_FILTER_BW:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_OMG_LP_PREC;
        } break;
        case CLC_CURRLOOP_P_GAIN:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_CURR_P_GAIN_PREC;
        } break;
        case CLC_CURRLOOP_I_GAIN:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = uiTemp / DP_SCM_CURR_I_GAIN_PREC;
        } break;
        default:
        {
            m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = 0.0;
        } break;
        }
    }
    else
    {
        m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dConstValue = 0.0;
    }

    sTemp = (m_UTxData.m_S_DiagCmd.m_ucByte2_Bit6_0 & 0x7F) << 7;
    sTemp |= ((m_UTxData.m_S_DiagCmd.m_ucByte3_Bit6_0 & 0x7F));
    if (m_UTxData.m_S_DiagCmd.m_ucByte1_CmdID == CMDID_DIAGDEM_POS)
    {
        m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dPosRateData = (sTemp * 180.0) / 8192.0;
    }
    else if (m_UTxData.m_S_DiagCmd.m_ucByte1_CmdID == CMDID_DIAGDEM_RATE)
    {
        m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dPosRateData = (sTemp * 200.0) / 8192.0;
    }
    else
    {
        m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dPosRateData = 0.0;
    }

    // Response
    m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucCommandID = m_URxData.m_S_DiagResp.m_ucByte1_CmdID;
    if (m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucCommandID == CMDID_DIAGMON_READ)
    {
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucDiagId = m_URxData.m_S_DiagResp.m_ucByte2_Bit6_0;
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucDiagData = m_URxData.m_S_DiagResp.m_ucByte3_Bit6_0;
    }
    else
    {
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucDiagId = DPSCM_INIT_0;
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucDiagData = DPSCM_INIT_0;
    }

    if ((m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucCommandID == CMDID_CLCCONFIG_UPDATE)\
            || (m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucCommandID == CMDID_CLCCONFIG_READ))
    {
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucConstantID = m_URxData.m_S_DiagResp.m_ucByte2_Bit6_0;
    }
    else
    {
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucConstantID = DPSCM_INIT_0;
    }

    if (m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucCommandID == CMDID_CLCCONFIG_READ)
    {
        uiTemp = (m_URxData.m_S_DiagResp.m_ucByte3_Bit6_0 & 0x7F) << 21;
        uiTemp |= ((m_URxData.m_S_DiagResp.m_ucByte4_Bit6_0 & 0x7F) << 14);
        uiTemp |= ((m_URxData.m_S_DiagResp.m_ucByte5_Bit6_0 & 0x7F) << 7);
        uiTemp |= ((m_URxData.m_S_DiagResp.m_ucByte6_Bit6_0 & 0x7F));

        switch (m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucConstantID)
        {
        case CLC_INVERSION_WORD:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_CONFIG_ST;
        } break;
        case CLC_ENABLE_ENDSTOP:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_EN_ENDSTOP;
        } break;
        case CLC_ENABLE_NOISE_FILTER:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_EN_NLP;
        } break;
        case CLC_ENABLE_RATE_FEED_FRWRD:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_EN_RFF;
        } break;
        case CLC_ENABLE_LAG_CONTROLLER:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_EN_LAG;
        } break;
        case CLC_MINIMUM_ENDSTOP:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_THETA_MIN_PREC;
        } break;
        case CLC_MAXIMUM_ENDSTOP:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_THETA_MAX_PREC;
        } break;
        case CLC_RATE_LIMIT:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_LIM_R_PREC;
        } break;
        case CLC_ACC_LIMIT:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_LIM_A_PREC;
        } break;
        case CLC_CUR_LIMIT:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_LIM_I_PREC;
        } break;
        case CLC_RATE_DEAD_ZONE:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_RATE_DZ_PREC;
        } break;
        case CLC_NOISEFILTER_CUTOFF_RATEMODE:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_OMG_NLP_PREC;
        } break;
        case CLC_DAMPING_FACTOR:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_ZETA_NLP_PREC;
        } break;
        case CLC_PREFILTER_DISCOUNT:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_ALPHA_PREC;
        } break;
        case CLC_PREFILTER_LINEARZONE:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_DELTA_PREC;
        } break;
        case CLC_RATE_FEEDFRWRD_BW:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_OMG_RFF_PREC;
        } break;
        case CLC_TOTAL_GEAR_RATIO:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_N_PREC;
        } break;
        case CLC_PROP_GAIN_LOADED:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_KPL_PREC;
        } break;
        case CLC_DERV_GAIN_LOADED:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_KDL_PREC;
        } break;
        case CLC_PROP_GAIN_UNLOADED:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_KPM_PREC;
        } break;
        case CLC_DERV_GAIN_UNLOADED:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_KDM_PREC;
        } break;
        case CLC_NORM_GAIN_LOADED:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_WL_PREC;
        } break;
        case CLC_NORM_GAIN_UNLOADED:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_WM_PREC;
        } break;
        case CLC_LAGFILTER_LAG_BREAKPOINT:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_OMG_1_PREC;
        } break;
        case CLC_LAGFILTER_LEAD_BREAKPOINT:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_OMG_2_PREC;
        } break;
        case CLC_LOWPASS_FILTER_BW:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_OMG_LP_PREC;
        } break;
        case CLC_CURRLOOP_P_GAIN:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_CURR_P_GAIN_PREC;
        } break;
        case CLC_CURRLOOP_I_GAIN:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = uiTemp / DP_SCM_CURR_I_GAIN_PREC;
        } break;
        default:
        {
            m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = 0.0;
        } break;
        }
    }
    else
    {
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dCLC_Const_Data = 0.0;
    }

    if ((m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucCommandID == CMDID_DIAGDEM_POS)\
            || (m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucCommandID == CMDID_DIAGDEM_RATE))
    {
        sTemp = DPSCM_INIT_0;
        sTemp = (m_URxData.m_S_DiagResp.m_ucByte2_Bit6_0 & 0x7F) << 7;
        sTemp |= ((m_URxData.m_S_DiagResp.m_ucByte3_Bit6_0 & 0x7F));
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dRateData = (sTemp * 200.0) / 8192.0;

        sTemp = DPSCM_INIT_0;
        sTemp = (m_URxData.m_S_DiagResp.m_ucByte4_Bit6_0 & 0x7F) << 7;
        sTemp |= ((m_URxData.m_S_DiagResp.m_ucByte5_Bit6_0 & 0x7F));
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dRateData = (sTemp * 180.0) / 8192.0;
    }
    else
    {
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dRateData = 0.0;
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dPositionData = 0.0;
    }

    if (m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_ucCommandID == CMDID_ZERO_POS_CALIB)
    {
        sTemp = DPSCM_INIT_0;
        sTemp = (m_URxData.m_S_DiagResp.m_ucByte2_Bit6_0 & 0x7F) << 7;
        sTemp |= ((m_URxData.m_S_DiagResp.m_ucByte3_Bit6_0 & 0x7F));
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dPositionData = (sTemp * 180.0) / 8192.0;
    }
    else
    {
        m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dPositionData = 0.0;
    }
}

void CDataProcessing::extractHDLCData()
{
    unsigned char ucFrameCounter = DPSCM_INIT_0;
    unsigned char ucBITEStatus = DPSCM_INIT_0;
    unsigned short usEncoderData = DPSCM_INIT_0;
    double dEncoderData = DPSCM_INIT_0;

    ucFrameCounter = (m_URxData.m_uiHDLCResponse >> 24) & 0xFF;
    ucBITEStatus = (m_URxData.m_uiHDLCResponse >> 16) & 0xFF;
    usEncoderData = m_URxData.m_uiHDLCResponse & 0xFFFF;
    dEncoderData = (usEncoderData * BIT_RESOLUTION_RATE) / BIT_RESOLUTION_16BIT;

    m_SHDLCData.m_ucFrameCounter = ucFrameCounter;
    m_SHDLCData.m_ucBITEStatus = ucBITEStatus;
    m_SHDLCData.m_dEncoderData = dEncoderData;
}

void CDataProcessing::extractDebugData()
{
    short sTemp = DPSCM_INIT_0;
    unsigned short usTemp = DPSCM_INIT_0;
    bool bIsRate = false;
    memset (&m_UCmdRespData_Diag, 0, sizeof(U_CMDRESP_DATA));

    if (m_SDebugData.m_ucByte1_CmdID == CMDID_CLOSELOOP_POS_TEST || m_SDebugData.m_ucByte1_CmdID == CMDID_DIAGDEM_POS)
    {
        bIsRate = false;
    }
    else
    {
        bIsRate = true;
    }

    sTemp = 0;
    sTemp = ((m_SDebugData.m_ucByte2_PL_Angle_13_7 & 0x7F) << 7);
    sTemp |= (m_SDebugData.m_ucByte3_PL_Angle_6_0 & 0x7F);
    if (sTemp >= BIT_RESOLUTION_14BIT)
    {
        sTemp |= 0xC000;
    }
    m_UCmdRespData_Diag.m_URespData.m_SResp_DebugData.m_dPayloadAngle = (sTemp * BIT_RESOLUTION_AZ_POS) / BIT_RESOLUTION_14BIT;

    sTemp = ((m_SDebugData.m_ucByte4_PL_Rate_13_7 & 0x7F) << 7);
    sTemp |= (m_SDebugData.m_ucByte5_PL_Rate_6_0 & 0x7F);
    if (sTemp >= BIT_RESOLUTION_14BIT)
    {
        sTemp |= 0xC000;
    }
    m_UCmdRespData_Diag.m_URespData.m_SResp_DebugData.m_dPayloadRate = (sTemp * BIT_RESOLUTION_RATE) / BIT_RESOLUTION_14BIT;

    sTemp = ((m_SDebugData.m_ucByte6_Mtr_Angle_13_7 & 0x7F) << 7);
    sTemp |= (m_SDebugData.m_ucByte7_Mtr_Angle_6_0 & 0x7F);
    if (sTemp >= BIT_RESOLUTION_14BIT)
    {
        sTemp |= 0xC000;
    }
    m_UCmdRespData_Diag.m_URespData.m_SResp_DebugData.m_dMotorAngle = (sTemp * BIT_RESOLUTION_AZ_POS) / BIT_RESOLUTION_14BIT;

    sTemp = ((m_SDebugData.m_ucByte8_Mtr_Cur_13_7 & 0x7F) << 7);
    sTemp |= (m_SDebugData.m_ucByte9_Mtr_Cur_6_0 & 0x7F);
    if (sTemp >= BIT_RESOLUTION_14BIT)
    {
        sTemp |= 0xC000;
    }
    m_UCmdRespData_Diag.m_URespData.m_SResp_DebugData.m_dMotorCurrent = ((sTemp * BIT_RESOLUTION_MAX_CUR) / BIT_RESOLUTION_14BIT);

    sTemp = ((m_SDebugData.m_ucByte10_Gimbal_Demad_13_7  & 0x7F) << 7) ;
    sTemp |= (m_SDebugData.m_ucByte11_Gimbal_Demad_6_0 & 0x7F);
    if (sTemp >= BIT_RESOLUTION_14BIT)
    {
        sTemp |= 0xC000;
    }
    if (bIsRate)
    {
        m_UCmdRespData_Diag.m_URespData.m_SResp_DebugData.m_dGimbalDemand = (sTemp * BIT_RESOLUTION_RATE) / BIT_RESOLUTION_14BIT;
    }
    else
    {
        m_UCmdRespData_Diag.m_URespData.m_SResp_DebugData.m_dGimbalDemand = (sTemp * BIT_RESOLUTION_AZ_POS) / BIT_RESOLUTION_14BIT;
    }
    sTemp = ((m_SDebugData.m_ucByte12_CTRL_Demand_13_7 & 0x7F) << 7);
    sTemp |= (m_SDebugData.m_ucByte13_CTRL_Demand_6_0 & 0x7F);
    if (sTemp >= BIT_RESOLUTION_14BIT)
    {
        sTemp |= 0xC000;
    }
    m_UCmdRespData_Diag.m_URespData.m_SResp_DebugData.m_dMotorCtrlDemand = ((sTemp * BIT_RESOLUTION_MAX_CUR) / BIT_RESOLUTION_14BIT);

    sTemp = ((m_SDebugData.m_ucByte14_Rate_Demand_13_7 & 0x7F) << 7);
    sTemp |= (m_SDebugData.m_ucByte15_Rate_Demand_6_0 & 0x7F);
    if (sTemp >= BIT_RESOLUTION_14BIT)
    {
        sTemp |= 0xC000;
    }
    m_UCmdRespData_Diag.m_URespData.m_SResp_DebugData.m_dRateDemand = (sTemp * BIT_RESOLUTION_RATE) / BIT_RESOLUTION_14BIT;

    sTemp = ((m_SDebugData.m_ucByte16_Pos_Demand_13_7 & 0x7F) << 7);
    sTemp |= (m_SDebugData.m_ucByte17_Pos_Demand_6_0 & 0x7F);
    if (sTemp >= BIT_RESOLUTION_14BIT)
    {
        sTemp |= 0xC000;
    }
    m_UCmdRespData_Diag.m_URespData.m_SResp_DebugData.m_dPositionDemand = (sTemp * BIT_RESOLUTION_AZ_POS) / BIT_RESOLUTION_14BIT;

    usTemp = ((m_SDebugData.m_ucTimerCount_MSB_13_7 & 0x7F) << 7);
    usTemp |= (m_SDebugData.m_ucTimerCount_LSB_6_0 & 0x7F);
    m_UCmdRespData_Diag.m_URespData.m_SResp_DebugData.m_usTimeCount = usTemp;
}

/*******************************************************************************
 * Name					: Start
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To start thread
 ***************************************************************************//**
 * @brief	This function is used to start the Data processing thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CDataProcessing::Start()
{
    if(!isRunning())
    {
        m_bDataProcessRunning = true;
        this->start(QThread::HighestPriority);
    }
    else
    {
        // Do nothing
    }
}

/*******************************************************************************
 * Name					: Stop
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To stop the thread
 ***************************************************************************//**
 * @brief	This function is used to terminate the Data processing thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CDataProcessing::Stop()
{
    if(isRunning())
    {
        m_bDataProcessRunning = false;
        m_bIsDebugDataRunning = false;
        m_bIsDemandPortRunning = false;
        m_bIsHDLCRunning = false;

        msleep(100);

        if(!isFinished())
        {
            this->terminate();
        }
        else
        {
            // Do nothing
        }
    }
    else
    {
        // Do nothing
    }
}

/*******************************************************************************
 * Name					: setTimeout
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set the timeout value
 ***************************************************************************//**
 * @brief	This function is used to reset the value of timeout
 *
 * @param[in]	in_iTimeout	Specifies the new timeeout value
 *
 * @return	NIL
 ******************************************************************************/
void CDataProcessing::setTimeout(int in_iTimeout)
{
    if (in_iTimeout < 0)
    {
        return;
    }
    else
    {
        // Do nothing
    }

    m_iTimeout = in_iTimeout;
}

/*******************************************************************************
 * Name					: run
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To execute the thread
 ***************************************************************************//**
 * @brief	This function contains the repeated execution of thread
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CDataProcessing::run()
{
    short sRetval = DPSCM_SUCCESS;

    g_SGlobal.m_qDemPortLogMsgQ->Clear();
    g_SGlobal.m_qDiagPortLogMsgQ->Clear();
    g_SGlobal.m_qDebugDataLogMsgQ->Clear();
    g_SGlobal.m_qHDLCDataLogMsgQ->Clear();


    while (m_bDataProcessRunning)
    {
#if 1
        if (m_bIsDemandPortRunning)
        {
            sRetval = g_SGlobal.m_pobjResponseMsgQ->Receive(&m_URxData, sizeof(U_DEM_PORT_RX), 0);
            if (sRetval <= DPSCM_INIT_0)
            {
                continue;
            }

            sRetval = g_SGlobal.m_pobjCommandMsgQ->Receive(&m_UTxData, sizeof(U_DEM_PORT_TX), 0);
            if (sRetval <= DPSCM_INIT_0)
            {
                   continue;
            }

            if (sRetval == DPSCM_INIT_0)
            {
                continue;
            }

            extractDemPortData();
            g_SGlobal.m_qDemPortLogMsgQ->Send(&m_UCmdRespData_Dem, sizeof(U_CMDRESP_DATA));
        }

#endif

        if (m_bIsDiagPortRunning)
        {
            sRetval = g_SGlobal.m_pobjDiagRespMsgQ->Receive(&m_URxData, sizeof(U_DEM_PORT_RX), 0);
            if (sRetval <= DPSCM_INIT_0)
            {
                continue;
            }

            sRetval = g_SGlobal.m_objDiagCmdMsgQ->Receive(&m_UTxData, sizeof(U_DEM_PORT_TX), 0);
            if (sRetval <= DPSCM_INIT_0)
            {
                   continue;
            }

            extractDiagPortData();
            emit sig_drawGraph(m_UCmdRespData_Diag.m_UCmdData.m_SCmd_Diag.m_dPosRateData, m_UCmdRespData_Diag.m_URespData.m_SResp_Diag.m_dPositionData, 0);
            g_SGlobal.m_qDiagPortLogMsgQ->Send(&m_UCmdRespData_Diag, sizeof(U_CMDRESP_DATA));
        }

        if (m_bIsDebugDataRunning)
        {
            sRetval = g_SGlobal.m_objDebugDataMsgQ->Receive(&m_SDebugData, sizeof(S_DIAG_DATA_RESP), 0);
            if (sRetval <= DPSCM_INIT_0)
            {
                continue;
            }

            extractDebugData();
            emit sig_drawGraph(m_UCmdRespData_Diag.m_URespData.m_SResp_DebugData.m_dPayloadAngle, m_UCmdRespData_Diag.m_URespData.m_SResp_DebugData.m_dPayloadRate, 1);
            g_SGlobal.m_qDebugDataLogMsgQ->Send(&m_UCmdRespData_Diag, sizeof(U_CMDRESP_DATA));
        }

        if (!m_bIsHDLCRunning)
        {
            emit sig_updateBITStatus(g_SGlobal.m_SBITStatus.m_u8DiagID, g_SGlobal.m_SBITStatus.m_u8BITStatus);
        }

        if (m_bIsHDLCRunning)
        {
            sRetval = g_SGlobal.m_objHDLCDataMsgQ->Receive(&m_URxData.m_uiHDLCResponse, sizeof(unsigned int), 0);
            if (sRetval <= DPSCM_INIT_0)
            {
                continue;
            }

            extractHDLCData();
            g_SGlobal.m_qHDLCDataLogMsgQ->Send(&m_SHDLCData, sizeof(S_HDLC_Response_Data));
        }

//        msleep(1);    // wait for 1ms
        usleep(100);
    }
}
