/**
* \file dp-scm-cbitstatus.cpp
* \brief This file contains the code for CBIT Status panel
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-cbitstatus.h"
#include "ui_dp-scm-cbitstatus.h"

extern S_GLOBAL g_SGlobal;
//extern CDPPCI755Wrapper g_objPCI755;

/*******************************************************************************
 * Name					: CCBITStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CCBITStatus class
 *
 * @param[in]	parent	Holds the reference to the parent (QWidget*)
 * @return	NA
 ******************************************************************************/
CCBITStatus::CCBITStatus(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CCBITStatus)
{
    ui->setupUi(this);

    m_pthCBITThread = new CCBITStatusThread(this);

    slot_resetCBITStatus();
}

/*******************************************************************************
 * Name					: ~CCBITStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief	This function is the destructor of CCBITStatus class
 *
 * @param		NIL
 * @return	NA
 ******************************************************************************/
CCBITStatus::~CCBITStatus()
{
    delete ui;
}

/*******************************************************************************
 * Name					: resetLEDinGB
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To reset LEDs in groupbox
 ***************************************************************************//**
 * @brief	This function will reset all the LEDs within the groupbox
 *
 * @param[in]	in_gbGroupbox	Holds the reference to the groupbox to reset LEDs	(QGroupBox*)
 * @return	NIL
 ******************************************************************************/
void CCBITStatus::resetLEDinGB(QGroupBox *in_gbGroupbox)
{
    QLabel *pLabel = NULL;

    foreach(QObject *pObj, in_gbGroupbox->children())
    {
        if (pObj->objectName().startsWith("lbLED"))
        {
            pLabel = (QLabel *)pObj;
            pLabel->setPixmap(QPixmap(LED_GRAY));
        }
        if (pObj->objectName().startsWith("gb"))
        {
            resetLEDinGB((QGroupBox *)pObj);
        }
    }
}

void CCBITStatus::slot_EnDisAzimuth(bool in_bIsAzimuth)
{
#if 1
    /* Azimuth LEDs */
    ui->lbLED_Az_HighRateErr->setEnabled (in_bIsAzimuth);
    ui->lbLED_Az_PosErr->setEnabled (in_bIsAzimuth);
    ui->lbLED_Az_CCWLimit->setEnabled (in_bIsAzimuth);
    ui->lbLED_Az_CWLimit->setEnabled (in_bIsAzimuth);
    ui->lbLED_Az_Exceeds_I2T->setEnabled (in_bIsAzimuth);
    ui->lbLED_Az_TempFault->setEnabled (in_bIsAzimuth);

    /* Elevation LEDs */
    ui->lbLED_El_HighRateErr->setEnabled (!in_bIsAzimuth);
    ui->lbLED_El_PosErr->setEnabled (!in_bIsAzimuth);
    ui->lbLED_El_PositiveDem->setEnabled (!in_bIsAzimuth);
    ui->lbLED_El_NegativeDem->setEnabled (!in_bIsAzimuth);
    ui->lbLED_El_Exceeds_I2T->setEnabled (!in_bIsAzimuth);
    ui->lbLED_El_TempFault->setEnabled (!in_bIsAzimuth);

    /* Azimuth Group Boxes */
    ui->gbZettlexStatus_Az->setEnabled (in_bIsAzimuth);
    ui->gbInternal_AzFault->setEnabled (in_bIsAzimuth);

    /* Elevation Group Boxes */
    ui->gbZettlexStatus_El->setEnabled (!in_bIsAzimuth);
    ui->gbInternal_ElFault->setEnabled (!in_bIsAzimuth);

    /* Azimuth Labels */
    ui->lbDisp_Az_HighRateErr->setEnabled (in_bIsAzimuth);
    ui->lbDisp_Az_PosErr->setEnabled (in_bIsAzimuth);
    ui->lbDisp_Az_CCWLimit->setEnabled (in_bIsAzimuth);
    ui->lbDisp_Az_CWLimit->setEnabled (in_bIsAzimuth);
    ui->lbDisp_Az_Exceeds_I2T->setEnabled (in_bIsAzimuth);
    ui->lbDisp_Az_TempFault->setEnabled (in_bIsAzimuth);

    /* Elevation Labels */
    ui->lbDisp_El_HighRateErr->setEnabled (!in_bIsAzimuth);
    ui->lbDisp_El_PosErr->setEnabled (!in_bIsAzimuth);
    ui->lbDisp_El_PositiveDem->setEnabled (!in_bIsAzimuth);
    ui->lbDisp_El_NegativeDem->setEnabled (!in_bIsAzimuth);
    ui->lbDisp_El_Exceeds_I2T->setEnabled (!in_bIsAzimuth);
    ui->lbDisp_El_TempFault->setEnabled (!in_bIsAzimuth);
#endif
}

/*******************************************************************************
 * Name					: slot_updateCBITStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To update the CBIT status
 ***************************************************************************//**
 * @brief	This function will update the CBIT Status
 *		This function shall be called when MainWindow emits sig_updateCITStatus signal
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CCBITStatus::slot_updateCBITStatus(unsigned char in_ucDiagID, unsigned char in_ucBITStatus)
{
    U8BIT u8BITSts = in_ucBITStatus;

    switch (in_ucDiagID)
    {
    case ID_01:
    {
        emit sig_updateCBITBar((PSSCM_CBIT01STS) &u8BITSts);
    } break;
        /// ID_02 is for PBIT
    case ID_03:
    {
        if (m_pthCBITThread->m_iRetVal != DPSCM_SUCCESS)
        {
            ui->lbLED_Az_CCWLimit->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_Az_CWLimit->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_PositiveDem->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_NegativeDem->setPixmap(QPixmap(LED_GRAY));
            break;
        }

        if ((READ_LSB(u8BITSts >> 0) == DPSCM_SUCCESS))
        {
            ui->lbLED_Az_CCWLimit->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_CCWLimit->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 1) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_CWLimit->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_CWLimit->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 2) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_PositiveDem->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_PositiveDem->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 3) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_NegativeDem->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_NegativeDem->setPixmap(QPixmap(LED_RED));
        }
    } break;
    case ID_04:
    {
        if (m_pthCBITThread->m_iRetVal != DPSCM_SUCCESS)
        {
            ui->lbLED_Checksum->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_IncorrectFormat->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_PartialMessage->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_LossOfComm->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_Az_HighRateErr->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_HighRateErr->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_UnrecogArrayIdent->setPixmap(QPixmap(LED_GRAY));
            break;
        }

        if (READ_LSB(u8BITSts >> 0) == DPSCM_SUCCESS)
        {
            ui->lbLED_Checksum->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Checksum->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 1) == DPSCM_SUCCESS)
        {
            ui->lbLED_IncorrectFormat->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_IncorrectFormat->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 2) == DPSCM_SUCCESS)
        {
            ui->lbLED_PartialMessage->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_PartialMessage->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 3) == DPSCM_SUCCESS)
        {
            ui->lbLED_LossOfComm->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_LossOfComm->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 4) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_HighRateErr->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_HighRateErr->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 5) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_HighRateErr->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_HighRateErr->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 6) == DPSCM_SUCCESS)
        {
            ui->lbLED_UnrecogArrayIdent->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_UnrecogArrayIdent->setPixmap(QPixmap(LED_RED));
        }
    } break;
    case ID_05:
    {
        if (m_pthCBITThread->m_iRetVal != DPSCM_SUCCESS)
        {
            ui->lbLED_Az_PosErr->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_PosErr->setPixmap(QPixmap(LED_GRAY));
            break;
        }

        if (READ_LSB(u8BITSts >> 0) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_PosErr->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_PosErr->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 1) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_PosErr->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_PosErr->setPixmap(QPixmap(LED_RED));
        }
    } break;
    case ID_06:
    {
        if (m_pthCBITThread->m_iRetVal != DPSCM_SUCCESS)
        {
            ui->lbLED_Az_Exceeds_I2T->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_Exceeds_I2T->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_Az_TempFault->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_TempFault->setPixmap(QPixmap(LED_GRAY));
            break;
        }

        if (READ_LSB(u8BITSts >> 0) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_Exceeds_I2T->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_Exceeds_I2T->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 1) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_Exceeds_I2T->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_Exceeds_I2T->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 2) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_TempFault->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_TempFault->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 3) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_TempFault->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_TempFault->setPixmap(QPixmap(LED_RED));
        }
    } break;
    case ID_38:
    {
        if (m_pthCBITThread->m_iRetVal != DPSCM_SUCCESS)
        {
            ui->lbLED_El_InternalPSUFault->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_FloatSupplyFault->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_LatchedErr->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_OCErr->setPixmap(QPixmap(LED_GRAY));
            break;
        }

        if (READ_LSB(u8BITSts >> 0) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_InternalPSUFault->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_InternalPSUFault->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 1) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_FloatSupplyFault->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_FloatSupplyFault->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 2) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_LatchedErr->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_LatchedErr->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 3) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_OCErr->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_OCErr->setPixmap(QPixmap(LED_RED));
        }
    } break;
    case ID_39:
    {
        if (m_pthCBITThread->m_iRetVal != DPSCM_SUCCESS)
        {
            ui->lbLED_Az_InternalPSUFault->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_Az_FloatSupplyFault->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_Az_LatchedErr->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_Az_OCErr->setPixmap(QPixmap(LED_GRAY));
            break;
        }

        if (READ_LSB(u8BITSts >> 0) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_InternalPSUFault->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_InternalPSUFault->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 1) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_FloatSupplyFault->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_FloatSupplyFault->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 2) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_LatchedErr->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_LatchedErr->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 3) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_OCErr->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_OCErr->setPixmap(QPixmap(LED_RED));
        }
    } break;
    case ID_40:
    {
        if (m_pthCBITThread->m_iRetVal != DPSCM_SUCCESS)
        {
            ui->lbLED_El_ChecksumErr->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_StaleData->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_PosNotSync->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_PosNotValid->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_El_AngleSetStatus->setPixmap(QPixmap(LED_GRAY));
            break;
        }

        if (READ_LSB(u8BITSts >> 0) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_ChecksumErr->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_ChecksumErr->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 1) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_StaleData->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_StaleData->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 2) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_PosNotSync->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_PosNotSync->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 3) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_PosNotValid->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_PosNotValid->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 4) == DPSCM_SUCCESS)
        {
            ui->lbLED_El_AngleSetStatus->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_El_AngleSetStatus->setPixmap(QPixmap(LED_RED));
        }
    } break;
    case ID_41:
    {
        if (m_pthCBITThread->m_iRetVal != DPSCM_SUCCESS)
        {
            ui->lbLED_Az_ChecksumErr->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_Az_StaleData->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_Az_PosNotSync->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_Az_PosNotValid->setPixmap(QPixmap(LED_GRAY));
            ui->lbLED_Az_AngleSetStatus->setPixmap(QPixmap(LED_GRAY));
            break;
        }

        if (READ_LSB(u8BITSts >> 0) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_ChecksumErr->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_ChecksumErr->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 1) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_StaleData->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_StaleData->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 2) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_PosNotSync->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_PosNotSync->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 3) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_PosNotValid->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_PosNotValid->setPixmap(QPixmap(LED_RED));
        }

        if (READ_LSB(u8BITSts >> 4) == DPSCM_SUCCESS)
        {
            ui->lbLED_Az_AngleSetStatus->setPixmap(QPixmap(LED_GREEN));
        }
        else
        {
            ui->lbLED_Az_AngleSetStatus->setPixmap(QPixmap(LED_RED));
        }
    } break;
    }
}

/*******************************************************************************
 * Name					: slot_resetCBITStatus
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To reset CBIT status
 ***************************************************************************//**
 * @brief	This function will reset CBIT Status in CBIT panel and CBIT Bar
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CCBITStatus::slot_resetCBITStatus()
{
    resetLEDinGB(ui->gbSerialCOMMStatus);
    resetLEDinGB(ui->gbCtrlLoopStatus);
    resetLEDinGB(ui->gbGimalPositionStatus);
    resetLEDinGB(ui->gbInternalSCMFault);
    resetLEDinGB(ui->gb_I2T_Monitoring);

    memset(&m_SBitfault01, 0, sizeof(SSCM_CBIT01STS));

    emit sig_resetCBITBar();
}

CCBITStatusThread::CCBITStatusThread(QObject *parent) : QThread(parent)
{
    m_bIsRunning = false;
    m_arrucCBIT_ID[0] = ID_01;
    m_arrucCBIT_ID[1] = ID_03;
    m_arrucCBIT_ID[2] = ID_04;
    m_arrucCBIT_ID[3] = ID_05;
    m_arrucCBIT_ID[4] = ID_06;
    m_arrucCBIT_ID[5] = ID_38;
    m_arrucCBIT_ID[6] = ID_39;
    m_arrucCBIT_ID[7] = ID_40;
    m_arrucCBIT_ID[8] = ID_41;
}

void CCBITStatusThread::Start()
{
    m_bIsRunning = true;
    start(QThread::HighPriority);
}

void CCBITStatusThread::Stop()
{
    m_bIsRunning = false;
    terminate();
}

void CCBITStatusThread::run()
{
    U_DEM_PORT_TX UTxCommand = { 0 };
    U_DEM_PORT_RX URxResponse = { 0 };
    unsigned int uiBytesRead = DPSCM_INIT_0;
    unsigned char ucData = DPSCM_INIT_0;
    unsigned char ucChecksum = DPSCM_INIT_0;
    QString qstrErrMsg = QString();
    QString qstrTemp = QString();

    while (m_bIsRunning)
    {
        if (g_SGlobal.m_ucConfiguredMode == DIAGNOSTICS_MODE)
        {
            UTxCommand.m_S_DiagCmd.m_ucByte0_Bit6_0 = 0;
            UTxCommand.m_S_DiagCmd.m_ucByte0_Bit7 = 1;

            UTxCommand.m_S_DiagCmd.m_ucByte1_CmdID = CMDID_DIAGMON_READ & 0x1F;
            UTxCommand.m_S_DiagCmd.m_ucByte1_TestInit = 0;
            UTxCommand.m_S_DiagCmd.m_ucByte1_Bit7 = 0;

            UTxCommand.m_S_DiagCmd.m_ucByte2_Bit6_0 = m_arrucCBIT_ID[m_ucCurrIdx] & 0x7F;

            dp_scm_7bit_xor_checksum((unsigned char *)&UTxCommand.m_S_DiagCmd, sizeof(S_DIAG_CMDRESP) - 1, &ucChecksum);

            UTxCommand.m_S_DiagCmd.m_ucByte7_Crc_Xor_CS = ucChecksum & 0x7F;

            m_iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_WriteData((char *)UTxCommand.m_arrucData, sizeof(S_DIAG_CMDRESP));
            if (m_iRetVal != DPSCM_SUCCESS)
            {
                g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&m_iRetVal, qstrErrMsg);
                qstrTemp.sprintf("Error Send Command : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), m_iRetVal);
                emit sig_updateActionLog(qstrTemp, LOG_ERROR);
                continue;
            }

            m_iRetVal = g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_DIAG_CMDRESP), (char *) &URxResponse.m_S_DiagResp, &uiBytesRead, 1);
            if (m_iRetVal != DPSCM_INIT_0)
            {
                g_SGlobal.m_objRS232[DIAGNOSTIC_PORT_IDX].DPRS232Wrap_GetLastError(&m_iRetVal, qstrErrMsg);
                qstrTemp.sprintf("Error Receiving Response for DiagID-%d : %s [ErrCode: %d]", m_arrucCBIT_ID[m_ucCurrIdx], CONV_QSTR_TO_SZ(qstrErrMsg), m_iRetVal);
                emit sig_updateActionLog(qstrTemp, LOG_ERROR);
                continue;
            }

            ucData = (URxResponse.m_S_DiagResp.m_ucByte3_Bit6_0 & 0x7F);
        }
        else
        {
            UTxCommand.m_S_RGACmd.m_ucByte0_MsgLength = sizeof(S_RGA_COMMAND) & 0x7F;
            UTxCommand.m_S_RGACmd.m_ucByte0_Bit7 = 1;

            UTxCommand.m_S_RGACmd.m_ucByte1_Spare = 0;
            UTxCommand.m_S_RGACmd.m_ucByte1_StrParameters = 0;
            UTxCommand.m_S_RGACmd.m_ucByte1_Bit7 = 0;

            UTxCommand.m_S_RGACmd.m_ucByte2_AzCmd_12_7 = 0;
            UTxCommand.m_S_RGACmd.m_ucByte2_AzModeSel = 0;
            UTxCommand.m_S_RGACmd.m_ucByte2_Bit7 = 0;

            UTxCommand.m_S_RGACmd.m_ucByte3_Spare = 0;
            UTxCommand.m_S_RGACmd.m_ucByte3_CW_UpEndStop = 0;
            UTxCommand.m_S_RGACmd.m_ucByte3_CCW_LowEndStop = 0;
            UTxCommand.m_S_RGACmd.m_ucByte3_ArrayIdent = 0;
            UTxCommand.m_S_RGACmd.m_ucByte3_Bit7 = 0;

            UTxCommand.m_S_RGACmd.m_ucByte4_AzCmd_6_0 = 0;
            UTxCommand.m_S_RGACmd.m_ucByte4_Bit7 = 0;

            UTxCommand.m_S_RGACmd.m_ucByte5_DiagnosticsID = m_arrucCBIT_ID[m_ucCurrIdx] & 0x7F;
            UTxCommand.m_S_RGACmd.m_ucByte5_Bit7 = 0;

            dp_scm_crc6_checksum((unsigned char *)&UTxCommand.m_S_RGACmd, (sizeof(S_RGA_COMMAND) - 1), &ucChecksum);
            UTxCommand.m_S_RGACmd.m_ucByte6_Crc6_CS = ucChecksum & 0x3F;
            UTxCommand.m_S_RGACmd.m_ucByte6_FarEndCSErr = 0;
            UTxCommand.m_S_RGACmd.m_ucByte6_Bit7 = 0;

            m_iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_WriteData((char *) UTxCommand.m_arrucData, sizeof(S_RGA_COMMAND));
            if (m_iRetVal != DPSCM_SUCCESS)
            {
                g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_GetLastError(&m_iRetVal, qstrErrMsg);
                qstrTemp.sprintf("Error Send Command : %s [ErrCode: %d]", CONV_QSTR_TO_SZ(qstrErrMsg), m_iRetVal);
                emit sig_updateActionLog(qstrTemp, LOG_ERROR);
                continue;
            }

            m_iRetVal = g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_ReadData((unsigned int) sizeof(S_RGA_RESPONSE), (char *) &URxResponse.m_S_RGAResp, &uiBytesRead, 1);
            if (m_iRetVal != DPSCM_SUCCESS)
            {
                g_SGlobal.m_objRS232[COMMAND_PORT_IDX].DPRS232Wrap_GetLastError(&m_iRetVal, qstrErrMsg);
                qstrTemp.sprintf("Error Receiving Response for DiagID-%d : %s [ErrCode: %d]", m_arrucCBIT_ID[m_ucCurrIdx], CONV_QSTR_TO_SZ(qstrErrMsg), m_iRetVal);
                emit sig_updateActionLog(qstrTemp, LOG_ERROR);
                continue;
            }

            ucData = URxResponse.m_S_RGAResp.m_ucByte4_BIT_DataVal & 0x7F;
        }

        emit sig_updateCBITStatus(m_arrucCBIT_ID[m_ucCurrIdx], ucData);
        m_ucCurrIdx++;
        if (m_ucCurrIdx == CBIT_ID_COUNT)
        {
            m_ucCurrIdx = 0;
        }
    }
}

void CCBITStatus::on_pbStart_clicked()
{
    CHECK_TC_RUNNING;

    if (ui->pbStart->text().contains("S&tart"))
    {
        if (g_SGlobal.m_ucConfiguredMode == DIAGNOSTICS_MODE)
        {
            CHECK_PORT_OPEN(DIAGNOSTIC_PORT_IDX);
        }
        else
        {
            CHECK_PORT_OPEN(COMMAND_PORT_IDX);
        }

        m_pthCBITThread->m_ucCurrIdx = 0;
        m_pthCBITThread->Start();
        ui->pbStart->setText("S&top");
    }
    else
    {
        m_pthCBITThread->m_ucCurrIdx = 0;
        m_pthCBITThread->Stop();
        ui->pbStart->setText("S&tart");
    }
}
