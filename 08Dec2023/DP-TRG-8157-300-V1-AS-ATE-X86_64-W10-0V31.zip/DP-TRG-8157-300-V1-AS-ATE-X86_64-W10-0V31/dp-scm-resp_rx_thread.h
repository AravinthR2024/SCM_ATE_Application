/**
* \file dp-scm-resp_rx_thread.h
* \brief This is the header file for dp-scm-resp_rx_thread.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef CRESPONSERX_H
#define CRESPONSERX_H

#include <QThread>
#include <QDebug>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "includes/dp_qt_msgqueue.h"

class CResponseRx : public QThread
{
		Q_OBJECT

	public:
		CResponseRx(QObject *parent = 0, int in_iTimeout = 0);

		bool m_bRespRxRunning;
		int m_iTimeout;
        U8BIT m_u8PortNo;

		void setTimeout(int in_iTimeout);
		void Start();
		void Stop();
		void run();

	signals:
		void sig_updateBITStatus();
        void sig_updateActionLog(QString, int);
};

#endif // CRESPONSERX_H
