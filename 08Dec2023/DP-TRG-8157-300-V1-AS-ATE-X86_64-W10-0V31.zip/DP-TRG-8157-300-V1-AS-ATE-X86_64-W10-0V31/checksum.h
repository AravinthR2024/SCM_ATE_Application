/**
*	\file DP_SCM_CHECKSUM.h
*	\brief DP_SCM_CHECKSUM Header file
*
*	This file contains the declarations of the functions in DP_SCM_CHECKSUM.c file
*
*	\author Madhusudhan D
*	\date 	Jul 13,2023 12:34 PM
*
*	\revision
*	- Initial version
*	- Added keywords for copyright & revision
*
*	\copyright Copyright (C) 2023 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
*	All Rights Reserved.\
*	Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
*   	Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
*   	Chennai-603103 | India\n
*	Website : http://www.datapatternsindia.com/\n
*	Phone: 91-44-4741-4000\n
*	FAX: 91-44-4741-4444 \n
************************************************************************************************/

#ifndef _SCM_CHECKSUM_
#define _SCM_CHECKSUM_

/*********MACROS**********/
#define CLEAR_MSB_DATA(Data)	(Data & 0x7F)
#define CRC16_CCITT_POLYNOM		0x1021
#define CRC_7_POLY				0x5B

/***Function Prototypes***/

/*! ***********************************************************************************************************
 * \fn    dp_scm_7bit_xor_checksum
 * \brief This function computes the 7bit XOR checksum
 *
 *	\param[in] 	in_pucData		- 	Specifies the data
 *	\param[in] 	in_ucDataSize	- 	Specifies the data size
 *	\param[out] out_pucChecksum - 	Specifies checksum data
 *
 * \retval  SCM_SUCCESS
 *
 * This function is used for 7bit XOR checksum computation.
 ****************************************************************************************************************/
short dp_scm_7bit_xor_checksum(unsigned char *in_pucData, unsigned char in_ucDataSize, unsigned char *out_pucChecksum);

/*! ***********************************************************************************************************
 * \fn    dp_scm_crc6_checksum
 * \brief This function computes the CRC6 checksum using polynomial : X^6 + X + 1
 *
 *	\param[in] 	in_pucData		- 	Specifies the data
 *	\param[in] 	in_ucDataSize	- 	Specifies the data size
 *	\param[out] out_pucChecksum - 	Specifies checksum data
 *
 * \retval  SCM_SUCCESS
 *
 * This function is used for CRC6 checksum computation.
 ****************************************************************************************************************/
short dp_scm_crc6_checksum(unsigned char *in_pucData, unsigned char in_ucDataSize, unsigned char *out_pucChecksum);

/*! ***********************************************************************************************************
 * \fn    dp_scm_crc16_ccitt
 * \brief This function computes the CRC-ccitt 16bit checksum
 *
 *	\param[in] 	in_pucData		- 	Specifies the data
 *	\param[in] 	in_ucDataSize	- 	Specifies the data size
 *	\param[out] out_pucChecksum - 	Specifies checksum data
 *
 * \retval  SCM_SUCCESS
 *
 * This function is used for CRC16 -ccitt checksum computation.
 ****************************************************************************************************************/
short dp_scm_crc16_ccitt(unsigned char *in_pucData, unsigned char in_ucDataSize, unsigned short *out_pusChecksum);


#endif // CHECKSUM_H

