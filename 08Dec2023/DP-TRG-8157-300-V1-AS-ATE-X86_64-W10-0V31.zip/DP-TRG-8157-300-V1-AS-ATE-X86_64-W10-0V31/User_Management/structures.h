#ifndef STRUCTURES
#define STRUCTURES

#include <QString>

typedef struct _S_USER_DETAILS
{
    QString m_sUserName;                        /*!< user name */
    QString m_sUserprevilage;                 /*!< user previlege */

}S_USER_DETAILS;

typedef struct _S_GLOBAL_HANDLES
{
    S_USER_DETAILS m_UserDetails;
}S_GLOBAL_HANDLES;

#endif // STRUCTURES
