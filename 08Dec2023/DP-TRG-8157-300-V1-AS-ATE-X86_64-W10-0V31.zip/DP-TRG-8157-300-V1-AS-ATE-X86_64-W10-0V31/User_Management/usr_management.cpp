#include "usr_management.h"

/**
*
*	\mainpage dp_uml_user_mang_function.c
*
*
*
*
*	\revision
*	- Initial version
*
*	\copyright Copyright (C) 2011 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
*	All Rights Reserved.\n
*	Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
*   	Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
*   	Chennai-603103 | India\n
*	Website : http://www.datapatternsindia.com/\n
*	Phone: 91-44-4741-4000\n
*	FAX: 91-44-4741-4444 \n
*
*	\image
*
*/

/**************************************************************************/
/**
*	\file dp_uml_user_mang_function.c
*	\brief This file having the function related to user Mangement & authentication
*
*	TThis file having the function related to user Mangement & authentication
*	\author A Kishore kumar
*	\date 20-11-2018
*
*	\revision
*	- Initial version
*
*	\copyright Copyright (C) 2011 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
*	All Rights Reserved.\n
*	Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
*   	Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
*   	Chennai-603103 | India\n
*	Website : http://www.datapatternsindia.com/\n
*	Phone: 91-44-4741-4000\n
*	FAX: 91-44-4741-4444 \n
*
*/
/**************************************************************************/

S_USER_ACCOUNTS m_arrSUsrAcc[255];
unsigned char key[32], g_ucMaxUser, g_ucMaxUsernamelen, g_ucMaxPassLen, g_ucMinUsernamelen, g_ucMinPassLen;
unsigned int g_uiRecCount = DP_UML_INIT_VALUE;
char g_arrAuthFileName[500];

char DP_UML_GetUserPrivilage(char *cUsername);

/**
*
*	\brief This function is used To get no of user in file
*
*	\param[out] iNoofusers - Specifies the no of user available
*	\retval ::DP_UML_SUCCESS Get no of users successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
char Usr_management::DP_UML_GetNoOfUsers(int *iNoofusers)
{
    *iNoofusers = g_uiRecCount;

    return DP_UML_SUCCESS;
}

/**
*
*	\brief This function is used To validate user
*
*	\param[in] cUsername - Specifies the username
*	\param[in] cPassword - Specifies the password
*	\retval ::DP_UML_SUCCESS Get validation successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
char Usr_management::DP_UML_Validate_User(char *cUsername, char *cPassword, char )
{
    unsigned int uiLoopVar = DP_UML_INIT_VALUE;
    int iNoofUsers = 0;

    DP_UML_GetNoOfUsers(&iNoofUsers);
    if(iNoofUsers == 0)
    {
        /** compare username with admin data **/

        if(strcasecmp("Administrator", cUsername ) == DP_UML_SUCCESS)
        {
            /** Check paswword is empty or not*/
            DP_UML_VALIDATE_PASSWORD_EMPTY (strlen (cPassword));

            /** compare password with exist data*/
            if(strcmp("admin", cPassword) == DP_UML_SUCCESS)
            {

			  m_qstrMatchedUsername = "Administrator";
                return DP_UML_SUCCESS;
            }
            else
            {
                return DP_UML_NOT_VALID_PASSWORD;
            }
        }
    }

    /** Check username is empty or not **/
    DP_UML_VALIDATE_USERNAME_EMPTY (strlen (cUsername));

    /** Check paswword is empty or not **/
    DP_UML_VALIDATE_PASSWORD_EMPTY (strlen (cPassword));

    /** Check username with special character or not **/
    DP_UML_VALIDATE_SPCL_CHAR_USERNAME (cUsername);

    /** Check Max length of username **/
    DP_UML_VALIDATE_MAX_USERNAME_LEN (strlen (cUsername), g_ucMaxUsernamelen);

    /** Check Min length of username **/
    DP_UML_VALIDATE_MIN_USERNAME_LEN (strlen (cUsername), g_ucMinUsernamelen);

    /** Check Max length of password **/
    if(strcmp("admin", cPassword) != 0)
    {
           DP_UML_VALIDATE_MAX_PASSWORD_LEN (strlen (cPassword), g_ucMaxPassLen);
    }

    /** Check Min length of password  **/
    if(strcmp("admin", cPassword) != 0)
    {
           DP_UML_VALIDATE_MIN_PASSWORD_LEN (strlen (cPassword), g_ucMinPassLen);
    }

    char carrUsrPwdHash[65] ;
    memset(carrUsrPwdHash, 0, (sizeof(char)*65));
    qstrcpy(carrUsrPwdHash, QCryptographicHash::hash(cPassword, QCryptographicHash::Sha256).toHex());

    while(uiLoopVar < g_uiRecCount)
    {
        /** compare username with exist data **/
        if(strcasecmp(m_arrSUsrAcc[uiLoopVar].m_szUserName, cUsername) == DP_UML_SUCCESS)
        {
            /** compare password with exist data **/
            if(strcmp(m_arrSUsrAcc[uiLoopVar].m_szPassword, carrUsrPwdHash) == DP_UML_SUCCESS)
            {
			  m_qstrMatchedUsername = QString(m_arrSUsrAcc[uiLoopVar].m_szUserName);
                return DP_UML_SUCCESS;
            }
            else
            {
                return DP_UML_NOT_VALID_PASSWORD;
            }
            break;
        }

        uiLoopVar++;
    }

    /** Check max user count **/
    if(uiLoopVar == g_uiRecCount)
    {
        return DP_UML_NOT_VALID_USERNAME;
    }

    return DP_UML_SUCCESS;
}

/**
*
*	\brief This function is used to add new user
*
*	\param[in] cUsername - Specifies the username
*	\retval ::DP_UML_SUCCESS Get user added successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
char Usr_management::DP_UML_AddNew_User(char *cUsername, char *in_cNewPassword, char *in_cConfirmPassword, const char *in_cPrivilage)
{

    /** compare username with admin data **/
    if(strcasecmp("Administrator", cUsername ) == DP_UML_SUCCESS)
    {
        /** Setting privilage as admin*/
        in_cPrivilage = "Adminuser";
    }

    /** Check Max no size **/
    DP_UML_VALIDATE_MAX_USER (g_uiRecCount, g_ucMaxUser);

    /** Check username is empty or not **/
    DP_UML_VALIDATE_USERNAME_EMPTY (strlen (cUsername));

    /** Check Max length of username **/
    DP_UML_VALIDATE_MAX_USERNAME_LEN (strlen (cUsername), g_ucMaxUsernamelen);

    /** Check Min length of username **/
    DP_UML_VALIDATE_MIN_USERNAME_LEN (strlen (cUsername), g_ucMinUsernamelen);

    /** Check any special character is present or not **/
    DP_UML_VALIDATE_SPCL_CHAR_USERNAME (cUsername);

    /** Check new paswword is empty or not **/
    DP_UML_VALIDATE_NEWPASSWORD_EMPTY (strlen (in_cNewPassword));

    /** Check old paswword is empty or not **/
    DP_UML_VALIDATE_CONFPASSWORD_EMPTY (strlen (in_cConfirmPassword));

    /** Check Max length of New password **/
    DP_UML_VALIDATE_MAX_PASSWORD_LEN (strlen (in_cNewPassword), g_ucMaxPassLen);

    /** Check Min length of New password  **/
    if(strcmp("admin", in_cNewPassword) != 0)
    {
          DP_UML_VALIDATE_MIN_PASSWORD_LEN (strlen (in_cNewPassword), g_ucMinPassLen);
    }

    /** Check Max length of Con password **/
    DP_UML_VALIDATE_MAX_PASSWORD_LEN (strlen (in_cConfirmPassword), g_ucMaxPassLen);

    /** Check Min length of Con password  **/
    if(strcmp("admin", in_cConfirmPassword) != 0)
    {
          DP_UML_VALIDATE_MIN_PASSWORD_LEN (strlen (in_cConfirmPassword), g_ucMinPassLen);
    }

    /** To check special character available or not **/
    if(strcmp("admin", in_cNewPassword) != 0)
    {
        DP_UML_VALIDATE_SPCL_CHAR (in_cNewPassword);
    }

    /** To check digit availble or not **/
    if(strcmp("admin", in_cNewPassword) != 0)
    {
        DP_UML_VALIDATE_DIGIT (in_cNewPassword);
    }

    if((IsAlreadyExists(cUsername)) != DP_UML_SUCCESS)
    {
        return DP_UML_USER_ALREADY_EXIST;
    }

#if 0
    /** Reallocate memory to store new user data **/
    m_arrSUsrAcc = (S_USER_ACCOUNTS *)realloc(m_arrSUsrAcc, (g_uiRecCount+1)*sizeof(S_USER_ACCOUNTS));

    if(m_arrSUsrAcc == NULL)
    {
        return DP_UML_ERR_MALLOC;
    }
#endif

    /** Copy the username in array **/
    strcpy(m_arrSUsrAcc[g_uiRecCount].m_szUserName, cUsername);

    /** compare new password and confirm password **/
    if(strcmp(in_cNewPassword, in_cConfirmPassword) == DP_UML_SUCCESS)
    {
        /** Copy the password array **/
        char carrUsrPwdHash[65] = {"\0"};
        qstrcpy(carrUsrPwdHash, QCryptographicHash::hash(in_cNewPassword, QCryptographicHash::Sha256).toHex());
        strcpy(m_arrSUsrAcc[g_uiRecCount].m_szPassword, carrUsrPwdHash);
    }
    else
    {
        return DP_UML_NOT_VALID_CONFPASSWORD;
    }

    /** Set user Pribvilage **/
    strcpy(m_arrSUsrAcc[g_uiRecCount].m_userprevilage, in_cPrivilage);

    /** Increment the total no of user count by 1 **/
    g_uiRecCount++;

    /**Update data into file **/
    UpdateAuthfile();

    //return DP_UML_SUCCESS;
    return DP_UML_SUCCESS;
}

/**
*
*	\brief This function is used To Change password of user
*
*	\param[in] cUsername - Specifies the username
*	\param[in] cOldPassword - Specifies the old password
*	\param[in] cNewPassword - Specifies the new password
*	\param[in] cConfPassword - Specifies the confirmed password
*	\retval ::DP_UML_SUCCESS Get changed user password successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
char Usr_management::DP_UML_Change_Password(char *cUsername, char *cOldPassword, char *cNewPassword, char *cConfPassword)
{
    unsigned int uiLocRecord = DP_UML_INIT_VALUE;

    /** Check username is empty or not **/
    DP_UML_VALIDATE_USERNAME_EMPTY (strlen (cUsername));

    /** Check old paswword is empty or not **/
    DP_UML_VALIDATE_PASSWORD_EMPTY (strlen (cOldPassword));

    /** Check new paswword is empty or not **/
    DP_UML_VALIDATE_NEWPASSWORD_EMPTY (strlen (cNewPassword));

    /** Check old paswword is empty or not **/
    DP_UML_VALIDATE_CONFPASSWORD_EMPTY (strlen (cConfPassword));

    /** Check Max length of username **/
    DP_UML_VALIDATE_MAX_USERNAME_LEN (strlen (cUsername), g_ucMaxUsernamelen);

    /** Check Min length of username **/
    DP_UML_VALIDATE_MIN_USERNAME_LEN (strlen (cUsername), g_ucMinUsernamelen);

    /** Check Max length of old password **/
    DP_UML_VALIDATE_MAX_PASSWORD_LEN (strlen (cOldPassword), g_ucMaxPassLen);

    /** Check Min length of old password  **/
    DP_UML_VALIDATE_MIN_PASSWORD_LEN (strlen (cOldPassword), g_ucMinPassLen);

    /** Check Max length of old password **/
    DP_UML_VALIDATE_MAX_PASSWORD_LEN (strlen (cNewPassword), g_ucMaxPassLen);

    /** Check Min length of old password  **/
    DP_UML_VALIDATE_MIN_PASSWORD_LEN (strlen (cNewPassword), g_ucMinPassLen);

    /** To check special character available or not **/
    DP_UML_VALIDATE_SPCL_CHAR (cNewPassword);

    /** To check digit availble or not **/
    DP_UML_VALIDATE_DIGIT (cNewPassword);

    uiLocRecord = IsAlreadyExists(cUsername);

    /** Check user is already exist or not **/
    if((uiLocRecord > DP_UML_SUCCESS))
    {
        char carrUsrOldPwdHash[65] = {"\0"};
        qstrcpy(carrUsrOldPwdHash, QCryptographicHash::hash(cOldPassword, QCryptographicHash::Sha256).toHex());
        /** compare password with exist data **/
        if(strcmp(m_arrSUsrAcc[uiLocRecord - 1].m_szPassword, carrUsrOldPwdHash) == DP_UML_SUCCESS)
        {
            /** compare new password and confirm password **/
            if(strcmp(cNewPassword, cConfPassword) == DP_UML_SUCCESS)
            {
                char carrUsrPwdHash[65] = {"\0"};
                qstrcpy(carrUsrPwdHash, QCryptographicHash::hash(cNewPassword, QCryptographicHash::Sha256).toHex());
                /** Update the new password **/
                strcpy( m_arrSUsrAcc[uiLocRecord - 1].m_szPassword, carrUsrPwdHash);
            }
            else
            {
                return DP_UML_NOT_VALID_CONFPASSWORD;
            }
        }
        else
        {
            return DP_UML_NOT_VALID_PASSWORD;
        }
    }
    else
    {
        // qDebug("CHANGE PASSWROD");
        return DP_UML_NOT_VALID_USERNAME;
    }

    /**Update data into file **/
    UpdateAuthfile();

    return DP_UML_SUCCESS;
}

/**
*
*	\brief This function is used To Change password of user by admin.
*
*	\param[in] cUsername - Specifies the username
*	\param[in] cOldPassword - Specifies the old password
*	\param[in] cNewPassword - Specifies the new password
*	\param[in] cConfPassword - Specifies the confirmed password
*	\retval ::DP_UML_SUCCESS Get changed user password successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author Kishore kumar
*	\date 27-10-2018
*	\revision
*	-Initial version
*/
char Usr_management::DP_UML_Admin_Change_Password(char *cUsername, char *cNewPassword, char *cConfPassword)
{
    unsigned int uiLocRecord = DP_UML_INIT_VALUE;

    /** Check username is empty or not **/
    DP_UML_VALIDATE_USERNAME_EMPTY (strlen (cUsername));

    /** Check new paswword is empty or not **/
    DP_UML_VALIDATE_NEWPASSWORD_EMPTY (strlen (cNewPassword));

    /** Check old paswword is empty or not **/
    DP_UML_VALIDATE_CONFPASSWORD_EMPTY (strlen (cConfPassword));

    /** Check Max length of username **/
    DP_UML_VALIDATE_MAX_USERNAME_LEN (strlen (cUsername), g_ucMaxUsernamelen);

    /** Check Min length of username **/
    DP_UML_VALIDATE_MIN_USERNAME_LEN (strlen (cUsername), g_ucMinUsernamelen);

    /** Check Max length of old password **/
    DP_UML_VALIDATE_MAX_PASSWORD_LEN (strlen (cNewPassword), g_ucMaxPassLen);

    /** Check Min length of old password  **/
    if(strcmp("admin", cNewPassword) != 0)
    {
        DP_UML_VALIDATE_MIN_PASSWORD_LEN (strlen (cNewPassword), g_ucMinPassLen);

    }

    /** To check special character available or not **/
    DP_UML_VALIDATE_SPCL_CHAR (cNewPassword);

    /** To check digit availble or not **/
    DP_UML_VALIDATE_DIGIT (cNewPassword);

    uiLocRecord = IsAlreadyExists(cUsername);

    /** Check user is already exist or not **/
    if((uiLocRecord > DP_UML_SUCCESS))
    {
        /** compare password with exist data **/

            /** compare new password and confirm password **/
            if(strcmp(cNewPassword, cConfPassword) == DP_UML_SUCCESS)
            {
                char carrUsrPwdHash[65] = {"\0"};
                qstrcpy(carrUsrPwdHash, QCryptographicHash::hash(cNewPassword, QCryptographicHash::Sha256).toHex());
                /** Update the new password **/
                strcpy( m_arrSUsrAcc[uiLocRecord - 1].m_szPassword, carrUsrPwdHash);
            }
            else
            {
                return DP_UML_NOT_VALID_CONFPASSWORD;
            }
    }
    else
    {
//        qDebug("ADMIN CHNG PASS");
        return DP_UML_NOT_VALID_USERNAME;
    }

    /**Update data into file **/
    UpdateAuthfile();

    return DP_UML_SUCCESS;
}

/**
*
*	\brief This function is used To delete user
*
*	\param[in] cUsername - Specifies the username
*	\retval ::DP_UML_SUCCESS Get user deleted successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
char Usr_management::DP_UML_Delete_User(char *cUsername)
{
    unsigned int uiLocRecord = DP_UML_INIT_VALUE;

    /** Check Max no size **/
    DP_UML_VALIDATE_MAX_USER (g_uiRecCount, g_ucMaxUser);

    /** Check username is empty or not **/
    DP_UML_VALIDATE_USERNAME_EMPTY (strlen (cUsername));

    /** Check Max length of username **/
    DP_UML_VALIDATE_MAX_USERNAME_LEN (strlen (cUsername), g_ucMaxUsernamelen);

    /** Check Min length of username **/
    DP_UML_VALIDATE_MIN_USERNAME_LEN (strlen (cUsername), g_ucMinUsernamelen);

    uiLocRecord = IsAlreadyExists(cUsername);

    /** Check user is already exist or not **/
    if(uiLocRecord > DP_UML_SUCCESS)
    {
        /** Delete the user **/
        memmove( &m_arrSUsrAcc[uiLocRecord-1], &m_arrSUsrAcc[uiLocRecord], (g_uiRecCount - uiLocRecord)*sizeof(S_USER_ACCOUNTS) );
        g_uiRecCount --;

    }
    else
    {
//        qDebug("DELETE USER");
        return DP_UML_NOT_VALID_USERNAME;
    }

    /**Update data into file **/
    UpdateAuthfile();

    return DP_UML_SUCCESS;
}


//added by kishore on 2/11/2018 for encryption and decryption of username and privilage

void Usr_management::Encrypt(char *in_array, int array_size, char *out_array)
{
    int i;
    unsigned char secret[32] = {22, 53, 44, 71, 66, 177, 253, 122, 55, 95, 177, 200, 110, 49, 240, 100, 22, 53, 44, 71, 66, 177, 253, 122, 55, 95, 177, 200, 110, 49, 240, 100};
    for(i = 0; i < array_size; i++)
        out_array[i] = in_array[i] ^ secret[i];
}

void Usr_management::Decrypt(char *in_array, int array_size, char *out_array)
{
    int i;
    unsigned char secret[32] = {22, 53, 44, 71, 66, 177, 253, 122, 55, 95, 177, 200, 110, 49, 240, 100, 22, 53, 44, 71, 66, 177, 253, 122, 55, 95, 177, 200, 110, 49, 240, 100};
    for(i = 0; i < array_size; i++)
        out_array[i] = in_array[i] ^ secret[i];
}
/**
*
*	\brief This function is used To encrypt data using AES
*
*	\param[in] UserDetailsTemp - Specifies the decrypted data
*	\param[out] UserDetailsEncoded - Specifies the array to get encrypted data
*	\retval ::DP_UML_SUCCESS Get encrypted data successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
int Usr_management::EncryptData(S_USER_ACCOUNTS  *UserDetailsTemp, S_USER_ACCOUNTS *UserDetailsEncoded)
{
    unsigned short usLoopIndex;

    for(usLoopIndex = DP_UML_INIT_VALUE;usLoopIndex < g_uiRecCount ; usLoopIndex++)
    {
        /** Encrypt username **/
        //aes_encrypt(UserDetailsTemp[usLoopIndex].m_szUserName, UserDetailsEncoded[usLoopIndex].m_szUserName, key_schedule, DP_UML_AES256);
        Encrypt(UserDetailsTemp[usLoopIndex].m_szUserName, 32, UserDetailsEncoded[usLoopIndex].m_szUserName);
    }
    for(usLoopIndex = DP_UML_INIT_VALUE;usLoopIndex < g_uiRecCount ; usLoopIndex++)
    {
        /** Encrypt Password **/
        //aes_encrypt(UserDetailsTemp[usLoopIndex].m_szPassword, UserDetailsEncoded[usLoopIndex].m_szPassword, key_schedule, DP_UML_AES256);
        strcpy(UserDetailsEncoded[usLoopIndex].m_szPassword, UserDetailsTemp[usLoopIndex].m_szPassword);
    }
    for(usLoopIndex = DP_UML_INIT_VALUE;usLoopIndex < g_uiRecCount ; usLoopIndex++)
    {
        /** Encrypt Privilage **/
        //aes_encrypt(UserDetailsTemp[usLoopIndex].m_userprevilage, UserDetailsEncoded[usLoopIndex].m_userprevilage, key_schedule, DP_UML_AES256);
        Encrypt(UserDetailsTemp[usLoopIndex].m_userprevilage, 16, UserDetailsEncoded[usLoopIndex].m_userprevilage);
    }
    return DP_UML_SUCCESS;
}

/**
*
*	\brief This function is used To Decrypt data using AES
*
*	\param[in] UserDetailsTemp - Specifies the encypted code
*	\param[out] UserDetailsDecoded - Specifies the array to get the decrypted data
*	\retval ::DP_UML_SUCCESS Get decypted data successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date  20-11-2018
*	\revision
*	-Initial version
*/
int Usr_management::DecryptData(S_USER_ACCOUNTS  *UserDetailsTemp , S_USER_ACCOUNTS *UserDetailsDecoded )
{
    unsigned short usLoopIndex = DP_UML_INIT_VALUE;

    for(usLoopIndex = DP_UML_INIT_VALUE; usLoopIndex < g_uiRecCount;usLoopIndex++)
    {
        /** Decrypt username **/
        Decrypt(UserDetailsTemp[usLoopIndex].m_szUserName, 32, UserDetailsDecoded[usLoopIndex].m_szUserName);
    }
    for(usLoopIndex = DP_UML_INIT_VALUE;usLoopIndex < g_uiRecCount;usLoopIndex++)
    {
        /** Decrypt password **/
        strcpy(UserDetailsDecoded[usLoopIndex].m_szPassword, UserDetailsTemp[usLoopIndex].m_szPassword);
    }
    for(usLoopIndex = DP_UML_INIT_VALUE;usLoopIndex < g_uiRecCount;usLoopIndex++)
    {
        /** Decrypt password **/
        Decrypt(UserDetailsTemp[usLoopIndex].m_userprevilage, 16, UserDetailsDecoded[usLoopIndex].m_userprevilage);
    }

    return DP_UML_SUCCESS;
}

/**
*
*	\brief This function is used To check user already exist or not
*
*	\param[in] cUsername - Specifies the username
*	\retval ::DP_UML_FAILURE  Not successful
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
int Usr_management::IsAlreadyExists(char *cUsername)
{
    unsigned int uiLoopVar = DP_UML_SUCCESS;

    while(uiLoopVar < g_uiRecCount)
    {
        /** Check username is available or not **/
        if(strcasecmp(m_arrSUsrAcc[uiLoopVar].m_szUserName, cUsername ) == DP_UML_SUCCESS)
            return (uiLoopVar+1);
        else
            uiLoopVar++;
    }

    return DP_UML_SUCCESS;
}

char  Usr_management::DP_UML_GetUserPrivilage(char *cUsername)
{
    unsigned int uiLoopVar = DP_UML_SUCCESS;

    while(uiLoopVar < g_uiRecCount)
    {
        /** Check username is available or not **/
        if(strcasecmp(m_arrSUsrAcc[uiLoopVar].m_szUserName, cUsername ) == DP_UML_SUCCESS)
        {
            if(strcmp(m_arrSUsrAcc[uiLoopVar].m_userprevilage, "Adminuser" ) == DP_UML_SUCCESS)
            {
                return 0;

            }
            else if(strcmp(m_arrSUsrAcc[uiLoopVar].m_userprevilage, "Super user" ) == DP_UML_SUCCESS)
            {
                return 1;
            }
            else if(strcmp(m_arrSUsrAcc[uiLoopVar].m_userprevilage, "user" ) == DP_UML_SUCCESS)
            {
                return 2;
            }
        }

        else
            uiLoopVar++;
    }

    return DP_UML_FAILURE;
}

/**
*
*	\brief This function is used To get no of user names in file
*
*	\param[out] Noofusernames - Specifies the no of user name available
*	\retval ::DP_UML_SUCCESS Get no of users name successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
char Usr_management::DP_UML_GetNoOfUserNames(S_USER_ACCOUNTS in_objArrUsers[])
{
    memcpy (in_objArrUsers, m_arrSUsrAcc, sizeof (m_arrSUsrAcc));

    return DP_UML_SUCCESS;
}

/**
*
*	\brief This function is used To initializa library
*
*	\param[in] in_ucMaxUsers - Specifies the Maximum username
*	\param[in] in_ucMaxUsernamelen - Specifies the Maximum username length
*	\param[in] in_ucMaxPasslen - Specifies the Maximum password length
*	\param[in] in_ucMinUsernamelen - Specifies the Minimum username length
*	\param[in] in_ucMinPasslen - Specifies the Minimum password length
*	\retval ::DP_UML_SUCCESS Get Initializa library successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
char Usr_management::DP_UML_Init_UMLLib(char in_ucMaxUsers, char in_ucMaxUsernamelen, char in_ucMaxPasslen, char in_ucMinUsernamelen, char in_ucMinPasslen, const char *AuthFilename)
{
    FILE *fpUserPass;
    S_USER_ACCOUNTS m_arrSDecUsrData[255];

    /** Initailize Max no of Users **/
    g_ucMaxUser = in_ucMaxUsers;

    /** Initailize Max no of User name length **/
    g_ucMaxUsernamelen = in_ucMaxUsernamelen;

    /** Initailize Max no of User password length **/
    g_ucMaxPassLen = in_ucMaxPasslen;

    /** Initailize Min no of User name length **/
    g_ucMinUsernamelen = in_ucMinUsernamelen;

    /** Initailize Min no of User password length **/
    g_ucMinPassLen = in_ucMinPasslen;

    strcpy(g_arrAuthFileName, AuthFilename);
//qDebug() << "authen2:" << g_arrAuthFileName << AuthFilename;
    fpUserPass = NULL;

    /* open password file */
    fpUserPass = fopen(g_arrAuthFileName, "rb");

    /* check availibility of file*/
    if(fpUserPass == NULL)
    {
        return Dp_UML_FILE_CORRUPTED;
    }

    g_uiRecCount = DP_UML_INIT_VALUE;

    fseek(fpUserPass, 0L, SEEK_END);

    int size = ftell(fpUserPass);

    if (size != 0)
    {
        g_uiRecCount = (ftell(fpUserPass) - 32) / sizeof(S_USER_ACCOUNTS);
    }
    else
    {
        g_uiRecCount = ftell(fpUserPass) / sizeof(S_USER_ACCOUNTS);
    }
    fseek(fpUserPass, 0L, SEEK_SET);

#if 0
    /** Allocate memory for data **/
    m_arrSUsrAcc = (S_USER_ACCOUNTS *)malloc (g_uiRecCount * sizeof(S_USER_ACCOUNTS));

    if(m_arrSUsrAcc == NULL)
    {
        return DP_UML_ERR_MALLOC;
    }
#endif
    fread(&m_arrSDecUsrData, sizeof(S_USER_ACCOUNTS), g_uiRecCount, fpUserPass);

    /** Decrypt data using AES **/
    DecryptData(m_arrSDecUsrData, m_arrSUsrAcc);
    fclose(fpUserPass);

    fpUserPass = NULL;
    return DP_UML_SUCCESS;
}

/**
*
*	\brief This function is used To update data in file
*
*	\retval ::DP_UML_SUCCESS Get updated successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
void Usr_management::UpdateAuthfile()
{
    FILE  *fpUserPass;
    S_USER_ACCOUNTS m_arrSEncUsrData[255];

    /** Encrypt data using AES **/
    EncryptData(m_arrSUsrAcc, m_arrSEncUsrData);

    /* to update the file */
    fpUserPass = fopen(g_arrAuthFileName, "rb+");
    if (fpUserPass != NULL)
    {
        fclose(fpUserPass);
        fpUserPass = fopen(g_arrAuthFileName, "wb");
        fwrite(&m_arrSEncUsrData, sizeof(S_USER_ACCOUNTS), g_uiRecCount, fpUserPass);
        fclose(fpUserPass);
        fpUserPass = NULL;
    }
}

/**
*
*	\brief This function is used To check special character is present or not
*
*	\param[in] cData - Specifies the username
*	\retval ::DP_UML_SUCCESS Get special character exists or not successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
int Usr_management::IsSpclCharExist(char *cData)
{
    unsigned char ucLoopVar = DP_UML_INIT_VALUE, ucSplflag = DP_UML_INIT_VALUE;

    while (cData[ucLoopVar] != '\0')
    {
        if((cData[ucLoopVar]>=33 && cData[ucLoopVar]<=45) || (cData[ucLoopVar]>=58 && cData[ucLoopVar]<=64) || (cData[ucLoopVar]>=91 && cData[ucLoopVar]<=96) || (cData[ucLoopVar]>=123 && cData[ucLoopVar]<=126) || cData[ucLoopVar]==47)
        {
            ucSplflag = DP_UML_SUCCESS;
            return  DP_UML_SUCCESS;
        }
        else
        {
            ucSplflag = DP_UML_FAILURE;
        }

        ucLoopVar++;
    }
    return ucSplflag;
}

/**
*
*	\brief This function is used To check digit is present or not
*
*	\param[in] cData - Specifies the data
*	\retval ::DP_UML_SUCCESS Get digit exists or not successful*
*	\pre	It can be called any time needed
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
int Usr_management::IsDigitExist(char *cData)
{
    unsigned char ucLoopVar = DP_UML_INIT_VALUE, ucSplflag = DP_UML_INIT_VALUE;

    while (cData[ucLoopVar] != '\0')
    {
        if((cData[ucLoopVar]>=48 && cData[ucLoopVar]<=57))
        {
            ucSplflag = DP_UML_SUCCESS;
            return  DP_UML_SUCCESS;
        }
        else
        {
            ucSplflag = DP_UML_FAILURE;
        }
        ucLoopVar++;
    }
    return ucSplflag;
}

/**
*
*	\brief This function is used to check the checksum of the file
*
*	\param[in] cfilename - Specifies the file name to which checksum has to be validated.
*	\retval ::DP_UML_SUCCESS Get  successful or not successful*
*                Dp_UML_FILE_CORRUPTED if file corrupted
*                Dp_UML_FILE_NOT_FOUND if file not found
*	\pre	It should be called after DP_UML_Init_UMLLib
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
int Usr_management::check_file_checksum(const char *cfilename)
{
    QByteArray FileHashData, fileData, check;
    qint64 file_size;
    QFile file(cfilename);

    if (file.open(QIODevice::ReadOnly))
    {
        if (file.size() != 0 )
        {
            fileData = file.read((file.size() - 32));

            FileHashData= QCryptographicHash::hash(fileData, QCryptographicHash::Md5);
            file.seek(0);
            file_size = file.size();
            file.seek(file_size - 32);
            check = file.read(32);
            if (strcmp(check, FileHashData.toHex()) != 0)
            {
                file.close();
                return Dp_UML_FILE_CORRUPTED;
            }
        }
        file.close();
    }
    else
    {
        return Dp_UML_FILE_NOT_FOUND;
    }
    return DP_UML_SUCCESS;
}
/**
*
*	\brief This function is used to updae the checksum of the file
*
*	\param[in] cfilename - Specifies the file name to which checksum has to be calculated.
*                   iNoOfUsers - Specifies number of users present.
*	\retval ::DP_UML_SUCCESS Get  successful or not successful*
*                Dp_UML_FILE_CORRUPTED if file corrupted
*                Dp_UML_FILE_NOT_FOUND if file not found
*	\pre	It should be called after DP_UML_Init_UMLLib
*	\post	NA
*
*	\author A Kishore kumar
*	\date 20-11-2018
*	\revision
*	-Initial version
*/
int Usr_management::update_file_checksum(const char *cfilename, int iNoOfUsers)
{
    QByteArray FileHashData;
    int iNoofUsers;
    qint64 file_size;
    QFile file(cfilename);
    Usr_management manage;

    manage.DP_UML_GetNoOfUsers(&iNoofUsers);
    file_size = iNoOfUsers * sizeof(S_USER_ACCOUNTS);

    if (file.open(QIODevice::ReadOnly))
    {
        QByteArray fileData = file.read(file_size);
        FileHashData = QCryptographicHash::hash(fileData, QCryptographicHash::Md5);
        file.close();
    }
    else
    {
        return Dp_UML_FILE_NOT_FOUND;
    }
    manage.UpdateAuthfile();
    file.open(QIODevice::Append);
    file.write(FileHashData.toHex());
    file.close();
    return DP_UML_SUCCESS;
}
