/*******************************************************************************
// File Name    : cchangepassword.cpp
// Author       : Kishore kumar A
// Created Date : Mar 11,2019
// Description  : To change the password of the normal user.
*******************************************************************************/

/*******************************************************************************
// Company Name : DATA PATTERNS INDIA PRIVATE LIMITED
// Address      : No. H9,4th MainRoad,SIPCOT IT Park,Siruseri,Chennai-603103
// Email        : support@datapatterns.co.in
// Phone        : +91 44 47414000
// Fax          : +91 44 47414444
*******************************************************************************/

/******************************************************************************
// Copyright (c) 2019 DATA PATTERNS
//
// All rights reserved. These materials are confidential and proprietary to
// DATA PATTERNSand no part of these materials should be reproduced or published
// in any form by any means, electronic or mechanical, including photocopy, on any
// information storage or retrieval system, nor should the materials be disclosed
// to third parties without the explicit written authorization of DATA PATTERNS.
//
*******************************************************************************/

#include "cchangepassword.h"
#include "ui_cchangepassword.h"

extern char g_arrAuthfileName[20];
extern S_GLOBAL_HANDLES g_Handles;

CChangePassword::CChangePassword(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CChangePassword)
{
    ui->setupUi(this);
    ui->le_ChgPswUsrName->setText(g_Handles.m_UserDetails.m_sUserName);
}

CChangePassword::~CChangePassword()
{
    delete ui;
}

/*******************************************************************************
 * Name                      : on_pb_ChgCnfirmUsrPwd_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : g_arrAuthfileName
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To change the password of the user.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CChangePassword::on_pb_ChgCnfirmUsrPwd_clicked()
{
    Usr_management manage;
    int iRetVal = 0;
    iRetVal = manage.check_file_checksum(g_arrAuthfileName);
    if (iRetVal == -77 || iRetVal == -76)
    {
        Msg_display(iRetVal);
        exit(0);
    }
    if(strcmp(ui->le_ChgPwdOldPwd->text().toLatin1().data(), ui->le_ChgPwdNewPwd->text().toLatin1().data()) != 0)
    {
        iRetVal = manage.DP_UML_Change_Password(ui->le_ChgPswUsrName->text().toLatin1().data(), ui->le_ChgPwdOldPwd->text().toLatin1().data(), ui->le_ChgPwdNewPwd->text().toLatin1().data(), ui->le_ChgPwdCnfirmPwd->text().toLatin1().data());
        if(iRetVal == 0)
        {
            QMessageBox :: information(this, "Information", "Password changed successfully");
            int iNoOfUsr;
            manage.DP_UML_GetNoOfUsers(&iNoOfUsr);
            int iRetval = manage.update_file_checksum(g_arrAuthfileName, iNoOfUsr);
            Msg_display(iRetval);
        }
        else
        {
            Msg_display(iRetVal);
            ui->le_ChgPwdCnfirmPwd->clear();
            ui->le_ChgPwdNewPwd->clear();
            ui->le_ChgPwdOldPwd->clear();
        }
    }
    else
    {
        QMessageBox :: information(this, "Error", "Old Password and New Password must be different");
    }
    ui->le_ChgPwdCnfirmPwd->clear();
    ui->le_ChgPwdNewPwd->clear();
    ui->le_ChgPwdOldPwd->clear();
}

void CChangePassword::on_pb_ChgPwdCancel_clicked()
{
    ui->le_ChgPwdCnfirmPwd->clear();
    ui->le_ChgPwdNewPwd->clear();
    ui->le_ChgPwdOldPwd->clear();
    this->close();
}

/*******************************************************************************
 * Name                      : Msg_display
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To display corresponding error message for the error code.
 *  * \param iErrorValue - Error Code to get error message.
 * * \return No return values.
*******************************************************************************/
void CChangePassword::Msg_display(int iErrorValue)
{
    switch(iErrorValue)
    {
    case -99:
        QMessageBox :: information(this, "Error", "Invalid Username");
        break;
    case -98:
        QMessageBox :: information(this, "Error", "Invalid Password");
        break;
    case -97:
        QMessageBox :: information(this, "Error", "Invalid Old Password");
        break;
    case -96:
        QMessageBox :: information(this, "Error", "Invalid Confirm Password");
        break;
    case -94:
        QMessageBox :: information(this, "Error", "User already exists");
        break;
    case -90:
        QMessageBox :: information(this, "Error", "Username must be of minimum 6 characters");
        break;
    case -89:
        QMessageBox :: information(this, "Error", "Username must be less than 32 characters");
        break;
    case -88:
        QMessageBox :: information(this, "Error", "Password must be of minimum 6 characters");
        break;
    case -87:
        QMessageBox :: information(this, "Error", "Password must be less than 32 characters");
        break;
    case -86:
        QMessageBox :: information(this, "Error", "Maximum number of users reached");
        break;
    case -85:
        QMessageBox :: information(this, "Error", "Password must contain atleast one special character");
        break;
    case -84:
        QMessageBox :: information(this, "Error", "Password must contain atleast one numeric character");
        break;
    case -82:
        QMessageBox :: information(this, "Error", "Username must not contain any special characters other than '.'");
        break;
    case -81:
        QMessageBox :: information(this, "Error", "Username field is empty");
        break;
    case -80:
        QMessageBox :: information(this, "Error", "Password field is empty");
        break;
    case -79:
        QMessageBox :: information(this, "Error", "NewPassword field is empty");
        break;
    case -78:
        QMessageBox :: information(this, "Error", "ConfirmPassword field is empty");
        break;
    case -77:
        QMessageBox :: information(this, "Error", "Authentication file corrupted", QMessageBox::Ok);
        break;
    case -76:
        QMessageBox :: information(this, "Error", "Authentication file not found", QMessageBox::Ok);
        break;
    default:
        break;
    }
}

/*******************************************************************************
 * Name                      : closeEvent
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To clear GUI fields on closing the window.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CChangePassword::closeEvent(QCloseEvent *)
{
    ui->le_ChgPwdCnfirmPwd->clear();
    ui->le_ChgPwdNewPwd->clear();
    ui->le_ChgPwdOldPwd->clear();
}

/************************************ END OF FILE *****************************/
