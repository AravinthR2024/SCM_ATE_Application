/*******************************************************************************
// File Name    : cusermanagement.cpp
// Author       : Kishore kumar A
// Created Date : Mar 11,2019
// Description  : Enables the administrator to add/remove and change password of the users.
*******************************************************************************/

/*******************************************************************************
// Company Name : DATA PATTERNS INDIA PRIVATE LIMITED
// Address      : No. H9,4th MainRoad,SIPCOT IT Park,Siruseri,Chennai-603103
// Email        : support@datapatterns.co.in
// Phone        : +91 44 47414000
// Fax          : +91 44 47414444
*******************************************************************************/

/******************************************************************************
// Copyright (c) 2019 DATA PATTERNS
//
// All rights reserved. These materials are confidential and proprietary to
// DATA PATTERNS and no part of these materials should be reproduced or published
// in any form by any means, electronic or mechanical, including photocopy, on any
// information storage or retrieval system, nor should the materials be disclosed
// to third parties without the explicit written authorization of DATA PATTERNS.
//
*******************************************************************************/

#include "cusermanagement.h"
#include "ui_cusermanagement.h"
#include "structures.h"

extern char g_arrAuthfileName[20];
extern S_GLOBAL_HANDLES g_Handles;

CUserManagement::CUserManagement(QWidget *parent) :
    QDialog(parent = 0),
    ui(new Ui::CUserManagement)
{
    ui->setupUi(this);
    this->setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);

    usrName = ui->le_AdChgUsername;

    Usr_management manage;
    ui->tw_UserDetails->horizontalHeader()->setStretchLastSection(true);
    ui->tw_UserDetails->horizontalHeader()->setSectionsClickable(false);
    window = new CAdminAuthentication (parent);
    ui->pb_AddUser->show();
    ui->pb_DeleteUser->show();
    ui->stackedWidget->setCurrentIndex(0);

    if(g_Handles.m_UserDetails.m_sUserName == "Administrator")
    {
      ui->pb_ChngPwd->setDisabled(false);
    }
    else
    {
        ui->pb_ChngPwd->setDisabled(true);
    }

    ui->pb_DeleteUser->setDisabled(true);
    int iNoofUsers = 0;
    int iRetVal = manage.DP_UML_Init_UMLLib(255, 32, 32, 6, 6, g_arrAuthfileName);
    if (iRetVal == -77)
    {
        QMessageBox :: information(this, "Error", "Authentication file corrupted", QMessageBox::Ok);
        exit(0);
    }

    S_USER_ACCOUNTS stArrNoofusers[255];
    QString str = "";

    if(manage.DP_UML_GetNoOfUsers(&iNoofUsers) == 0)
    {
        if(iNoofUsers == 0)
        {
            QString privelage;
            privelage = "Adminuser";
            QByteArray byte;
            byte = privelage.toLatin1();
            manage.DP_UML_AddNew_User((char*)"Administrator", (char*) "admin", (char*) "admin", byte.data());
        }
    }

    if(manage.DP_UML_GetNoOfUsers(&iNoofUsers) == 0)
    {
        /* Get the user names */
        if(manage.DP_UML_GetNoOfUserNames(stArrNoofusers) == 0)
        {
            for(int iLoop = 0; iLoop < iNoofUsers; iLoop++)
            {
                int icount = ui->tw_UserDetails->rowCount();
                ui->tw_UserDetails->insertRow(icount);
                str.sprintf("%s", stArrNoofusers[iLoop].m_szUserName);
                ui->tw_UserDetails->setItem(iLoop, 0, new QTableWidgetItem(str));
            }
        }
    }

    if(iNoofUsers == 0)
    {
        ui->tw_UserDetails->setItem(0, 0, new QTableWidgetItem("Administrator"));
    }

    int iNoOfUsr;
    manage.DP_UML_GetNoOfUsers(&iNoOfUsr);
    int iRetvalue = manage.update_file_checksum(g_arrAuthfileName, iNoOfUsr);
    Msg_display(iRetvalue);
}

CUserManagement::~CUserManagement()
{
    delete ui;
}

/*******************************************************************************
 * Name                      : on_pb_AddUser_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To open the add user window.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::on_pb_AddUser_clicked()
{
    window->exec();
    if(window->iPwdCrt)
    {
        window->iPwdCrt = 0;
        ui->stackedWidget->setCurrentIndex(1);
    }
}

/*******************************************************************************
 * Name                      : on_pb_Close_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To close the user management window.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::on_pb_Close_clicked()
{
    this->close();
}

/*******************************************************************************
 * Name                      : on_pb_AddUsrCnfirmNewUsrPwd_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : g_arrAuthfileName
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To verify password and add new user.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::on_pb_AddUsrCnfirmNewUsrPwd_clicked()
{
    Usr_management manage;
    int RetVal = 0;
    RetVal = manage.check_file_checksum(g_arrAuthfileName);
    if (RetVal == -77 || RetVal == -76)
    {
        Msg_display(RetVal);
        exit(0);
    }

    char iRetVal = 0;
    QString privelage;
    if(ui->cmb_UserPrevilege->currentIndex() == 0)
    {
            privelage = "Adminuser";
    }
    else
    {
            privelage = "user";
    }
    QByteArray byte;
    byte = privelage.toLatin1();

    //Adding New User
    iRetVal =  manage.DP_UML_AddNew_User(ui->le_NewUsrName->text().toLatin1().data(), ui->le_NewPwd->text().toLatin1().data(), ui->le_NewCnfirmPwd->text().toLatin1().data(), byte.data());
    if(iRetVal == 0)
    {
        updateuser();
        QMessageBox :: information(this, "Information", "User added successfully");
        ui->le_NewCnfirmPwd->clear();
        ui->le_NewPwd->clear();
        ui->le_NewUsrName->clear();
    }
    else
    {
        Msg_display(iRetVal);
    }
}

/*******************************************************************************
 * Name                      : updateuser
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To update the user details to the table widget.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::updateuser()
{
    int iNoofUsers = 0;
    QString str = "";
    S_USER_ACCOUNTS stArrNoofusers[255];
    Usr_management manage;
    ui->tw_UserDetails->clearContents();

    /** Memset the no of user array **/
    memset (stArrNoofusers, 0, sizeof (stArrNoofusers));

    /* Get the no of user */
    if(manage.DP_UML_GetNoOfUsers(&iNoofUsers) == 0)
    {
        /* Get the user names */
        if(manage.DP_UML_GetNoOfUserNames(stArrNoofusers) == 0)
        {
            for(int iLoop = 0; iLoop < iNoofUsers; iLoop++)
            {
                int icount = ui->tw_UserDetails->rowCount();
                if(iNoofUsers > icount )
                {
                    ui->tw_UserDetails->insertRow(icount);
                }
                else if(icount > iNoofUsers)
                {
                    ui->tw_UserDetails->removeRow(icount);
                }
                str.sprintf("%s", stArrNoofusers[iLoop].m_szUserName);
                ui->tw_UserDetails->setItem(iLoop, 0, new QTableWidgetItem(str));
            }
        }
    }
    int iNoOfUsr;
    manage.DP_UML_GetNoOfUsers(&iNoOfUsr);
    int iRetval = manage.update_file_checksum(g_arrAuthfileName, iNoOfUsr);
    Msg_display(iRetval);
}

/*******************************************************************************
 * Name                      : on_pb_AddUsrCancel_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To clear the GUI fields on cancelling.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::on_pb_AddUsrCancel_clicked()
{
    ui->le_NewCnfirmPwd->clear();
    ui->le_NewPwd->clear();
    ui->le_NewUsrName->clear();
    update();
    ui->stackedWidget->setCurrentIndex(0);
}

/*******************************************************************************
 * Name                      : on_pb_ChngPwd_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : g_arrAuthfileName
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To open the change password window.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::on_pb_ChngPwd_clicked()
{
    Usr_management manage;
    int RetVal = 0;
    RetVal = manage.check_file_checksum(g_arrAuthfileName);
    if (RetVal == -77 || RetVal == -76)
    {
        Msg_display(RetVal);
        exit(0);
    }

    window->exec();
    if(window->iPwdCrt)
    {
        window->iPwdCrt = 0;
        int row = ui->tw_UserDetails->currentRow();
        QString str;
        QTableWidgetItem* itm = ui->tw_UserDetails->item( row, 0 );
        if (itm)
        {
            str = itm->text();
            ui->le_AdChgUsername->setText(str);
            ui->stackedWidget->setCurrentIndex(2);
        }
    }
}

/*******************************************************************************
 * Name                      : on_pb_AdChgCnfirmPwd_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : g_arrAuthfileName
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To verify and change the password of the admin.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::on_pb_AdChgCnfirmPwd_clicked()
{
    Usr_management manage;
    int RetVal = 0;
    RetVal = manage.check_file_checksum(g_arrAuthfileName);
    if (RetVal == -77 || RetVal == -76)
    {
        Msg_display(RetVal);
        exit(0);
    }
    int iRetVal = 0;
    if (ui->pb_AdminChgCancel->text().compare(QString("Cancel")) == 0)
    {
        iRetVal = manage.DP_UML_Change_Password(ui->le_AdChgUsername->text().toLatin1().data(), ui->le_AdChgPwd->text().toLatin1().data(), ui->le_AdChgCnfirmPwd->text().toLatin1().data(), ui->leCnfrmPass->text().toLatin1().data());
    }
    else
    {
        iRetVal = manage.DP_UML_Admin_Change_Password(ui->le_AdChgUsername->text().toLatin1().data(), ui->le_AdChgPwd->text().toLatin1().data(), ui->le_AdChgCnfirmPwd->text().toLatin1().data());
    }
    if(iRetVal == 0)
    {
        int iNoOfUsr;
        manage.DP_UML_GetNoOfUsers(&iNoOfUsr);
        int iRetvalue = manage.update_file_checksum(g_arrAuthfileName, iNoOfUsr);
        Msg_display(iRetvalue);
        QMessageBox :: information(this, "Information", "Password  changed successfully");
    }
    else
    {
        Msg_display(iRetVal);
    }
    ui->le_AdChgPwd->clear();
    ui->le_AdChgCnfirmPwd->clear();
    ui->leCnfrmPass->clear();
    ui->le_AdChgPwd->setFocus();
}

/*******************************************************************************
 * Name                      : on_pb_AdminChgCancel_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To cancel the changing of admin password and go to user management window.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::on_pb_AdminChgCancel_clicked()
{
    if (ui->pb_AdminChgCancel->text().compare(QString("Cancel")) == 0)
    {
        this->close();
    }
    else
    {
        ui->stackedWidget->setCurrentIndex(0);
    }
//    ui->le_AdChgUsername->clear();
//    ui->le_AdChgPwd->clear();
//    ui->le_AdChgCnfirmPwd->clear();
//    ui->stackedWidget->setCurrentIndex(0);
}

/*******************************************************************************
 * Name                      : on_pb_DeleteUser_clicked
 * Author                    : Kishore kumar A
 * Global Variables affected : g_arrAuthfileName
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To remove a user.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::on_pb_DeleteUser_clicked()
{
    if(ui->tw_UserDetails->currentRow() == 0)
    {
        QMessageBox::information(this, "Information", "Administrator account cannot be deleted...!");
        return;
    }

    if (m_qstrLoggedinUser.compare(m_qstrSelectedUser, Qt::CaseInsensitive) == 0)
    {
        int iResponse = QMessageBox::question(this, "Alert", "Do you really want to remove yourself?", QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
        if (iResponse == QMessageBox::No)
        {
            return;
        }
    }

    Usr_management manage;
    int RetVal = 0;
    RetVal = manage.check_file_checksum(g_arrAuthfileName);
    if (RetVal == -77 || RetVal == -76)
    {
        Msg_display(RetVal);
        exit(0);
    }
    int iRetVal = 0;
    QTableWidgetItem* itm;int row;QString str = "";
    window->exec();
    if(window->iPwdCrt)
    {
        window->iPwdCrt = 0;
        row = ui->tw_UserDetails->currentRow();
        itm = ui->tw_UserDetails->item(row, 0 );
        if (itm)
        {
            str = itm->text();
        }
        switch(QMessageBox::question(this, "Information", "Do you want to remove the selected user?", QMessageBox::No, QMessageBox::Yes))
        {
        case QMessageBox::Yes:
            iRetVal = manage.DP_UML_Delete_User(str.toLatin1().data());

            if(iRetVal == 0)
            {
                QMessageBox :: information(this, "Information", "User deleted successfully");
                ui->tw_UserDetails->removeRow(row);
                updateuser();
            }
            else
            {
                Msg_display(iRetVal);
            }
            break;
        case QMessageBox::No:
            break;
        }
    }
}

/*******************************************************************************
 * Name                      : on_tw_UserDetails_cellClicked
 * Author                    : Manoj Loganathan
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : July 07, 2021
 * Reason for Revising       : to reduce code lines
 ***************************************************************************//**
 * To check for username availability and enable/disable usermanagement options.
 *  * \param iRow - Row number of the selected cell in the table.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::on_tw_UserDetails_cellClicked(int iRow)
{
    Q_UNUSED(iRow);
#if 0
    if (iRow == 0)
    {
        ui->pb_DeleteUser->setDisabled(true);
    }
    else
    {
        ui->pb_DeleteUser->setDisabled(false);
    }
#endif
}

/*******************************************************************************
 * Name                      : Msg_display
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To display corresponding error message for the error code.
 *  * \param iErrorValue - Error Code to get error message.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::Msg_display(int iErrorValue)
{
    switch(iErrorValue)
    {
    case -99:
        QMessageBox :: information(this, "Error", "Invalid Username");
        break;
    case -98:
        QMessageBox :: information(this, "Error", "Invalid Password");
        break;
    case -97:
        QMessageBox :: information(this, "Error", "Invalid Old Password");
        break;
    case -96:
        QMessageBox :: information(this, "Error", "Invalid Confirm Password");
        break;
    case -94:
        QMessageBox :: information(this, "Error", "User already exists");
        break;
    case -90:
        QMessageBox :: information(this, "Error", "Username must be of minimum 6 characters");
        break;
    case -89:
        QMessageBox :: information(this, "Error", "Username must be less than 32 characters");
        break;
    case -88:
        QMessageBox :: information(this, "Error", "Password must be of minimum 6 characters");
        break;
    case -87:
        QMessageBox :: information(this, "Error", "Password must be less than 32 characters");
        break;
    case -86:
        QMessageBox :: information(this, "Error", "Maximum number of users reached");
        break;
    case -85:
        QMessageBox :: information(this, "Error", "Password must contain atleast one special character");
        break;
    case -84:
        QMessageBox :: information(this, "Error", "Password must contain atleast one numeric character");
        break;
    case -82:
        QMessageBox :: information(this, "Error", "Username must not contain any special characters other than '.'");
        break;
    case -81:
        QMessageBox :: information(this, "Error", "Username field is empty");
        break;
    case -80:
        QMessageBox :: information(this, "Error", "Password field is empty");
        break;
    case -79:
        QMessageBox :: information(this, "Error", "NewPassword field is empty");
        break;
    case -78:
        QMessageBox :: information(this, "Error", "ConfirmPassword field is empty");
        break;
    case -77:
        QMessageBox :: information(this, "Error", "Authentication file corrupted", QMessageBox::Ok);
        break;
    case -76:
        QMessageBox :: information(this, "Error", "Authentication file not found", QMessageBox::Ok);
        break;
    default:
        break;
    }
}

void CUserManagement::execChangePassword()
{
    ui->stackedWidget->setCurrentIndex(2);
    ui->le_AdChgUsername->setText(m_qstrLoggedinUser);
    ui->pb_AdminChgCancel->setText("Cancel");
    ui->lbAdmNewPass->setText("Current Password");
    ui->le_AdChgPwd->setToolTip ("Enter Current Password");
    ui->lbAdmCnfrmPass->setText("New Password");
    ui->le_AdChgCnfirmPwd->setToolTip ("Enter New Password");
    ui->lbCnfrmPass->setVisible(true);
    ui->lbCnfrmPass->setText("Confirm Password");
    ui->leCnfrmPass->setToolTip ("Enter again the New Password");
    ui->leCnfrmPass->setVisible(true);
    this->exec();
}

void CUserManagement::execUserMgmt()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->pb_AdminChgCancel->setText("Close");
    ui->lbAdmNewPass->setText("New Password");
    ui->le_AdChgPwd->setToolTip ("Enter New Password");
    ui->lbAdmCnfrmPass->setText("Confirm Password");
    ui->le_AdChgCnfirmPwd->setToolTip ("Enter again the New Password");
    ui->lbCnfrmPass->setVisible(false);
    ui->leCnfrmPass->setVisible(false);
    this->exec();
}

/*******************************************************************************
 * Name                      : closeEvent
 * Author                    : Kishore kumar A
 * Global Variables affected : NIL
 * Created Date              : Mar 11, 2019
 * Revision Date             : NIL
 * Reason for Revising       : NIL
 ***************************************************************************//**
 * To set the usermanagement window while closing.
 *  * \param NIL.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::closeEvent(QCloseEvent *)
{
    ui->stackedWidget->setCurrentIndex(0);
}

/*******************************************************************************
 * Name                      : on_le_NewUsrName_textChanged
 * Author                    : Manoj Loganathan
 * Global Variables affected : NIL
 * Created Date              : Jul 06, 2021
 * Revision Date             : NIL
 * Reason for Revising       : NLL
 ***************************************************************************//**
  * This function(slot for new username line editor) will be used to restrict spaces
  * in username string.
  * \return No Return values.
*******************************************************************************/
void CUserManagement::on_le_NewUsrName_textChanged(const QString &in_str)
{
    if(in_str == " ")
    {
        ui->le_NewUsrName->setText("");
        return;
    }
    else if(in_str.endsWith(" "))
    {
        QString temp = in_str;
        temp.chop(1);
        ui->le_NewUsrName->setText(temp);
    }
}

/*******************************************************************************
 * Name                      : on_tw_UserDetails_itemSelectionChanged
 * Author                    : Manoj Loganathan
 * Global Variables affected : NIL
 * Created Date              : Jul 06, 2021
 * Revision Date             : NIL
 * Reason for Revising       : NLL
 ***************************************************************************//**
 * To check for username availability and enable/disable usermanagement options.
 * * \return No return values.
*******************************************************************************/
void CUserManagement::on_tw_UserDetails_itemSelectionChanged()
{
    on_tw_UserDetails_cellClicked(ui->tw_UserDetails->currentRow());
}

/************************************ END OF FILE *****************************/

void CUserManagement::on_tw_UserDetails_itemClicked(QTableWidgetItem *item)
{
    m_qstrSelectedUser = item->text();
    ui->pb_ChngPwd->setEnabled(false);
    ui->pb_DeleteUser->setEnabled(false);
#if 0
    if (m_qstrSelectedUser.compare(m_qstrLoggedinUser, Qt::CaseInsensitive) == 0 || m_qstrLoggedinUser.compare("Administrator", Qt::CaseInsensitive) == 0)
    {
        ui->pb_ChngPwd->setEnabled(true);
        ui->pb_DeleteUser->setEnabled(true);
    }
    else
    {
        ui->pb_ChngPwd->setEnabled(false);
        ui->pb_DeleteUser->setEnabled(false);
    }

    if (m_qstrSelectedUser.compare(m_qstrLoggedinUser, Qt::CaseInsensitive) == 0)
    {
        ui->pb_DeleteUser->setText("Remove Myself");
    }
    else
    {
        ui->pb_DeleteUser->setText("Remove User");
    }

    if ((m_qstrLoggedinUserPrevil == SUPER_USER) && m_qstrSelectedUser.compare("Administrator", Qt::CaseInsensitive) != 0)
    {
        ui->pb_ChngPwd->setEnabled(true);
    }
#endif
    if (m_qstrSelectedUser.compare("Administrator", Qt::CaseInsensitive) == 0)
    {
        ui->pb_DeleteUser->setText("Remove User");
        ui->pb_DeleteUser->setEnabled(false);
        if (m_qstrLoggedinUser.compare("Administrator", Qt::CaseInsensitive) == 0)
        {
            ui->pb_ChngPwd->setEnabled(true);
        }
        else
        {
            ui->pb_ChngPwd->setEnabled(false);
        }
    }
    else
    {
        if ((m_iLoggedinUserPrevil == SUPER_USER) || (m_qstrLoggedinUser.compare(m_qstrSelectedUser, Qt::CaseInsensitive) == 0))
        {
            ui->pb_ChngPwd->setEnabled(true);
            ui->pb_DeleteUser->setEnabled(true);
        }
        else
        {
            ui->pb_ChngPwd->setEnabled(false);
            ui->pb_DeleteUser->setEnabled(false);
        }

        if (m_qstrLoggedinUser.compare(m_qstrSelectedUser, Qt::CaseInsensitive) == 0)
        {
            ui->pb_DeleteUser->setText("Remove Myself");
        }
        else
        {
            ui->pb_DeleteUser->setText("Remove User");
        }

    }
}
