#ifndef LOADINGSCREEN_H
#define LOADINGSCREEN_H

#include <QDialog>
#include <QMovie>
#include <QLabel>

namespace Ui {
class CLoadingScreen;
}

class CLoadingScreen : public QDialog
{
    Q_OBJECT

public:
    explicit CLoadingScreen(QWidget *parent = 0);
    ~CLoadingScreen();

    QMovie *movieLoading;

    void Start();
    void Stop();

    private:
        Ui::CLoadingScreen *ui;
};

#endif // LOADINGSCREEN_H
