/**
* \file dp_pci755_wrapper.cpp
* \brief This file contains the wrapper functions for DP-PCI-755
*
* \author aravinth.rajalingam
* \date 21 November, 2022
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dppci755_wrapper.h"

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_Initialize(U16BIT in_u16NoOfBoards, SDPPCI755_DeviceLocation in_pSDeviceLocation[], SDPPCI755APP_DEVICELOC out_pSDeviceLocation[])
{
	PSDPPCI755_DEVICE_LOCATION pSAllDevLocations;
	//    SDPPCI755_DeviceDetails SDeviceLocation;
	U8BIT u8BoardNo = DPPCI755_INIT_0;
	U8BIT u8Loop = DPPCI755_INIT_0;

#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u16NoOfBoards);
	Q_UNUSED(in_pSDeviceLocation);
	Q_UNUSED(out_pSDeviceLocation);
	Q_UNUSED(pSAllDevLocations);
	Q_UNUSED(u8BoardNo);
	Q_UNUSED(u8Loop);
#endif

#ifdef _DPPCI755_DRV_ENABLE_
	/* Get the total number of boards detected */
	m_s32RetVal = DPPCI755_GetTotalDeviceFound(&m_u16NoOfBoards);
	if (m_s32RetVal != DPPCI755_SUCCESS)
	{
		DPPCI755_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
		return DPPCI755_FAILURE;
	}

    if (m_u16NoOfBoards <= 0)
    {
        sprintf(m_szErrMsg, "No devices found");
        return DPPCI755_FAILURE;
    }

	/* Allocate memory to store location of all detected boards */
	pSAllDevLocations = (PSDPPCI755_DEVICE_LOCATION) malloc(sizeof(SDPPCI755_DEVICE_LOCATION) * m_u16NoOfBoards);
	if (pSAllDevLocations == NULL)
	{
		strcpy(m_szErrMsg, "Cannot allocate memory for all device location");
		m_s32RetVal = -1;
		return DPPCI755_FAILURE;
	}

	/* Get all board locations that are detected */
	m_s32RetVal = DPPCI755_GetAllDeviceLocations(pSAllDevLocations, m_u16NoOfBoards);
	if (m_s32RetVal != DPPCI755_SUCCESS)
	{
		DPPCI755_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
		free(pSAllDevLocations);
		return DPPCI755_FAILURE;
	}

	if((in_pSDeviceLocation == NULL) || (m_u16NoOfBoards == DPPCI755_MAX_BOARDS) || (m_u16NoOfBoards == DPPCI755_INIT_0))
	{
        for(u8BoardNo = DPSCM_INIT_0; u8BoardNo < (m_u16NoOfBoards); u8BoardNo++)
		{
			/* open the found boards */
			m_s32RetVal = DPPCI755_Open(&pSAllDevLocations[u8BoardNo], &m_vpHandle[u8BoardNo]);
			if(m_s32RetVal != DPPCI755_SUCCESS)
			{
				DPPCI755_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
				free(pSAllDevLocations);
				return DPPCI755_FAILURE;
			}

			/* Reset all the opened boards */
			m_s32RetVal = DPPCI755_Reset(m_vpHandle[u8BoardNo]);
			if (m_s32RetVal != DPPCI755_SUCCESS)
			{
				DPPCI755_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
				free(pSAllDevLocations);
				return DPPCI755_FAILURE;
			}

			/* Execute self test for opened boards */
			m_s32RetVal = DPPCI755_SelfTest(m_vpHandle[u8BoardNo]);
			if (m_s32RetVal != DPPCI755_SUCCESS)
			{
				DPPCI755_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
				free(pSAllDevLocations);
				return DPPCI755_FAILURE;
			}

            out_pSDeviceLocation[u8BoardNo].m_s8BoardSts = DPPCI755_BRD_STS_EN;
            out_pSDeviceLocation[u8BoardNo].m_u8BusNo = pSAllDevLocations[u8BoardNo].u.pci.m_u8BusNo;
            out_pSDeviceLocation[u8BoardNo].m_u8FunctionNo = pSAllDevLocations[u8BoardNo].u.pci.m_u8FunctionNo;
            out_pSDeviceLocation[u8BoardNo].m_u8SlotNo = pSAllDevLocations[u8BoardNo].u.pci.m_u8SlotNo;
		}
	}
	else
	{
		for(u8Loop = 0; u8Loop < in_u16NoOfBoards; u8Loop++)
		{
			for(u8BoardNo = 0; u8BoardNo < m_u16NoOfBoards; u8BoardNo++)
			{
                if((pSAllDevLocations[u8BoardNo].u.pci.m_u8SlotNo == in_pSDeviceLocation[u8Loop].u8SlotNo)\
                        && (pSAllDevLocations[u8BoardNo].u.pci.m_u8BusNo ==  in_pSDeviceLocation[u8Loop].u8BusNo)\
                        && (pSAllDevLocations[u8BoardNo].u.pci.m_u8FunctionNo == in_pSDeviceLocation[u8Loop].u8FunctionNo))
				{
                    out_pSDeviceLocation[u8BoardNo].m_u8BusNo = pSAllDevLocations[u8BoardNo].u.pci.m_u8BusNo;
                    out_pSDeviceLocation[u8BoardNo].m_u8FunctionNo = pSAllDevLocations[u8BoardNo].u.pci.m_u8FunctionNo;
                    out_pSDeviceLocation[u8BoardNo].m_u8SlotNo = pSAllDevLocations[u8BoardNo].u.pci.m_u8SlotNo;
                    out_pSDeviceLocation[u8Loop].m_s8BoardSts = DPPCI755_BRD_STS_EN;
					break;
				}
			}

			if(u8BoardNo == m_u16NoOfBoards)
			{
                out_pSDeviceLocation[u8BoardNo].m_u8BusNo = pSAllDevLocations[u8BoardNo].u.pci.m_u8BusNo;
                out_pSDeviceLocation[u8BoardNo].m_u8FunctionNo = pSAllDevLocations[u8BoardNo].u.pci.m_u8FunctionNo;
                out_pSDeviceLocation[u8BoardNo].m_u8SlotNo = pSAllDevLocations[u8BoardNo].u.pci.m_u8SlotNo;
                out_pSDeviceLocation[u8Loop].m_s8BoardSts = DPPCI755_BRD_STS_DIS;
				continue;
			}

			m_s32RetVal = DPPCI755_Open(&pSAllDevLocations[u8BoardNo], &m_vpHandle[u8BoardNo]);
			if(m_s32RetVal != DPPCI755_SUCCESS)
			{
				DPPCI755_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
				free(pSAllDevLocations);
				return DPPCI755_FAILURE;
			}

			/* Reset all the opened boards */
			m_s32RetVal = DPPCI755_Reset(m_vpHandle[u8BoardNo]);
			if (m_s32RetVal != DPPCI755_SUCCESS)
			{
				DPPCI755_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
				free(pSAllDevLocations);
				return DPPCI755_FAILURE;
			}

			/* Execute self test for opened boards */
			m_s32RetVal = DPPCI755_SelfTest(m_vpHandle[u8BoardNo]);
			if (m_s32RetVal != DPPCI755_SUCCESS)
			{
				DPPCI755_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
				free(pSAllDevLocations);
				return DPPCI755_FAILURE;
			}
		}
    }

#else
	m_s32RetVal = DPPCI755_FAILURE;
	sprintf(m_szErrMsg, "DP-PCI-755 Driver Not Enabled");
	return DPPCI755_FAILURE;
#endif

    free(pSAllDevLocations);

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_Close(U8BIT in_u8BoardNo)
{
	U8BIT u8BoardId;
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(u8BoardId);
	Q_UNUSED(in_u8BoardNo);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
    if (in_u8BoardNo != DPPCI755_INIT_0)
	{
        if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
		{
            m_s32RetVal = DPPCI755_Close(m_vpHandle[in_u8BoardNo]);
			CHECK_RETVAL;
		}
		else
		{
			sprintf(m_szErrMsg, "Invalid board number");
			return DPPCI755_FAILURE;
		}
	}
	else
	{
		for (u8BoardId = DPPCI755_INIT_0; u8BoardId < m_u16NoOfBoards; u8BoardId++)
		{
			m_s32RetVal = DPPCI755_Close(m_vpHandle[u8BoardId]);
			CHECK_RETVAL;
		}
	}
#endif
	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_Reset(U8BIT in_u8BoardNo)
{
	U8BIT u8BoardId;
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(u8BoardId);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
    if (in_u8BoardNo != DPPCI755_INIT_0)
	{
        if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
		{
            m_s32RetVal = DPPCI755_Reset(m_vpHandle[in_u8BoardNo]);
			CHECK_RETVAL;
		}
		else
		{
			sprintf(m_szErrMsg, "Invalid board number");
			return DPPCI755_FAILURE;
		}
	}
	else
	{
		for (u8BoardId = DPPCI755_INIT_0; u8BoardId < m_u16NoOfBoards; u8BoardId++)
		{
			m_s32RetVal = DPPCI755_Reset(m_vpHandle[u8BoardId]);
			CHECK_RETVAL;
		}
	}
#endif
	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_GetDriverDetails(PSDPPCI755_DRIVER_DETAILS out_pSDriverDetails)
{

#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(out_pSDriverDetails);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
	if (out_pSDriverDetails == NULL)
	{
		sprintf(m_szErrMsg, "Invalid pointer to store driver details");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}

	m_s32RetVal = DPPCI755_GetDriverDetails(out_pSDriverDetails);
	CHECK_RETVAL;
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_GetDeviceLocation(U8BIT in_u8BoardNo, PSDPPCI755_DEVICE_LOCATION out_pSDeviceLocation)
{
	U8BIT u8BoardId = DPSCM_INIT_0;

#ifndef _DPPCI755_DRV_ENABLE_	// Temp Change to ifndef
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(u8BoardId);
	Q_UNUSED(out_pSDeviceLocation);
#endif
#ifdef _DPPCI755_DRV_ENABLE_	// Temp Change to ifdef
	if (out_pSDeviceLocation == NULL)
	{
		sprintf(m_szErrMsg, "Invalid pointer to store device location");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}

	if (in_u8BoardNo == DPPCI755_INIT_0)
	{
		for (u8BoardId = DPPCI755_INIT_0; u8BoardId < m_u16NoOfBoards; u8BoardId++)
		{
			m_s32RetVal = DPPCI755_GetDeviceLocation (m_vpHandle[u8BoardId], &out_pSDeviceLocation[u8BoardId]);
			CHECK_RETVAL;
		}
	}
	else
	{
        if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
		{
            m_s32RetVal = DPPCI755_GetDeviceLocation (m_vpHandle[in_u8BoardNo], out_pSDeviceLocation);
			CHECK_RETVAL;
		}
		else
		{
			sprintf(m_szErrMsg, "Invalid board number");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_GetFirmwareVersion(PU32BIT out_pu32FWVersion, U8BIT in_u8BoardNo)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(out_pu32FWVersion);
	Q_UNUSED(in_u8BoardNo);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
	U8BIT u8BoardId = DPPCI755_INIT_0;
	U32BIT u32FWVersion = DPPCI755_INIT_0;

	if (out_pu32FWVersion == NULL)
	{
		sprintf(m_szErrMsg, "Invalid pointer to store version value");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}

	if (in_u8BoardNo == DPPCI755_INIT_0)
	{
		for (u8BoardId = DPPCI755_INIT_0; u8BoardId < m_u16NoOfBoards; u8BoardId++)
		{
			m_s32RetVal = DPPCI755_GetFirmwareVersion(m_vpHandle[u8BoardId], &u32FWVersion);
			CHECK_RETVAL;

			out_pu32FWVersion[u8BoardId] = u32FWVersion;
		}
	}
	else
	{
        if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
		{
            m_s32RetVal = DPPCI755_GetFirmwareVersion(m_vpHandle[in_u8BoardNo], out_pu32FWVersion);
			CHECK_RETVAL;
		}
		else
		{
			sprintf(m_szErrMsg, "Invalid board number");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}
	}

#else
	*out_pu32FWVersion = 1;
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_WriteDWord(U8BIT in_u8BoardNo, U8BIT in_u8BarNo, U32BIT in_u32Offset, U32BIT in_u32DWordData)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_u8BarNo);
	Q_UNUSED(in_u32Offset);
	Q_UNUSED(in_u32DWordData);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
        m_s32RetVal = DPPCI755_WriteDWord(m_vpHandle[in_u8BoardNo], in_u8BarNo, in_u32Offset, in_u32DWordData);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_ReadDWord(U8BIT in_u8BoardNo, U8BIT in_u8BarNo, U32BIT in_u32Offset, PU32BIT out_pu32DWordData)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_u8BarNo);
	Q_UNUSED(in_u32Offset);
	Q_UNUSED(out_pu32DWordData);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
		if (out_pu32DWordData == NULL)
		{
			sprintf(m_szErrMsg, "Cannot allocate memory to store the read data");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}

        m_s32RetVal = DPPCI755_ReadDWord(m_vpHandle[in_u8BoardNo], in_u8BarNo, in_u32Offset, out_pu32DWordData);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_WriteMemBlock(U8BIT in_u8BoardNo, U8BIT in_u8BarNo, U32BIT in_u32Offset, U32BIT in_u32Bytes, PU32BIT in_pu32WrData)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_u8BarNo);
	Q_UNUSED(in_u32Offset);
	Q_UNUSED(in_u32Bytes);
	Q_UNUSED(in_pu32WrData);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
        m_s32RetVal = DPPCI755_WriteMemBlock(m_vpHandle[in_u8BoardNo], in_u8BarNo, in_u32Offset, in_u32Bytes, in_pu32WrData);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_ReadMemBlock(U8BIT in_u8BoardNo, U8BIT in_u8BarNo, U32BIT in_u32Offset, U32BIT in_u32Bytes, PU32BIT out_pu32RdData)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_u8BarNo);
	Q_UNUSED(in_u32Offset);
	Q_UNUSED(in_u32Bytes);
	Q_UNUSED(out_pu32RdData);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
		if (out_pu32RdData == NULL)
		{
			sprintf(m_szErrMsg, "Invalid pointer to store read data");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}

        m_s32RetVal = DPPCI755_ReadMemBlock(m_vpHandle[in_u8BoardNo], in_u8BarNo, in_u32Offset, in_u32Bytes, out_pu32RdData);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_SetDeviceShare(U8BIT in_u8BoardNo, bool in_bSetShare)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_bSetShare);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
	U8BIT u8BoardId = DPPCI755_INIT_0;

	if (in_u8BoardNo == DPPCI755_INIT_0)
	{
		for (u8BoardId = DPPCI755_INIT_0; u8BoardId < m_u16NoOfBoards; u8BoardId++)
		{
			m_s32RetVal = DPPCI755_SetDeviceShare(m_vpHandle[u8BoardId], in_bSetShare);
			CHECK_RETVAL;
		}
	}
	else
	{
        if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
		{
            m_s32RetVal = DPPCI755_SetDeviceShare(m_vpHandle[in_u8BoardNo], in_bSetShare);
			CHECK_RETVAL;
		}
		else
		{
			sprintf(m_szErrMsg, "Invalid Board number");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_SetMasterMode(U8BIT in_u8BoardNo, bool in_bSetMaster)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_bSetMaster);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
	U8BIT u8BoardId = DPPCI755_INIT_0;

	if (in_u8BoardNo == DPPCI755_INIT_0)
	{
		for (u8BoardId = DPPCI755_INIT_0; u8BoardId < m_u16NoOfBoards; u8BoardId++)
		{
			m_s32RetVal = DPPCI755_SetModeRegister(m_vpHandle[u8BoardId], in_bSetMaster);
			CHECK_RETVAL;
		}
	}
	else
	{
        if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
		{
			m_s32RetVal = DPPCI755_SetModeRegister(m_vpHandle[in_u8BoardNo], in_bSetMaster);
			CHECK_RETVAL;
		}
		else
		{
			sprintf(m_szErrMsg, "Invalid Board number");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_ConfigureAnaParameters(U8BIT in_u8BoardNo, SDPPCI755_CONFIG in_SConfigData)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_SConfigData);
#endif

#ifdef _DPPCI755_DRV_ENABLE_
	U8BIT u8BoardId = DPPCI755_INIT_0;
	
    if (in_SConfigData.m_u32GainIndex[DPPCI755_ADC_CH_1_IDX] > GAIN_1000)
    {
        in_SConfigData.m_u32GainIndex[DPPCI755_ADC_CH_1_IDX] = GAIN_1;
    }

    if (in_SConfigData.m_u32GainIndex[DPPCI755_ADC_CH_2_IDX] > GAIN_1000)
    {
        in_SConfigData.m_u32GainIndex[DPPCI755_ADC_CH_2_IDX] = GAIN_1;
    }

    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
        u8BoardId = in_u8BoardNo;

		m_s32RetVal = DPPCI755_SetDelay(m_vpHandle[u8BoardId], in_SConfigData.m_fDelay, in_SConfigData.m_bDelayInSec);
		CHECK_RETVAL;

		m_s32RetVal = DPPCI755_SetAmplitudeBias(m_vpHandle[u8BoardId], in_SConfigData.m_fAmplitude, in_SConfigData.m_fOffset, in_SConfigData.m_bRMS);
		CHECK_RETVAL;

		m_s32RetVal = DPPCI755_SetGain(m_vpHandle[u8BoardId], DPPCI755_CH_1, in_SConfigData.m_u32GainIndex[DPPCI755_ADC_CH_1_IDX]);
		CHECK_RETVAL;

#if 1
        m_s32RetVal = DPPCI755_SetGain(m_vpHandle[u8BoardId], DPPCI755_CH_2, in_SConfigData.m_u32GainIndex[DPPCI755_ADC_CH_2_IDX]);
		CHECK_RETVAL;
#endif
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_ConfigureWaveform(U8BIT in_u8BoardNo, SDPPCI755_CONFIG in_SConfigData)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_SConfigData);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
	U8BIT u8BoardId = DPPCI755_INIT_0;

    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
        u8BoardId = in_u8BoardNo;

        m_s32RetVal = DPPCI755_SetWaveform(m_vpHandle[u8BoardId], (in_SConfigData.m_u32WaveformType + 1));  // Sine wave starts from 1
		CHECK_RETVAL;

        if (in_SConfigData.m_u32WaveformType == E_WAVEINP_RAMP)
		{
			m_s32RetVal = DPPCI755_SetStopAngle(m_vpHandle[u8BoardId], DPPCI755_INIT_0);
			CHECK_RETVAL;

			m_s32RetVal = DPPCI755_SetStartAngle(m_vpHandle[u8BoardId], DPPCI755_INIT_0);
			CHECK_RETVAL;
		}

        if (in_SConfigData.m_u32WaveformType == E_WAVEINP_SINE)
		{
			m_s32RetVal = DPPCI755_SetFrequency(m_vpHandle[u8BoardId], in_SConfigData.m_fStartFreq, in_SConfigData.m_fEndFreq, in_SConfigData.m_fStepSize, in_SConfigData.m_bLog);
			CHECK_RETVAL;
		}
		else
		{
			m_s32RetVal = DPPCI755_SetTime(m_vpHandle[u8BoardId], (1 / in_SConfigData.m_fTime));
			CHECK_RETVAL;
		}

		m_s32RetVal = DPPCI755_SetNoOfCycles(m_vpHandle[u8BoardId], in_SConfigData.m_u32NoOfCycles);
		CHECK_RETVAL;

        if ((in_SConfigData.m_u32WaveformType == E_WAVEINP_SQUARE) || (in_SConfigData.m_u32WaveformType == E_WAVEINP_SINE))
		{
			m_s32RetVal = DPPCI755_SetStartAngle(m_vpHandle[u8BoardId], in_SConfigData.m_u32StartAngle);
			CHECK_RETVAL;
		}

		m_s32RetVal = DPPCI755_SetStopAngle(m_vpHandle[u8BoardId], in_SConfigData.m_u32StopAngle);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_SetReferenceVolt(U8BIT in_u8BoardNo, U8BIT in_u8ADCChannelNo, PSDPPCI755_CALIBDETAILS in_pSCalibDetails)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_u8ADCChannelNo);
	Q_UNUSED(in_pSCalibDetails);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
	U8BIT u8BoardId = DPPCI755_INIT_0;

    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
        u8BoardId = in_u8BoardNo;

		if ((in_u8ADCChannelNo != DPPCI755_ADC_CH_1_IDX) && (in_u8ADCChannelNo != DPPCI755_ADC_CH_2_IDX))
		{
			m_s32RetVal = DPPCI755_FAILURE;
			sprintf(m_szErrMsg, "Invalid ADC Channel Number");
			return DPPCI755_FAILURE;
		}
		m_s32RetVal = DPPCI755_SetRefVoltage(m_vpHandle[u8BoardId], in_u8ADCChannelNo, in_pSCalibDetails);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_CalibrationADC(U8BIT in_u8BoardNo, U8BIT in_u8ADCChannelNo, U8BIT in_u8CalibrationMode, PSDPPCI755_CALIBDETAILS in_pSCalibDetails, SDPPCI755_CONFIG in_SConfigData[])
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_u8ADCChannelNo);
	Q_UNUSED(in_u8CalibrationMode);
	Q_UNUSED(in_pSCalibDetails);
	Q_UNUSED(in_SConfigData);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
	U8BIT u8BoardId = DPPCI755_INIT_0;

    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
        u8BoardId = in_u8BoardNo;

		if ((in_u8ADCChannelNo != DPPCI755_ADC_CH_1_IDX) && (in_u8ADCChannelNo != DPPCI755_ADC_CH_2_IDX))
		{
			sprintf(m_szErrMsg, "Invalid ADC Channel Number");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}

		if ((in_u8CalibrationMode != CALIB_INTERNAL_MODE) && (in_u8CalibrationMode != CALIB_EXTERNAL_MODE))
		{
			sprintf(m_szErrMsg, "Invalid Calibration mode");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}

		m_s32RetVal = DPPCI755_SetRefVoltage(m_vpHandle[u8BoardId], in_u8ADCChannelNo, in_pSCalibDetails);
		CHECK_RETVAL;

		m_s32RetVal = DPPCI755_SetGain(m_vpHandle[u8BoardId], in_u8ADCChannelNo, in_SConfigData[u8BoardId].m_u32GainIndex[in_u8ADCChannelNo]);
		CHECK_RETVAL;

		m_s32RetVal = DPPCI755_DoADCCalibration(m_vpHandle[u8BoardId], in_u8ADCChannelNo, in_u8CalibrationMode);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_CalibrationDAC(U8BIT in_u8BoardNo, U8BIT in_u8RefLvl, FSINGLE in_fInpVolt, FSINGLE in_fMesVolt, U8BIT in_u8DacType)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_u8RefLvl);
	Q_UNUSED(in_fInpVolt);
	Q_UNUSED(in_fMesVolt);
	Q_UNUSED(in_u8DacType);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
	U8BIT u8BoardId = DPPCI755_INIT_0;

    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
        u8BoardId = in_u8BoardNo;

		if ((in_u8DacType != DPPCI755_DACTYPE_OFFSET) && (in_u8DacType != DPPCI755_DACTYPE_RAM))
		{
			sprintf(m_szErrMsg, "Invalid DAC Type");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}

		m_s32RetVal = DPPCI755_SetDACInputVoltage(m_vpHandle[u8BoardId], in_u8RefLvl, in_fInpVolt, in_u8DacType);
		CHECK_RETVAL;

		m_s32RetVal = DPPCI755_SetDACMeasuredVoltage(m_vpHandle[u8BoardId], in_u8RefLvl, in_fMesVolt, in_u8DacType);
		CHECK_RETVAL;

		m_s32RetVal = DPPCI755_DoDACCalibration(m_vpHandle[u8BoardId], in_u8DacType);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_StoreCalibData(U8BIT in_u8BoardNo)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
        m_s32RetVal = DPPCI755_StoreCalibration(m_vpHandle[in_u8BoardNo]);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_StartStopAcquisition(U8BIT in_u8BoardNo, bool in_bStart)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_bStart);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
	U8BIT u8BoardId = DPPCI755_INIT_0;
	U8BIT u8Status = DPPCI755_INIT_0;

	u8Status = in_bStart ? 1 : 0;

	if (in_u8BoardNo == DPPCI755_INIT_0)
	{
		for (u8BoardId = DPPCI755_INIT_0; u8BoardId < m_u16NoOfBoards; u8BoardId++)
		{
			if (in_bStart)
			{
				m_s32RetVal = DPPCI755_SetRelayOnOff(m_vpHandle[u8BoardId], u8Status);
				CHECK_RETVAL;
			}
			m_s32RetVal = DPPCI755_StartStopAcquisition(m_vpHandle[u8BoardId], u8Status);
			CHECK_RETVAL;
		}
	}
	else
	{
        if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
		{
			if (in_bStart)
			{
                m_s32RetVal = DPPCI755_SetRelayOnOff(m_vpHandle[in_u8BoardNo], u8Status);
				CHECK_RETVAL;
			}
            m_s32RetVal = DPPCI755_StartStopAcquisition(m_vpHandle[in_u8BoardNo], u8Status);
			CHECK_RETVAL;
		}
		else
		{
			sprintf(m_szErrMsg, "Invalid Board number");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_ReadAnalyzedData(U8BIT in_u8BoardNo, PU32BIT out_pu32DataCount, PSDPPCI755_ANALYZEDDATABUFFER out_pSAnaData)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(out_pu32DataCount);
	Q_UNUSED(out_pSAnaData);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
		if (out_pu32DataCount == NULL)
		{
			sprintf(m_szErrMsg, "Invalid pointer to store data count");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}
		if (out_pSAnaData == NULL)
		{
			sprintf(m_szErrMsg, "Invalid pointer to store analyzed data");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}

        m_s32RetVal = DPPCI755_ReadSineWaveData(m_vpHandle[in_u8BoardNo], out_pu32DataCount, out_pSAnaData);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_ReadRawData(U8BIT in_u8BoardNo, PU32BIT out_pu32DataCount, PSDPPCI755_RAWDATABUFFER out_pSRawData)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(out_pu32DataCount);
	Q_UNUSED(out_pSRawData);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
		if (out_pu32DataCount == NULL)
		{
			sprintf(m_szErrMsg, "Invalid pointer to store data count");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}
		if (out_pSRawData == NULL)
		{
			sprintf(m_szErrMsg, "Invalid pointer to store raw data");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}

        m_s32RetVal = DPPCI755_ReadRawData(m_vpHandle[in_u8BoardNo], out_pSRawData, out_pu32DataCount);
        qDebug("ReadRawData Wrapper Return : %d", m_s32RetVal);
//		CHECK_RETVAL;
        DPPCI755_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
        return  m_s32RetVal;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_ReadCurrentAnaData(U8BIT in_u8BoardNo, PSDPPCI755_ANALYZEDDATABUFFER out_pSCurrentAnaData)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(out_pSCurrentAnaData);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
		if (out_pSCurrentAnaData == NULL)
		{
			sprintf(m_szErrMsg, "Invalid pointer to store analyzed data");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}

        m_s32RetVal = DPPCI755_ReadCurrentData(m_vpHandle[in_u8BoardNo], out_pSCurrentAnaData);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_ReadADCValue(U8BIT in_u8BoardNo, PFSINGLE out_pfADCValue)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(out_pfADCValue);
#endif

#ifdef _DPPCI755_DRV_ENABLE_
    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
		if (out_pfADCValue == NULL)
		{
			sprintf(m_szErrMsg, "Invalid pointer to store ADC value");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}

        m_s32RetVal = DPPCI755_ReadADCValue(m_vpHandle[in_u8BoardNo], out_pfADCValue);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_ReadSineWaveData(U8BIT in_u8BoardNo, PU32BIT out_pu32DataCount, PSDPPCI755_ANALYZEDDATABUFFER out_pSAnaDataBuffer)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(out_pu32DataCount);
	Q_UNUSED(out_pSAnaDataBuffer);
#endif

#ifdef _DPPCI755_DRV_ENABLE_
    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
		if (out_pu32DataCount == NULL)
		{
			sprintf(m_szErrMsg, "Invalid pointer to store Data Count");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}

		if (out_pSAnaDataBuffer == NULL)
		{
			sprintf(m_szErrMsg, "Invalid pointer to store Analysed Data");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}

        m_s32RetVal = DPPCI755_ReadSineWaveData(m_vpHandle[in_u8BoardNo], out_pu32DataCount, out_pSAnaDataBuffer);
//		CHECK_RETVAL;
        DPPCI755_GetErrorMessage(m_s32RetVal, m_szErrMsg, sizeof(m_szErrMsg));
        return m_s32RetVal;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board Number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_GetStatusRegister(U8BIT in_u8BoardNo, PSDPPCI755_STATUS_REG out_pSStatusReg)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(out_pSStatusReg);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
		if (out_pSStatusReg == NULL)
		{
			sprintf(m_szErrMsg, "Invalid pointer to store Status register");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}

        m_s32RetVal = DPPCI755_GetStatusRegister(m_vpHandle[in_u8BoardNo], out_pSStatusReg);
		CHECK_RETVAL;
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_FAILURE;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_SelfTest(U8BIT in_u8BoardNo)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
	SDPPCI755_STATUS_REG SStatusReg;
    if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
	{
        //        m_s32RetVal = DPPCI755_SelfTest(m_vpHandle[in_u8BoardNo]);
        m_s32RetVal = DPPCI755_GetStatusRegister(m_vpHandle[in_u8BoardNo], &SStatusReg);
		CHECK_RETVAL;

		if (SStatusReg.m_u8SelfTestPassed == 1)
		{
			return DPPCI755_SUCCESS;
		}
		else
		{
			sprintf(m_szErrMsg, "Selftest failed");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}
	}
	else
	{
		sprintf(m_szErrMsg, "Invalid Board number");
		m_s32RetVal = DPPCI755_FAILURE;
		return DPPCI755_FAILURE;
	}
#endif

	return DPPCI755_FAILURE;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_SetRelayStatus(U8BIT in_u8BoardNo, bool in_bRelayOn)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_bRelayOn);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
	U8BIT u8BoardId = DPPCI755_INIT_0;
	U8BIT u8Status = DPPCI755_INIT_0;

	u8Status = in_bRelayOn ? 1 : 0;

	if (in_u8BoardNo == DPPCI755_INIT_0)
	{
		for (u8BoardId = DPPCI755_INIT_0; u8BoardId < m_u16NoOfBoards; u8BoardId++)
		{
			m_s32RetVal = DPPCI755_SetRelayOnOff(m_vpHandle[u8BoardId], u8Status);
			CHECK_RETVAL;
		}
	}
	else
	{
        if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
		{
            m_s32RetVal = DPPCI755_SetRelayOnOff(m_vpHandle[in_u8BoardNo], u8Status);
			CHECK_RETVAL;
		}
		else
		{
			sprintf(m_szErrMsg, "Invalid Board number");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}
	}
#endif

	return DPPCI755_SUCCESS;
}

S32BIT CDPPCI755Wrapper::DPPCI755Wrap_ResetBiasVoltage(U8BIT in_u8BoardNo, FSINGLE in_fVoltReductionAmt)
{
#ifndef _DPPCI755_DRV_ENABLE_
	Q_UNUSED(in_u8BoardNo);
	Q_UNUSED(in_fVoltReductionAmt);
#endif
#ifdef _DPPCI755_DRV_ENABLE_
	U8BIT u8BoardId = DPPCI755_INIT_0;

	if (in_u8BoardNo == DPPCI755_INIT_0)
	{
		for (u8BoardId = DPPCI755_INIT_0; u8BoardId < m_u16NoOfBoards; u8BoardId++)
		{
			m_s32RetVal = DPPCI755_EnableBiasReset(m_vpHandle[u8BoardId], BIAS_RESET_ENABLE);
			CHECK_RETVAL;

			m_s32RetVal = DPPCI755_ResetBias(m_vpHandle[u8BoardId], in_fVoltReductionAmt);
			CHECK_RETVAL;

			m_s32RetVal = DPPCI755_EnableBiasReset(m_vpHandle[u8BoardId], BIAS_RESET_DISABLE);
			CHECK_RETVAL;
		}
	}
	else
	{
        if ((in_u8BoardNo >= 0) && (in_u8BoardNo < m_u16NoOfBoards))
		{
            m_s32RetVal = DPPCI755_EnableBiasReset(m_vpHandle[in_u8BoardNo], BIAS_RESET_ENABLE);
			CHECK_RETVAL;

            m_s32RetVal = DPPCI755_ResetBias(m_vpHandle[in_u8BoardNo], in_fVoltReductionAmt);
			CHECK_RETVAL;

            m_s32RetVal = DPPCI755_EnableBiasReset(m_vpHandle[in_u8BoardNo], BIAS_RESET_DISABLE);
			CHECK_RETVAL;
		}
		else
		{
			sprintf(m_szErrMsg, "Invalid Board number");
			m_s32RetVal = DPPCI755_FAILURE;
			return DPPCI755_FAILURE;
		}
	}
#endif

	return DPPCI755_SUCCESS;
}

void CDPPCI755Wrapper::DPPCI755Wrap_GetLastErrorMessage(PS32BIT out_ps32ErrCode, PS8BIT out_ps8ErrMsg)
{
	if (out_ps32ErrCode != NULL)
	{
		*out_ps32ErrCode = m_s32RetVal;
	}

	if (out_ps8ErrMsg != NULL)
	{
		sprintf(out_ps8ErrMsg, "%s", m_szErrMsg);
	}
}

