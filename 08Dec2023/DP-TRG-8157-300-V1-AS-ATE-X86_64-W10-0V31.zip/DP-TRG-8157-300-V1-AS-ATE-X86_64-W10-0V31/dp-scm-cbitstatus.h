/**
* \file dp-scm-cbitstatus.h
* \brief This is the header file for dp-scm-cbitstatus.cpp
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef CBITSTATUS_H
#define CBITSTATUS_H

#include <QWidget>
#include <QThread>
#include <QDebug>
#include <QGroupBox>

#include "includes/dp-scm-macros.h"
#include "includes/dp-scm-structures.h"
#include "checksum.h"

#define READ_LSB(val) (val & 0x01)
#define CBIT_ID_COUNT   9

#define CBIT_MODE_SERVO 0
#define CBIT_MODE_DIAG  1

namespace Ui {
	class CCBITStatus;
}

class CCBITStatusThread : public QThread
{
    Q_OBJECT

public:
    explicit CCBITStatusThread(QObject *parent = 0);

    bool m_bIsRunning;
    int m_iRetVal;
    unsigned char m_ucCurrIdx;
    unsigned char m_arrucCBIT_ID[CBIT_ID_COUNT];
    SSCM_CBIT01STS m_SBitfault01;
    SSCM_BITSTATUS m_SBITStatus;

    void Start();
    void Stop();
    void run() override;

signals:
    void sig_updateActionLog(QString, int);
    void sig_updateCBITStatus(unsigned char, unsigned char);
};

class CCBITStatus : public QWidget
{
		Q_OBJECT

	public:
		explicit CCBITStatus(QWidget *parent = 0);
		~CCBITStatus();

		SSCM_CBIT01STS m_SBitfault01;
		SSCM_BITSTATUS m_SBITStatus;
        CCBITStatusThread *m_pthCBITThread;

		void resetLEDinGB(QGroupBox *in_gbGroupbox);

    private:
        Ui::CCBITStatus *ui;

    public slots:
        void slot_EnDisAzimuth(bool in_bIsAzimuth);
		void slot_resetCBITStatus();
        void slot_updateCBITStatus(unsigned char in_ucDiagID, unsigned char in_ucBITStatus);

	signals:
		void sig_updateActionLog(QString, int);
		void sig_changePage(int);
		void sig_updateCBITBar(PSSCM_CBIT01STS);
		void sig_resetCBITBar();

private slots:
        void on_pbStart_clicked();
};

#endif // CBITSTATUS_H
