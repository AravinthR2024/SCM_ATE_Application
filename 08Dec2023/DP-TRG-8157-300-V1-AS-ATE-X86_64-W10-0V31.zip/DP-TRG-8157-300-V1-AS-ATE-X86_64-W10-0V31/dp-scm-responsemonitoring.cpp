/**
* \file dp-scm-responsemonitoring.cpp
* \brief This file contains the code for Response Monitoring panel
*
* \author aravinth.rajalingam
* \date 17th Feb, 2023
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#include "dp-scm-responsemonitoring.h"
#include "ui_dp-scm-responsemonitoring.h"

extern S_GLOBAL g_SGlobal;
QVector <double> qvXAxis_Time, qvYAxisCmd, qvYAxis2Resp;
extern double g_dTime;

/*******************************************************************************
 * Name					: CResponseMonitoring
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Constructor
 ***************************************************************************//**
 * @brief	This function is the constructor of CResponseMonitoring class
 *
 * @param[in]	parent	Holds the reference to the parent
 *
 * @return	NA
 ******************************************************************************/
CResponseMonitoring::CResponseMonitoring(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CResponseMonitoring)
{
    ui->setupUi(this);

    m_qstrTCLogFileName = QString("");
    m_iSelectedTestCase = E_TC_INVALID;
    m_bIsGraphPlotted = false;
    m_bPlot3Tracers = false;

    m_pThFRAAcq = new CDataReadThread(this);
    m_pdCmdArr = NULL;

    m_ulLimit = 0;
    m_ulXLimit_L = 0;
    m_ulXLimit_U = 0;
    m_uiCurrIndx = 0;
    m_ui_X_Min = 0;
    m_ui_X_Max = 0;
    m_ui_Y_Min = 0;
    m_ui_Y_Max = 0;
    m_ui_Y2_Min = 0;
    m_ui_Y2_Max = 0;
    m_bEnableTracing_Gain = false;
    m_bEnableTracing_Phase = false;
    m_bIsGraphPlotted = false;

    /* Menus for Graph context menu */
    m_menuContextMenu = new QMenu("Context Menu", ui->widgetGraph);
    m_actClear = new QAction("&Clear Graph", m_menuContextMenu);
    m_actReset = new QAction("&Reset Graph", m_menuContextMenu);
    m_actDeleteLabels = new QAction("&Delete Selected Labels", m_menuContextMenu);
    m_actShowLegend = new QAction("&Show Legend", m_menuContextMenu);
    m_actTrace_Gain = new QAction("Trace &Gain Plot", m_menuContextMenu);
    m_actTrace_Phase = new QAction("Trace &Phase Plot", m_menuContextMenu);

    m_actShowLegend->setCheckable(true);
    m_actShowLegend->setChecked(false);
    m_actTrace_Gain->setCheckable(true);
    m_actTrace_Gain->setChecked(false);
    m_actTrace_Phase->setCheckable(true);
    m_actTrace_Phase->setChecked(false);

    connect(m_actClear, SIGNAL(triggered(bool)), this, SLOT(slot_contextMenu_Clear_triggered()));
    connect(m_actReset, SIGNAL(triggered(bool)), this, SLOT(slot_contextMenu_Reset_triggered()));
    connect(m_actDeleteLabels, SIGNAL(triggered(bool)), this, SLOT(slot_contextMenu_Delete_Labels()));
    connect (m_actShowLegend, SIGNAL(triggered(bool)), this, SLOT(slot_contextMenu_ShowHide_Legend_triggered(bool)));
    connect (m_actTrace_Gain, SIGNAL(triggered(bool)), this, SLOT(slot_contextMenu_Trace_Gain_triggered(bool)));
    connect (m_actTrace_Phase, SIGNAL(triggered(bool)), this, SLOT(slot_contextMenu_Trace_Phase_triggered(bool)));

    m_menuContextMenu->addAction(m_actClear);
    m_menuContextMenu->addAction(m_actReset);
    m_menuContextMenu->addAction(m_actDeleteLabels);
    m_menuContextMenu->addSeparator();
    m_menuContextMenu->addAction(m_actShowLegend);
    m_menuContextMenu->addAction(m_actTrace_Gain);
    m_menuContextMenu->addAction(m_actTrace_Phase);
    /********************************/

    slot_clearGraph();

    connect(ui->widgetGraph, SIGNAL(mouseRelease(QMouseEvent*)), this, SLOT(slot_contextMenuRequested(QMouseEvent*)));
    connect(ui->widgetGraph, SIGNAL(mouseDoubleClick(QMouseEvent*)), this, SLOT(slot_graphSavepoint(QMouseEvent*)));
    connect(ui->widgetGraph, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(slot_graphTracePoint(QMouseEvent*)));
}

/*******************************************************************************
 * Name					: ~CResponseMonitoring
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: Destructor
 ***************************************************************************//**
 * @brief	This function is the destructor of CResponseMonitoring class
 *
 * @param		NIL
 * @return	NA
 ******************************************************************************/
CResponseMonitoring::~CResponseMonitoring()
{
    free(m_pdCmdArr);

    delete ui;
}

/*******************************************************************************
 * Name					: initGraph
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To initialize graph
 ***************************************************************************//**
 * @brief	This function is used to initialize the graph data and appearance
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CResponseMonitoring::initGraph()
{
    /* Clear all graphs, tracers, tracer lines and tracer labels, if any */
    if (ui->widgetGraph->graphCount() > 0)
    {
        ui->widgetGraph->clearItems();
        ui->widgetGraph->clearGraphs();
    }

    /* Set user-interactions allowed in the graph plot -> Drag Range, Zoom Range */
    ui->widgetGraph->setInteractions(QCP::iNone);

    /* Show Legend, X-Axis, Y-Axis, Y2-Axis and Hide X2-Axis */
    m_actShowLegend->setChecked(false); // ui->widgetGraph->legend->setVisible(false);
    ui->widgetGraph->xAxis->setVisible(true);
    ui->widgetGraph->xAxis2->setVisible(false);
    ui->widgetGraph->yAxis->setVisible(true);
    ui->widgetGraph->yAxis2->setVisible(true);

    ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis);
    ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis2);

    /* Initializing tracers */
    initTracer();

    /* Change graph styling */
    setGraphAppearance();

    ui->widgetGraph->xAxis->grid()->setSubGridVisible(true);

    /* Make sure to replot to reflect the changes */
    ui->widgetGraph->replot();
}

/*******************************************************************************
 * Name					: initTracer
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To initialize tracers
 ***************************************************************************//**
 * @brief	This function is used to initialize tracers for the graph
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CResponseMonitoring::initTracer()
{
    /* Create a tracer(cursor) for 1st graph */
    m_pTracer = new QCPItemTracer(ui->widgetGraph);
    m_pTracer->setSelectable(false);

    /* Create tracer label (text on tracer) */
    m_pTracerLabel = new QCPItemText(ui->widgetGraph);
    m_pTracerLabel->setSelectable(false);
    m_pTracerLabel->setLayer("overlay");

    /* Make the tracer label change position with respect to the tracer */
    m_pTracerLabel->position->setParentAnchor(m_pTracer->position);
    m_pTracerLabel->position->setCoords(0,0);

    /* Create tracer line */
    m_pTracerLine = new QCPItemLine(ui->widgetGraph);
    m_pTracerLine->setSelectable(false);
    m_pTracerLine->start->setCoords(0, 0);
    m_pTracerLine->end->setCoords(0, 0);

    /* Creating tracer, tracer label for 2nd graph */
    m_pTracer2 = new QCPItemTracer(ui->widgetGraph);
    m_pTracer2->setSelectable(false);
    m_pTracer2->position->setType(QCPItemPosition::ptViewportRatio);
    m_pTracerLabel2 = new QCPItemText(ui->widgetGraph);
    m_pTracerLabel2->setSelectable(false);
    m_pTracerLabel2->setLayer("overlay");
    m_pTracerLabel2->position->setParentAnchor(m_pTracer2->position);
    m_pTracerLabel2->position->setCoords(0, 0);

    /* Change 1st tracer style */
    m_pTracer->setPen(QPen(TRACER1_COLOR));
    m_pTracer->setBrush(QBrush(TRACER1_COLOR));
    m_pTracer->setStyle(TRACER_STYLE);
    m_pTracer->setSize(TRACER_SIZE);

    /* Change 1st tracer label style */
    m_pTracerLabel->setPen(QPen(TRACER1_COLOR));
    m_pTracerLabel->setPositionAlignment(TRACER1_LABEL_POSITION);

    /* Change 2nd tracer style */
    m_pTracer2->setPen(QPen(TRACER2_COLOR));
    m_pTracer2->setBrush(QBrush(TRACER2_COLOR));
    m_pTracer2->setStyle(TRACER_STYLE);
    m_pTracer2->setSize(TRACER_SIZE);

    /* Change 2nd tracer label style */
    m_pTracerLabel2->setPen(QPen(TRACER2_COLOR));
    m_pTracerLabel2->setPositionAlignment(TRACER2_LABEL_POSITION);

    if (m_bPlot3Tracers)
    {
        /* Creating tracer, tracer label for 3rd graph */
        m_pTracer3 = new QCPItemTracer(ui->widgetGraph);
        m_pTracer3->position->setType(QCPItemPosition::ptViewportRatio);
        m_pTracerLabel3 = new QCPItemText(ui->widgetGraph);
        m_pTracerLabel3->setLayer("overlay");
        m_pTracerLabel3->position->setParentAnchor(m_pTracer3->position);
        m_pTracerLabel3->position->setCoords(0, 0);

        /* Change 3rd tracer style */
        m_pTracer3->setPen(QPen(TRACER3_COLOR));
        m_pTracer3->setBrush(QBrush(TRACER3_COLOR));
        m_pTracer3->setStyle(TRACER_STYLE);
        m_pTracer3->setSize(TRACER_SIZE);

        /* Change 3rd tracer label style */
        m_pTracerLabel3->setPen(QPen(TRACER3_COLOR));
        m_pTracerLabel3->setPositionAlignment(TRACER3_LABEL_POSITION);
    }

    /* Change tracer line style */
    m_pTracerLine->setPen(QPen(TRACER_LINE_COLOR));

    /* Hide tracer, tracer label, tracer line initially */
    m_pTracerLine->setVisible(false);
    m_pTracerLabel->setVisible(false);
    m_pTracer->setVisible(false);

    m_pTracer2->setVisible(false);
    m_pTracerLabel2->setVisible(false);
    if (m_bPlot3Tracers)
    {
        m_pTracer3->setVisible(false);
        m_pTracerLabel3->setVisible(false);
    }
}

/*******************************************************************************
 * Name					: setGraphAppearance
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To set the graph appearance
 ***************************************************************************//**
 * @brief	This function is used to set the graph styles
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CResponseMonitoring::setGraphAppearance()
{
    /* Create a Dash lined pen */
    QPen pen(Qt::DashLine);

    /* Set pen style for all axes */
    pen.setColor(GRID_COLOR);
    ui->widgetGraph->xAxis->grid()->setPen(pen);

    pen.setColor(Qt::lightGray);
    ui->widgetGraph->yAxis->grid()->setPen(pen);

    pen.setColor(Qt::darkGray);
    ui->widgetGraph->yAxis2->grid()->setPen(pen);

    ui->widgetGraph->xAxis->grid()->setVisible(true);
    ui->widgetGraph->yAxis->grid()->setVisible(true);
    ui->widgetGraph->yAxis2->grid()->setVisible(true);

    /* Change X-axis subgrid style */
    pen.setColor(SUBGRID_COLOR);
    ui->widgetGraph->xAxis->grid()->setSubGridPen(pen);

    /* Set Graph Background */
    ui->widgetGraph->setBackground(QBrush(GRAPH_BACKGROUND_COLOR));

    /* Change legend style */
    ui->widgetGraph->legend->setBrush(QBrush(LEGEND_COLOR));
    ui->widgetGraph->legend->setTextColor(LEGEND_TEXT_COLOR);
    ui->widgetGraph->legend->setBorderPen(QPen(LEGEND_BORDER_COLOR));

    /* Change Base color for all axes */
    ui->widgetGraph->xAxis->setBasePen(QPen(XAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis->setBasePen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis2->setBasePen(QPen(YAXIS2_BASE_TICK_COLOR));

    /* Change tick style for all axes */
    ui->widgetGraph->xAxis->setTickPen (QPen(XAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis->setTickPen (QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis2->setTickPen (QPen(YAXIS2_BASE_TICK_COLOR));

    /* Change subtick style for all axes */
    ui->widgetGraph->xAxis->setSubTickPen(QPen(XAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis->setSubTickPen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis2->setSubTickPen(QPen(YAXIS2_BASE_TICK_COLOR));

    /* Change label color, font for all axes */
    ui->widgetGraph->xAxis->setLabelColor(XAXIS_BASE_TICK_COLOR);
    ui->widgetGraph->yAxis->setLabelColor(YAXIS_BASE_TICK_COLOR);
    ui->widgetGraph->yAxis2->setLabelColor(YAXIS2_BASE_TICK_COLOR);
    ui->widgetGraph->xAxis->setLabelFont(LABEL_FONT);
    ui->widgetGraph->yAxis->setLabelFont(LABEL_FONT);
    ui->widgetGraph->yAxis2->setLabelFont(LABEL_FONT);

    /* Change tick label color for all axes */
    ui->widgetGraph->xAxis->setTickLabelColor(LEGEND_TEXT_COLOR);
    ui->widgetGraph->yAxis->setTickLabelColor(LEGEND_TEXT_COLOR);
    ui->widgetGraph->yAxis2->setTickLabelColor(LEGEND_TEXT_COLOR);
}

/*******************************************************************************
 * Name					: saveGraph
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To save the graph
 ***************************************************************************//**
 * @brief	This function is used to save the current graph as PDF
 *
 * @param[in]	in_qstrFilename	Holds the path of the PDF file to save
 *
 * @return	NIL
 ******************************************************************************/
void CResponseMonitoring::saveGraph(QString in_qstrFilename)
{
    bool bIsSuccess     = false;
    QString qstrTitle   = QString("");
    QString qstrMessage = QString("");

    SET_TRACING_STATE(false);

    /* Save the graph with given filename */
    if (in_qstrFilename.endsWith(".pdf", Qt::CaseInsensitive))
        bIsSuccess = ui->widgetGraph->savePdf(in_qstrFilename);
    else if (in_qstrFilename.endsWith(".jpg", Qt::CaseInsensitive))
        bIsSuccess = ui->widgetGraph->saveJpg(in_qstrFilename);
    else if (in_qstrFilename.endsWith(".png", Qt::CaseInsensitive))
        bIsSuccess = ui->widgetGraph->savePng(in_qstrFilename);
    else
    {
        DISPLAY_MESSAGE_BOX(this, "Save Graph", "Invalid File Format selected to Save graph");
        SET_TRACING_STATE(true);
        return;
    }
    if (bIsSuccess)
    {
        qstrTitle.sprintf("Graph");
        qstrMessage = QString("Graph saved in <a style=\"color: navy;\" href=\"file:///%1\">%1</a>")\
                .arg(in_qstrFilename);  /* Display saved message with link to the file */
    }
    else
    {
        qstrTitle.sprintf("Graph Unsaved");
        qstrMessage.sprintf("Error saving Graph as PDF");
    }

    SET_TRACING_STATE(true);

    /* Display success or error message */
    emit sig_updateActionLog(qstrMessage, LOG_SUCCESS);
}

void CResponseMonitoring::slot_changeButtonName(QString in_qstrName)
{
    ui->pbStart->setText(in_qstrName);
}

float CResponseMonitoring::DP_GetMinimumValAnaData(QVector<SDPPCI755_DATA_BUFFER> in_pSBuffer, U32BIT in_u32FileSize, U8BIT in_u8Option, U8BIT in_u8Coordinates)
{
    U32BIT u32LoopCnt = 0;
    float fSmallestVal = 0.0f;

    if (in_pSBuffer.isEmpty())
    {
        emit sig_updateActionLog("No Buffer data Read for Ana Data", LOG_ERROR);
        return DPSCM_FAILURE;
    }

    if(in_u8Coordinates == DPPCI755_POLAR_COORDINATES)
    {
        if(in_u8Option == DPPCI755_FREQUENCY) // Frequency
        {
            for(u32LoopCnt = 1; u32LoopCnt < in_u32FileSize; u32LoopCnt++)
            {
                if(fSmallestVal > in_pSBuffer[u32LoopCnt].m_fFreqData)
                {
                    fSmallestVal = in_pSBuffer[u32LoopCnt].m_fFreqData;
                }
            }
        }

        if(in_u8Option == DPPCI755_GAIN_WITH_RATIO) // Gain
        {
            fSmallestVal = in_pSBuffer[0].m_fGainData;

            for(u32LoopCnt = 1; u32LoopCnt < in_u32FileSize; u32LoopCnt++)
            {
                if(fSmallestVal > in_pSBuffer[u32LoopCnt].m_fGainData)
                {
                    fSmallestVal = in_pSBuffer[u32LoopCnt].m_fGainData;
                }
            }
        }

        if(in_u8Option == DPPCI755_PHASE) // Phase
        {
            fSmallestVal = in_pSBuffer[0].m_fPhaseData;

            for(u32LoopCnt = 1; u32LoopCnt < in_u32FileSize; u32LoopCnt++)
            {
                if(fSmallestVal > in_pSBuffer[u32LoopCnt].m_fPhaseData)
                {
                    fSmallestVal = in_pSBuffer[u32LoopCnt].m_fPhaseData;
                }
            }
        }
    }

    return fSmallestVal;
}

float CResponseMonitoring::DP_GetMaximuValAnaData(QVector<SDPPCI755_DATA_BUFFER> in_pSBuffer, U32BIT in_u32FileSize, U8BIT in_u8Option, U8BIT in_u8Coordinates)
{
    U32BIT u32LoopCnt = 0;
    float fLargestVal = 0.0f;

    if(in_u8Coordinates == DPPCI755_POLAR_COORDINATES)
    {
        if(in_u8Option == DPPCI755_FREQUENCY) // Frequency
        {
            fLargestVal = in_pSBuffer[0].m_fFreqData;

            for(u32LoopCnt = 1; u32LoopCnt < in_u32FileSize; u32LoopCnt++)
            {
                if(fLargestVal < in_pSBuffer[u32LoopCnt].m_fFreqData)
                {
                    fLargestVal = in_pSBuffer[u32LoopCnt].m_fFreqData;
                }
            }

        }
        else if(in_u8Option == DPPCI755_GAIN_WITH_RATIO) // Gain
        {
            fLargestVal = in_pSBuffer[0].m_fGainData;

            for(u32LoopCnt = 1; u32LoopCnt < in_u32FileSize; u32LoopCnt++)
            {
                if(fLargestVal < in_pSBuffer[u32LoopCnt].m_fGainData)
                {
                    fLargestVal = in_pSBuffer[u32LoopCnt].m_fGainData;
                }
            }

        }
        else if(in_u8Option == DPPCI755_PHASE) // Phase
        {
            fLargestVal = in_pSBuffer[0].m_fPhaseData;
            for(u32LoopCnt = 1; u32LoopCnt < in_u32FileSize; u32LoopCnt++)
            {
                if(fLargestVal < in_pSBuffer[u32LoopCnt].m_fPhaseData)
                {
                    fLargestVal = in_pSBuffer[u32LoopCnt].m_fPhaseData;
                }
            }
        }
    }

    return fLargestVal;
}

/*******************************************************************************
 * Name					: slot_graphSavepoint
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To save the tracer point within graph
 ***************************************************************************//**
 * @brief	This function is used to save the current value of the tracer in graph
 *		This function is called when mouseDoubleClick signal is emitted from graph
 *			(every time double clicked in the graph)
 *
 * @param[in]	in_pMevent	Holds the Mouse event occured
 *
 * @return	NIL
 ******************************************************************************/
void CResponseMonitoring::slot_graphSavepoint(QMouseEvent *in_pMevent)
{
    if (!m_bEnableTracing_Gain && !m_bEnableTracing_Phase)
    {
        return;
    }

    /* Ignore if other than left mouse button is clicked */
    if (in_pMevent->button() != Qt::LeftButton)
    {
        return;
    }

    if (g_SGlobal.m_bIsGraphBeingPlotted)
    {
        return;
    }

    /* Ignore if number of graphs is not equal to 2 */
    if (ui->widgetGraph->graphCount() <= 0)
    {
        return;
    }

    FDOUBLE xValue      = 0.0;
    FDOUBLE yValue		= 0.0;
    QString qstrData	= QString("");
    QPointF qPos        = QPointF();
    QPointF qPos2       = QPointF();
    QPointF qPos3       = QPointF();
    QCPItemText *pTracerLabel = NULL;

    /** First Graph */
    if (m_bEnableTracing_Gain)
    {
        m_pTracer->setGraph(ui->widgetGraph->graph(0));
        qPos = m_pTracer->position->pixelPosition();
        /* Create a tracer label for 1st graph */
        pTracerLabel = new QCPItemText(ui->widgetGraph);
        pTracerLabel->setLayer("overlay");

        /* Set style for tracer label */
        pTracerLabel->setPen(QPen(YAXIS_BASE_TICK_COLOR));
        pTracerLabel->setColor(MOUSE_TRACER_LABEL_COLOR);
        pTracerLabel->setPositionAlignment(TRACER1_LABEL_POSITION);

        /* Get X and Y values from the tracer */
        xValue = m_pTracer->position->key();
        yValue = m_pTracer->position->value();
        qstrData.sprintf("(%0.5f, %0.5f)", xValue, yValue);

        /* Set label at the tracer position (fixed) */
        pTracerLabel->position->setPixelPosition(qPos);
        pTracerLabel->setText(qstrData);
    }

    /** Second Graph */
    if (m_bEnableTracing_Phase)
    {
        m_pTracer2->setGraph(ui->widgetGraph->graph(1));
        qPos2 = m_pTracer2->position->pixelPosition();
        /* Create a tracer label for 2nd graph */
        pTracerLabel = new QCPItemText(ui->widgetGraph);
        pTracerLabel->setLayer("overlay");

        /* Set style for tracer label */
        pTracerLabel->setPen(QPen(YAXIS2_BASE_TICK_COLOR));
        pTracerLabel->setColor(LEGEND_TEXT_COLOR);
        pTracerLabel->setPositionAlignment(TRACER2_LABEL_POSITION);

        /* Get X and Y values from the tracer2 */
        xValue = m_pTracer2->position->key();
        yValue = m_pTracer2->position->value();
        qstrData.sprintf("(%0.5f, %0.5f)", xValue, yValue);

        /* Set label at the tracer2 position (fixed) */
        pTracerLabel->position->setPixelPosition(qPos2);
        pTracerLabel->setText(qstrData);
    }

    /** Third Graph */
    if (m_bPlot3Tracers)
    {
        m_pTracer3->setGraph(ui->widgetGraph->graph(2));
        qPos3 = m_pTracer3->position->pixelPosition();

        /* Create a tracer label for 3rd graph */
        pTracerLabel = new QCPItemText(ui->widgetGraph);
        pTracerLabel->setLayer("overlay");

        /* Set style for tracer label */
        pTracerLabel->setPen(QPen(MOUSE_TRACER3_COLOR));
        pTracerLabel->setColor(LEGEND_TEXT_COLOR);
        pTracerLabel->setPositionAlignment(TRACER3_LABEL_POSITION);

        /* Get X and Y values from the tracer2 */
        xValue = m_pTracer3->position->key();
        yValue = m_pTracer3->position->value();
        qstrData.sprintf("(%0.5f, %0.5f)", xValue, yValue);

        /* Set label at the tracer2 position (fixed) */
        pTracerLabel->position->setPixelPosition(qPos3);
        pTracerLabel->setText(qstrData);
    }

    /* Replot to reflect the changes */
//    slot_enableGraphInteraction(false);
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

/*******************************************************************************
 * Name					: slot_graphTracePoint
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To move the tracer
 ***************************************************************************//**
 * @brief	This function is used to move the tracer to the cursor position in graph
 *		This function is called when mouseMove signal is emitted from the graph
 *			(everytime when mouse cursor is moved within the graph)
 *
 * @param[in]	in_pMevent	Holds the Mouse event occured
 *
 * @return	NIL
 ******************************************************************************/
void CResponseMonitoring::slot_graphTracePoint(QMouseEvent *in_pMevent)
{
    if (!m_bEnableTracing_Gain && !m_bEnableTracing_Phase)
    {
        return;
    }

    /* Ignore if number of graph is not 2 */
    if (ui->widgetGraph->graphCount() < 1)
    {
        return;
    }

    if (g_SGlobal.m_bIsGraphBeingPlotted)
    {
        return;
    }

    QString qstrData    = QString("");
    FDOUBLE dMouseX      = 0.0;
    FDOUBLE dStart       = 0.0;
    FDOUBLE dEnd         = 0.0;
    FDOUBLE dValueX      = 0.0;
    FDOUBLE dValueY      = 0.0;

    /* Get X value of mouse position */
    dMouseX = ui->widgetGraph->xAxis->pixelToCoord(in_pMevent->pos().x());

    /* Get start and end (0 and height of graph) */
    dStart = ui->widgetGraph->yAxis->pixelToCoord(0);
    dEnd = ui->widgetGraph->yAxis->pixelToCoord(ui->widgetGraph->size().height());

    /* Set tracer line start at (mouseX, start) and ends at (mouseX, end) */
    m_pTracerLine->start->setCoords(dMouseX, dStart);
    m_pTracerLine->end->setCoords(dMouseX, dEnd);

    /** Tracer for Gain Graph */
    if (m_bEnableTracing_Gain)
    {
        /* Set tracer for Gain graph */
        m_pTracer->setGraph(ui->widgetGraph->graph(0));

        /* Set tracer position key to mouseX */
        m_pTracer->setGraphKey(dMouseX);

        /* Set interpolation for the graph
    * Enable to trace along the plot
    * Else only plotted data points is positioned */
        m_pTracer->setInterpolating(true);

        /* Update position everytime to move tracer to new position */
        m_pTracer->updatePosition();

        /* Get X(Frequency) and Y(Gain) values from tracer position */
        dValueX = m_pTracer->position->key();
        dValueY = m_pTracer->position->value();
        qstrData.sprintf("(%0.5f, %0.5f)", dValueX, dValueY);

        /* Set label position */
        m_pTracerLabel->position->setType(QCPItemPosition::ptAbsolute);
        m_pTracerLabel->setPositionAlignment(TRACER1_LABEL_POSITION);
        m_pTracerLabel->position->setCoords(1.0, 1);

        /* Set tracer style */
        m_pTracer->setPen(QPen(MOUSE_TRACER_COLOR));
        m_pTracer->setBrush(QBrush(MOUSE_TRACER_COLOR));

        /* Set label style */
        m_pTracerLabel->setTextAlignment(Qt::AlignRight);
        m_pTracerLabel->setFont(QFont(font().family(), 12));
        m_pTracerLabel->setPadding(QMargins(9, 3, 3, 9));
        m_pTracerLabel->setColor(LEGEND_TEXT_COLOR);
        m_pTracerLabel->setText(qstrData);   // Display label

        /* Show tracer, tracer label for Gain graph */
        m_pTracer->setVisible(true);
        m_pTracerLabel->setVisible(true);
    }

    if (m_bEnableTracing_Phase)
    {
        /* Set tracer2 for Gain graph */
        m_pTracer2->setGraph(ui->widgetGraph->graph(1));

        /* Set tracer position key to mouseX */
        m_pTracer2->setGraphKey(dMouseX);

        /* Set interpolation for the graph
         * Enable to trace along the plot
         * Else only plotted data points is positioned
         */
        m_pTracer2->setInterpolating(true);

        /* Update position everytime to move tracer2 to new position */
        m_pTracer2->updatePosition();

        /* Get X(Frequency) and Y(Gain) values from tracer2 position */
        dValueX = m_pTracer2->position->key();
        dValueY = m_pTracer2->position->value();
        qstrData.sprintf("(%0.5f, %0.5f)", dValueX, dValueY);

        /* Set label2 position */
        m_pTracerLabel2->position->setType(QCPItemPosition::ptAbsolute);
        m_pTracerLabel2->setPositionAlignment(TRACER2_LABEL_POSITION);
        m_pTracerLabel2->position->setCoords(0, 0);

        /* Set tracer2 style */
        m_pTracer2->setPen(QPen(MOUSE_TRACER2_COLOR));
        m_pTracer2->setBrush(QBrush(MOUSE_TRACER2_COLOR));

        /* Set label2 style */
        m_pTracerLabel2->setTextAlignment(Qt::AlignRight);
        m_pTracerLabel2->setFont(QFont(font().family(), 12));
        m_pTracerLabel2->setPadding(QMargins(9, 3, 3, 9));
        m_pTracerLabel2->setColor(LEGEND_TEXT_COLOR);
        m_pTracerLabel2->setText(qstrData);  /* Display label2 */

        /* Show tracer, tracer label for Phase graph */
        m_pTracer2->setVisible(true);
        m_pTracerLabel2->setVisible(true);
    }

    if (ui->widgetGraph->graphCount() >= 3)
    {
        m_pTracer3->setGraph(ui->widgetGraph->graph(2));

        /* Set tracer position key to mouseX */
        m_pTracer3->setGraphKey(dMouseX);

        /* Set interpolation for the graph
        * Enable to trace along the plot
        * Else only plotted data points is positioned */
        m_pTracer3->setInterpolating(false);

        /* Update position everytime to move tracer3 to new position */
        m_pTracer3->updatePosition();

        /* Get X and Y values from tracer3 position */
        dValueX = m_pTracer3->position->key();
        dValueY = m_pTracer3->position->value();
        qstrData.sprintf("(%0.5f, %0.5f)", dValueX, dValueY);

        /* Set label3 position */
        m_pTracerLabel3->position->setType(QCPItemPosition::ptAxisRectRatio);
        m_pTracerLabel3->setPositionAlignment(TRACER3_LABEL_POSITION);
        m_pTracerLabel3->position->setCoords(0, 0);

        /* Set tracer3 style */
        m_pTracer3->setPen(QPen(MOUSE_TRACER3_COLOR));
        m_pTracer3->setBrush(QBrush(MOUSE_TRACER3_COLOR));

        /* Set labe3 style */
        m_pTracerLabel3->setTextAlignment(Qt::AlignRight);
        m_pTracerLabel3->setFont(QFont(font().family(), 12));
        m_pTracerLabel3->setPadding(QMargins(9, 3, 3, 9));
        m_pTracerLabel3->setColor(LEGEND_TEXT_COLOR);
        m_pTracerLabel3->setText(qstrData);  /* Display label3 */

        /* Show Tracer for Graph 3 */
        m_pTracerLabel3->setVisible(true);
        m_pTracer3->setVisible(false);
    }

    /* Show tracer line */
    m_pTracerLine->setVisible(true);

    /* Replot graph to reflect the changes */
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

void CResponseMonitoring::slot_configureGraph(int in_iSelectedTestcase, char in_cGraphType, int in_iXMin, int in_iXMax, int in_iYMin, int in_iYMax, int in_iY2Min, int in_iY2Max)
{
    QString qstrGraph1Name = QString();
    QString qstrGraph2Name = QString();
    QDateTime timeNow;
    timeNow = timeNow.currentDateTime();

    updateTestcaseDetails(in_iSelectedTestcase);
    initGraph();
    m_actShowLegend->setChecked(true); // ui->widgetGraph->legend->setVisible(true);
    slot_contextMenu_ShowHide_Legend_triggered(true);

    if (in_cGraphType == GRAPHTYPE_GAIN_PHASE)
    {
        ui->widgetGraph->xAxis->setLabel("Frequency (Hz)");
        ui->widgetGraph->yAxis->setLabel("Gain (dB)");
        ui->widgetGraph->yAxis2->setLabel("Phase (deg)");
        qstrGraph1Name = "Gain";
        qstrGraph2Name = "Phase";
        ENABLE_BODE_GRAPH(ui->widgetGraph); /** Enabling Bode Graph */
    }
    else
    {
        ui->widgetGraph->xAxis->setLabel("Time (ms)");
        ui->widgetGraph->yAxis->setLabel("Position Response (deg)");
        ui->widgetGraph->yAxis2->setLabel("Rate Response (deg/s)");
        qstrGraph1Name = "Payload Position";
        qstrGraph2Name = "Payload Rate";
        DISABLE_BODE_GRAPH(ui->widgetGraph);    /** Disabling Bode Graph */
    }

    ui->widgetGraph->graph(0)->setPen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->graph(0)->setLineStyle(QCPGraph::lsLine);
    ui->widgetGraph->graph(1)->setPen(QPen(YAXIS2_BASE_TICK_COLOR));
    ui->widgetGraph->graph(1)->setLineStyle(QCPGraph::lsLine);

    if (in_iXMax == 0 && in_iXMin == 0)
    {
        in_iXMin = 0;
        in_iXMax = 60000;   // 60s === 1min
    }
    else
    {
        // Do nothing
    }

    if (in_iYMax == 0 && in_iYMin == 0)
    {
        in_iYMax = (int) DP_SCM_POS_MAX;
        in_iYMin = (int) DP_SCM_POS_MIN;
    }
    else
    {
        // Do nothing
    }

    if (in_iY2Max == 0 && in_iY2Min == 0)
    {
        in_iY2Max = (int) DP_SCM_RATE_MAX;
        in_iY2Min = (int) DP_SCM_RATE_MIN;
    }
    else
    {
        // Do nothing
    }

    m_ulXLimit_L = in_iXMin;
    m_ulXLimit_U = in_iXMax;

    m_ulLimit = m_ulXLimit_L + ((m_ulXLimit_U - m_ulXLimit_L) * 0.6);
    ui->widgetGraph->xAxis->setRange(m_ulXLimit_L, m_ulXLimit_U);
    ui->widgetGraph->yAxis->setRange(in_iYMin, in_iYMax);
    ui->widgetGraph->yAxis2->setRange(in_iY2Min, in_iY2Max);

    m_ui_X_Min  = m_ulXLimit_L;
    m_ui_X_Max  = m_ulXLimit_U;
    m_ui_Y_Min  = in_iYMin;
    m_ui_Y_Max  = in_iYMax;
    m_ui_Y2_Min = in_iY2Min;
    m_ui_Y2_Max = in_iY2Max;

    setGraphAppearance();
    ui->widgetGraph->graph(0)->setName(qstrGraph1Name);
    ui->widgetGraph->graph(1)->setName(qstrGraph2Name);
    ui->widgetGraph->replot();
}

/*******************************************************************************
 * Name					: slot_updateTestcaseDetails
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To update selected test case
 ***************************************************************************//**
 * @brief	This function is used to update the selected test case and
 *			respective log file
 *
 * @param[in]	in_iSelectedTestcase	Specifies the selected test case
 * @param[in]	in_qstrTCLogfile	Specifies the log file for selected test case
 *
 * @return	NIL
 ******************************************************************************/
void CResponseMonitoring::updateTestcaseDetails(int in_iSelectedTestcase)
{
    m_iSelectedTestCase = in_iSelectedTestcase;
    m_qstrTCLogFileName = QString();
}

void CResponseMonitoring::slot_onlineGraphAddValue(void *param)
{
    SDPPCI755_DATA_BUFFER * in_pSDataBuffer = (SDPPCI755_DATA_BUFFER *)param;

    if((in_pSDataBuffer->m_fFreqData == m_stTempBuffer[0].m_fFreqData)
            ||(in_pSDataBuffer->m_fGainData == m_stTempBuffer[0].m_fGainData)
            ||(in_pSDataBuffer->m_fGainData == m_stTempBuffer[0].m_fPhaseData) )
    {
        return;
    }

    memcpy(&m_stTempBuffer[0], in_pSDataBuffer,sizeof(SDPPCI755_DATA_BUFFER));

    if(m_stBoard1Buffer.size() <= (S32BIT)m_u32DispIdx)
    {
        m_stBoard1Buffer.resize(m_u32DispIdx+1);
    }

    QString qstrTemp;
    qstrTemp.sprintf("%.04f,%.04f,%.04f\n", in_pSDataBuffer->m_fFreqData, in_pSDataBuffer->m_fGainData, in_pSDataBuffer->m_fPhaseData);
    g_SGlobal.m_qfFRALog.write(CONV_QSTR_TO_SZ(qstrTemp));

    memcpy(&m_stBoard1Buffer[m_u32DispIdx],in_pSDataBuffer,sizeof(SDPPCI755_DATA_BUFFER));

    DrawGraph();
    m_u32DispIdx++;
}
void CResponseMonitoring::slot_updateServoGraph(float in_fCmd, float in_fResp, double in_dTime)
{
    QString qstrTime = "";

    if (m_uiCurrIndx == g_SGlobal.m_uiServoDataCount)
    {
        m_uiCurrIndx = 0;
    }

    if (g_SGlobal.g_ulTime > m_ulLimit)
    {
        m_ulXLimit_L = (m_ulXLimit_L + ((m_ulXLimit_U - m_ulXLimit_L) * 0.3));
        m_ulXLimit_U = m_ulXLimit_L + (1000 * 60);
        ui->widgetGraph->xAxis->setRange(m_ulXLimit_L, m_ulXLimit_U);
        ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
        m_ulLimit = m_ulXLimit_L + ((m_ulXLimit_U - m_ulXLimit_L) * 0.6);
    }

    if (in_dTime == 1)
    {
        ui->widgetGraph->xAxis->setLabel("Time (ms)");
        ui->widgetGraph->yAxis->setLabel("Position (deg)");
        ui->widgetGraph->yAxis2->setLabel("Rate (deg/s)");
        ui->widgetGraph->graph(0)->setName("Payload Angle");
        ui->widgetGraph->graph(1)->setName("Payload Rate");
        DISABLE_BODE_GRAPH(ui->widgetGraph);
    }

    ui->widgetGraph->graph(0)->addData(g_SGlobal.g_ulTime, in_fCmd);
    ui->widgetGraph->graph(1)->addData(g_SGlobal.g_ulTime, in_fResp);
    if ((g_SGlobal.g_ulTime % 200) == 0)
    {
        ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
    }
}

void CResponseMonitoring::DrawGraph()
{
    QVector<double>xFreq, yGainLeft, yPhaseRight;
    QVector<double>yAxis0;
    QVector<double>yAxis2;
    float fMinVal = 0;
    float fMaxVal = 0;

    yAxis0.clear();
    yAxis2.clear();
    m_u32nIdx	= DPSCM_INIT_0;
    m_u32nSelectedGraph = 2; /// 2 - for Both graph (Gain and Phase)

    memcpy(&m_OnGraphSCfgData, &g_SGlobal.m_SFRAConfig, sizeof(SDPPCI755_CONFIG));
    if(m_OnGraphSCfgData.m_bLog)
    {
        m_u32nNoOfData = (U32BIT)ceil(log10(m_OnGraphSCfgData.m_fEndFreq / m_OnGraphSCfgData.m_fStartFreq)) * m_OnGraphSCfgData.m_fStepSize;
    }
    else
    {
        m_u32nNoOfData	= (U32BIT) (((m_OnGraphSCfgData.m_fEndFreq - m_OnGraphSCfgData.m_fStartFreq) + 1) / m_OnGraphSCfgData.m_fStepSize);
    }

    m_stBoard1Buffer.resize(m_u32nNoOfData);

    fMinVal =  DP_GetMinimumValAnaData(m_stBoard1Buffer, m_u32DispIdx, DPPCI755_GAIN_WITH_RATIO, DPPCI755_POLAR_COORDINATES);
    fMaxVal =  DP_GetMaximuValAnaData(m_stBoard1Buffer, m_u32DispIdx, DPPCI755_GAIN_WITH_RATIO, DPPCI755_POLAR_COORDINATES);
    yAxis0.push_back(fMinVal);
    yAxis0.push_back(fMaxVal);

    //       m_ui_Y_Min  = yAxis0.at(0);
    //       m_ui_Y_Max  = yAxis0.at(1);
    m_ui_Y_Min = fMinVal;
    m_ui_Y_Max = fMaxVal;
    //       ui->widgetGraph->yAxis->setRange(yAxis0.at(0), yAxis0.at(1));

    // fMinVal = fMinVal - (fMinVal * 5 / 100);
    // fMaxVal = fMaxVal + (fMaxVal * 5 / 100);
    ui->widgetGraph->yAxis->setRange(fMinVal, fMaxVal);

    fMinVal = DP_GetMinimumValAnaData(m_stBoard1Buffer, m_u32DispIdx, DPPCI755_PHASE, DPPCI755_POLAR_COORDINATES);
    fMaxVal = DP_GetMaximuValAnaData(m_stBoard1Buffer, m_u32DispIdx, DPPCI755_PHASE, DPPCI755_POLAR_COORDINATES);
    yAxis2.push_back(fMinVal);
    yAxis2.push_back(fMaxVal);

    //       m_ui_Y2_Min = yAxis2.at(0);
    //       m_ui_Y2_Max = yAxis2.at(1);
    m_ui_Y2_Min = fMinVal;
    m_ui_Y2_Max = fMaxVal;
    // fMinVal = fMinVal - (fMinVal * 5 / 100);
    // fMaxVal = fMaxVal + (fMaxVal * 5 / 100);
    //       ui->widgetGraph->yAxis2->setRange(yAxis2.at(0), yAxis2.at(1));
    ui->widgetGraph->yAxis2->setRange(fMinVal, fMaxVal);

    m_u32nCount	= DPSCM_INIT_0;
    for(; m_u32nCount <= m_u32DispIdx; m_u32nCount++)
    {
        xFreq.push_back(m_stBoard1Buffer[m_u32nCount].m_fFreqData);
        yGainLeft.push_back(m_stBoard1Buffer[m_u32nCount].m_fGainData);
        yPhaseRight.push_back(m_stBoard1Buffer[m_u32nCount].m_fPhaseData);
    }

    ui->widgetGraph->graph(0)->setPen(YAXIS_BASE_TICK_COLOR);
    ui->widgetGraph->graph(0)->setLineStyle(QCPGraph::lsLine);
    ui->widgetGraph->graph(0)->setData(xFreq, yGainLeft);

    ui->widgetGraph->graph(1)->setPen(YAXIS2_BASE_TICK_COLOR);
    ui->widgetGraph->graph(1)->setLineStyle(QCPGraph::lsLine);
    ui->widgetGraph->graph(1)->setData(xFreq, yPhaseRight);

//    ui->widgetGraph->legend->item(0)->setVisible(true);
//    ui->widgetGraph->legend->item(1)->setVisible(true);
    ui->widgetGraph->replot();
}

void CResponseMonitoring::removeTracingFromGraph()
{
    m_pTracer->setVisible(false);
    m_pTracerLabel->setVisible(false);
    m_pTracer2->setVisible(false);
    m_pTracerLabel2->setVisible(false);

    if (!m_bEnableTracing_Gain && !m_bEnableTracing_Phase)
    {
        m_pTracerLine->setVisible(false);
    }

    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

/*******************************************************************************
 * Name					: slot_updateDiagParam
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To update diagnostics parameters
 ***************************************************************************//**
 * @brief	This function is used to update the diagnostics parameter in GUI
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CResponseMonitoring::slot_updateDiagParam(S_RESP_DEBUG_DATA in_SDebugData)
{
    QString qstrTemp = QString("");

    qstrTemp.sprintf("%4.05f", in_SDebugData.m_dMotorCurrent);
    ui->leMotorCurrent->setText(qstrTemp);

    qstrTemp.sprintf("%4.05f", in_SDebugData.m_dMotorCtrlDemand);
    ui->leMotorCtrlDemand->setText(qstrTemp);

    qstrTemp.sprintf("%4.05f", in_SDebugData.m_dMotorAngle);
    ui->leMotorAngle->setText(qstrTemp);

    qstrTemp.sprintf("%4.05f", in_SDebugData.m_dPayloadRate);
    ui->lePayloadRate->setText(qstrTemp);

    qstrTemp.sprintf("%4.05f", in_SDebugData.m_dPayloadAngle);
    ui->lePayloadAngle->setText(qstrTemp);

    qstrTemp.sprintf("%4.05f", in_SDebugData.m_dGimbalDemand);
    ui->leGimbalDemand->setText(qstrTemp);

    qstrTemp.sprintf("%4.05f", in_SDebugData.m_dPositionDemand);
    ui->lePositionDemand->setText(qstrTemp);

    qstrTemp.sprintf("%4.05f", in_SDebugData.m_dRateDemand);
    ui->leRateDemand->setText(qstrTemp);
}

/*******************************************************************************
 * Name					: on_pbStart_clicked
 * Author					: aravinth.rajalingam
 * Global Variables affected	: NIL
 * Created Date			: Feb 17, 2023
 * Revised By				: NA
 * Revision Date			: NA
 * Reason for revision		: NA
 * Description				: To start response monitoring
 ***************************************************************************//**
 * @brief	This function is used to start the monitoring of response and plot graph
 *
 * @param		NIL
 * @return	NIL
 ******************************************************************************/
void CResponseMonitoring::on_pbStart_clicked()
{
    emit sig_startResponseMonitoring();
}

void CResponseMonitoring::slot_clearGraph()
{
    int iSize = DPSCM_INIT_0;

    initGraph();

    m_dvectCol1.clear();
    m_dvectCol2.clear();
    m_dvectCol3.clear();
    m_dvectCol4.clear();
    m_stBoard1Buffer.clear();

    m_stBoard1Buffer.resize(500000);
    m_stTempBuffer.resize(500000);
    m_stTempBuffer[0].m_fFreqData = 0.0f;
    m_stTempBuffer[0].m_fGainData = 0.0f;
    m_stTempBuffer[0].m_fPhaseData = 0.0f;
    m_u32DispIdx = 0;

    iSize = (g_SGlobal.m_SFRAConfig.m_fEndFreq - g_SGlobal.m_SFRAConfig.m_fStartFreq + 1) * g_SGlobal.m_SFRAConfig.m_fStepSize;

    m_dvectCol1.resize(iSize);
    m_dvectCol2.resize(iSize);
    m_dvectCol3.resize(iSize);
    m_dvectCol4.resize(iSize);

    slot_enableGraphInteraction(false);
}

void CResponseMonitoring::slot_enableGraphInteraction(bool in_bEnable)
{
    if (in_bEnable)
    {
        ui->widgetGraph->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectItems | QCP::iMultiSelect);
        m_bEnableTracing_Gain = true;
        m_bEnableTracing_Phase = true;
        m_actTrace_Gain->setChecked(true);
        m_actTrace_Phase->setChecked(true);
    }
    else
    {
        m_bEnableTracing_Gain = false;
        m_bEnableTracing_Phase = false;
        m_actTrace_Gain->setChecked(false);
        m_actTrace_Phase->setChecked(false);
        ui->widgetGraph->setInteractions(QCP::iNone);
    }


    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

void CResponseMonitoring::slot_show_hide_DiagParams(bool in_bShow)
{
    if (in_bShow)
    {
        ui->dockDiagParams->show();
    }
    else
    {
        ui->dockDiagParams->close();
    }

    ui->teNote->setVisible(in_bShow);
}

void CResponseMonitoring::slot_changeTestcaseName(QString in_qstrTCName)
{
    QString qstrText = "<p style=\"margin-top: 12px;"
                       "margin-bottom: 12px;"
                       "margin-left: 0px;"
                       "margin-right: 0px;"
                       "-qt-block-indent: 0;"
                       "text-indent: 0px;"
                       "font-weight: 600;"
                       "font-size: 15pt;"
                       "font-family: \"Times New Roman\">"
                       "%s</p>";
    QString qstrTitle = QString();

    qstrTitle.sprintf(CONV_QSTR_TO_SZ(qstrText), CONV_QSTR_TO_SZ(in_qstrTCName));
    ui->lbDisp_TestCaseName->setText(qstrTitle);
}

void CResponseMonitoring::slot_contextMenuRequested(QMouseEvent* in_qMouseEvt)
{
    if (in_qMouseEvt->type() != QEvent::MouseButtonRelease)
    {
        return;
    }

    if (in_qMouseEvt->button() != Qt::RightButton)
    {
        return;
    }

    if (g_SGlobal.m_bIsGraphBeingPlotted)
    {
        return;
    }

    QPoint qptGraph = ui->widgetGraph->pos ();
    QPoint qptResult = QPoint();

    qptResult = (QPoint((in_qMouseEvt->pos().x () + qptGraph.x ()), \
                        (in_qMouseEvt->pos().y () + qptGraph.y ())));

    m_menuContextMenu->exec(mapToGlobal(qptResult));
}

void CResponseMonitoring::slot_contextMenu_Reset_triggered()
{
    ui->widgetGraph->xAxis->setRange(m_ui_X_Min, m_ui_X_Max);
    ui->widgetGraph->yAxis->setRange(m_ui_Y_Min, m_ui_Y_Max);
    ui->widgetGraph->yAxis2->setRange(m_ui_Y2_Min, m_ui_Y2_Max);
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

void CResponseMonitoring::slot_contextMenu_Clear_triggered()
{
    slot_contextMenu_Reset_triggered();
    slot_clearGraph();
    slot_enableGraphInteraction(false);
}

void CResponseMonitoring::slot_contextMenu_Delete_Labels()
{
    foreach (QCPAbstractItem *pItem, ui->widgetGraph->selectedItems())
    {
        ui->widgetGraph->removeItem(pItem);
    }

    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

void CResponseMonitoring::slot_contextMenu_ShowHide_Legend_triggered(bool in_bIsChecked)
{
    if (!in_bIsChecked)
    {
        ui->widgetGraph->legend->setVisible(false);
    }
    else
    {
        ui->widgetGraph->legend->setVisible(true);
    }

    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

void CResponseMonitoring::slot_contextMenu_Trace_Gain_triggered(bool in_bIsChecked)
{
    m_bEnableTracing_Gain = in_bIsChecked;

    if (!in_bIsChecked)
    {
        removeTracingFromGraph();
    }
}

void CResponseMonitoring::slot_contextMenu_Trace_Phase_triggered(bool in_bIsChecked)
{
    m_bEnableTracing_Phase = in_bIsChecked;

    if (!in_bIsChecked)
    {
        removeTracingFromGraph();
    }
}

void CResponseMonitoring::on_dockDiagParams_visibilityChanged(bool visible)
{
    emit sig_show_hide_DiagParams(visible);
    ui->teNote->setVisible(visible);
    ui->lbDisp_TestCaseName->setVisible(visible);
}
