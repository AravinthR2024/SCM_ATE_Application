/*******************************************************************************
// File Name            : dp_qt_msgqueue.cpp
// Author               : Sathishkumar K
// Created Date         : Nov 16,2010
// Revised By           : Manoj L
// Revision Date        : Jun 20,2020
// Reason for Revising  : Porting to QT
// Description          : Message Queues function definitions
*******************************************************************************/

/*******************************************************************************
// Company Name : DATA PATTERNS (INDIA) LTD.
// Address      : No. H9,4th MainRoad,SIPCOT IT Park,Siruseri,Chennai-603103
// Email        : support@datapatterns.co.in
// Phone        : +91 44 47414000
// Fax          : +91 44 47414444
*******************************************************************************/

/******************************************************************************
// Copyright (c) 2010 DATA PATTERNS (INDIA) LTD.
//
// All rights reserved. These materials are confidential and proprietary to
// DATA PATTERNS and no part of these materials should be reproduced or published
// in any form by any means, electronic or mechanical, including photocopy, on any
// information storage or retrieval system, nor should the materials be disclosed
// to third parties without the explicit written authorization of DATA PATTERNS.
//
*******************************************************************************/

#include "includes/dp_qt_msgqueue.h"

/************* Function Definition **********/

/*******************************************************************************
 * Name                      : CDPMsgQueue
 * Author                    : Sathishkumar K
 * Global Variables affected : NIL
 * Created Date              : Nov 16,2010
 * Revised By                : Manoj L
 * Revision Date             : Jun 20,2020
 * Reason for Revising       : Porting to QT
 ***************************************************************************//**
 * To create circular buffer for the given message sizes. The size of the message buffer
 * will be (in_uiTotalMsgs * in_uiMsgSizeMax).
 *
 * \param in_s_pMsgQueue - Pointer to the circular buffer with the type of 'S_DP_MESSAGE_QUEUE
 * to initialize the message buffers parameters.
 * \param in_uiTotalMsgs - The maximum number of message(s) the specified buffer can hold.
 * \param in_uiMsgSizeMax - size of largest message can be stored in buffer.
 *
 * \return Error code (0 - no error, negative values - Error code). use 'GetErrMsg'
 * function to get the error message for the corresponding error code.
*******************************************************************************/
CDPMsgQueue::CDPMsgQueue(unsigned int in_uiTotalMsgs, unsigned int in_uiMsgSizeMax)
{
    /* initialization of buffer parameters */
    m_uiMsgSizeMax = in_uiMsgSizeMax;
    m_uiMaxNoOfMsgs = in_uiTotalMsgs;
    m_uiNoOfMsgs = 0;
    m_QueueRxSem = new QSemaphore(1);
    m_spMsgFront = NULL;
    m_spMsgRear = NULL;
}

/*******************************************************************************
 * Name                      : GetMsgCount
 * Author                    : Sathishkumar K
 * Global Variables affected : NIL
 * Created Date              : Nov 16,2010
 * Revised By                : Manoj L
 * Revision Date             : Jun 20,2020
 * Reason for Revising       : Porting to QT
 ***************************************************************************//**
 * To get the message count from the given buffer(in_s_pMsgQueue).
 *
 * \param in_s_pMsgQueue - Pointer to the circular buffer to get the message count.
 * it should not be used without initialization (using Init())
 * \param out_uipMsgCount - This will contain the number of messages available in the
 * 	given buffer (in_s_pMsgQueue).
 *
 * \return Error code (0 - no error, negative values - Error code). 'use GetErrMsg'
 * 	function to get the error message for the corresponding error code.
*******************************************************************************/
short CDPMsgQueue::GetMsgCount(unsigned int * out_uipMsgCount)
{
    /* Lock the the Queue resources */
    m_thrdMutex.lock();

    *out_uipMsgCount = m_uiNoOfMsgs;

    /* Unlock the the Queue resources */
    m_thrdMutex.unlock();

    return COE_MSGQ_SUCCESS;
}

/*******************************************************************************
 * Name                      : Receive
 * Author                    : Sathishkumar K
 * Global Variables affected : NIL
 * Created Date              : Nov 16,2010
 * Revised By                : Manoj L
 * Revision Date             : Jun 20,2020
 * Reason for Revising       : Porting to QT
 ***************************************************************************//**
 * To get a message from the given buffer(in_s_pMsgQueue). based on
 * the 'in_uiNoSem' parameter thin can be act as block or non block mode .
 *
 * \param in_s_pMsgQueue - Pointer to the circular buffer to get the message count.
 * 	it should not be used without initialization (using Init())
 * \param out_vpMsgBuffer - Pointer to a buffer that that can store a message.
 * \param in_uiBuffSize - The maximum number of bytes the specified buffer
 *  (out_vpMsgBuffer) can hold.
 * \param in_uiNoSem - if 0, this function will return immediate regardless of
 *  availability of message(s) in buffer.
 *  If 1, This function will wait for at least one message (if any message(s)are available
 *  in buffer, it will return immediately).
 *  \param in_ipTimeOutMS - The timeout value in (millisecond) to return the function in case of no data.
 *   This value is applicable only in block mode(i.e. in_uiNoSem is 1) otherwise it will be ignored.
 *   \n If 0, it will wait infinitely for next message.
 *   \n If non zero, it will wait for the specified millisecond(s) and if the timeout occurs it will return error.
 *
 * \return Non-Zero - size of the message (and no error), negative values - Error code. 'use GetErrMsg'
 *  function to get the error message for the corresponding error code.
*******************************************************************************/

int CDPMsgQueue::Receive(void * out_vpMsgBuffer, unsigned int in_uiBuffSize, int * in_ipTimeOutMS)
{
    unsigned int uiTempMsgSize = 0;
    S_DP_BUFFER *s_pCurrentMsg = NULL;

    if(in_ipTimeOutMS != NULL)
    {
        /* if any data available in the Queue it will return immediately otherwise
         * it will go to block state until timout occurs or any message added into queue */
        if(*in_ipTimeOutMS > 0)
        {
            if(!(m_QueueRxSem->tryAcquire(MSGQ_SEMAPHORE_COUNT, *in_ipTimeOutMS)))
            {
                return COE_MSGQ_ERR_TIMEOUT;
            }
        }
        else if(*in_ipTimeOutMS == 0)
        {
            /* no wait*/
            if(m_QueueRxSem->tryAcquire(MSGQ_SEMAPHORE_COUNT) != 1)
            {
			  qDebug() << "RECEIVE SEMAPHORE ERROR";
                return COE_MSGQ_ERR_SEM_ERR;
            }
        }
    }
    else
    {
        //Infinite wait
        m_QueueRxSem->acquire(MSGQ_SEMAPHORE_COUNT);
    }

    m_thrdMutex.lock();

    /* check whether the Queue is empty*/
    if((m_uiNoOfMsgs > 0) && (m_spMsgFront != NULL))
    {
        uiTempMsgSize = in_uiBuffSize;

        /* Check enough buffer is available to store the all data*/
        if(in_uiBuffSize < m_spMsgFront->uiMsgSize)
        {
            /* if enough buffer size is not available truncate to buffer size */
            uiTempMsgSize = m_spMsgFront->uiMsgSize;
        }
        memcpy(out_vpMsgBuffer, m_spMsgFront->pucMessage, uiTempMsgSize);
        s_pCurrentMsg = m_spMsgFront;
        /* point the next message */
        m_spMsgFront = m_spMsgFront->s_pNextMsg;
        m_uiNoOfMsgs--;

        /* free the message buffer & current message */
        free(s_pCurrentMsg->pucMessage);
        free(s_pCurrentMsg);
        /* if Queue is empty */
        if(m_uiNoOfMsgs == 0)
        {
            m_spMsgFront = NULL;
            m_spMsgRear = NULL;
        }
    }
    else
    {
        m_thrdMutex.unlock();
        m_QueueRxSem->release();
        return COE_MSGQ_ERR_QUEUE_EMPTY;
    }
    m_thrdMutex.unlock();
    m_QueueRxSem->release();
//    qDebug() << "MSG BUFFER DATA RECV : " << out_vpMsgBuffer;
    return uiTempMsgSize;
}

/*******************************************************************************
 * Name                      : Send
 * Author                    : Sathishkumar K
 * Global Variables affected : NIL
 * Created Date              : Nov 16,2010
 * Revised By                : Manoj L
 * Revision Date             : Jun 20,2020
 * Reason for Revising       : Porting to QT
 ***************************************************************************//**
 * To store the messages in to the corresponding queue.
 *
 * \param in_s_pMsgQueue - Pointer to the circular buffer to get the message count.
 * 	it should not be used without initialization (using Init())
 * \param in_vpMsgBuffer - Pointer to a buffer that contains message to send to queue.
 * \param in_uiMsgSize - Size of the message available in the given message buffer (in_vpMsgBuffer)
 *
 * \return Non-Zero - Error code (0 - no error, negative values - Error code). 'use GetErrMsg'
 *  function to get the error message for the corresponding error code.
*******************************************************************************/
short CDPMsgQueue::Send(void * in_vpMsgBuffer, unsigned int in_uiMsgSize)
{
//    qDebug() << "available semaphore in send:" << m_QueueRxSem->available();
    S_DP_BUFFER *s_pNewMsg = NULL;

    m_thrdMutex.lock();

    /* check whether the queue is reached to max. number of messages */
    if(m_uiNoOfMsgs >= m_uiMaxNoOfMsgs)
    {
        m_thrdMutex.unlock();
        return COE_MSGQ_ERR_QUEUE_FULL;
    }
    /* if the size is greater than max message size then return error */
    if(m_uiMsgSizeMax && (in_uiMsgSize > m_uiMsgSizeMax))
    {
        m_thrdMutex.unlock();
        return COE_MSGQ_ERR_INVALID_MSG_SIZE;
    }

    if(in_vpMsgBuffer)
    {
        s_pNewMsg = (S_DP_BUFFER *) malloc(sizeof(S_DP_BUFFER));
        if(s_pNewMsg == NULL)
        {
            m_thrdMutex.unlock();
            return COE_MSGQ_ERR_MEM_ALLOC;
        }
        s_pNewMsg->s_pNextMsg = NULL;
        s_pNewMsg->uiMsgSize = in_uiMsgSize;
        s_pNewMsg->pucMessage = (unsigned char *) malloc(in_uiMsgSize);

        if(s_pNewMsg->pucMessage == NULL)
        {
            m_thrdMutex.unlock();
		free(s_pNewMsg);
            return COE_MSGQ_ERR_MEM_ALLOC;
        }

        memcpy(s_pNewMsg->pucMessage, in_vpMsgBuffer, in_uiMsgSize);
        /* */
        if(m_spMsgRear != NULL)
        {
            m_spMsgRear->s_pNextMsg = s_pNewMsg;
        }

        if( m_spMsgFront == NULL)
        {
            m_spMsgFront = s_pNewMsg;
        }
        m_spMsgRear = s_pNewMsg;

        /* Increment total number of messages */
        m_uiNoOfMsgs++;

        /* Increment the semaphore*/
        if((m_QueueRxSem->available()) == 0)
        {
            m_QueueRxSem->release();
        }
    }
    else
    {
        m_thrdMutex.unlock();
        return COE_MSGQ_ERR_INVALID_MSG_BUFF;
    }
    m_thrdMutex.unlock();
//    qDebug() << "available semaphore in send end:" << m_QueueRxSem->available();
    return COE_MSGQ_SUCCESS;
}

/*******************************************************************************
 * Name                      : Clear
 * Author                    : Sathishkumar K
 * Global Variables affected : NIL
 * Created Date              : Nov 16,2010
 * Revised By                : Manoj L
 * Revision Date             : Jun 20,2020
 * Reason for Revising       : Porting to QT
 ***************************************************************************//**
 * To clear the messages from the giver message queue.
 *
 * \param in_s_pMsgQueue - Pointer to the circular buffer to get the message count.
 * 	it should be used in this function after initialization (using Init()).
 *
 * \return Non-Zero - Error code (0 - no error, negative values - Error code). 'use GetErrMsg'
 *  function to get the error message for the corresponding error code.
*******************************************************************************/
short CDPMsgQueue::Clear()
{
    S_DP_BUFFER *s_pCurrentMsg = NULL;

    m_thrdMutex.lock();

    while(m_spMsgFront != NULL)
    {
        s_pCurrentMsg = m_spMsgFront;
        m_spMsgFront = m_spMsgFront->s_pNextMsg;

        /* free the message buffer & current message */
        free(s_pCurrentMsg->pucMessage);
        free(s_pCurrentMsg);
        m_uiNoOfMsgs--;

        /*decrement the sem count */
        if(m_QueueRxSem->available())
        {
            m_QueueRxSem->acquire(MSGQ_SEMAPHORE_COUNT);
        }
    }
    m_uiNoOfMsgs = 0;
    m_spMsgFront = NULL;
    m_spMsgRear = NULL;

    m_thrdMutex.unlock();
    return COE_MSGQ_SUCCESS;
}

/*******************************************************************************
 * Name                      : Destroy
 * Author                    : Sathishkumar K
 * Global Variables affected : NIL
 * Created Date              : Nov 16,2010
 * Revised By                : Manoj L
 * Revision Date             : Jun 20,2020
 * Reason for Revising       : Porting to QT
 ***************************************************************************//**
 * To destroy the circular buffer. It will deallocate the memory, which is allocated
 * using 'Init()' function.
 *
 * \param in_s_pMsgQueue - Pointer to the circular buffer to get the message count.
 * 	it should be used in this function after initialization (using Init()).
 *
 * \return Non-Zero - Error code (0 - no error, negative values - Error code). 'use GetErrMsg'
 *  function to get the error message for the corresponding error code.
*******************************************************************************/
short CDPMsgQueue::Destroy()
{
    S_DP_BUFFER *s_pCurrentMsg = NULL;

    m_thrdMutex.lock();

    /* free the allocated memory for the buffer */
    while(m_spMsgFront != NULL)
    {
        s_pCurrentMsg = m_spMsgFront;
        m_spMsgFront = m_spMsgFront->s_pNextMsg;

        /* free the message buffer & current message */
        free(s_pCurrentMsg->pucMessage);
        free(s_pCurrentMsg);
        m_uiNoOfMsgs--;
    }
    m_uiNoOfMsgs = 0;
    m_spMsgFront = NULL;
    m_spMsgRear = NULL;

    m_uiMaxNoOfMsgs = 0;
    m_uiMsgSizeMax = 0;

    /* destroy the semaphore of the buffer */
    delete m_QueueRxSem;
    m_thrdMutex.unlock();
//    m_thrdMutex.~QMutex();

    return COE_MSGQ_SUCCESS;
}

/*******************************************************************************
 * Name                      : GetErrorMsg
 * Author                    : Sathishkumar K
 * Global Variables affected : NIL
 * Created Date              : Nov 16,2010
 * Revised By                : Manoj L
 * Revision Date             : Jun 20,2020
 * Reason for Revising       : Porting to QT
 ***************************************************************************//**
 * To get the error message for the corresponding error code.
 *
 * \param in_sErrorCode - Error Code to get error message.
 * 	it should be used in this function after initialization (using Init()).
 * \param out_szErrMsgBuf - Pointer to the buffer to store the error message.
 * \param in_uiMaxBufSize - The maximum number of characters the specified buffer (including '\\0' character)
 *
 * \return No return values.
*******************************************************************************/
void CDPMsgQueue::GetErrorMsg(short in_sErrorCode, char * out_szErrMsgBuf, unsigned int in_uiMaxBufSize)
{
    char szErrMsg[50];
    unsigned short uiErrMsgSize = 0;

    switch(in_sErrorCode)
    {
    case COE_MSGQ_SUCCESS:
        strcpy(szErrMsg, "Success.");
        break;
    case COE_MSGQ_FAILURE:
        strcpy(szErrMsg, "Queue Operation Failed.");
        break;
    case COE_MSGQ_ERR_MEM_ALLOC:
        strcpy(szErrMsg, "Invalid Memory Allocation.");
        break;
    case COE_MSGQ_ERR_INVALID_MSG_SIZE:
        strcpy(szErrMsg, "Invalid Message Size.");
        break;
    case COE_MSGQ_ERR_INVALID_MSG_BUFF:
        strcpy(szErrMsg, "Invalid Message Buffer.");
        break;
    case COE_MSGQ_ERR_QUEUE_EMPTY:
        strcpy(szErrMsg, "Queue is Empty.");
        break;
    case COE_MSGQ_ERR_QUEUE_FULL:
        strcpy(szErrMsg, "Queue is Full.");
        break;
    case COE_MSGQ_ERR_SEM_ERR:
        strcpy(szErrMsg, "Semaphore Operation is Failed.");
        break;
    case COE_MSGQ_ERR_TIMEOUT:
        strcpy(szErrMsg, "Timeout Occurred.");
        break;

    default:
        strcpy(szErrMsg, "Invalid Error Code.");
    }
    uiErrMsgSize = strlen(szErrMsg);
    if(in_uiMaxBufSize < uiErrMsgSize)
    {
        uiErrMsgSize = in_uiMaxBufSize;
        szErrMsg[uiErrMsgSize] ='\0';
    }
    strcpy(out_szErrMsgBuf, szErrMsg);
}


/************************************ END OF FILE *****************************/

